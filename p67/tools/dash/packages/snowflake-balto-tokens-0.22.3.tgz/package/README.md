# Balto Tokens

**Themed token library for the Balto Design System.**

@snowflake/balto-tokens is a library that makes available themed color and dimension tokens in multiple formats.

- CSS variables
- Typescript Object (rgba hexadecimal strings)
- Typescript Object of CSS variable names
- Typescript key array of keys used in object representations above

Core-ui and Balto components will use values from these tokens directly and it is preferable to use the default values unless there is a domain specific need to use them directly.

---

## Developer workflow

### Exporting tokens from Figma

The source of truth for tokens are variables in Figma. Each design area has a specific Figma File that houses the tokens relavant to that area.

- [Balto Design System](https://www.figma.com/file/KLjmxtar2Y3T4C4GEJBn9G/Balto-Library?type=design&mode=design&t=e0RCwLDciIspjOvS-0)
- [Balto Illustrations](https://www.figma.com/file/omVqz0lB9E89kBwD5fV8PP/Balto-Illustrations?type=design&node-id=426-17559&mode=design&t=e0RCwLDciIspjOvS-0)

We use the Figma REST API to export files into `./data` subdirectory.

#### Steps to export a JSON file from a Figma file

1. From the relevant Figma file note the `file_key`. usually the path segment immediately after`https://www.figma.com/design/<file_key>/...`
2. Use the [Get Local Variables](https://www.figma.com/developers/api#get-local-variables-endpoint) Figma Rest API

   1. This can be done in the Browser with the `Try it Yourself` section on that page
   2. Generate your personal access token by clicking the link
   3. Enter the file_key from step 1
   4. Submit API Request

3. Copy Paste the response in the correct file in the data sub folder in this repo
4. Update the data file as part of your PR for new tokens.
5. See the Re-generating files section below

### Re-generating files

Run the following command to re-generate files.

```
./packages/tokens/generate-all.sh
```

Once re-generated the files can be updated by raising a PR and following merge and publish from the root of the repo.
