import type { DataRecord } from "@snowflake/stellar-data-tools";
import { createContext, useContext } from "react";

import type { ColumnDefinitionWithId } from "../types";

interface ColumnContextValue<T extends DataRecord = DataRecord> {
  columnDefinition: ColumnDefinitionWithId<T, string>;
}
const defaultColumnState: ColumnContextValue = {
  columnDefinition: {
    id: "never",
    field: "never" as never,
    label: "---",
  },
} as const;

const ColumnContext = createContext<ColumnContextValue>(defaultColumnState);

const useColumnContext = () => {
  const context = useContext(ColumnContext);
  if (context === defaultColumnState) {
    throw new Error(
      "useColumnContext must be used within a ColumnContextProvider",
    );
  }
  return context;
};
export { ColumnContext, useColumnContext };
export type { ColumnContextValue };
