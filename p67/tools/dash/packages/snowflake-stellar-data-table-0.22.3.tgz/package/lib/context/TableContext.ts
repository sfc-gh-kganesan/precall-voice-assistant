import type { DataRecord } from "@snowflake/stellar-data-tools";
import { createContext, useContext } from "react";

import type { TableState } from "../types";

const defaultTableState: TableState<never> = {
  density: "compact",
  column: {},
  pinLeft: [] as never,
  pinRight: [] as never,
  sort: [],
} as const;

const TableContext = createContext(defaultTableState);

const useTableContext = <T extends DataRecord>(): TableState<T> => {
  const context = useContext(TableContext);
  if (context === defaultTableState) {
    throw new Error(
      "useTableContext must be used within a TableContextProvider",
    );
  }
  return context as unknown as TableState<T>;
};
export { TableContext, useTableContext };
