import { createContext, useContext } from "react";

interface RowState<T> {
  rowData: T;
}
const defaultRowState: RowState<null> = {
  rowData: null,
} as const;

const RowContext = createContext(defaultRowState);

const useRowContext = <T>() => {
  const context = useContext(RowContext) as RowState<T>;
  if (context === defaultRowState) {
    throw new Error("useRowContext must be used within a RowContextProvider");
  }
  return context;
};
export { RowContext, useRowContext };
