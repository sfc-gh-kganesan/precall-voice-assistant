import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import * as stylex from "@stylexjs/stylex";

export const cellStyles = stylex.create({
  fontVariantTabularNums: {
    fontVariantNumeric: "tabular-nums",
  },
  textAlignCenter: {
    textAlign: "center",
    justifyContent: "center",
  },
  textAlignEnd: {
    textAlign: "end",
    justifyContent: "flex-end",
  },
  textAlignStart: {
    textAlign: "start",
    justifyContent: "flex-start",
  },
  fontFamilyMono: {
    fontFamily: baltoTheme.fontFamilyMono,
  },
  textWeightBold: {
    fontWeight: baltoTheme.fontWeightBold,
  },
  textWeightSemiBold: {
    fontWeight: baltoTheme.fontWeightSemiBold,
  },
  textWeightMedium: {
    fontWeight: baltoTheme.fontWeightMedium,
  },
  textWeightRegular: {
    fontWeight: baltoTheme.fontWeightRegular,
  },
  textSizeSmall: {
    fontSize: baltoTheme.fontSizeSmall,
  },
  textSizeRegular: {
    fontSize: baltoTheme.fontSizeRegular,
  },
  textSizeLarge: {
    fontSize: baltoTheme.fontSizeLarge,
  },
  textItalic: {
    fontStyle: "italic",
  },
  textUnderline: {
    textDecoration: "underline",
  },
  textStrikeThrough: {
    textDecoration: "line-through",
  },
  cellBackgroundNeutral: {
    backgroundColor: baltoTheme.statusNeutralBackground,
    color: baltoTheme.statusNeutralText,
  },
  cellBackgroundSuccess: {
    backgroundColor: baltoTheme.statusSuccessBackground,
    color: baltoTheme.statusSuccessText,
  },
  cellBackgroundCaution: {
    backgroundColor: baltoTheme.statusCautionBackground,
    color: baltoTheme.statusCautionText,
  },
  cellBackgroundInfo: {
    backgroundColor: baltoTheme.statusInfoBackground,
    color: baltoTheme.statusInfoText,
  },
  cellBackgroundCritical: {
    backgroundColor: baltoTheme.statusCriticalBackground,
    color: baltoTheme.statusCriticalText,
  },
});
