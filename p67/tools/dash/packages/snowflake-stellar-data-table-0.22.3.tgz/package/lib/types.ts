import type { ControlledComponent } from "@snowflake/stellar-components";
import type {
  CellRendererProps,
  DataRecord,
  FieldDefinition,
  FieldFormatter,
} from "@snowflake/stellar-data-tools";
import type {
  CompiledStyles,
  InlineStyles,
  StyleXArray,
} from "@stylexjs/stylex";
import type { ComponentType, HTMLAttributes } from "react";

/**
 * Possible densities for  DataTable.
 */
const densities = ["compact", "regular", "comfortable"] as const;

/**
 * The density of a DataTable.
 */
type Density = (typeof densities)[number];

/**
 * StyleX input type.
 */
type StyleXInput = ReadonlyArray<
  StyleXArray<
    | (null | undefined | CompiledStyles)
    | boolean
    | Readonly<[CompiledStyles, InlineStyles]>
  >
>;

type ColumnDefinitions<T extends DataRecord> = {
  [K in keyof T]: ColumnDefinition<T, K, T[K]>;
}[keyof T];

interface DerivedColumnDefinition<T extends DataRecord, S>
  extends Omit<
    ColumnDefinition<T, never, never>,
    // omit fields that need to be required/never
    "field" | "id" | "renderer" | "accessor" | "formatter"
  > {
  id: string;
  accessor: (row: T) => S;
  renderer: ComponentType<CellRendererProps<S, T>>;
  formatter?: FieldFormatter<S, T> | undefined;
}

type ColumnDefinitionArray<T extends DataRecord> = (
  | ColumnDefinitions<T>
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  | DerivedColumnDefinition<T, any>
)[];
/**
 * Column definition for DataTable.
 */
interface ColumnDefinition<
  T extends DataRecord,
  K extends keyof T,
  S extends T[K] = T[K],
> extends FieldDefinition<T, K, S> {
  /**
   * Whether the column is resizable.
   * default false
   */
  resizable?: boolean | undefined;
  // filterable?: boolean;
  // columns?: ColumnDefinition<T, K>[];
  renderer?: ComponentType<CellRendererProps<S, T>> | undefined;

  /**
   * The width of the column.
   * default auto
   */
  width?: number | "auto" | undefined;
  /**
   * Whether the column will expand to fill the available space.
   * can be used alongside maxWidth and minWidth. setting width to a number will override this.
   * default 1
   */
  flex?: number | undefined;
  /**
   * The minimum width of the column.
   */
  minWidth?: number | undefined;
  /**
   * The maximum width of the
   */
  maxWidth?: number | undefined;

  /**
   * Whether the column is hidden.
   * default false
   */
  hide?: boolean | undefined;
  /**
   * Whether the column is pinned.
   * default false
   */
  pin?: "left" | "right" | undefined;
  /**
   * Styles to be applied to the cell
   */
  cellStyles?:
    | StyleXInput
    | ((props: CellRendererProps<S, T>) => StyleXInput | undefined)
    | undefined;
  headerCellStyles?:
    | StyleXInput
    | ((props: CellRendererProps<S, T>) => StyleXInput | undefined)
    | undefined;
  // tooltip?: string | ((props: CellRendererProps<S, T>) => string) | undefined;

  // tooltipComponent?: ComponentType<CellRendererProps<S, T>> | undefined;
  hideLabel?: boolean | undefined;
  columns?: ColumnDefinitionArray<T> | undefined;
}

interface ColumnDefinitionWithId<
  T extends DataRecord,
  K extends keyof T = keyof T,
> extends ColumnDefinition<T, K> {
  id: string;
}

/**
 * Default column definition for DataTable.
 * omits field specific properties.
 */
type DefaultColumnDefinition<T extends DataRecord> = Omit<
  ColumnDefinition<T, never, never>,
  "field" | "id" | "label"
>;

interface Sort<Z> {
  id: Z;
  desc: boolean;
}
type Visiblity<T extends DataRecord, K extends keyof T = keyof T> = Record<
  K,
  boolean
>;
interface ColumnState {
  /**
   * Whether the column is visible.
   * default true
   */
  visible?: boolean | undefined;
  /**
   * The width of the column.
   * default auto
   */
  width?: number | undefined;
  /**
   * Whether the column is sortable.
   * default false
   */
  sortable?: boolean | undefined;
  /**
   * Whether the column is pinned.
   * default false
   */
  pinned?: "left" | "right" | undefined;
}
interface BaseTableState<T extends DataRecord> {
  density?: Density | undefined;
  column: Record<keyof T, ColumnState>;
  sort: Sort<keyof T>[];
}
interface TableState<T extends DataRecord> extends BaseTableState<T> {
  pinLeft: (keyof T)[];
  pinRight: (keyof T)[];
}
interface RowClickEvent<T> {
  rowData: T;
  event: React.MouseEvent<HTMLDivElement>;
}

interface BaseDataTableProps<T extends DataRecord>
  extends Omit<ControlledComponent<"state", TableState<T>>, "defaultState">,
    HTMLAttributes<HTMLDivElement> {
  isLoading?: boolean | undefined;
  defaultState?: Partial<TableState<T>> | undefined;
  rowData: T[];
  defaultColumnDefinition?: DefaultColumnDefinition<T> | undefined;
  columnDefinition: ColumnDefinitionArray<T>;

  // Event handlers
  onRowClick?: ((event: RowClickEvent<T>) => void) | undefined;
  onScrolledToEnd?: (() => void) | undefined;
  // one off feature flags
  disableUnsortedState?: boolean | undefined;
}

// Variant with density (no rowHeight allowed)
interface DataTablePropsWithDensity<T extends DataRecord>
  extends BaseDataTableProps<T> {
  density?: Density | undefined;
  rowHeight?: never;
}

// Variant with custom rowHeight (no density allowed)
interface DataTablePropsWithRowHeight<T extends DataRecord>
  extends BaseDataTableProps<T> {
  /**
   * Custom row height in pixels. Cannot be used together with density.
   */
  rowHeight: number;
  density?: never;
}

// Union type for DataTableProps
type DataTableProps<T extends DataRecord> =
  | DataTablePropsWithDensity<T>
  | DataTablePropsWithRowHeight<T>;

export type {
  BaseTableState,
  CellRendererProps,
  ColumnDefinition,
  ColumnDefinitions,
  ColumnDefinitionArray,
  ColumnDefinitionWithId,
  ColumnState,
  DataTableProps,
  DefaultColumnDefinition,
  Density,
  RowClickEvent,
  Sort,
  StyleXInput,
  TableState,
  Visiblity,
  DerivedColumnDefinition,
};

export { densities };
