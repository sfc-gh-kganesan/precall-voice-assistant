import { useMergedStyles } from "@snowflake/stellar-components";
import type { DataRecord } from "@snowflake/stellar-data-tools";
import * as stylex from "@stylexjs/stylex";
import { type HTMLAttributes, useMemo } from "react";

import { TableContext } from "../../context/TableContext";
import type { BaseTableState, ColumnState, TableState } from "../../types";

const styles = stylex.create({
  table: {
    borderCollapse: "collapse",
  },
});

interface TableProps<T extends DataRecord>
  extends HTMLAttributes<HTMLDivElement>,
    Partial<BaseTableState<T>> {}

const Table = <T extends DataRecord>(props: TableProps<T>) => {
  const {
    style,
    className,
    density = "regular",
    column = {},
    sort = [],
    ...otherProps
  } = props;
  const styleProps = useMergedStyles(
    className,
    style,
    stylex.props(styles.table),
  );
  const state = useMemo(
    (): TableState<T> => ({
      density,
      column: column as Record<keyof T, ColumnState>,
      sort,
      pinLeft: [] as never,
      pinRight: [] as never,
    }),
    [density, column, sort],
  );
  return (
    <TableContext.Provider value={state as never}>
      <div {...otherProps} {...styleProps} />
    </TableContext.Provider>
  );
};

export { Table };
export type { TableProps };
