import { DragPreview, useDrag } from "@react-aria/dnd";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { baseDimension } from "@snowflake/balto-themes/baseDimension.stylex.js";
import {
  Flex,
  Tooltip,
  useMergedStyles,
  useTextStyles,
} from "@snowflake/stellar-components";
import {
  ArrowDownIcon,
  ArrowUpIcon,
  IconContextProvider,
  InfoCircleSmallIcon,
} from "@snowflake/stellar-icons";
import { tokens } from "@snowflake/stellar-tokens/tokens.stylex";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";
import { useCallback, useMemo, useRef } from "react";

import { cellStyles } from "./cellStyles";
import { useTableContext } from "../../context/TableContext";
import type { ColumnState, StyleXInput } from "../../types";

interface TableHeadCellProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The id of the column.
   */
  columnId?: string | undefined;
  /**
   * The callback function to handle the sort change.
   */
  onSortChange?: ((columnId: string) => void) | undefined;
  /**
   * The width of the cell.
   */
  width?: number | null | "auto" | "min-content" | "max-content" | undefined;
  /**
   * Whether the cell is sortable.
   */
  sortable?: boolean | undefined;
  /**
   * The text to display in the cell.
   */
  text?: string | null | undefined;
  /**
   * The description of the column.
   */
  description?: string | undefined;
  // columnIndex: number;
  /**
   * style overrides
   */
  styleOverrides?: StyleXInput | undefined;
  /**
   * hide column label
   */
  hideLabel?: boolean | undefined;
  /**
   * Whether the column is resizable.
   * default false
   */
  isResizable?: boolean | undefined;
  /**
   * The callback function to update column width.
   */
  onResizeChange?: ((columnId: string, delta: number) => void) | undefined;
}

const styles = stylex.create({
  headTextAdditionalStyles: {
    overflow: "hidden",
    textOverflow: "ellipsis",
    textTransform: "uppercase",
  },
  headControls: {
    opacity: 0.2,
    transition: "opacity 0.1s ease-in-out",
  },
  headControlsHover: {
    opacity: 1,
  },
  sortButton: {
    opacity: {
      default: 0.2,
      ":hover": 1,
      ":focus": 1,
    },
    // outline: "none",
  },
  sortButtonSelected: {
    color: {
      default: baltoTheme.reusableSelectedUi,
      ":hover": baltoTheme.reusableSelectedUi,
      ":focus": baltoTheme.reusableSelectedUi,
    },
    opacity: 1,
  },
  tableCellWithControls: {},
  sortEnabled: {
    cursor: "pointer",
  },
  hideLabel: {
    height: "1px",
    left: "-10000px",
    overflow: "hidden",
    position: "absolute",
    top: "-10000px",
    width: "1px",
  },
  ghostButton: {
    backgroundColor: "transparent",
    backgroundImage: "none",
    borderColor: "inherit",
    borderRadius: tokens["radius-sm"],
    borderStyle: "none",
    borderWidth: "0px",
    color: "inherit",
    cursor: "pointer",
    font: "inherit",
    outlineColor: {
      ":focus-visible": baltoTheme.reusableBorderFocusedActiveItem,
    },
    outlineStyle: { ":focus-visible": "solid" },
    outlineWidth: {
      default: "0px",
      ":focus-visible": "2px",
    },
    padding: "0px",
  },
  headCell: {
    userSelect: "none",
  },
  resizeHandle: {
    bottom: 0,
    cursor: "ew-resize",
    height: "2em",
    margin: "auto",
    position: "absolute",
    right: 0,
    top: 0,
    width: tokens["size-2xs"],
  },

  resizeIndicator: {
    backgroundColor: {
      default: baltoTheme.reusableBorderDefault,
      ":hover": baltoTheme.reusableBorderActive,
    },
    borderRadius: tokens["radius-md"],
    content: "",
    display: "block",
    height: "100%",
    left: "50%",
    position: "absolute",
    width: baseDimension.spacing_0_25x,
  },
  draggingIndicator: {
    backgroundColor: baltoTheme.reusableBorderActive,
  },
  draggingIndicatorPosition: {
    position: "absolute",
    top: "-50%",
  },
  notDraggingIndicator: {
    backgroundColor: {
      default: baltoTheme.reusableBorderDefault,
      ":hover": baltoTheme.reusableBorderActive,
    },
  },
  dragging: {
    zIndex: 1000,
  },
  notDragging: {
    zIndex: 1,
  },
});

const TableHeadCell = (props: TableHeadCellProps) => {
  const {
    children,
    className,
    columnId,
    onSortChange,
    sortable = false,
    style,
    width = null,
    styleOverrides,
    text,
    hideLabel,
    description,
    isResizable = false,
    onResizeChange,
    ...otherProps
  } = props;
  const { column, density, sort } = useTableContext();
  const myColumn = column[columnId as keyof typeof column] as ColumnState;
  const sorted = useMemo(
    () => sort?.find((sort) => sort.id === columnId),
    [sort, columnId],
  );
  const textStyles = useTextStyles({
    size: "small",
    weight: "medium",
  });

  const dragStartRef = useRef<number>(-1);
  const preview = useRef(null);

  const { dragProps, isDragging } = useDrag({
    onDragStart: (e) => {
      dragStartRef.current = e.x;
    },
    preview: preview,
    onDragEnd: (e) => {
      if (dragStartRef.current !== -1 && columnId && onResizeChange) {
        const dragEnd = e.x;
        const dragDistance = dragEnd - dragStartRef.current;
        onResizeChange(columnId, dragDistance);
      }
      dragStartRef.current = -1;
    },
    getAllowedDropOperations: () => ["move"],

    getItems: () => {
      return [
        {
          "text/plain": "hello world",
        },
      ];
    },
  });

  const showControls = sortable || myColumn?.sortable || sorted;
  const controlsWidth = showControls ? 16 : 0;
  const headingTextStyles = stylex.props(
    textStyles,
    styles.headTextAdditionalStyles,
    sorted && styles.sortButtonSelected,

    // width from prop
    width === "auto" ? cellStyles.autoWidth : null,
    width === "min-content" ? cellStyles.minContentWidth : null,
    width === "max-content" ? cellStyles.maxContentWidth : null,
    Number(width)
      ? cellStyles.fixedMaxWidth(Number(width) - controlsWidth - 8)
      : null,
    // width from column context
    !width && myColumn?.width
      ? cellStyles.fixedMaxWidth(myColumn.width - controlsWidth - 8)
      : null,
    text ? cellStyles.tableCellText : null,
    hideLabel ? styles.hideLabel : null,
  );
  const sortEnabled = useMemo(() => {
    return sortable || myColumn?.sortable || sorted;
  }, [sortable, myColumn?.sortable, sorted]);
  const styleProps = useMergedStyles(
    className,
    style,
    stylex.props(
      styles.headCell,
      textStyles,
      sorted && styles.sortButtonSelected,
      cellStyles.tableCell,
      !density || density === "regular" ? cellStyles.regular : null,
      density === "compact" ? cellStyles.compact : null,
      density === "comfortable" ? cellStyles.comfortable : null,
      // width from prop
      width === "auto" ? cellStyles.autoWidth : null,
      width === "min-content" ? cellStyles.minContentWidth : null,
      width === "max-content" ? cellStyles.maxContentWidth : null,
      Number(width) ? cellStyles.fixedWidth(Number(width)) : null,
      // width from column context
      !width && myColumn?.width ? cellStyles.fixedWidth(myColumn.width) : null,

      showControls ? styles.tableCellWithControls : null,
      sortEnabled ? styles.sortEnabled : null,
      styleOverrides,
    ),
  );
  const onSortChangeInternal = useCallback(() => {
    if (sortEnabled && columnId) {
      onSortChange?.(columnId);
    }
  }, [sortEnabled, onSortChange, columnId]);

  return (
    <Flex
      {...otherProps}
      {...styleProps}
      // tabIndex={sortEnabled ? 0 : -1}
      onClick={onSortChangeInternal}
      align="center"
      // required for firing onDragEnd immediately after button is released
      // may need to move this when re-ordering is supported
      onDragOver={(e) => e.preventDefault()}
    >
      {description ? (
        <IconContextProvider color="currentColor">
          <Tooltip text={description}>
            <Flex
              gap="0_25x"
              direction="row"
              align="center"
              justify="center"
              onClick={onSortChangeInternal}
              {...headingTextStyles}
            >
              {text || children}
              <InfoCircleSmallIcon />
            </Flex>
          </Tooltip>
        </IconContextProvider>
      ) : (
        <div onClick={onSortChangeInternal} {...headingTextStyles}>
          {text || children}
        </div>
      )}

      {sortEnabled && (
        <Flex
          asChild
          direction="row"
          align="center"
          {...stylex.props(
            styles.headControls,
            sorted && styles.headControlsHover,
          )}
        >
          <button
            role="button"
            {...stylex.props(styles.ghostButton)}
            aria-label="Sort"
          >
            <IconContextProvider size="16px" color="currentColor">
              {sorted?.desc === true ? <ArrowDownIcon /> : <ArrowUpIcon />}
            </IconContextProvider>
          </button>
        </Flex>
      )}
      {isResizable && (
        <>
          <div
            {...stylex.props(styles.resizeHandle)}
            {...dragProps}
            role="separator"
            aria-valuenow={myColumn?.width}
            aria-orientation="vertical"
            aria-label={`Resize ${text || "column"}`}
            tabIndex={0}
          >
            <div
              {...stylex.props(
                styles.resizeIndicator,
                isDragging
                  ? styles.draggingIndicator
                  : styles.notDraggingIndicator,
              )}
            />
          </div>
          <DragPreview ref={preview}>
            {(_items) => (
              <div {...stylex.props(styles.resizeHandle)}>
                <div
                  {...stylex.props(
                    styles.resizeIndicator,
                    styles.draggingIndicator,
                    styles.draggingIndicatorPosition,
                  )}
                />
              </div>
            )}
          </DragPreview>
        </>
      )}
    </Flex>
  );
};

export { TableHeadCell };
export type { TableHeadCellProps };
