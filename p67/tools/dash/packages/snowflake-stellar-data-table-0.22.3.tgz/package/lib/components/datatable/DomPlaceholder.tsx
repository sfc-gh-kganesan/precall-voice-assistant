import * as stylex from "@stylexjs/stylex";

import { dataTableStyles } from "./styles";

const placeholderStyle = stylex.create({
  root: {
    left: 0,
    minHeight: 1,
    minWidth: 1,
    position: "absolute",
    top: 0,
    visibility: "hidden",
    zIndex: -1,
  },
});

const DomPlaceholder = (props: {
  /**
   * The height of the placeholder.
   */
  height?: number | undefined;
  /**
   * The width of the placeholder.
   */
  width?: number | undefined;
  /**
   * The style of the placeholder.
   */
  style?: React.CSSProperties | undefined;
}) => {
  const { height, width } = props;
  return (
    <div
      {...stylex.props(
        height ? dataTableStyles.fixHeight(height) : undefined,
        width ? dataTableStyles.fixWidth(width) : undefined,
        placeholderStyle.root,
      )}
      role="presentation"
    />
  );
};

export { DomPlaceholder };
