import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useMergedStyles } from "@snowflake/stellar-components";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";

interface TableFootProps extends HTMLAttributes<HTMLTableSectionElement> {
  /**
   * The alignment of the cell content.
   */
  align?: "left" | "center" | "right" | undefined;
}
const styles = stylex.create({
  tableHead: {
    color: baltoTheme.reusableTextSecondary,
  },
});
const TableFoot = ({ style, className, ...otherProps }: TableFootProps) => {
  const styleProps = useMergedStyles(
    className,
    style,
    stylex.props(styles.tableHead),
  );
  return <div {...otherProps} {...styleProps} />;
};

export { TableFoot };
export type { TableFootProps };
