import type { DataRecord } from "@snowflake/stellar-data-tools";
import * as stylex from "@stylexjs/stylex";
import type { Header, HeaderGroup } from "@tanstack/react-table";
import type { HTMLAttributes } from "react";
import { useMemo } from "react";

import { dataTableStyles } from "./styles";
import { ColumnContext } from "../../context/ColumnContext";
import { useTableContext } from "../../context/TableContext";
import type { ColumnDefinitionWithId } from "../../types";
import { TableHeadCell } from "../table/TableHeadCell";
import { TableRow } from "../table/TableRow";

/**
 * The component that renders the header group.
 */
function RenderHeaderGroup<T extends DataRecord>(props: {
  /**
   * The header group.
   */
  headerGroup: HeaderGroup<T>;
  /**
   * The column definitions by id.
   */
  columnDefinitionsById: Record<string, ColumnDefinitionWithId<T, keyof T>>;
  /**
   * The callback function to update the sort.
   */
  onSortChange: (columnId: string) => void;
  /**
   * The callback function to update column width.
   */
  onResizeChange: (columnId: string, delta: number) => void;
  /**
   * The width of the cell.
   */
  cellWidth?: "auto" | "min-content" | "max-content" | undefined;
}) {
  const {
    headerGroup,
    columnDefinitionsById,
    onSortChange,
    cellWidth,
    onResizeChange,
  } = props;
  const { column } = useTableContext();

  const minRowWidth = useMemo(() => {
    return headerGroup.headers
      .map((header) => header.column.id)
      .filter((col) => column[col]?.visible)
      .reduce((acc, col) => {
        return acc + (column[col]?.width ?? 0);
      }, 0);
  }, [column, headerGroup]);

  return (
    <TableRow
      key={headerGroup.id}
      role="row"
      {...stylex.props(
        dataTableStyles.tableRow,
        dataTableStyles.fixMinWidth(minRowWidth),
      )}
    >
      {headerGroup.headers.map((header) => (
        <RenderHeaderCell
          key={header.id}
          aria-colindex={header.column.getIndex() + 1}
          header={header}
          columnDefinitionsById={columnDefinitionsById}
          onResizeChange={onResizeChange}
          onSortChange={onSortChange}
          cellWidth={cellWidth}
        />
      ))}
    </TableRow>
  );
}

interface RenderHeaderCellProps<T extends DataRecord>
  extends HTMLAttributes<HTMLDivElement> {
  /**
   *
   */
  header: Header<T, unknown>;
  /**
   *
   */
  columnDefinitionsById: Record<string, ColumnDefinitionWithId<T, keyof T>>;
  /**
   *
   */
  onSortChange: (columnId: string) => void;
  /**
   *
   */
  onResizeChange: (columnId: string, delta: number) => void;
  /**
   *
   */
  cellWidth?: "auto" | "min-content" | "max-content" | undefined;
}
/**
 *
 */
function RenderHeaderCell<T extends DataRecord>(
  props: RenderHeaderCellProps<T>,
) {
  const {
    columnDefinitionsById,
    header,
    onSortChange,
    cellWidth,
    onResizeChange,
    ...otherProps
  } = props;
  const columnDefinition = columnDefinitionsById[
    header.column.id
  ] as ColumnDefinitionWithId<Record<string, unknown>, string>;
  const cellProps = useMemo(
    () => ({ fieldDefinition: columnDefinition }),
    [columnDefinition],
  );
  const { sort } = useTableContext();
  const sorted = useMemo(
    () => sort?.find((sort) => sort.id === header.column.id),
    [sort, header.column.id],
  );

  const isResizable = useMemo(
    () =>
      columnDefinition?.resizable &&
      typeof columnDefinition?.width !== "number",
    [columnDefinition?.resizable, columnDefinition?.width],
  );

  const headerCellStyles = useMemo(() => {
    return typeof columnDefinition?.headerCellStyles === "function"
      ? columnDefinition?.headerCellStyles(cellProps)
      : Array.isArray(columnDefinition?.headerCellStyles)
        ? columnDefinition?.headerCellStyles
        : undefined;
  }, [columnDefinition, cellProps]);

  if (!columnDefinition) {
    return null;
  }

  return (
    <ColumnContext.Provider
      value={{
        columnDefinition,
      }}
      key={header.id}
    >
      <TableHeadCell
        key={header.id}
        columnId={header.column.id}
        onSortChange={onSortChange}
        role="columnheader"
        aria-sort={
          !sorted
            ? undefined
            : sorted.desc === true
              ? "descending"
              : "ascending"
        }
        width={cellWidth}
        text={header.column.columnDef.header?.toString() ?? ""}
        description={columnDefinition.description}
        styleOverrides={headerCellStyles}
        hideLabel={columnDefinition.hideLabel}
        isResizable={isResizable}
        onResizeChange={onResizeChange}
        {...otherProps}
      />
    </ColumnContext.Provider>
  );
}
/**
 * The component that renders the header.
 */
function RenderHeader<T extends DataRecord>(props: {
  /**
   * The header groups.
   */
  headerGroups: HeaderGroup<T>[];
  /**
   * The callback function to update the sort.
   */
  onSortChange: (columnId: string) => void;
  /**
   * The callback function to update column width.
   */
  onResizeChange: (columnId: string, delta: number) => void;
  /**
   * The column definitions by id.
   */
  columnDefinitionsById: Record<string, ColumnDefinitionWithId<T>>;
  /**
   * The width of the cell.
   */
  cellWidth?: "auto" | "min-content" | "max-content" | undefined;
}) {
  const {
    headerGroups,
    columnDefinitionsById,
    onSortChange,
    cellWidth,
    onResizeChange,
  } = props;
  return (
    <>
      {headerGroups.map((headerGroup) => (
        <RenderHeaderGroup
          key={headerGroup.id}
          headerGroup={headerGroup}
          columnDefinitionsById={columnDefinitionsById}
          onResizeChange={onResizeChange}
          onSortChange={onSortChange}
          cellWidth={cellWidth}
        />
      ))}
    </>
  );
}

export { RenderHeader };
