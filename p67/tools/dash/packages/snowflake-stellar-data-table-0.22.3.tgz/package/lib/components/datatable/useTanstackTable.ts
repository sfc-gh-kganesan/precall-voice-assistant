import type { DataRecord } from "@snowflake/stellar-data-tools";
import {
  createColumnHelper,
  getCoreRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";
import type {
  ColumnDef,
  ColumnDefBase,
  ColumnOrderState,
  ColumnPinningState,
  DisplayColumnDef,
  IdIdentifier,
  Row,
  SortingState,
  TableState as TanstackTableState,
} from "@tanstack/react-table";
import { useMemo } from "react";

import type { ColumnDefinitionWithId, TableState } from "../../types";

interface TanStackTableProps<T extends DataRecord> {
  data: readonly T[];
  columnDefinitionsWithId: ColumnDefinitionWithId<T>[];
  state: TableState<T>;
}
const useTanStackTable = <T extends DataRecord>(
  props: TanStackTableProps<T>,
) => {
  const { data, columnDefinitionsWithId, state } = props;
  const columnHelper = useMemo(() => createColumnHelper<T>(), []);
  const columns = useMemo((): ColumnDef<T, T[keyof T]>[] => {
    if (columnDefinitionsWithId.length > 0) {
      return columnDefinitionsWithId
        .filter((def) => !def.hide)
        .map((def) => {
          const inferred: IdIdentifier<T, keyof T> &
            ColumnDefBase<T, T[keyof T]> &
            DisplayColumnDef<T, T[keyof T]> = {
            id: def.id,
            header: def.label,
            size: def.width as number,
          };
          if (def && def.compareFn) {
            const fn = def.compareFn;
            inferred.sortingFn = (
              rowA: Row<T>,
              rowB: Row<T>,
              columnId: string,
            ) =>
              fn(
                rowA.getValue(columnId),
                rowB.getValue(columnId),
                rowA.original,
                rowB.original,
              );
          }
          return columnHelper.accessor(
            def.accessor ?? ((data: T) => data[def.field]),
            inferred,
          );
        });
    } else return [];
  }, [columnDefinitionsWithId, columnHelper]);

  const columnOrder = useMemo(
    (): ColumnOrderState => columnDefinitionsWithId.map((def) => def.id),
    [columnDefinitionsWithId],
  );
  const columnPinning = useMemo((): ColumnPinningState => {
    return {
      left: state.pinLeft as unknown as string[],
      right: state.pinRight as unknown as string[],
    };
  }, [state.pinLeft, state.pinRight]);
  const columnVisibility = useMemo((): Record<string, boolean> => {
    return columnOrder.reduce(
      (acc, id) => {
        acc[id] = !!state.column[id as keyof T].visible;
        return acc;
      },
      {} as Record<string, boolean>,
    );
  }, [state.column, columnOrder]);
  const tanStackState = useMemo((): TanstackTableState => {
    return {
      sorting: state.sort as SortingState,
      columnVisibility,
      columnOrder,
      columnPinning,
      rowPinning: {},
      globalFilter: undefined,
      grouping: [],
      expanded: {},
      columnSizing: {},
      columnFilters: [],
      rowSelection: {},
      columnSizingInfo: {
        columnSizingStart: [],
        deltaOffset: null,
        deltaPercentage: null,
        isResizingColumn: "",
        startOffset: null,
        startSize: null,
      },
      pagination: {
        pageIndex: 0,
        pageSize: 10,
      },
    };
  }, [state.sort, columnOrder, columnPinning, columnVisibility]);
  const table = useReactTable<T>({
    columns,
    data: data as T[],
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    state: tanStackState,
  });
  return table;
};

export { useTanStackTable };
