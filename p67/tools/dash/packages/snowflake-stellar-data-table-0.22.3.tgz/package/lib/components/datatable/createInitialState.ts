import type { DataRecord } from "@snowflake/stellar-data-tools";

import type {
  ColumnDefinitionWithId,
  ColumnState,
  Density,
  Sort,
  TableState,
} from "../../types";

const createInitialState = <T extends DataRecord>(props: {
  columnDefinition: Record<string, ColumnDefinitionWithId<T>>;
  defaultState?: Partial<TableState<T>>;
  density?: Density;
  rowHeight?: number;
}): TableState<T> => {
  const { columnDefinition, defaultState, density, rowHeight } = props;
  const pinLeft: (keyof T)[] = [];
  const pinRight: (keyof T)[] = [];
  const sort: Sort<keyof T>[] = defaultState?.sort ?? [];
  const column = Object.keys(columnDefinition).reduce(
    (acc, key) => {
      const def = columnDefinition[key];
      if (!def) {
        return acc;
      }
      const val: ColumnState = {
        sortable: def.sortable,
        width: def.width === "auto" ? undefined : (def.width ?? 32),
        visible: !def.hide,
        pinned: def.pin,
      };
      if (def.pin === "left") {
        pinLeft.push(key);
      } else if (def.pin === "right") {
        pinRight.push(key);
      }
      acc[key as keyof T] = val;
      return acc;
    },
    {} as Record<keyof T, ColumnState>,
  );
  return {
    density: rowHeight
      ? undefined
      : (density ?? defaultState?.density ?? "regular"),
    column,
    sort,
    pinLeft,
    pinRight,
  };
};

export { createInitialState };
