import { useMergedStyles } from "@snowflake/stellar-components";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";
interface TableBodyProps extends HTMLAttributes<HTMLTableSectionElement> {
  /**
   * The alignment of the cell content.
   */
  align?: "left" | "center" | "right" | undefined;
}
const TableBody = ({ style, className, ...otherProps }: TableBodyProps) => {
  const styleProps = useMergedStyles(className, style, stylex.props());
  return <div {...otherProps} {...styleProps} />;
};

export { TableBody };
export type { TableBodyProps };
