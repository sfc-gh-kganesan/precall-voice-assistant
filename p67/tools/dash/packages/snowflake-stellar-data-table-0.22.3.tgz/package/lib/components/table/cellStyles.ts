import { tokens } from "@snowflake/stellar-tokens/tokens.stylex";
import * as stylex from "@stylexjs/stylex";

const cellStyles = stylex.create({
  tableCell: {
    alignItems: "center",
    overflow: "hidden",
    alignContent: "center",

    paddingInlineEnd: {
      default: tokens["space-horizontal-sm"],
    },
    paddingInlineStart: {
      default: tokens["space-horizontal-sm"],
    },
    position: "relative",
  },
  tableCellText: {
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  compact: {
    height: tokens["size-md"],
    lineHeight: tokens["size-md"],
    paddingInlineEnd: {
      default: tokens["space-horizontal-xs"],
    },
    paddingInlineStart: {
      default: tokens["space-horizontal-xs"],
    },
  },
  regular: {
    height: tokens["size-lg"],
    lineHeight: tokens["size-lg"],
    paddingInlineEnd: {
      default: tokens["space-horizontal-sm"],
    },
    paddingInlineStart: {
      default: tokens["space-horizontal-sm"],
    },
  },
  comfortable: {
    height: tokens["size-xl"],
    lineHeight: tokens["size-xl"],
    paddingInlineEnd: {
      default: tokens["space-horizontal-sm"],
    },
    paddingInlineStart: {
      default: tokens["space-horizontal-sm"],
    },
  },

  autoWidth: {
    width: "auto",
  },
  minContentWidth: {
    width: "min-content",
  },
  maxContentWidth: {
    width: "max-content",
  },
  fixedWidth: (width: number) => ({
    width,
  }),
  fixedMaxWidth: (width: number) => ({
    maxWidth: width,
  }),
  loadingCellWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    flexBasis: "auto",
  },
});
export { cellStyles };
