import { useLatest, useMergedStyles } from "@snowflake/stellar-components";
import type { DataRecord } from "@snowflake/stellar-data-tools";
import * as stylex from "@stylexjs/stylex";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import type { ColumnMeterApi, ContentRect } from "./ColumnMeter";
import { ColumnMeter } from "./ColumnMeter";
import { rowHeights } from "./constants";
import { DomPlaceholder } from "./DomPlaceholder";
import { HoveredTableRow } from "./hovered-row-context";
import { RenderHeader } from "./RenderHeader";
import { RenderRows } from "./RenderRows";
import { dataTableStyles } from "./styles";
import type { DataTableHookProps } from "./useDataTable";
import { useDataTable } from "./useDataTable";
import { TableContext } from "../../context/TableContext";
import { useScrollbarSize } from "../../hook/useScrollbarSize";
import type { ScrollBarHandle } from "../../parts/ScrollBar";
import { ScrollBar } from "../../parts/ScrollBar";
import type { ColumnState, DataTableProps, RowClickEvent } from "../../types";
const BUFFER = 3;
const FALLBACK_RESIZABLE_WIDTH = 200;
const MIN_RESIZABLE_WIDTH = 50;
/**
 * The component that renders the data table.
 */
function DataTable<T extends DataRecord>(props: DataTableProps<T>) {
  const {
    // will re-render when this changes
    className,
    columnDefinition: columnDefinitionFromProps,
    defaultColumnDefinition: defaultColumnDefinitionFromProps,
    density: densityFromProps,
    isLoading,
    onStateChange: onStateChangeFromProps,
    rowData: rowDataFromProps,
    rowHeight: rowHeightFromProps,
    state: stateFromProps,
    style,
    // will not re-render when this changes
    defaultState: defaultStateFromProps,
    onRowClick: onRowClickFromProps,
    onScrolledToEnd: onScrolledToEndFromProps,
    disableUnsortedState,

    ...otherProps
  } = props;
  const styleProps = useMergedStyles(
    className,
    style,
    stylex.props(dataTableStyles.root),
  );
  const onRowClick = useLatest(onRowClickFromProps);
  const onScrolledToEnd = useLatest(onScrolledToEndFromProps);
  const hasRowClick = useMemo(
    () => onRowClickFromProps !== undefined,
    [onRowClickFromProps],
  );
  const defaultState = useLatest(defaultStateFromProps);
  const [hoveredRowId, setHoveredRowId] = useState<string | undefined>(
    undefined,
  );
  const hoveredRowContextValue = useMemo(
    () => ({
      hoveredRowId,
      onRowHover: setHoveredRowId,
    }),
    [hoveredRowId],
  );

  const horizScrollRef = useRef<ScrollBarHandle>(null);
  const vertScrollRef = useRef<ScrollBarHandle>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const contentLeftRef = useRef<HTMLDivElement>(null);
  const contentRightRef = useRef<HTMLDivElement>(null);
  const centerHeaderRef = useRef<HTMLDivElement>(null);

  const columnMeterRef = useRef<ColumnMeterApi>(null);

  const [isCalculatingWidths, setIsCalculatingWidths] = useState(true);

  const scrollbarMeasurements = useScrollbarSize();

  const updateScrollX = useCallback((x: number) => {
    if (contentRef.current) {
      contentRef.current.scrollLeft = x;
    }
    if (centerHeaderRef.current) {
      centerHeaderRef.current.scrollLeft = x;
    }
  }, []);

  const newProps = useMemo((): DataTableHookProps<T> => {
    const baseProps = {
      rowData: rowDataFromProps,
      defaultColumnDefinition: defaultColumnDefinitionFromProps,
      columnDefinition: columnDefinitionFromProps,
      getScrollElement: () => contentRef.current,
      state: stateFromProps,
      onStateChange: onStateChangeFromProps,
      defaultState: defaultState.current,
      isLoading,
    };

    if (rowHeightFromProps !== undefined) {
      return {
        ...baseProps,
        rowHeight: rowHeightFromProps,
      };
    }

    return {
      ...baseProps,
      density: densityFromProps,
    };
  }, [
    columnDefinitionFromProps,
    defaultColumnDefinitionFromProps,
    defaultState,
    densityFromProps,
    onStateChangeFromProps,
    rowDataFromProps,
    rowHeightFromProps,
    stateFromProps,
    isLoading,
  ]);
  const {
    state,
    vRow,
    totalSize,
    rows,
    sampleRows,
    columnDefinitionsById,
    onStateChange,
    rowHeight,
    headerGroups,
    visibleLeafColumns,
  } = useDataTable(newProps);

  // Header height should use regular density when custom rowHeight is specified,
  // otherwise use the same height as rows (for density presets)
  const headerHeight = useMemo(() => {
    return rowHeightFromProps !== undefined ? rowHeights.regular : rowHeight;
  }, [rowHeightFromProps, rowHeight]);

  const minLeftWidth = useMemo(() => {
    return Object.entries(state.column)
      .filter(
        ([id, col]) =>
          (col as ColumnState)?.visible &&
          visibleLeafColumns.left.find((c) => c.id === id),
      )
      .reduce((acc, [_id, col]) => {
        return acc + ((col as ColumnState)?.width ?? 0);
      }, 0);
  }, [state.column, visibleLeafColumns.left]);

  const minRightWidth = useMemo(() => {
    return Object.entries(state.column)
      .filter(
        ([id, col]) =>
          (col as ColumnState)?.visible &&
          visibleLeafColumns.right.find((c) => c.id === id),
      )
      .reduce((acc, [_id, col]) => {
        return acc + ((col as ColumnState)?.width ?? 0);
      }, 0);
  }, [state.column, visibleLeafColumns.right]);

  const minCenterWidth = useMemo(() => {
    return Object.entries(state.column)
      .filter(
        ([id, col]) =>
          (col as ColumnState)?.visible &&
          visibleLeafColumns.center.find((c) => c.id === id),
      )
      .reduce((acc, [_id, col]) => {
        return acc + ((col as ColumnState)?.width ?? 0);
      }, 0);
  }, [state.column, visibleLeafColumns.center]);
  const [contentRect, setContentRect] = useState<ContentRect | null>(null);
  const hasVerticalScroll = useMemo(
    () => contentRect && totalSize > contentRect.height,
    [contentRect, totalSize],
  );
  const hasHorizontalScroll = useMemo(
    () => contentRect && minCenterWidth > contentRect.width,
    [contentRect, minCenterWidth],
  );
  const updateScrollY = useCallback(
    (y: number) => {
      if (contentRect && y > totalSize - 2 * contentRect.height) {
        onScrolledToEnd.current?.();
      }
      if (contentRef.current) {
        contentRef.current.scrollTop = y;
      }
      if (contentLeftRef.current) {
        contentLeftRef.current.scrollTop = y;
      }
      if (contentRightRef.current) {
        contentRightRef.current.scrollTop = y;
      }
    },
    [contentRect, onScrolledToEnd, totalSize],
  );
  const updateColumnWidths = useCallback(() => {
    if (columnMeterRef.current) {
      const widths = columnMeterRef.current.getColumnWidths();
      const newWidthColumns = widths.reduce(
        (acc, c) => {
          const colState = state.column[c.id];
          if (colState) {
            if (colState.width !== c.width) {
              acc[c.id] = {
                ...colState,
                width: Math.floor(c.width),
              };
            }
          }
          return acc;
        },
        {} as Record<string, ColumnState>,
      );
      onStateChange({
        ...state,
        column: {
          ...state.column,
          ...newWidthColumns,
        },
      });

      setIsCalculatingWidths(false);
    }
  }, [onStateChange, state]);

  const onSortChange = useCallback(
    (columnId: string) => {
      const current = state.sort.find((s) => s.id === columnId);

      if (disableUnsortedState) {
        onStateChange({
          ...state,
          sort: [{ id: columnId, desc: current ? !current.desc : false }],
        });
      } else {
        if (!current) {
          // if no sort, set to ascending
          onStateChange({
            ...state,
            sort: [{ id: columnId, desc: false }],
          });
        } else if (!current.desc) {
          // if ascending, set to descending
          onStateChange({
            ...state,
            sort: [{ id: columnId, desc: true }],
          });
        } else {
          // else clear sort
          onStateChange({
            ...state,
            sort: [],
          });
        }
      }
    },
    [onStateChange, state, disableUnsortedState],
  );

  const onResizeChange = useCallback(
    (columnId: string, delta: number) => {
      const currentColumn = state.column[columnId as keyof typeof state.column];
      const currentWidth = currentColumn?.width ?? FALLBACK_RESIZABLE_WIDTH;
      const newWidth = Math.max(MIN_RESIZABLE_WIDTH, currentWidth + delta);

      onStateChange({
        ...state,
        column: {
          ...state.column,
          [columnId]: {
            ...currentColumn,
            width: newWidth,
          },
        },
      });
    },
    [onStateChange, state],
  );

  useEffect(() => {
    // This effect is needed since React does not support setting passive: false on the wheel event
    // https://github.com/facebook/react/issues/22794
    const contentEl = contentRef.current;
    const centerHeader = centerHeaderRef.current;
    const leftSection = contentLeftRef.current;
    const rightSection = contentRightRef.current;
    const updateScroll = (e: WheelEvent) => {
      if (hasVerticalScroll || hasHorizontalScroll) {
        e.preventDefault();
      }
      if (contentRef.current) {
        if (vertScrollRef.current) {
          vertScrollRef.current.scrollDelta(e.deltaX, e.deltaY);
        }
        if (horizScrollRef.current) {
          horizScrollRef.current.scrollDelta(e.deltaX, e.deltaY);
        }
      }
    };
    if (contentEl) {
      contentEl.addEventListener("wheel", updateScroll, { passive: false });
    }
    if (centerHeader) {
      centerHeader.addEventListener("wheel", updateScroll, { passive: false });
    }
    if (leftSection) {
      leftSection.addEventListener("wheel", updateScroll, { passive: false });
    }
    if (rightSection) {
      rightSection.addEventListener("wheel", updateScroll, { passive: false });
    }
    return () => {
      if (contentEl) {
        contentEl.removeEventListener("wheel", updateScroll);
      }
      if (centerHeader) {
        centerHeader.removeEventListener("wheel", updateScroll);
      }
      if (leftSection) {
        leftSection.removeEventListener("wheel", updateScroll);
      }
      if (rightSection) {
        rightSection.removeEventListener("wheel", updateScroll);
      }
    };
  }, [hasHorizontalScroll, hasVerticalScroll]);

  return (
    <HoveredTableRow.Provider value={hoveredRowContextValue}>
      <TableContext.Provider value={state as never}>
        <div
          {...otherProps}
          {...styleProps}
          style={{ visibility: isCalculatingWidths ? "hidden" : "visible" }}
          role="grid"
        >
          <ColumnMeter
            rows={sampleRows}
            ref={columnMeterRef}
            onContentRectChange={setContentRect}
            columnDefinitionsById={columnDefinitionsById}
            headerGroups={headerGroups}
            visibleLeafColumns={visibleLeafColumns}
            onUpdate={updateColumnWidths}
          />
          {visibleLeafColumns.left.length > 0 && (
            <div
              {...stylex.props(
                dataTableStyles.headerForLeft,
                dataTableStyles.fixHeight(headerHeight),
                dataTableStyles.leftSectionBorder,
                contentRef.current && contentRef.current.scrollLeft > BUFFER
                  ? dataTableStyles.leftSectionBorderVisible
                  : undefined,
                dataTableStyles.fixWidth(minLeftWidth),
              )}
            >
              <RenderHeader<T>
                onSortChange={onSortChange}
                onResizeChange={onResizeChange}
                columnDefinitionsById={columnDefinitionsById}
                headerGroups={headerGroups.left}
              />
            </div>
          )}

          {visibleLeafColumns.right.length > 0 && (
            <div
              {...stylex.props(
                dataTableStyles.headerForRight,
                dataTableStyles.fixHeight(headerHeight),
                dataTableStyles.rightSectionBorder,
                contentRef.current &&
                  contentRef.current.scrollLeft +
                    contentRef.current.offsetWidth <
                    minCenterWidth - BUFFER
                  ? dataTableStyles.rightSectionBorderVisible
                  : undefined,
                dataTableStyles.fixWidth(minRightWidth),
              )}
            >
              <RenderHeader
                headerGroups={headerGroups.right}
                onSortChange={onSortChange}
                onResizeChange={onResizeChange}
                columnDefinitionsById={columnDefinitionsById}
              />
            </div>
          )}
          <div
            ref={centerHeaderRef}
            // redo focus
            tabIndex={0}
            role="rowgroup"
            onScroll={(e) => e.preventDefault()}
            {...stylex.props(dataTableStyles.headerForContent)}
          >
            <RenderHeader
              onSortChange={onSortChange}
              onResizeChange={onResizeChange}
              columnDefinitionsById={columnDefinitionsById}
              headerGroups={headerGroups.center}
            />
          </div>

          {/* pinned rows <div {...stylex.props(styles.contentOfTopLeft)}>e</div>
        <div {...stylex.props(styles.contentOfTop)}>f</div>
        <div {...stylex.props(styles.contentOfTopRight)}>g</div> */}
          <div
            ref={contentRef}
            {...stylex.props(
              dataTableStyles.contentGridArea,
              dataTableStyles.content,
              dataTableStyles.contentHeight(rowHeight * 2),
            )}
            // redo focus
            tabIndex={0}
            onScroll={(e) => e.preventDefault()}
            role="rowgroup"
          >
            <RenderRows
              columnDefinition={columnDefinitionsById}
              columns={visibleLeafColumns.center}
              isLoading={isLoading}
              onRowClick={
                hasRowClick
                  ? (e) => onRowClick.current?.(e as RowClickEvent<T>)
                  : undefined
              }
              rows={rows}
              vRow={vRow}
              rowHeight={rowHeight}
            />
            <DomPlaceholder height={totalSize} />
          </div>
          {visibleLeafColumns.left.length > 0 && (
            <div
              ref={contentLeftRef}
              onScroll={(e) => e.preventDefault()}
              {...stylex.props(
                dataTableStyles.contentOfLeft,
                dataTableStyles.leftSectionBorder,
                contentRef.current && contentRef.current.scrollLeft > BUFFER
                  ? dataTableStyles.leftSectionBorderVisible
                  : undefined,
              )}
              // redo focus
              tabIndex={0}
              role="rowgroup"
            >
              <RenderRows
                columnDefinition={columnDefinitionsById}
                columns={visibleLeafColumns.left}
                isLoading={isLoading}
                onRowClick={
                  hasRowClick
                    ? (e) => onRowClick.current?.(e as RowClickEvent<T>)
                    : undefined
                }
                rows={rows}
                vRow={vRow}
                rowHeight={rowHeight}
              />
              <DomPlaceholder height={totalSize} />
            </div>
          )}
          {visibleLeafColumns.right.length > 0 && (
            <div
              ref={contentRightRef}
              onScroll={(e) => e.preventDefault()}
              {...stylex.props(
                dataTableStyles.contentOfRight,
                dataTableStyles.rightSectionBorder,

                contentRef.current &&
                  contentRef.current.scrollLeft +
                    contentRef.current.offsetWidth <
                    minCenterWidth - BUFFER
                  ? dataTableStyles.rightSectionBorderVisible
                  : undefined,
              )}
              // redo focus
              tabIndex={0}
              role="rowgroup"
            >
              <RenderRows
                columnDefinition={columnDefinitionsById}
                columns={visibleLeafColumns.right}
                isLoading={isLoading}
                onRowClick={
                  hasRowClick
                    ? (e) => onRowClick.current?.(e as RowClickEvent<T>)
                    : undefined
                }
                rows={rows}
                vRow={vRow}
                rowHeight={rowHeight}
              />
              <DomPlaceholder height={totalSize} />
            </div>
          )}
          {hasVerticalScroll && (
            <>
              <div
                {...stylex.props(
                  dataTableStyles.scrollSpacer,
                  dataTableStyles.scrollSpacerForTop,
                  dataTableStyles.fixWidth(scrollbarMeasurements.width),
                )}
              ></div>
              <ScrollBar
                measurements={scrollbarMeasurements}
                ref={vertScrollRef}
                height={totalSize}
                updateScroll={updateScrollY}
                {...stylex.props(dataTableStyles.verticalScroll)}
              />
              <div
                {...stylex.props(
                  dataTableStyles.scrollSpacer,
                  dataTableStyles.scrollSpacerForBottom,
                  dataTableStyles.fixWidth(scrollbarMeasurements.width),
                )}
              ></div>
            </>
          )}
          {/*  pinned rows bottom <div {...stylex.props(styles.contentOfBottomLeft)}>l</div>
        <div {...stylex.props(styles.contentOfBottom)}>m</div>
        <div {...stylex.props(styles.contentOfBottomRight)}>n</div> */}
          {/* footer <div {...stylex.props(styles.footerForLeft)}>o</div>
        <div {...stylex.props(styles.footerForContent)}>p</div>
        <div {...stylex.props(styles.footerForRight)}>q</div> */}
          {hasHorizontalScroll && (
            <>
              <div
                {...stylex.props(
                  dataTableStyles.scrollSpacer,
                  dataTableStyles.scrollSpacerForLeft,
                  dataTableStyles.fixHeight(scrollbarMeasurements.height),
                )}
              ></div>

              <ScrollBar
                measurements={scrollbarMeasurements}
                ref={horizScrollRef}
                {...stylex.props(dataTableStyles.horizontalScroll)}
                updateScroll={updateScrollX}
                width={minCenterWidth}
              />
              <div
                {...stylex.props(
                  dataTableStyles.scrollSpacer,
                  dataTableStyles.scrollSpacerForRight,
                  dataTableStyles.fixHeight(scrollbarMeasurements.height),
                )}
              ></div>
            </>
          )}
        </div>
      </TableContext.Provider>
    </HoveredTableRow.Provider>
  );
}
DataTable.displayName = "DataTable";
export { DataTable };
