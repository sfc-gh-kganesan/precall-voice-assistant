import { SkeletonRectangle } from "@snowflake/stellar-components";
import type { DataRecord } from "@snowflake/stellar-data-tools";
import * as stylex from "@stylexjs/stylex";
import type { Cell, Column, Row } from "@tanstack/react-table";
import { flexRender } from "@tanstack/react-table";
import type { VirtualItem } from "@tanstack/react-virtual";
import { memo, useContext, useMemo } from "react";

import { rowHeights } from "./constants";
import { HoveredTableRow } from "./hovered-row-context";
import { dataTableStyles } from "./styles";
import { useTableContext } from "../../context/TableContext";
import type {
  CellRendererProps,
  ColumnDefinitionWithId,
  RowClickEvent,
} from "../../types";
import { cellStyles } from "../table/cellStyles";
import { TableCell } from "../table/TableCell";
import { TableRow } from "../table/TableRow";

const RenderRow = <T extends DataRecord>(props: {
  /**
   * The row.
   */
  row: Row<T>;
  /**
   * The virtual row.
   */
  virtualRow?: VirtualItem | undefined;
  /**
   * The columns.
   */
  columns: Column<T, unknown>[];
  /**
   * The column definition.
   */
  columnDefinition: Record<string, ColumnDefinitionWithId<T>>;
  /**
   * The width of the cell.
   */
  cellWidths?: "auto" | "min-content" | "max-content" | undefined;
  /**
   * The callback function to handle the row click.
   */
  onRowClick?: ((event: RowClickEvent<T>) => void) | undefined;
}) => {
  const { row, virtualRow, columns, columnDefinition, cellWidths, onRowClick } =
    props;
  const cells = row._getAllCellsByColumnId();
  const { onRowHover, hoveredRowId } = useContext(HoveredTableRow);

  return (
    <TableRow
      {...stylex.props(
        dataTableStyles.tableRow,
        virtualRow ? dataTableStyles.tableRowVirtual : undefined,
      )}
      onClick={
        onRowClick
          ? (event) => onRowClick({ rowData: row.original, event })
          : undefined
      }
      onMouseEnter={onRowClick ? () => onRowHover(row.id) : undefined}
      onMouseLeave={onRowClick ? () => onRowHover(undefined) : undefined}
      isHovered={row.id === hoveredRowId}
      style={
        virtualRow
          ? {
              top: `${virtualRow.start}px`,
              height: `${virtualRow.size}px`,
            }
          : undefined
      }
      role="row"
    >
      {columns.map((column) => (
        <RenderCellMemo<unknown, T>
          key={column.id}
          column={column as Column<unknown, unknown>}
          columnDefinition={
            columnDefinition[column.id] as ColumnDefinitionWithId<T, keyof T>
          }
          cell={cells[column.id] as Cell<T, unknown>}
          cellWidths={cellWidths}
          height={virtualRow?.size ?? rowHeights.regular}
        />
      ))}
    </TableRow>
  );
};
const RenderRowMemoed = memo(RenderRow) as typeof RenderRow & {
  /**
   * The display name of the component.
   */
  displayName: string;
};
RenderRowMemoed.displayName = "RenderRowMemoed";
const RenderCell = <T, V extends DataRecord>(props: {
  /**
   * The column.
   */
  column: Column<T, unknown>;
  /**
   * The cell.
   */
  cell: Cell<V, unknown>;
  /**
   * The column definition.
   */
  columnDefinition: ColumnDefinitionWithId<V>;

  /**
   * The width of the cell.
   */
  cellWidths?: "auto" | "min-content" | "max-content" | undefined;
  /**
   * The height of the cell.
   */
  height: number;
}) => {
  const { cell, columnDefinition: columnDef, cellWidths, height } = props;

  const renderCell = columnDef?.renderer;

  const formatter = columnDef?.formatter;
  const cellData = cell.getValue() as V[keyof V];
  const rowData = cell.row.original as V;
  const rendererData = useMemo((): CellRendererProps<V[keyof V], V> => {
    return {
      cellData,
      rowData,
      fieldDefinition: columnDef,
    };
  }, [cellData, columnDef, rowData]);

  if (!cell) {
    return null;
  }
  const cellStyles =
    typeof columnDef?.cellStyles === "function"
      ? columnDef?.cellStyles(rendererData)
      : Array.isArray(columnDef?.cellStyles)
        ? columnDef?.cellStyles
        : undefined;
  const formattedValue: string = !renderCell
    ? formatter
      ? // eslint-disable-next-line @typescript-eslint/no-explicit-any
        formatter(cell.getValue() as any, cell.row.original)
      : (cell.renderValue() as string)
    : "";

  return (
    <TableCell
      key={cell.id}
      columnId={cell.column.id}
      aria-colindex={cell.column.getIndex() + 1}
      aria-rowindex={cell.row.index + 1}
      role="gridcell"
      width={cellWidths}
      {...stylex.props(
        dataTableStyles.fixHeight(height),
        !renderCell && dataTableStyles.textCell,
      )}
      text={!renderCell ? formattedValue : undefined}
      styleOverrides={cellStyles}
    >
      {renderCell ? flexRender(renderCell, rendererData) : null}
    </TableCell>
  );
};
const RenderCellMemo = memo(RenderCell) as typeof RenderCell & {
  /**
   * The display name.
   */
  displayName: string;
};
RenderCellMemo.displayName = "RenderCellMemo";

/**
 * A row shown when data is loading.
 */
function LoadingRow<T extends DataRecord>({
  columns,
  cellWidths,
  rowHeight,
  minRowWidth,
  style,
}: {
  /**
   * The columns.
   */
  columns: Column<T, unknown>[];
  /**
   * The width of the cell.
   */
  cellWidths?: "auto" | "min-content" | "max-content" | undefined;
  /**
   * The height of the row.
   */
  rowHeight?: number | undefined;
  /**
   * The minimum width of the row.
   */
  minRowWidth: number;
  /**
   * The style of the row.
   */
  style?: React.CSSProperties | undefined;
}) {
  return (
    <TableRow
      {...stylex.props(
        dataTableStyles.tableRow,
        dataTableStyles.fixMinWidth(minRowWidth),
      )}
      style={style}
    >
      {columns.map((col) => {
        return (
          <TableCell
            key={col.id}
            columnId={col.id}
            width={cellWidths}
            {...stylex.props(
              cellStyles.loadingCellWrapper,
              rowHeight ? dataTableStyles.fixHeight(rowHeight) : undefined,
            )}
          >
            <SkeletonRectangle height="1em" width="100%" />
          </TableCell>
        );
      })}
    </TableRow>
  );
}

/**
 * The component that renders the rows.
 */
function RenderRows<T extends DataRecord>(props: {
  /**
   * Whether the rows are loading.
   */
  isLoading?: boolean | undefined;
  /**
   * The columns.
   */
  columns: Column<T, unknown>[];
  /**
   * The virtual rows.
   */
  vRow?: VirtualItem[] | undefined;
  /**
   * The rows.
   */
  rows: Row<T>[];
  /**
   * The column definition.
   */
  columnDefinition: Record<string, ColumnDefinitionWithId<T, keyof T>>;
  /**
   * The width of the cell.
   */
  cellWidths?: "auto" | "min-content" | "max-content" | undefined;
  /**
   * The callback function to handle the row click.
   */
  onRowClick?: ((event: RowClickEvent<T>) => void) | undefined;
  /**
   * The height of the row.
   */
  rowHeight?: number | undefined;
}) {
  const {
    vRow,
    rows,
    columnDefinition,
    columns,
    isLoading,
    cellWidths,
    onRowClick,
    rowHeight,
  } = props;
  const { column } = useTableContext();
  const minRowWidth = useMemo(() => {
    return Object.entries(column)
      .filter(([id, col]) => col?.visible && columns.find((c) => c.id === id))
      .reduce((acc, [_id, col]) => {
        return acc + (col?.width ?? 0);
      }, 0);
  }, [column, columns]);

  if (isLoading && rows.length === 0) {
    return (
      <>
        {Array.from({ length: 10 }, (_item, index) => (
          <LoadingRow
            key={`loading-row-${index}`}
            columns={columns}
            cellWidths={cellWidths}
            rowHeight={rowHeight}
            minRowWidth={minRowWidth}
          />
        ))}
      </>
    );
  }

  if (vRow) {
    return (
      <>
        {vRow.map((virtualRow) => {
          const row = rows[virtualRow.index];

          if (!row) {
            if (isLoading) {
              return (
                <LoadingRow
                  key={`loading-row-${virtualRow.index}`}
                  columns={columns}
                  cellWidths={cellWidths}
                  rowHeight={rowHeight}
                  minRowWidth={minRowWidth}
                  style={{
                    position: "absolute",
                    top: `${virtualRow.start}px`,
                    height: `${virtualRow.size}px`,
                  }}
                />
              );
            }

            return null;
          }

          return (
            <RenderRowMemoed
              key={`render-row-${virtualRow.key}`}
              row={row}
              virtualRow={virtualRow}
              columns={columns}
              columnDefinition={columnDefinition}
              cellWidths={cellWidths}
              onRowClick={onRowClick}
            />
          );
        })}
      </>
    );
  }

  return (
    <>
      {rows.map((row) => {
        return (
          <RenderRowMemoed
            key={`render-row-${row.id}`}
            row={row}
            columns={columns}
            columnDefinition={columnDefinition}
            cellWidths={cellWidths}
            onRowClick={onRowClick}
          />
        );
      })}
    </>
  );
}

export { RenderRows };
