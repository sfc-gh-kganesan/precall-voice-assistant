import type { DataRecord } from "@snowflake/stellar-data-tools";

import type { DataSource } from "../../internal/DataSource";
import type { DataTableProps } from "../../types";
interface DataSourceTableProps<T extends DataRecord>
  extends Omit<DataTableProps<T>, "rowData"> {
  /**
   *
   */
  dataSource: DataSource<T>;
}
/**
 *
 */
function DataSourceTable<T extends DataRecord>(
  _props: DataSourceTableProps<T>,
) {
  return <div>DataSourceTable</div>;
}

export { DataSourceTable };
export type { DataSourceTableProps };
