import { createContext } from "react";

export const HoveredTableRow = createContext<{
  /**
   * The id of the row that is being hovered.
   */
  hoveredRowId: string | undefined;
  /**
   * Update the id of the row that is being hovered.
   */
  onRowHover: (rowId: string | undefined) => void;
}>({
  hoveredRowId: undefined,
  onRowHover: () => {},
});
