import { useMergedStyles, useTextStyles } from "@snowflake/stellar-components";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";

import { cellStyles } from "./cellStyles";
import { useTableContext } from "../../context/TableContext";
import type { StyleXInput } from "../../types";

interface TableCellProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The width of the cell.
   */
  width?: number | null | "auto" | "min-content" | "max-content" | undefined;
  /**
   * The column id of the cell.
   */
  columnId?: string | undefined;
  /**
   * The text to display in the cell.
   */
  text?: string | null | undefined;
  /**
   * style overrides
   */
  styleOverrides?: StyleXInput | undefined;
}

const TableCell = ({
  style,
  width = null,
  columnId,
  className,
  text,
  children,
  styleOverrides,
  ...otherProps
}: TableCellProps) => {
  const tableContext = useTableContext();
  const column =
    tableContext.column[columnId as keyof typeof tableContext.column];
  const textStyles = useTextStyles({
    size: "small",
  });
  const styleProps = useMergedStyles(
    className,
    style,
    stylex.props(
      cellStyles.tableCell,
      text ? cellStyles.tableCellText : null,
      textStyles,
      tableContext.density === "regular" ? cellStyles.regular : null,
      tableContext.density === "compact" ? cellStyles.compact : null,
      tableContext.density === "comfortable" ? cellStyles.comfortable : null,
      // width from prop
      width === "auto" ? cellStyles.autoWidth : null,
      width === "min-content" ? cellStyles.minContentWidth : null,
      width === "max-content" ? cellStyles.maxContentWidth : null,
      Number(width) ? cellStyles.fixedWidth(Number(width)) : null,
      // width from column context
      !width && column?.width ? cellStyles.fixedWidth(column.width) : null,
      styleOverrides,
    ),
  );
  return (
    <div {...otherProps} {...styleProps}>
      {text || children}
    </div>
  );
};

export { TableCell };
export type { TableCellProps };
