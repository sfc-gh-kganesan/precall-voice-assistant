import type { Density } from "../../types";

const rowHeights: Record<Density, number> = {
  compact: 32,
  regular: 40,
  comfortable: 48,
};
export { rowHeights };
