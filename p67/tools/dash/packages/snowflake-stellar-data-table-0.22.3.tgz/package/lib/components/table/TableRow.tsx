import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { Flex, useMergedStyles } from "@snowflake/stellar-components";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";

const styles = stylex.create({
  tableRow: {
    borderBottomColor: baltoTheme.reusableBorderDefault,
    borderBottomStyle: "solid",
    borderBottomWidth: 1,
  },
  tableRowClickable: {
    backgroundColor: {
      ":hover": baltoTheme.reusableBackgroundRowHover,
    },
    cursor: "pointer",
  },
  tableRowHovered: {
    backgroundColor: baltoTheme.reusableBackgroundRowHover,
  },
});
interface TableRowProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The alignment of the cell content.
   */
  align?: "left" | "center" | "right" | undefined;
  // rowIndex: number;
  /**
   * Whether the row is hovered.
   */
  isHovered?: boolean | undefined;
}
const TableRow = ({
  style,
  className,
  align: _align,
  onClick,
  isHovered,
  ...otherProps
}: TableRowProps) => {
  const styleProps = useMergedStyles(
    className,
    style,
    stylex.props(
      styles.tableRow,
      onClick ? styles.tableRowClickable : undefined,
      isHovered ? styles.tableRowHovered : undefined,
    ),
  );
  return (
    <Flex
      gap="0x"
      {...otherProps}
      {...styleProps}
      direction="row"
      onClick={onClick}
    />
  );
};

export { TableRow };
export type { TableRowProps };
