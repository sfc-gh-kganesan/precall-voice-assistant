import type { DataRecord } from "@snowflake/stellar-data-tools";
import type { Column, HeaderGroup, Row, Table } from "@tanstack/react-table";
import type { VirtualItem } from "@tanstack/react-virtual";
import { useVirtualizer } from "@tanstack/react-virtual";
import { useCallback, useEffect, useMemo, useState } from "react";

import { rowHeights } from "./constants";
import { createInitialState } from "./createInitialState";
import { useTanStackTable } from "./useTanstackTable";
import type {
  ColumnDefinitionWithId,
  DataTableProps,
  TableState,
} from "../../types";

type DataTableHookProps<T extends DataRecord> = DataTableProps<T> & {
  /**
   * The callback function to get the scroll element.
   */
  getScrollElement?: (() => HTMLElement | null) | undefined;
};

interface DataTableAPI<T extends DataRecord> {
  /**
   * The table.
   */
  table: Table<T>;
  /**
   * The state of the table.
   */
  state: TableState<T>;
  /**
   * The virtual rows.
   */
  vRow: VirtualItem[];
  /**
   * The total size of the table.
   */
  totalSize: number;
  /**
   * The rows.
   */
  rows: Row<T>[];
  /**
   * The sample rows.
   */
  sampleRows: Row<T>[];
  /**
   * The column definitions by id.
   */
  columnDefinitionsById: Record<string, ColumnDefinitionWithId<T, keyof T>>;
  /**
   * The callback function to handle the state change.
   */
  onStateChange: (state: TableState<T>) => void;
  /**
   * The height of the row.
   */
  rowHeight: number;
  /**
   * The header groups.
   */
  headerGroups: {
    /**
     * The left header groups.
     */
    left: HeaderGroup<T>[];
    /**
     * The center header groups.
     */
    center: HeaderGroup<T>[];
    /**
     * The right header groups.
     */
    right: HeaderGroup<T>[];
  };
  /**
   * The visible leaf columns.
   */
  visibleLeafColumns: {
    /**
     * The left visible leaf columns.
     */
    left: Column<T, unknown>[];
    /**
     * The center visible leaf columns.
     */
    center: Column<T, unknown>[];
    /**
     * The right visible leaf columns.
     */
    right: Column<T, unknown>[];
  };
}

const useDataTable = <T extends DataRecord>(
  props: DataTableHookProps<T>,
): DataTableAPI<T> => {
  const {
    density,
    rowData,
    columnDefinition: colDef,
    defaultColumnDefinition,
    getScrollElement = () => null,
    onStateChange: onChangeFromProps,
    state: stateFromProps,
    defaultState,
    rowHeight: customRowHeight,
    isLoading,
  } = props;

  const columnDefinitionsWithId = useMemo((): ColumnDefinitionWithId<T>[] => {
    const allIds = new Set();
    return colDef.map((def, index): ColumnDefinitionWithId<T> => {
      const id = def.id ?? ("field" in def ? def.field : undefined);
      if (!id) {
        throw new Error(
          `Column at index ${index} must have either 'id' or 'field' defined`,
        );
      }
      if (allIds.has(id)) {
        throw new Error(
          `Duplicate column id: ${id.toString()} at index: ${index}`,
        );
      }
      allIds.add(id);
      return {
        ...defaultColumnDefinition,
        ...def,
        id: id.toString(),
      } as ColumnDefinitionWithId<T>;
    });
  }, [colDef, defaultColumnDefinition]);
  const columnDefinitionsById = useMemo(
    () =>
      columnDefinitionsWithId.reduce(
        (acc, def) => {
          acc[def.id] = def;
          return acc;
        },
        {} as Record<string, ColumnDefinitionWithId<T>>,
      ),
    [columnDefinitionsWithId],
  );

  // Handle controlled and uncontrolled use
  //------------------------------------------------------------------------------------------------
  const [internalState, setInternalState] = useState<TableState<T>>(
    createInitialState({
      columnDefinition: columnDefinitionsById,
      defaultState,
      density,
      rowHeight: customRowHeight,
    }),
  );

  const isControlled = typeof stateFromProps != "undefined";
  const state = isControlled ? stateFromProps : internalState;
  const onStateChange = useCallback(
    (newState: TableState<T>) => {
      if (onChangeFromProps) {
        onChangeFromProps(newState);
      }

      if (!isControlled) {
        setInternalState(newState);
      }
    },
    [isControlled, onChangeFromProps],
  );
  //------------------------------------------------------------------------------------------------
  const table = useTanStackTable({
    data: rowData,
    columnDefinitionsWithId,
    state,
  });

  const { rows } = table.getRowModel();
  const rowHeight = useMemo(() => {
    if (customRowHeight !== undefined && customRowHeight > 0) {
      return customRowHeight;
    }

    if (!density || density === "regular") {
      return rowHeights.regular;
    } else if (density === "compact") {
      return rowHeights.compact;
    } else {
      return rowHeights.comfortable;
    }
  }, [customRowHeight, density]);

  const estimateSize = useMemo(() => () => rowHeight, [rowHeight]);
  const virtualizer = useVirtualizer({
    count: rows.length + (isLoading ? 1 : 0),
    getScrollElement,
    estimateSize,
    overscan: 20,
  });
  const vRow = virtualizer.getVirtualItems();
  const totalSize = virtualizer.getTotalSize();
  useEffect(() => {
    virtualizer.measure();
  }, [density, rowHeight, virtualizer]);
  const headerGroups = useMemo(
    () => ({
      left: table.getLeftHeaderGroups(),
      center: table.getCenterHeaderGroups(),
      right: table.getRightHeaderGroups(),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [table, state],
  );
  const visibleLeafColumns = useMemo(
    () => ({
      left: table.getLeftVisibleLeafColumns(),
      center: table.getCenterVisibleLeafColumns(),
      right: table.getRightVisibleLeafColumns(),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [table, state],
  );

  const sampleRows = useMemo(() => {
    if (rows.length === 0) {
      return [];
    }
    const sample = [...rows.slice(0, 5), ...rows.slice(-5)];
    return sample;
  }, [rows]);
  return {
    table,
    state,
    sampleRows,
    vRow,
    totalSize,
    rows,
    columnDefinitionsById,
    onStateChange,
    rowHeight,
    headerGroups,
    visibleLeafColumns,
  };
};

export { useDataTable };
export type { DataTableHookProps };
