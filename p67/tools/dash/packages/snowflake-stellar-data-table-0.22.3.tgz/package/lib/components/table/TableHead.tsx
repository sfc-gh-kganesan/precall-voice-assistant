import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useMergedStyles, useTextStyles } from "@snowflake/stellar-components";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";

interface TableHeadProps extends HTMLAttributes<HTMLTableSectionElement> {
  /**
   * The alignment of the cell content.
   */
  align?: "left" | "center" | "right" | undefined;
}
const styles = stylex.create({
  tableHead: {
    backgroundColor: baltoTheme.reusableBackgroundAdditionalInfo,
    color: baltoTheme.reusableTextSecondary,
    position: "sticky",
    textTransform: "uppercase",
    top: 0,
    zIndex: 1,
  },
});
const TableHead = ({ style, className, ...otherProps }: TableHeadProps) => {
  const textStyles = useTextStyles({
    size: "small",
    weight: "semibold",
  });
  const styleProps = useMergedStyles(
    className,
    style,
    stylex.props(styles.tableHead, ...textStyles),
  );
  return <div {...otherProps} {...styleProps} />;
};

export { TableHead };
export type { TableHeadProps };
