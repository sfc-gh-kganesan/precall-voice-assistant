import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import * as stylex from "@stylexjs/stylex";

const dataTableStyles = stylex.create({
  root: {
    display: "grid",
    gridTemplateAreas: `
        "headerForLeft        headerForContent  headerForRight        headerForRight        spacerForTop"
        "contentOfTopLeft     contentOfTop      contentOfTopRight     contentOfTopRight     scrollSpacerForTop"  
        "contentOfLeft        content           contentOfRight        contentOfRight        verticalScroll"
        "contentOfBottomLeft  contentOfBottom   contentOfBottomRight  contentOfBottomRight  scrollSpacerForBottom" 
        "footerForLeft        footerForContent  footerForRight        footerForRight        scrollSpacerForBottom"  
        "scrollSpacerForLeft  horizontalScroll  scrollSpacerForRight  scrollSpacerForRight  scrollSpacerForRight"
        `,
    gridTemplateColumns: "min-content auto min-content min-content min-content",
    gridTemplateRows:
      "min-content min-content auto min-content min-content min-content",
    height: "100%",
    width: "100%",
  },
  scrollSpacer: {
    backgroundColor: baltoTheme.statusNeutralBackground,
  },
  headerForLeft: {
    gridArea: "headerForLeft",
    position: "relative",
  },
  leftSectionBorder: {
    borderInlineEndWidth: 1,
    borderInlineEndStyle: "solid",
    borderInlineEndColor: "transparent",
    transition: "border-color 0.6s linear",
  },
  leftSectionBorderVisible: {
    borderInlineEndColor: baltoTheme.reusableBorderBright,
  },
  rightSectionBorder: {
    borderInlineStartWidth: 1,
    borderInlineStartStyle: "solid",
    borderInlineStartColor: "transparent",
    transition: "border-color 0.6s linear",
  },
  rightSectionBorderVisible: {
    borderInlineStartColor: baltoTheme.reusableBorderBright,
  },
  headerForContent: {
    gridArea: "headerForContent",
    zIndex: 1,
    MsOverflowStyle: "none" /* IE and Edge */,
    overflow: "scroll",
    position: "relative",
    scrollbarWidth: "none" /* Firefox */,
  },
  headerForRight: {
    gridArea: "headerForRight",
    position: "relative",
  },
  contentOfTopLeft: {
    gridArea: "contentOfTopLeft",
  },
  contentOfTop: {
    gridArea: "contentOfTop",
  },
  contentOfTopRight: {
    gridArea: "contentOfTopRight",
  },
  contentOfLeft: {
    MsOverflowStyle: "none" /* IE and Edge */,
    // boxShadow: baltoTheme.elevation_2BoxShadow,

    gridArea: "contentOfLeft",
    height: "100%",
    minWidth: "0px",
    overflow: "scroll",
    position: "relative",
    scrollbarWidth: "none" /* Firefox */,
  },
  content: {
    MsOverflowStyle: "none" /* IE and Edge */,
    overflow: "scroll",
    position: "relative",
    scrollbarWidth: "none" /* Firefox */,
  },
  contentHeight: (height: number) => ({
    minHeight: height,
  }),
  contentGridArea: {
    height: "100%",
    width: "100%",
    gridArea: "content",
  },
  contentOfRight: {
    MsOverflowStyle: "none" /* IE and Edge */,
    // boxShadow: baltoTheme.elevation_2BoxShadow,
    gridArea: "contentOfRight",
    height: "100%",
    minWidth: "0px",
    overflow: "scroll",
    position: "relative",
    scrollbarWidth: "none" /* Firefox */,
    width: "100%",
  },
  verticalScroll: {
    gridArea: "verticalScroll",
  },
  contentOfBottomLeft: {
    gridArea: "contentOfBottomLeft",
  },
  contentOfBottom: {
    gridArea: "contentOfBottom",
  },
  contentOfBottomRight: {
    gridArea: "contentOfBottomRight",
  },
  footerForLeft: {
    gridArea: "footerForLeft",
  },
  footerForContent: {
    gridArea: "footerForContent",
  },
  footerForRight: {
    gridArea: "footerForRight",
  },
  scrollSpacerForLeft: {
    gridArea: "scrollSpacerForLeft",
  },
  horizontalScroll: {
    gridArea: "horizontalScroll",
  },
  scrollSpacerForRight: {
    gridArea: "scrollSpacerForRight",
  },
  scrollSpacerForTop: {
    gridArea: "scrollSpacerForTop",
  },
  scrollSpacerForBottom: {
    gridArea: "scrollSpacerForBottom",
  },
  fixHeight: (height: number) => ({
    height,
  }),
  fixWidth: (width: number) => ({
    width,
  }),
  fixMinWidth: (width: number) => ({
    minWidth: width,
  }),
  tableRow: {
    display: "flex",
    flexDirection: "row",
    flexWrap: "nowrap",
    left: 0,
    transition: "top 0.1s ease-in-out",
  },
  tableRowVirtual: {
    position: "absolute",
  },
  textCell: {
    whiteSpace: "nowrap",
    textOverflow: "ellipsis",
    overflow: "hidden",
    display: "block",
  },
});

export { dataTableStyles };
