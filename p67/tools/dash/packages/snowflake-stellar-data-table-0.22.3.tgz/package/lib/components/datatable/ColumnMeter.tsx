/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  useDebouncedCallback,
  useLatest,
  useMergedStyles,
} from "@snowflake/stellar-components";
import type { DataRecord } from "@snowflake/stellar-data-tools";
import * as stylex from "@stylexjs/stylex";
import type { Column, HeaderGroup, Row } from "@tanstack/react-table";
import type { HTMLAttributes } from "react";
import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from "react";
import { useSharedResizeObserver } from "use-shared-resize-observer";

import { RenderHeader } from "./RenderHeader";
import { RenderRows } from "./RenderRows";
import { dataTableStyles } from "./styles";
import type { FieldWidth } from "../../hook/useColumnWidths";
import { useColumnWidths } from "../../hook/useColumnWidths";
import type { ColumnDefinitionWithId } from "../../types";

interface InternalColumnWidth {
  /**
   * The id of the column.
   */
  colId: string;
  /**
   * The header of the column.
   */
  header: number;
  /**
   * The cell of the column.
   */
  cell: number;
}
const getInternalColumnWidths = (
  cols: Column<unknown, unknown>[],
  renderedRef: HTMLDivElement | null,
): InternalColumnWidth[] => {
  const returnValue: InternalColumnWidth[] = [];
  if (!renderedRef) {
    return returnValue;
  }
  const headers = renderedRef.childNodes.item(0);
  const rows: HTMLDivElement[] = [];
  renderedRef.childNodes.forEach((child, index) => {
    if (index === 0) {
      return;
    }
    rows.push(child as HTMLDivElement);
  });
  cols.forEach((col, index) => {
    const header = headers.childNodes.item(index);
    const validRows = rows.filter(
      (row) => (row.childNodes.item(index) as HTMLDivElement).offsetWidth > 0,
    );
    const renderedColumnWidths = validRows.map(
      (row) => (row.childNodes.item(index) as HTMLDivElement).offsetWidth,
    );
    const maxColumnWidth = Math.max(...renderedColumnWidths);

    if (header) {
      returnValue.push({
        colId: col.id,
        header: (header as HTMLDivElement).offsetWidth,
        cell: Math.ceil(maxColumnWidth) + 2, // add 2px for variations in font widths. may still result in ellipsis for some columns
      });
    }
  });
  return returnValue;
};
interface ColumnMeterApi {
  /**
   * Measure the width of the column.
   */
  measure: () => number;
  /**
   * Get the widths of the columns.
   */
  getColumnWidths: () => FieldWidth[];
}
interface ColumnMeterProps<T extends DataRecord, K extends keyof T>
  extends HTMLAttributes<HTMLDivElement> {
  /**
   * The ref of the column meter.
   */
  ref: React.Ref<ColumnMeterApi>;
  /**
   * The rows of the table.
   */
  rows: Row<T>[];
  /**
   * The column definitions of the table.
   */
  columnDefinitionsById: Record<string, ColumnDefinitionWithId<T, K>>;
  /**
   * The callback function to update the content rect.
   */
  onContentRectChange?: ((contentRect: ContentRect) => void) | undefined;
  /**
   * The header groups of the table.
   */
  headerGroups: {
    /**
     * The left header groups of the table.
     */
    left: HeaderGroup<T>[];
    /**
     * The center header groups of the table.
     */
    center: HeaderGroup<T>[];
    /**
     * The right header groups of the table.
     */
    right: HeaderGroup<T>[];
  };
  /**
   * The visible leaf columns of the table.
   */
  visibleLeafColumns: {
    /**
     * The left visible leaf columns of the table.
     */
    left: Column<T, unknown>[];
    /**
     * The center visible leaf columns of the table.
     */
    center: Column<T, unknown>[];
    /**
     * The right visible leaf columns of the table.
     */
    right: Column<T, unknown>[];
  };
  /**
   * The callback function to update the widths.
   */
  onUpdate: () => void;
}
const styles = stylex.create({
  hiddenMeter: {
    backgroundColor: "rebeccapurple",
    left: -100000,
    position: "absolute",
    top: -100000,
    visibility: "hidden",
    zIndex: -100,
  },
});
const noOp = () => {};
interface ContentRect {
  /**
   * The width of the content.
   */
  width: number;
  /**
   * The height of the content.
   */
  height: number;
}
const MeasurePart = (props: {
  /**
   * The header of the part.
   */
  header: HeaderGroup<any>[];

  /**
   * The first rows of the part.
   */
  firstRows: Row<any>[];

  /**
   * The last rows of the part.
   */
  lastRows: Row<any>[];

  /**
   * The column definitions of the part.
   */
  columnDefinitionsById: Record<string, ColumnDefinitionWithId<any, any>>;

  /**
   * The visible leaf columns of the part.
   */
  visibleLeafColumns: Column<any>[];
}) => {
  const {
    header,
    firstRows,
    lastRows,
    columnDefinitionsById,
    visibleLeafColumns,
  } = props;
  return (
    <div>
      <RenderHeader
        cellWidth="min-content"
        onSortChange={noOp}
        onResizeChange={noOp}
        headerGroups={header}
        columnDefinitionsById={columnDefinitionsById}
      />
      <RenderRows
        cellWidths="min-content"
        rows={firstRows}
        columns={visibleLeafColumns}
        columnDefinition={columnDefinitionsById}
      />
      <RenderRows
        cellWidths="min-content"
        rows={lastRows}
        columns={visibleLeafColumns}
        columnDefinition={columnDefinitionsById}
      />
    </div>
  );
};

const ColumnMeter = forwardRef<ColumnMeterApi, ColumnMeterProps<any, any>>(
  (props, ref) => {
    const {
      headerGroups,
      visibleLeafColumns,
      rows,
      columnDefinitionsById,
      className,
      style,
      onUpdate,
      onContentRectChange,
    } = props;
    const gridAreaRef = useRef<HTMLDivElement>(null);
    const onContentRectChangeRef = useLatest(onContentRectChange);

    const [centerAvailableWidth, setCenterAvailableWidth] = useState<number>(0);
    const [headerRenderedWidths, setHeaderRenderedWidths] = useState<
      Record<string, number>
    >({});
    const [contentRenderedWidths, setContentRenderedWidths] = useState<
      Record<string, number>
    >({});
    const renderedElementRef = useRef<HTMLDivElement>(null);

    const styleProps = useMergedStyles(
      className,
      style,
      stylex.props(styles.hiddenMeter),
    );

    const columnWidths = useColumnWidths({
      columnDefinitionsById,
      headerRenderedWidths,
      contentRenderedWidths,
      centerAvailableWidth: centerAvailableWidth,
      visibleLeafColumns,
    });

    // ColumnMeterApi
    useImperativeHandle(
      ref,
      (): ColumnMeterApi => ({
        measure: () => {
          return 0;
        },
        getColumnWidths: () => columnWidths,
      }),
    );
    const [contentRect, setContentRect] = useState<ContentRect | null>(null);

    const updateWidths = useCallback(
      (width: number) => {
        setCenterAvailableWidth(width);
        if (renderedElementRef.current) {
          const parent = renderedElementRef.current;
          const headerWidths: Record<string, number> = {};
          const contentWidths: Record<string, number> = {};
          getInternalColumnWidths(
            visibleLeafColumns.left,
            parent.childNodes.item(0) as HTMLDivElement,
          ).map((col) => {
            headerWidths[col.colId] = col.header;
            contentWidths[col.colId] = col.cell;
          });
          getInternalColumnWidths(
            visibleLeafColumns.center,
            parent.childNodes.item(1) as HTMLDivElement,
          ).map((col) => {
            headerWidths[col.colId] = col.header;
            contentWidths[col.colId] = col.cell;
          });
          getInternalColumnWidths(
            visibleLeafColumns.right,
            parent.childNodes.item(2) as HTMLDivElement,
          ).map((col) => {
            headerWidths[col.colId] = col.header;
            contentWidths[col.colId] = col.cell;
          });
          setHeaderRenderedWidths(headerWidths);
          setContentRenderedWidths(contentWidths);
        }
        setTimeout(() => {
          onUpdate();
        }, 16);
      },
      [
        onUpdate,
        visibleLeafColumns.center,
        visibleLeafColumns.left,
        visibleLeafColumns.right,
      ],
    );

    // Recalculate widths when visible columns change
    const visibleColumnIds = useMemo(
      () =>
        [
          ...visibleLeafColumns.left.map((col) => col.id),
          ...visibleLeafColumns.center.map((col) => col.id),
          ...visibleLeafColumns.right.map((col) => col.id),
        ].join(","),
      [
        visibleLeafColumns.left,
        visibleLeafColumns.center,
        visibleLeafColumns.right,
      ],
    );

    const updateWidthsRef = useLatest(updateWidths);
    useEffect(() => {
      if (contentRect) {
        if (onContentRectChangeRef.current) {
          onContentRectChangeRef.current(contentRect);
        }
        updateWidthsRef.current(contentRect.width);
      }
    }, [
      contentRect,
      onContentRectChangeRef,
      updateWidthsRef,
      visibleColumnIds,
    ]);
    const updateWidthsDebounced = useDebouncedCallback(setContentRect, 16);
    useSharedResizeObserver({
      ref: gridAreaRef,
      onUpdate: (entry) =>
        updateWidthsDebounced({
          width: Math.floor(entry.contentRect.width),
          height: Math.floor(entry.contentRect.height),
        }),
    });
    const firstRows = useMemo(
      () => rows.slice(0, Math.min(rows.length - 1, 2)),
      [rows],
    );
    const lastRows = useMemo(() => {
      const remainingRows = rows.slice(firstRows.length + 1);
      return remainingRows.slice(-1 * Math.min(remainingRows.length - 1, 2));
    }, [rows, firstRows]);

    return (
      <>
        <div
          aria-hidden
          role="presentation"
          {...stylex.props(dataTableStyles.contentGridArea)}
          ref={gridAreaRef}
        />
        <div aria-hidden {...styleProps} ref={renderedElementRef} tabIndex={-1}>
          <MeasurePart
            header={headerGroups.left}
            firstRows={firstRows}
            lastRows={lastRows}
            columnDefinitionsById={columnDefinitionsById}
            visibleLeafColumns={visibleLeafColumns.left}
          />
          <MeasurePart
            header={headerGroups.center}
            firstRows={firstRows}
            lastRows={lastRows}
            columnDefinitionsById={columnDefinitionsById}
            visibleLeafColumns={visibleLeafColumns.center}
          />
          <MeasurePart
            header={headerGroups.right}
            firstRows={firstRows}
            lastRows={lastRows}
            columnDefinitionsById={columnDefinitionsById}
            visibleLeafColumns={visibleLeafColumns.right}
          />
        </div>
      </>
    );
  },
);

ColumnMeter.displayName = "ColumnMeter";

export type { ColumnMeterProps, ColumnMeterApi, ContentRect };
export { ColumnMeter };
