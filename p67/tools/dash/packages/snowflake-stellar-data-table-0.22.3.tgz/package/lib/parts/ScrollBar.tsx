import { useMergedStyles } from "@snowflake/stellar-components";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";
import { forwardRef, useCallback, useImperativeHandle, useRef } from "react";

import type { ScrollbarMeasurements } from "../hook/useScrollbarSize";

interface ScrollBarHandle {
  /**
   * The callback function to handle the scroll delta.
   */
  scrollDelta: (x: number, y: number) => void;
}
interface ScrollbarProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The measurements of the scrollbar.
   */
  measurements: ScrollbarMeasurements;
  /**
   * The width of the scrollbar.
   */
  width?: number | undefined;
  /**
   * The height of the scrollbar.
   */
  height?: number | undefined;
  /**
   * The callback function to update the scroll.
   */
  updateScroll: (scroll: number) => void;
  /**
   * The ref of the scrollbar.
   */
  ref: React.RefObject<ScrollBarHandle>;
}

const styles = stylex.create({
  wrapper: {
    height: "100%",

    position: "relative",
    width: "100%",
  },
  wrapperVertical: (measuredWidth: number) => ({
    overflowY: "scroll",
    width: measuredWidth === 0 ? 1 : measuredWidth,
  }),
  wrapperHorizontal: (measuredHeight: number) => ({
    height: measuredHeight === 0 ? 1 : measuredHeight,
    overflowX: "scroll",
  }),
  virtualEl: {
    height: 1,
    left: 0,
    position: "absolute",
    top: 0,
    visibility: "hidden",
    width: 1,
  },
  virtualHorizontalEl: (width: number) => ({
    width,
  }),
  virtualVerticalEl: (height: number) => ({
    height,
  }),
});
const ScrollBar = forwardRef<ScrollBarHandle, ScrollbarProps>(
  (props, forwardedRef) => {
    const {
      measurements,
      width,
      height,
      updateScroll,
      className,
      style,
      ...otherProps
    } = props;
    const wrapperRef = useRef<HTMLDivElement>(null);
    const styleProps = useMergedStyles(
      className,
      style,
      stylex.props(
        styles.wrapper,
        width ? styles.wrapperHorizontal(measurements.height) : null,
        height ? styles.wrapperVertical(measurements.width) : null,
      ),
    );
    const updateScrollposition = useCallback(() => {
      if (!wrapperRef.current) {
        return;
      }
      if (width) {
        updateScroll(wrapperRef.current.scrollLeft);
      }
      if (height) {
        updateScroll(wrapperRef.current.scrollTop);
      }
    }, [height, updateScroll, width]);
    useImperativeHandle(forwardedRef, () => ({
      scrollDelta: (x: number, y: number) => {
        if (!wrapperRef.current) {
          return;
        }
        wrapperRef.current.scrollLeft += x;
        wrapperRef.current.scrollTop += y;
      },
    }));
    if ((width && height) || !(width || height)) {
      return null;
    }
    return (
      <div
        {...otherProps}
        {...styleProps}
        ref={wrapperRef}
        onScroll={updateScrollposition}
      >
        <div
          {...stylex.props(
            styles.virtualEl,
            height
              ? styles.virtualVerticalEl(height - measurements.height)
              : null,
            width
              ? styles.virtualHorizontalEl(width - measurements.width)
              : null,
          )}
        ></div>
      </div>
    );
  },
);
ScrollBar.displayName = "ScrollBar";

export { ScrollBar };
export type { ScrollBarHandle, ScrollbarProps };
