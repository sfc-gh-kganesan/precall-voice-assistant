/**
 * A Least Recently Used (LRU) cache implementation that maintains a fixed maximum size.
 * When the cache reaches its size limit, the least recently accessed items are removed first.
 * @template K - The type of keys used to store and retrieve values
 * @template V - The type of values stored in the cache
 */
export interface LRUMap<K, V> {
  /**
   * Retrieves a value from the cache by its key. Accessing a value marks it as recently used.
   * @param key - The key to look up
   * @returns The cached value if found, undefined otherwise
   */
  get(key: K): V | undefined;

  /**
   * Stores a value in the cache with the given key. If the cache is full, removes the least recently used item.
   * @param key - The key to store the value under
   * @param value - The value to cache
   */
  set(key: K, value: V): void;

  /**
   * Checks if a key exists in the cache
   * @param key - The key to check
   * @returns true if the key exists, false otherwise
   */
  has(key: K): boolean;

  /**
   * Removes an item from the cache
   * @param key - The key of the item to remove
   * @returns true if an item was removed, false if the key wasn't found
   */
  delete(key: K): boolean;

  /**
   * Removes all items from the cache
   */
  clear(): void;

  /**
   * The current number of items in the cache
   */
  size: number;
}

export const createLRUMap = <K, V>(maxSize: number): LRUMap<K, V> => {
  type Node = {
    key: K;
    value: V;
    prev: Node | null;
    next: Node | null;
  };

  const nodeByKey = new Map<K, Node>();
  let head: Node | null = null; // least recently used
  let tail: Node | null = null; // most recently used

  const addNodeToTail = (node: Node): void => {
    if (tail === null) {
      head = node;
      tail = node;
      node.prev = null;
      node.next = null;
      return;
    }
    node.prev = tail;
    node.next = null;
    tail.next = node;
    tail = node;
  };

  const removeNode = (node: Node): void => {
    if (node.prev) {
      node.prev.next = node.next;
    } else {
      head = node.next;
    }
    if (node.next) {
      node.next.prev = node.prev;
    } else {
      tail = node.prev;
    }
    node.prev = null;
    node.next = null;
  };

  const moveNodeToTail = (node: Node): void => {
    if (tail === node) return;
    removeNode(node);
    addNodeToTail(node);
  };

  const evictIfNeeded = (): void => {
    if (nodeByKey.size >= maxSize) {
      if (head !== null) {
        const lruKey = head.key;
        removeNode(head);
        nodeByKey.delete(lruKey);
      }
    }
  };

  return {
    get(key: K): V | undefined {
      const node = nodeByKey.get(key);
      if (node === undefined) return undefined;
      moveNodeToTail(node);
      return node.value;
    },

    set(key: K, value: V): void {
      const existing = nodeByKey.get(key);
      if (existing) {
        existing.value = value;
        moveNodeToTail(existing);
        return;
      }

      evictIfNeeded();
      const newNode: Node = { key, value, prev: null, next: null };
      addNodeToTail(newNode);
      nodeByKey.set(key, newNode);
    },

    has(key: K): boolean {
      return nodeByKey.has(key);
    },

    delete(key: K): boolean {
      const node = nodeByKey.get(key);
      if (!node) return false;
      removeNode(node);
      nodeByKey.delete(key);
      return true;
    },

    clear(): void {
      nodeByKey.clear();
      head = null;
      tail = null;
    },

    get size(): number {
      return nodeByKey.size;
    },
  };
};
