import type { DataRecord } from "@snowflake/stellar-data-tools";

import type { TableState } from "../../types";

const updateSort = <T extends DataRecord>(
  state: TableState<T>,
  columnId: keyof T,
): TableState<T> => {
  const { sort } = state;
  const entry = (sort ?? []).find((sort) => sort.id === columnId);
  if (!entry) {
    return {
      ...state,
      sort: [{ id: columnId, desc: false }],
    };
  }
  if (entry?.desc === false) {
    return {
      ...state,
      sort: [{ id: columnId, desc: true }],
    };
  } else {
    return {
      ...state,
      sort: [],
    };
  }
};

export { updateSort };
