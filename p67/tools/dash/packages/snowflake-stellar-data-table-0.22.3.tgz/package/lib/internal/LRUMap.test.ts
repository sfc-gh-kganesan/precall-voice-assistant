import { describe, expect, test } from "vitest";

import { createLRUMap } from "./LRUMap";

describe("LRUMap", () => {
  describe("createLRUMap", () => {
    test("should create an LRU map with the specified max size", () => {
      const lru = createLRUMap<string, number>(3);
      expect(lru).toBeDefined();
      expect(lru.size).toBe(0);
      expect(typeof lru.get).toBe("function");
      expect(typeof lru.set).toBe("function");
      expect(typeof lru.has).toBe("function");
      expect(typeof lru.delete).toBe("function");
      expect(typeof lru.clear).toBe("function");
    });

    test("should handle maxSize of 0", () => {
      const lru = createLRUMap<string, number>(0);
      expect(lru.size).toBe(0);

      lru.set("key1", 1);
      expect(lru.size).toBe(1); // maxSize 0 still allows one item
      expect(lru.has("key1")).toBe(true);
      expect(lru.get("key1")).toBe(1);

      // Adding another item should replace the first
      lru.set("key2", 2);
      expect(lru.size).toBe(1);
      expect(lru.has("key1")).toBe(false);
      expect(lru.has("key2")).toBe(true);
    });

    test("should handle maxSize of 1", () => {
      const lru = createLRUMap<string, number>(1);

      lru.set("key1", 1);
      expect(lru.size).toBe(1);
      expect(lru.has("key1")).toBe(true);

      lru.set("key2", 2);
      expect(lru.size).toBe(1);
      expect(lru.has("key1")).toBe(false);
      expect(lru.has("key2")).toBe(true);
    });
  });

  describe("basic operations", () => {
    test("should set and get values", () => {
      const lru = createLRUMap<string, number>(3);

      lru.set("a", 1);
      lru.set("b", 2);
      lru.set("c", 3);

      expect(lru.get("a")).toBe(1);
      expect(lru.get("b")).toBe(2);
      expect(lru.get("c")).toBe(3);
      expect(lru.size).toBe(3);
    });

    test("should return undefined for non-existent keys", () => {
      const lru = createLRUMap<string, number>(3);
      expect(lru.get("nonexistent")).toBeUndefined();
    });

    test("should check if keys exist with has()", () => {
      const lru = createLRUMap<string, number>(3);

      expect(lru.has("a")).toBe(false);

      lru.set("a", 1);
      expect(lru.has("a")).toBe(true);

      lru.delete("a");
      expect(lru.has("a")).toBe(false);
    });

    test("should delete keys and return correct boolean", () => {
      const lru = createLRUMap<string, number>(3);

      lru.set("a", 1);
      lru.set("b", 2);

      expect(lru.delete("a")).toBe(true);
      expect(lru.has("a")).toBe(false);
      expect(lru.size).toBe(1);

      expect(lru.delete("nonexistent")).toBe(false);
      expect(lru.size).toBe(1);
    });

    test("should clear all items", () => {
      const lru = createLRUMap<string, number>(3);

      lru.set("a", 1);
      lru.set("b", 2);
      lru.set("c", 3);

      expect(lru.size).toBe(3);

      lru.clear();

      expect(lru.size).toBe(0);
      expect(lru.has("a")).toBe(false);
      expect(lru.has("b")).toBe(false);
      expect(lru.has("c")).toBe(false);
    });

    test("should update size correctly", () => {
      const lru = createLRUMap<string, number>(5);

      expect(lru.size).toBe(0);

      lru.set("a", 1);
      expect(lru.size).toBe(1);

      lru.set("b", 2);
      expect(lru.size).toBe(2);

      lru.set("c", 3);
      expect(lru.size).toBe(3);

      lru.delete("b");
      expect(lru.size).toBe(2);

      lru.clear();
      expect(lru.size).toBe(0);
    });
  });

  describe("LRU behavior", () => {
    test("should evict least recently used item when maxSize is reached", () => {
      const lru = createLRUMap<string, number>(3);

      // Fill to capacity
      lru.set("a", 1);
      lru.set("b", 2);
      lru.set("c", 3);

      expect(lru.size).toBe(3);
      expect(lru.has("a")).toBe(true);
      expect(lru.has("b")).toBe(true);
      expect(lru.has("c")).toBe(true);

      // Add fourth item - should evict 'a' (least recently used)
      lru.set("d", 4);

      expect(lru.size).toBe(3);
      expect(lru.has("a")).toBe(false); // evicted
      expect(lru.has("b")).toBe(true);
      expect(lru.has("c")).toBe(true);
      expect(lru.has("d")).toBe(true);
    });

    test("should update access order when getting items", () => {
      const lru = createLRUMap<string, number>(3);

      lru.set("a", 1);
      lru.set("b", 2);
      lru.set("c", 3);

      // Access 'a' - making it most recently used
      lru.get("a");

      // Add fourth item - should evict 'b' (now least recently used)
      lru.set("d", 4);

      expect(lru.has("a")).toBe(true); // still present due to recent access
      expect(lru.has("b")).toBe(false); // evicted
      expect(lru.has("c")).toBe(true);
      expect(lru.has("d")).toBe(true);
    });

    test("should update access order when setting existing items", () => {
      const lru = createLRUMap<string, number>(3);

      lru.set("a", 1);
      lru.set("b", 2);
      lru.set("c", 3);

      // Update 'a' - making it most recently used
      lru.set("a", 10);

      // Add fourth item - should evict 'b' (now least recently used)
      lru.set("d", 4);

      expect(lru.has("a")).toBe(true); // still present due to recent update
      expect(lru.get("a")).toBe(10); // value was updated
      expect(lru.has("b")).toBe(false); // evicted
      expect(lru.has("c")).toBe(true);
      expect(lru.has("d")).toBe(true);
    });

    test("should maintain correct order with multiple accesses", () => {
      const lru = createLRUMap<string, number>(3);

      lru.set("a", 1);
      lru.set("b", 2);
      lru.set("c", 3);

      // Access pattern: c, a, b (making b most recent)
      lru.get("c");
      lru.get("a");
      lru.get("b");

      // Add fourth item - should evict 'c' (least recently accessed after the pattern)
      lru.set("d", 4);

      expect(lru.has("a")).toBe(true);
      expect(lru.has("b")).toBe(true); // most recently accessed
      expect(lru.has("c")).toBe(false); // evicted
      expect(lru.has("d")).toBe(true);
    });

    test("should handle complex access patterns", () => {
      const lru = createLRUMap<string, number>(4);

      // Fill cache
      lru.set("a", 1);
      lru.set("b", 2);
      lru.set("c", 3);
      lru.set("d", 4);

      // Access some items in specific order
      lru.get("b"); // b becomes most recent
      lru.get("a"); // a becomes most recent
      lru.set("c", 30); // c gets updated and becomes most recent

      // Add two more items - should evict d and b
      lru.set("e", 5);
      expect(lru.has("d")).toBe(false); // d was least recent

      lru.set("f", 6);
      expect(lru.has("b")).toBe(false); // b was next least recent

      // Remaining items should be a, c, e, f
      expect(lru.has("a")).toBe(true);
      expect(lru.has("c")).toBe(true);
      expect(lru.get("c")).toBe(30); // updated value
      expect(lru.has("e")).toBe(true);
      expect(lru.has("f")).toBe(true);
    });
  });

  describe("edge cases", () => {
    test("should handle accessing non-existent keys without affecting order", () => {
      const lru = createLRUMap<string, number>(2);

      lru.set("a", 1);
      lru.set("b", 2);

      // Try to access non-existent key
      expect(lru.get("nonexistent")).toBeUndefined();

      // Add another item - should still evict 'a' (oldest)
      lru.set("c", 3);

      expect(lru.has("a")).toBe(false);
      expect(lru.has("b")).toBe(true);
      expect(lru.has("c")).toBe(true);
    });

    test("should handle deleting from empty cache", () => {
      const lru = createLRUMap<string, number>(3);
      expect(lru.delete("nonexistent")).toBe(false);
      expect(lru.size).toBe(0);
    });

    test("should handle clearing empty cache", () => {
      const lru = createLRUMap<string, number>(3);
      lru.clear();
      expect(lru.size).toBe(0);
    });

    test("should handle has() on empty cache", () => {
      const lru = createLRUMap<string, number>(3);
      expect(lru.has("anything")).toBe(false);
    });

    test("should handle setting same key multiple times", () => {
      const lru = createLRUMap<string, number>(3);

      lru.set("a", 1);
      lru.set("a", 2);
      lru.set("a", 3);

      expect(lru.size).toBe(1);
      expect(lru.get("a")).toBe(3);
    });

    test("should handle undefined and null values", () => {
      const lru = createLRUMap<string, null | undefined>(3);

      lru.set("null", null);
      lru.set("undefined", undefined);

      expect(lru.has("null")).toBe(true);
      expect(lru.get("null")).toBeNull();
      expect(lru.has("undefined")).toBe(true);
      expect(lru.get("undefined")).toBeUndefined();

      expect(lru.size).toBe(2);
    });
  });

  describe("different data types", () => {
    test("should work with number keys", () => {
      const lru = createLRUMap<number, string>(3);

      lru.set(1, "one");
      lru.set(2, "two");
      lru.set(3, "three");

      expect(lru.get(1)).toBe("one");
      expect(lru.get(2)).toBe("two");
      expect(lru.get(3)).toBe("three");

      lru.set(4, "four");
      expect(lru.has(1)).toBe(false); // evicted
    });

    test("should work with object keys", () => {
      const lru = createLRUMap<object, string>(2);

      const key1 = { id: 1 };
      const key2 = { id: 2 };
      const key3 = { id: 3 };

      lru.set(key1, "first");
      lru.set(key2, "second");

      expect(lru.get(key1)).toBe("first");
      expect(lru.get(key2)).toBe("second");

      lru.set(key3, "third");
      expect(lru.has(key1)).toBe(false); // evicted
      expect(lru.has(key2)).toBe(true);
      expect(lru.has(key3)).toBe(true);
    });

    test("should work with complex value types", () => {
      interface ComplexValue {
        data: number[];
        metadata: { created: Date; updated: Date };
      }

      const lru = createLRUMap<string, ComplexValue>(2);

      const now = new Date();
      const value1: ComplexValue = {
        data: [1, 2, 3],
        metadata: { created: now, updated: now },
      };

      lru.set("complex1", value1);

      const retrieved = lru.get("complex1");
      expect(retrieved).toEqual(value1);
      expect(retrieved?.data).toEqual([1, 2, 3]);
    });
  });

  describe("performance characteristics", () => {
    test("should handle large number of operations efficiently", () => {
      const lru = createLRUMap<number, string>(1000);

      // Add 1000 items
      for (let i = 0; i < 1000; i++) {
        lru.set(i, `value-${i}`);
      }

      expect(lru.size).toBe(1000);

      // Add one more - should evict the first item
      lru.set(1000, "value-1000");

      expect(lru.size).toBe(1000);
      expect(lru.has(0)).toBe(false); // first item evicted
      expect(lru.has(1000)).toBe(true);
      expect(lru.has(999)).toBe(true);
    });

    test("should maintain correct order with frequent access", () => {
      const lru = createLRUMap<string, number>(5);

      // Fill cache
      for (let i = 0; i < 5; i++) {
        lru.set(`key${i}`, i);
      }

      // Frequently access first item
      for (let i = 0; i < 10; i++) {
        lru.get("key0");
      }

      // Add new items - key0 should remain due to frequent access
      lru.set("new1", 100);
      lru.set("new2", 200);

      expect(lru.has("key0")).toBe(true); // should still be present
      expect(lru.has("key1")).toBe(false); // should be evicted
      expect(lru.has("key2")).toBe(false); // should be evicted
    });
  });

  describe("state consistency", () => {
    test("should maintain size consistency after various operations", () => {
      const lru = createLRUMap<string, number>(3);

      expect(lru.size).toBe(0);

      lru.set("a", 1);
      expect(lru.size).toBe(1);

      lru.set("b", 2);
      expect(lru.size).toBe(2);

      lru.set("c", 3);
      expect(lru.size).toBe(3);

      lru.set("d", 4); // evicts 'a'
      expect(lru.size).toBe(3);

      lru.delete("b");
      expect(lru.size).toBe(2);

      lru.set("e", 5);
      expect(lru.size).toBe(3);

      lru.clear();
      expect(lru.size).toBe(0);
    });

    test("should maintain internal consistency when deleting from middle", () => {
      const lru = createLRUMap<string, number>(4);

      // Fill cache to maxSize
      lru.set("a", 1);
      lru.set("b", 2);
      lru.set("c", 3);
      lru.set("d", 4);

      // Delete from middle
      lru.delete("c");
      expect(lru.size).toBe(3);

      // Add two new items - second one should evict the oldest
      lru.set("e", 5);
      expect(lru.size).toBe(4);

      lru.set("f", 6);
      expect(lru.size).toBe(4);

      expect(lru.has("a")).toBe(false); // oldest should be evicted
      expect(lru.has("b")).toBe(true);
      expect(lru.has("c")).toBe(false); // was deleted
      expect(lru.has("d")).toBe(true);
      expect(lru.has("e")).toBe(true);
      expect(lru.has("f")).toBe(true);
    });
  });

  describe("fuzzing", () => {
    // Deterministic RNG (mulberry32)
    const createRng = (seed: number) => {
      let t = seed >>> 0;
      return () => {
        t += 0x6d2b79f5;
        let r = Math.imul(t ^ (t >>> 15), 1 | t);
        r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
        return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
      };
    };

    function pick(rng: () => number, items: ReadonlyArray<string>): string {
      if (items.length === 0) {
        throw new Error("pick(): items must be non-empty");
      }
      const idx = Math.floor(rng() * items.length);
      return items[idx] as string;
    }

    test("should never exceed capacity under random stress (including maxSize=0)", () => {
      const seeds = [11, 12, 13];
      for (const seed of seeds) {
        const rng = createRng(seed);
        const maxSize = Math.floor(rng() * 5); // 0..4
        const lru = createLRUMap<string, number>(maxSize);
        const keys = Array.from({ length: 10 }, (_, i) => `k${i}`);

        for (let i = 0; i < 500; i++) {
          const key = pick(rng, keys);
          const value = Math.floor(rng() * 10000);
          const r = rng();
          if (r < 0.5) lru.set(key, value);
          else if (r < 0.7) lru.get(key);
          else if (r < 0.9) lru.delete(key);
          else lru.clear();

          // For maxSize 0 our implementation allows size 1 after an insertion
          const allowedMax = maxSize === 0 ? 1 : maxSize;
          expect(lru.size).toBeLessThanOrEqual(allowedMax);
        }
      }
    });
  });
});
