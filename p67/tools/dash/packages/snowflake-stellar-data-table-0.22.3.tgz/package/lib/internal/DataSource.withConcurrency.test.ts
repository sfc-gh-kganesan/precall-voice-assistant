import { describe, expect, test, vi } from "vitest";

import { withConcurrency } from "./DataSource";

interface Row {
  id: number;
}

const createMockDataSource = (
  impl: (start: number, end: number) => Promise<readonly Row[]>,
) => {
  return {
    pageSize: 10,
    rowCount: 100,
    fetchRows: ({
      startIndex,
      endIndex,
    }: {
      startIndex: number;
      endIndex: number;
    }) => impl(startIndex, endIndex),
  } as const;
};

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

function assertExactlyOne<T>(arr: readonly T[]): asserts arr is readonly [T] {
  expect(arr.length).toBe(1);
}

describe("withConcurrency", () => {
  test("honors concurrency limit by queueing extra requests", async () => {
    const inFlight: Set<number> = new Set();
    let maxConcurrent = 0;

    const fetchMock = vi.fn(async (start: number) => {
      inFlight.add(start);
      maxConcurrent = Math.max(maxConcurrent, inFlight.size);
      // hold a bit to allow overlap
      await delay(30);
      inFlight.delete(start);
      return [{ id: start }];
    });

    const ds = createMockDataSource(async (start) => fetchMock(start));
    const limited = withConcurrency(ds, 2);

    const p1 = limited.fetchRows({ startIndex: 0, endIndex: 1, sort: [] });
    const p2 = limited.fetchRows({ startIndex: 1, endIndex: 2, sort: [] });
    const p3 = limited.fetchRows({ startIndex: 2, endIndex: 3, sort: [] });
    const p4 = limited.fetchRows({ startIndex: 3, endIndex: 4, sort: [] });

    const results = await Promise.all([p1, p2, p3, p4]);

    expect(results).toHaveLength(4);
    expect(maxConcurrent).toBeLessThanOrEqual(2);
    expect(fetchMock).toHaveBeenCalledTimes(4);
  });

  test("starts queued requests when prior ones finish", async () => {
    const resolvers: Array<() => void> = [];
    const fetchMock = vi.fn(
      () =>
        new Promise<readonly Row[]>((resolve) => {
          resolvers.push(() => resolve([{ id: resolvers.length }]));
        }),
    );

    const ds = createMockDataSource(async () => fetchMock());
    const limited = withConcurrency(ds, 2);

    const p1 = limited.fetchRows({ startIndex: 0, endIndex: 1, sort: [] });
    const p2 = limited.fetchRows({ startIndex: 1, endIndex: 2, sort: [] });
    const p3 = limited.fetchRows({ startIndex: 2, endIndex: 3, sort: [] });

    // Only two should be in-flight initially
    expect(fetchMock).toHaveBeenCalledTimes(2);

    // Resolve one -> should trigger next from queue
    resolvers.shift()?.();
    await delay(0);
    expect(fetchMock).toHaveBeenCalledTimes(3);

    resolvers.forEach((r) => r());
    const [r1, r2, r3] = await Promise.all([p1, p2, p3]);
    expect(r1.length + r2.length + r3.length).toBe(3);
  });

  test("propagates errors and continues processing queue", async () => {
    const calls: number[] = [];
    const fetchMock = vi.fn(async (start: number) => {
      calls.push(start);
      if (start === 1) {
        await delay(10);
        throw new Error("boom");
      }
      await delay(10);
      return [{ id: start }];
    });

    const ds = createMockDataSource(async (start) => fetchMock(start));
    const limited = withConcurrency(ds, 1);

    const p1 = limited.fetchRows({ startIndex: 0, endIndex: 1, sort: [] });
    const p2 = limited.fetchRows({ startIndex: 1, endIndex: 2, sort: [] });
    const p3 = limited.fetchRows({ startIndex: 2, endIndex: 3, sort: [] });

    const r1 = await p1;
    assertExactlyOne(r1);
    expect(r1[0].id).toBe(0);
    await expect(p2).rejects.toThrow("boom");
    const r3 = await p3;
    assertExactlyOne(r3);
    expect(r3[0].id).toBe(2);

    expect(fetchMock).toHaveBeenCalledTimes(3);
  });
});
