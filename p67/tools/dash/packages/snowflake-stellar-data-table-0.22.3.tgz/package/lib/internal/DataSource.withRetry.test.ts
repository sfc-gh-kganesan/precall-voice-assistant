import { afterEach, beforeEach, describe, expect, test, vi } from "vitest";

import { withRetry } from "./DataSource";

interface Row {
  id: number;
}

const createMockDataSource = (
  impl: (start: number, end: number) => Promise<readonly Row[]>,
) => {
  return {
    pageSize: 25,
    rowCount: 500,
    fetchRows: ({
      startIndex,
      endIndex,
    }: {
      startIndex: number;
      endIndex: number;
    }) => impl(startIndex, endIndex),
  } as const;
};

describe("withRetry", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  test("passes through on first success without retries", async () => {
    const fetchMock = vi.fn(async (start: number) => [{ id: start }]);
    const ds = createMockDataSource((start) => fetchMock(start));
    const retried = withRetry(ds, 3);

    const result = retried.fetchRows({ startIndex: 0, endIndex: 1, sort: [] });
    // No timers should be needed
    await expect(result).resolves.toEqual([{ id: 0 }]);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  test("retries on failure and eventually succeeds within retryCount", async () => {
    let callCount = 0;
    const fetchMock = vi.fn(async (start: number) => {
      callCount++;
      if (callCount < 3) {
        throw new Error("temporary");
      }
      return [{ id: start }];
    });

    const ds = createMockDataSource((start) => fetchMock(start));
    const retried = withRetry(ds, 3);

    const p = retried.fetchRows({ startIndex: 5, endIndex: 6, sort: [] });

    // Backoff timings: 2^1*100=200ms, then 2^2*100=400ms
    await vi.advanceTimersByTimeAsync(200);
    await vi.advanceTimersByTimeAsync(400);

    await expect(p).resolves.toEqual([{ id: 5 }]);
    expect(fetchMock).toHaveBeenCalledTimes(3);
  });

  test("fails after reaching retryCount", async () => {
    const fetchMock = vi.fn(async () => {
      throw new Error("always fail");
    });

    const ds = createMockDataSource(() => fetchMock());
    const retried = withRetry(ds, 3);

    const p = retried.fetchRows({ startIndex: 0, endIndex: 1, sort: [] });
    // Attach a rejection handler immediately to avoid unhandled rejection warnings
    const caught = p.then(
      () => ({ ok: true as const }),
      (e) => ({ ok: false as const, error: e as Error }),
    );

    // Two backoffs will occur (after attempt 1 and 2). Final attempt throws immediately.
    await vi.advanceTimersByTimeAsync(200);
    await vi.advanceTimersByTimeAsync(400);

    const result = await caught;
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.error.message).toBe("always fail");
    }
    expect(fetchMock).toHaveBeenCalledTimes(3);
  });

  test("preserves pageSize and rowCount from original data source", async () => {
    const ds = createMockDataSource(async (start) => [{ id: start }]);
    const retried = withRetry(ds, 2);

    expect(retried.pageSize).toBe(25);
    expect(retried.rowCount).toBe(500);
  });
});
