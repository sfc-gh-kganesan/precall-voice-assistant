import { describe, expect, test, vi } from "vitest";

import { withLRUCache } from "./DataSource";

interface Row {
  id: number;
}

const createMockDataSource = (
  impl: (start: number, end: number) => Promise<readonly Row[]>,
) => {
  return {
    pageSize: 50,
    rowCount: 1000,
    fetchRows: ({
      startIndex,
      endIndex,
    }: {
      startIndex: number;
      endIndex: number;
    }) => impl(startIndex, endIndex),
  } as const;
};

describe("withLRUCache", () => {
  test("returns cached result on repeated calls with same startIndex", async () => {
    const fetchMock = vi.fn(async (start: number) => [{ id: start }]);
    const ds = createMockDataSource((start, _end) => fetchMock(start));
    const cached = withLRUCache(ds, 10);

    const r1 = await cached.fetchRows({
      startIndex: 5,
      endIndex: 10,
      sort: [],
    });
    const r2 = await cached.fetchRows({
      startIndex: 5,
      endIndex: 10,
      sort: [],
    });

    expect(r1).toEqual([{ id: 5 }]);
    expect(r2).toEqual([{ id: 5 }]);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  test("evicts least recently used entries when capacity exceeded", async () => {
    const fetchMock = vi.fn(async (start: number) => [{ id: start }]);
    const ds = createMockDataSource((start, _end) => fetchMock(start));
    const cached = withLRUCache(ds, 2);

    await cached.fetchRows({ startIndex: 0, endIndex: 1, sort: [] }); // cache 0
    await cached.fetchRows({ startIndex: 1, endIndex: 2, sort: [] }); // cache 1
    await cached.fetchRows({ startIndex: 2, endIndex: 3, sort: [] }); // cache 2, evict 0

    expect(fetchMock).toHaveBeenCalledTimes(3);

    // 0 should have been evicted; fetching again should hit underlying
    await cached.fetchRows({ startIndex: 0, endIndex: 1, sort: [] });
    expect(fetchMock).toHaveBeenCalledTimes(4);
  });

  test("preserves pageSize and rowCount from original data source", () => {
    const ds = createMockDataSource(async (start) => [{ id: start }]);
    const cached = withLRUCache(ds, 5);

    expect(cached.pageSize).toBe(50);
    expect(cached.rowCount).toBe(1000);
  });
});
