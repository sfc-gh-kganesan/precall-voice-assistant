import type { Sort } from "../types";
import { createLRUMap } from "./LRUMap";
/**
 * Parameters describing a row fetch request for a data source.
 *
 * @template T - The row/item type returned by the data source.
 */
interface FetchParam<T> {
  // inclusive
  startIndex: Readonly<number>;
  // not inclusive
  endIndex: Readonly<number>;
  sort: Readonly<Sort<T>[]>;
  // TODO add server side filter
}
/**
 * Minimal interface for a lazy-loading data source consumed by the DataTable.
 *
 * Implementations should paginate consistently with a fixed `pageSize`, and
 * report the total `rowCount`. The `fetchRows` function retrieves a contiguous
 * slice of rows in the half-open interval [startIndex, endIndex), optionally
 * ordered by the provided `sort` descriptors.
 *
 * @template T - The row/item type returned by the data source.
 */
interface DataSource<T> {
  pageSize: Readonly<number>;
  rowCount: Readonly<number>;
  fetchRows: (fetchParam: FetchParam<T>) => Promise<Readonly<T[]>>;
}
/**
 * Creates a simple in-memory array-backed data source.
 *
 * Notes/Assumptions:
 * - Sorting is not applied; the original array order is preserved.
 * - The requested range is treated as [startIndex, endIndex).
 * - Wrapped with an LRU cache to deduplicate concurrent/adjacent requests.
 *
 * @template T - The item type contained in `items`.
 * @param items - The full, in-memory collection of rows.
 * @param pageSize - Logical page size used by consumers. Default 100.
 * @returns A `DataSource<T>` that slices from the provided array.
 */
const createArrayDataSource = <T>(
  items: Readonly<T[]>,
  pageSize: Readonly<number> = 100,
): DataSource<T> => {
  return withLRUCache({
    pageSize,
    rowCount: items.length,
    fetchRows: (fetchParam: FetchParam<T>) => {
      const { startIndex, endIndex } = fetchParam;
      return Promise.resolve(items.slice(startIndex, endIndex));
    },
  });
};
/**
 * Internal queue item used to coordinate concurrency-limited fetches.
 *
 * @template T - The row/item type returned by the data source.
 */
interface QueueItem<T> {
  fetchParam: FetchParam<T>;
  promise: Promise<Readonly<T[]>>;
  resolve: (value: Readonly<T[]>) => void;
  reject: (reason?: unknown) => void;
}
/**
 * Wraps a `DataSource` to limit the number of concurrent `fetchRows` calls.
 *
 * Calls beyond the `concurrencyLimit` are queued and executed in FIFO order.
 * The wrapper preserves `pageSize` and `rowCount` from the original source.
 *
 * @template T - The row/item type returned by the data source.
 * @param dataSource - The underlying data source.
 * @param concurrencyLimit - Maximum in-flight fetch requests. Default 3.
 * @returns A `DataSource<T>` enforcing concurrent request limits.
 */
const withConcurrency = <T>(
  dataSource: DataSource<T>,
  concurrencyLimit: Readonly<number> = 3,
): DataSource<T> => {
  const { fetchRows: fetchRowsOriginal, pageSize, rowCount } = dataSource;

  const concurrentRequests = new Set<QueueItem<T>>();

  const queue: QueueItem<T>[] = [];

  const processNextFromQueue = () => {
    if (queue.length === 0) {
      return;
    }
    if (concurrentRequests.size >= concurrencyLimit) {
      return;
    }
    const itemsToQueue = Math.min(
      concurrencyLimit - concurrentRequests.size,
      queue.length,
    );
    for (let i = 0; i < itemsToQueue; i++) {
      const queuedItem = queue.shift();
      if (queuedItem) {
        concurrentRequests.add(queuedItem);
        fetchRowsOriginal(queuedItem.fetchParam)
          .then((result) => {
            queuedItem.resolve(result);
          })
          .catch((error) => {
            queuedItem.reject(error);
          })
          .finally(() => {
            concurrentRequests.delete(queuedItem);
            processNextFromQueue();
          });
      }
    }
  };

  const fetchWithConcurrency = (
    fetchParam: FetchParam<T>,
  ): Promise<Readonly<T[]>> => {
    let resolve: (value: Readonly<T[]>) => void = () => {};
    let reject: (reason?: unknown) => void = () => {};
    const deferredPromise = new Promise<Readonly<T[]>>((res, rej) => {
      resolve = res;
      reject = rej;
    });
    const queuedItem = {
      fetchParam,
      promise: deferredPromise,
      resolve,
      reject,
    };
    queue.push(queuedItem);
    processNextFromQueue();
    return queuedItem.promise;
  };

  return {
    fetchRows: fetchWithConcurrency,
    pageSize: pageSize,
    rowCount: rowCount,
  };
};

/**
 * Wraps a `DataSource` with retry logic using exponential backoff.
 *
 * If a `fetchRows` attempt fails, it is retried up to `retryCount` times.
 * Backoff delay is 2^attempts * 100ms (e.g., 200ms, 400ms, 800ms ...).
 * The wrapper preserves `pageSize` and `rowCount`.
 *
 * @template T - The row/item type returned by the data source.
 * @param dataSource - The underlying data source.
 * @param retryCount - Total number of attempts, including the first. Default 3.
 * @returns A `DataSource<T>` that retries transient failures.
 */
const withRetry = <T>(
  dataSource: DataSource<T>,
  retryCount: Readonly<number> = 3,
): DataSource<T> => {
  const { fetchRows: fetchRowsOriginal, pageSize, rowCount } = dataSource;
  const fetchWithRetry = async (
    fetchParam: FetchParam<T>,
  ): Promise<Readonly<T[]>> => {
    let attempts = 0;
    while (attempts < retryCount) {
      try {
        return await fetchRowsOriginal(fetchParam);
      } catch (error) {
        attempts++;
        if (attempts === retryCount) {
          throw error;
        }
        await new Promise((resolve) =>
          setTimeout(resolve, Math.pow(2, attempts) * 100),
        );
      }
    }
    throw new Error("Failed to load data after retries");
  };

  return {
    fetchRows: fetchWithRetry,
    pageSize: pageSize,
    rowCount: rowCount,
  };
};

/**
 * Wraps a `DataSource` with an LRU cache for `fetchRows` calls.
 *
 * Cache key is the `startIndex` of the requested range, assuming a fixed
 * `pageSize` and stable `sort` such that a page can be identified by its start.
 * This deduplicates concurrent requests for the same page by sharing the
 * underlying promise. The wrapper preserves `pageSize` and `rowCount`.
 *
 * Important: If callers vary `endIndex` or `sort` for the same `startIndex`,
 * results may be shared across logically different requests. Use only when the
 * calling pattern is page-based and consistent.
 *
 * @template T - The row/item type returned by the data source.
 * @param dataSource - The underlying data source.
 * @param cacheSize - Maximum number of cached entries. Default 1000.
 * @returns A `DataSource<T>` with LRU caching for page fetches.
 */
const withLRUCache = <T>(
  dataSource: DataSource<T>,
  cacheSize: Readonly<number> = 1000,
): DataSource<T> => {
  const { fetchRows: fetchRowsOriginal, pageSize, rowCount } = dataSource;
  const cache = createLRUMap<number, Promise<readonly T[]>>(cacheSize);
  const fetchWithLRUCache = (
    fetchParam: FetchParam<T>,
  ): Promise<Readonly<T[]>> => {
    let cached = cache.get(fetchParam.startIndex);
    if (!cached) {
      const promise = fetchRowsOriginal(fetchParam);
      cache.set(fetchParam.startIndex, promise);
      cached = promise;
    }
    return cached;
  };
  return {
    fetchRows: fetchWithLRUCache,
    pageSize: pageSize,
    rowCount: rowCount,
  };
};

/**
 * Composes a robust `DataSource` with concurrency-limiting, retry, and caching.
 *
 * The composition order is:
 * 1) Limit concurrency
 * 2) Add retries with exponential backoff
 * 3) Add LRU caching by page start index
 *
 * @template T - The row/item type returned by the data source.
 * @param dataSource - The underlying data source.
 * @param fetchConcurrency - Maximum in-flight requests. Default 3.
 * @param retryCount - Total attempts per request. Default 3.
 * @param cacheSize - Maximum number of cached pages. Default 1000.
 * @returns A composed `DataSource<T>` suitable for resilient UIs.
 */
const createRobustDataSource = <T>(
  dataSource: DataSource<T>,
  fetchConcurrency: Readonly<number> = 3,
  retryCount: Readonly<number> = 3,
  cacheSize: Readonly<number> = 1000,
): DataSource<T> => {
  return withLRUCache(
    withRetry(withConcurrency(dataSource, fetchConcurrency), retryCount),
    cacheSize,
  );
};
export {
  createArrayDataSource,
  createRobustDataSource,
  withConcurrency,
  withRetry,
  withLRUCache,
};

export type { DataSource };
