/**
 * Type definitions for column width calculations
 */
import type { DataRecord } from "@snowflake/stellar-data-tools";
import type { Column } from "@tanstack/react-table";

import type { ColumnDefinitionWithId } from "../types";

/**
 * Props for the useColumnWidths hook
 */
interface UseColumnWidthsProps<T extends DataRecord> {
  columnDefinitionsById: Record<string, ColumnDefinitionWithId<T, string>>;
  /** Array of column definitions with IDs */
  // columnDefinition: ColumnDefinitionWithId<Record<string, unknown>, string>[];
  /** Map of header widths by column ID */
  headerRenderedWidths: Record<string, number>;
  /** Map of content widths by column ID */
  contentRenderedWidths: Record<string, number>;
  /** Available width for center columns */
  centerAvailableWidth: number;

  /** Array of visible leaf columns */
  visibleLeafColumns: {
    left: Column<T, unknown>[];
    center: Column<T, unknown>[];
    right: Column<T, unknown>[];
  };
}

/**
 * Represents width information for a single column
 */
interface FieldWidth {
  /** Column ID */
  id: string;
  /** Column width in pixels */
  width: number;
}

/**
 * Calculates widths for a group of columns
 * @param columnIds - Array of column IDs to calculate widths for
 * @param columnDefinition - Array of column definitions
 * @param headerRenderedWidths - Map of header widths by column ID
 * @param contentRenderedWidths - Map of content widths by column ID
 * @param isContent - Whether these are center content columns that can flex
 * @param centerAvailableWidth - Available width for center columns to expand into
 * @returns Array of calculated column widths
 */
const calculateColumnWidths = <T extends DataRecord>(
  columnIds: string[],
  columnDefinitionsById: Record<string, ColumnDefinitionWithId<T, string>>,
  headerRenderedWidths: Record<string, number>,
  contentRenderedWidths: Record<string, number>,
  isContent: boolean = false,
  centerAvailableWidth?: number,
): FieldWidth[] => {
  const widths = columnIds.map((id) => {
    const column = columnDefinitionsById[id];
    const fixedWidth =
      typeof column?.width === "number" ? column.width : undefined;
    let width =
      fixedWidth ??
      Math.max(headerRenderedWidths[id] ?? 0, contentRenderedWidths[id] ?? 0);

    // Apply min width constraint if defined
    if (column?.minWidth !== undefined) {
      width = Math.max(width, column.minWidth);
    }

    // Apply max width constraint if defined
    if (column?.maxWidth !== undefined) {
      width = Math.min(width, column.maxWidth);
    }

    return {
      id,
      width,
      flex: column?.flex ?? 1,
      hasFixedWidth: fixedWidth !== undefined,
    };
  });

  if (isContent && centerAvailableWidth) {
    const totalWidth = widths.reduce((sum, col) => sum + col.width, 0);
    const extraWidth = Math.max(0, centerAvailableWidth - totalWidth);

    // Only distribute extra width if there are flexible columns
    const flexColumns = widths.filter((col) => !col.hasFixedWidth);
    const totalFlex = flexColumns.reduce((sum, col) => sum + col.flex, 0);

    if (totalFlex > 0) {
      widths.forEach((col) => {
        if (!col.hasFixedWidth) {
          const extraForColumn = (extraWidth * col.flex) / totalFlex;
          col.width += extraForColumn;
        }
      });
    }
  }

  return widths.map(({ id, width }) => ({ id, width }));
};

/**
 * Hook to calculate column widths for a data table
 * Handles fixed widths, min/max constraints, and flex distribution of remaining space
 * @param props - Configuration for width calculations
 * @returns Object containing calculated widths for left, center and right columns
 */
const useColumnWidths = <T extends DataRecord>(
  props: UseColumnWidthsProps<T>,
): FieldWidth[] => {
  const {
    columnDefinitionsById,
    visibleLeafColumns,
    headerRenderedWidths,
    contentRenderedWidths,
    centerAvailableWidth,
  } = props;
  const centerIds = visibleLeafColumns.center.map((column) => column.id);
  const pinLeft = visibleLeafColumns.left.map((column) => column.id);
  const pinRight = visibleLeafColumns.right.map((column) => column.id);
  const columnWidths: FieldWidth[] = [
    ...calculateColumnWidths(
      pinLeft,
      columnDefinitionsById,
      headerRenderedWidths,
      contentRenderedWidths,
    ),
    ...calculateColumnWidths(
      centerIds,
      columnDefinitionsById,
      headerRenderedWidths,
      contentRenderedWidths,
      true,
      centerAvailableWidth,
    ),
    ...calculateColumnWidths(
      pinRight,
      columnDefinitionsById,
      headerRenderedWidths,
      contentRenderedWidths,
    ),
  ];
  return columnWidths;
};
export { useColumnWidths };
export type { FieldWidth };
