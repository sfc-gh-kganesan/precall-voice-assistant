import type {
  FieldDefinition,
  FieldFormatter,
} from "@snowflake/stellar-data-tools";

import type { ChartSemanticColor, DataRecord, DataRecordValue } from "../types";

export type ChartField = FieldDefinition<DataRecord, string, DataRecordValue>;
export type ChartFieldFormatter = FieldFormatter<DataRecordValue, DataRecord>;

export type ChartDataType = "quantitative" | "temporal" | "ordinal" | "nominal";

export type GridPadding = "none" | "standard" | "spacious" | undefined;

export interface XAxisConfig
  extends Pick<ChartField, "field" | "fieldType" | "formatter"> {
  /**
   * The formatter for the tooltip heading.
   */
  tooltipFormatter?: ChartFieldFormatter | undefined;
  /**
   * The label shown below the x-axis.
   */
  label?: string | undefined;

  // Internally used props.
  dateFormatOptions?: Record<string, string | boolean> | undefined;
  tooltipDateFormatOptions?: Record<string, string | boolean> | undefined;
  timeUnit?: string | undefined;
  timeUnitStep?: number | undefined;
  isMonthYear?: boolean;
}

export interface YAxisConfig extends Pick<ChartField, "formatter"> {
  /**
   * The label shown next to the y-axis.
   */
  label?: string | undefined;
  /**
   * The domain of the y-axis.
   */
  domain?: [number, number] | undefined;
}

export type TooltipConfig = Pick<ChartField, "formatter">;

export const defaultXAxisConfig: XAxisConfig = {
  field: "",
  label: "",
};

export const defaultYAxisConfig: YAxisConfig = {
  label: "",
};

export const defaultTooltipConfig: TooltipConfig = {};

export interface ChartMetadata extends ChartField {
  type: ChartType;
  /**
   * The color variant of the chart.
   * @default "primary"
   */
  variant?: "primary" | "secondary" | "tertiary" | undefined;
  field2?: string | undefined;
  label2?: string | undefined;
  /**
   * The label of the chart shown in tooltip.
   */
  tooltipLabel?: string | undefined;
  tooltipLabel2?: string | undefined;
  /**
   * The stack id of the Barchart.
   */
  stackId?: string | undefined;
  /**
   * Whether to hide the chart and only show chart data in tooltip.
   */
  hide?: boolean | undefined;
  isReference?: boolean | undefined;
  /**
   * The semantic color of the chart (when using semantic palette).
   */
  semanticColor?: ChartSemanticColor | undefined;
  internalColor?: string | undefined;
  withFill?: boolean | undefined;
  /**
   * The padding of the grid for heat map.
   */
  gridPadding?: GridPadding | undefined;
}

// Common props that all charts (Line/Bar/Area/etc.) should support.
export type BaseChartProps = Pick<
  ChartMetadata,
  | "label"
  | "tooltipLabel"
  | "field"
  | "fieldType"
  | "formatter"
  | "variant"
  | "hide"
  | "semanticColor"
>;

export type ChartType = "line" | "bar" | "area" | "point" | "band" | "rect";

export interface ChartTooltipItem {
  label: string;
  value: string;
  chartType: ChartType;
  legendColor?: string | undefined;
}
