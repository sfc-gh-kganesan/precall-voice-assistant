import type { Locale } from "@snowflake/stellar-components";
import type { FieldDataType } from "@snowflake/stellar-data-tools";
import { dateTimeFormatter } from "@snowflake/stellar-data-tools";

import type { DataRecord, DataRecordValue } from "../types";
import type { ChartMetadata, XAxisConfig } from "./types";

const defaultDataFormatter = (
  value: DataRecordValue,
  type?: FieldDataType | undefined,
  locale?: Locale | undefined,
  dateFormatOptions?: Record<string, string | boolean> | undefined,
): string => {
  if (type === "date") {
    return dateTimeFormatter(value as string | number, {
      ...(dateFormatOptions ?? { month: "short", day: "numeric" }),
      locale: locale ?? "en-US",
    });
  }
  return value as string;
};

function generateId(prefix: string) {
  return `${prefix}${Math.random().toString(36).substring(2, 9)}`;
}

function getDataInterval(
  data: DataRecord[],
  field: string | number,
  fieldType: FieldDataType,
) {
  if (data.length < 2 || fieldType !== "date") {
    return 0;
  }
  const sortedDates = data
    .map((d) => {
      const date = d[field] as string | number;
      if (typeof date === "number") {
        return date;
      }
      return new Date(date).getTime();
    })
    .sort((a, b) => a - b);

  let interval = 0;
  for (let i = 1; i < sortedDates.length; i++) {
    const diff = (sortedDates[i] ?? 0) - (sortedDates[i - 1] ?? 0);
    if (diff > 0) {
      if (diff !== interval && interval > 0) {
        console.error(
          `Warning: Inconsistent data intervals are not supported in Balto charts. Found intervals: ${interval} and ${diff}.`,
        );
      }
      interval = diff;
    }
  }
  return interval;
}

function getDateFormatOptions(interval: number): {
  xAxis: Record<string, string | boolean> | undefined;
  tooltip: Record<string, string | boolean> | undefined;
  timeUnit: string | undefined;
  timeUnitStep: number | undefined;
  isMonthYear: boolean;
} {
  let dateFormat: Record<string, string | boolean> = {
    month: "short",
    day: "numeric",
  };
  let tooltipFormat: Record<string, string | boolean> = {
    month: "short",
    day: "numeric",
  };
  let timeUnit: string | undefined;
  let timeUnitStep: number | undefined;
  let isMonthYearFormat = false;

  const MINUTE_IN_MS = 60 * 1000;
  const HOUR_IN_MS = 60 * MINUTE_IN_MS;
  const DAY_IN_MS = 24 * HOUR_IN_MS;
  const MONTH_IN_MS = 28 * DAY_IN_MS;
  const YEAR_IN_MS = 365 * DAY_IN_MS;

  if (interval < MINUTE_IN_MS) {
    timeUnit = "yearmonthdatehoursminutesseconds";
    timeUnitStep = interval / 1000;
    dateFormat = { hour: "numeric", minute: "numeric", hour12: true };
    tooltipFormat = {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
    };
  } else if (interval < HOUR_IN_MS) {
    timeUnit = "yearmonthdatehoursminutes";
    timeUnitStep = interval / 1000 / 60;
    dateFormat = { hour: "numeric", hour12: true };
    tooltipFormat = {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    };
  } else if (interval < DAY_IN_MS) {
    timeUnit = "yearmonthdatehours";
    timeUnitStep = interval / 1000 / 60 / 60;
    dateFormat = { month: "short", day: "numeric" };
    tooltipFormat = {
      month: "short",
      day: "numeric",
      hour: "numeric",
    };
  } else if (interval < MONTH_IN_MS) {
    timeUnit = "yearmonthdate";
    timeUnitStep = interval / 1000 / 60 / 60 / 24;
    dateFormat = { month: "short", day: "numeric" };
    tooltipFormat = {
      month: "short",
      day: "numeric",
      year: "numeric",
    };
  } else if (interval < YEAR_IN_MS) {
    timeUnit = "yearmonth";
    timeUnitStep = 1; // Discretize to month.
    isMonthYearFormat = true;
    dateFormat = { month: "short", year: "numeric" };
    tooltipFormat = {
      month: "short",
      year: "numeric",
    };
  } else {
    timeUnit = "year";
    timeUnitStep = 1; // Discretize to year.
    dateFormat = { year: "numeric" };
    tooltipFormat = {
      year: "numeric",
    };
  }
  return {
    xAxis: dateFormat,
    tooltip: tooltipFormat,
    timeUnit: "binned" + timeUnit,
    timeUnitStep: timeUnitStep === 0 ? 1 : timeUnitStep,
    isMonthYear: isMonthYearFormat,
  };
}

function getFormattedXAxisLabels(
  sortedData: DataRecord[],
  xAxisConfig: XAxisConfig,
  locale: Locale,
) {
  const formattedData = sortedData.map((data, index) => {
    const v = data[xAxisConfig.field] as string | number;

    // If user provides a formatter, simplyuse it.
    if (xAxisConfig.formatter) {
      return xAxisConfig.formatter?.(v, data) ?? v;
    }

    // Otherwise, for non-date fields, return them as-is.
    if (xAxisConfig.fieldType !== "date") {
      return v;
    }

    // Otherwise, process date fields.
    let formatOptions = xAxisConfig.dateFormatOptions;

    // For month-year format, only show unique years for the first interval.
    if (xAxisConfig.isMonthYear && index > 0) {
      const previousValue = sortedData[index - 1]?.[xAxisConfig.field] as
        | string
        | number;
      const prevYear = new Date(previousValue).getFullYear();
      const currentYear = new Date(v).getFullYear();
      if (prevYear === currentYear) {
        formatOptions = { month: "short" };
      }
    }
    return dateTimeFormatter(new Date(v).toISOString(), {
      ...formatOptions,
      locale: locale ?? "en-US",
    });
  });

  // Remove duplicate labels.
  const results: string[] = [];
  results.push(formattedData[0] as string);
  for (let i = 1; i < formattedData.length; i++) {
    if (formattedData[i] !== formattedData[i - 1]) {
      results.push(formattedData[i] as string);
    } else {
      results.push("");
    }
  }

  return results;
}

function getBarCornerRadius(
  data: DataRecord[],
  charts: ChartMetadata[],
  chartWidth: number,
) {
  let cornerRadius = 0;
  const barCharts = charts.filter((chart) => chart.type === "bar");
  // Remove estimated width of the y-axis and gaps between bars.
  const binWidth = (chartWidth - 50 > 0 ? chartWidth - 50 : 0) / data.length;
  let numBarsPerBin = barCharts.length;
  const barStackIds = new Set<string>();
  barCharts.forEach((chart) => {
    if (chart.stackId) {
      if (barStackIds.has(chart.stackId)) {
        numBarsPerBin--;
      }
      barStackIds.add(chart.stackId);
    }
  });
  const barWidth = binWidth / (numBarsPerBin > 0 ? numBarsPerBin : 1);
  if (barWidth >= 50) {
    cornerRadius = 4;
  } else if (barWidth >= 10) {
    cornerRadius = 2;
  }
  return cornerRadius;
}

function getSortedDataByXAxis(data: DataRecord[], xAxisConfig: XAxisConfig) {
  return data.sort((dataA, dataB) => {
    const a = dataA[xAxisConfig.field] as string | number;
    const b = dataB[xAxisConfig.field] as string | number;
    if (typeof a === "number" && typeof b === "number") {
      return a - b;
    }
    return a > b ? 1 : -1;
  });
}

export {
  defaultDataFormatter,
  generateId,
  getDataInterval,
  getFormattedXAxisLabels,
  getDateFormatOptions,
  getSortedDataByXAxis,
  getBarCornerRadius,
};
