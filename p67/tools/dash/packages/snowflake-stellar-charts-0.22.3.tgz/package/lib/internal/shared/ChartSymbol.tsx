import * as stylex from "@stylexjs/stylex";
import { type HTMLAttributes, forwardRef } from "react";

import { type ChartType } from "../types";

interface ChartSymbolProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The type of the symbol.
   */
  type: ChartType;
  /**
   * The color of the symbol.
   */
  color: string | undefined;
}

const legendStyles = stylex.create({
  symbol: {
    borderRadius: 1,
    height: 8,
    width: 8,
  },
  lineSymbol: {
    borderRadius: 1,
    height: 2,
    width: 8,
  },
  pointSymbol: {
    borderRadius: 8,
    height: 8,
    width: 8,
  },
});

const ChartSymbol = forwardRef<HTMLDivElement, ChartSymbolProps>(
  (props, ref) => {
    const { type, color, ...otherProps } = props;

    return (
      <div
        {...stylex.props(
          legendStyles.symbol,
          type === "line" && legendStyles.lineSymbol,
          type === "point" && legendStyles.pointSymbol,
        )}
        {...otherProps}
        style={{
          backgroundColor: color,
        }}
        ref={ref}
      />
    );
  },
);
ChartSymbol.displayName = "ChartSymbol";

export { ChartSymbol };
