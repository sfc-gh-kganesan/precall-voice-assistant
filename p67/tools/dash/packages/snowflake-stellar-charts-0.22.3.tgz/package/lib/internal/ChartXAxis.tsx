import { useLayoutEffect } from "@react-aria/utils";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { baseDimension } from "@snowflake/balto-themes/baseDimension.stylex.js";
import {
  Flex,
  useBaltoContext,
  useDebouncedCallback,
  useMergedStyles,
} from "@snowflake/stellar-components";
import { tokens } from "@snowflake/stellar-tokens/tokens.stylex";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";
import { forwardRef, useMemo, useRef, useState } from "react";
import { useSharedResizeObserver } from "use-shared-resize-observer";

import { useChartContext } from "./ChartContext";
import { defaultXAxisConfig } from "./types";
import { getFormattedXAxisLabels } from "./utils";
import type { ChartLayout } from "../types";

type ChartXAxisProps = HTMLAttributes<HTMLDivElement> & {
  /**
   * The layout of the chart ("horizontal" or "vertical").
   */
  layout: ChartLayout;
  /**
   * The width of the chart.
   */
  width: number;
};

type LabelRect = Pick<DOMRect, "x" | "width" | "y" | "height">;

/**
 * A component to render an axis label.
 */
function AxisLabel({
  label,
  onGetSize,
  layout,
  totalLabels,
  index,
  hidden,
}: {
  /**
   * The label text.
   */
  label: string;
  /**
   * The layout of the chart ("horizontal" or "vertical").
   */
  layout: ChartLayout;
  /**
   * The total number of labels.
   */
  totalLabels: number;
  /**
   * The index of the label.
   */
  index: number;
  /**
   * Whether the label is hidden.
   */
  hidden: boolean;
  /**
   * A callback to get the size of the label.
   */
  onGetSize: (size: LabelRect) => void;
}) {
  const outerRef = useRef<HTMLDivElement>(null);
  const ref = useRef<HTMLDivElement>(null);
  const lastInnerSize = useRef<DOMRect | null>(null);

  useSharedResizeObserver({
    ref: ref,
    onUpdate: (entry) => {
      lastInnerSize.current = entry.target.getBoundingClientRect();
    },
  });
  useSharedResizeObserver({
    ref: outerRef,
    onUpdate: (entry) => {
      {
        const domRect = entry.target.getBoundingClientRect();

        onGetSize({
          x: domRect.x,
          y: domRect.y,
          height: domRect.height,
          width: lastInnerSize.current?.width ?? domRect.width,
        });
      }
    },
  });

  return (
    <div
      ref={outerRef}
      {...stylex.props(
        styles.label,
        layout === "horizontal" && styles.labelHorizontal,
        layout === "vertical" && styles.labelVertical,
      )}
      style={{
        ...(hidden ? { visibility: "hidden" } : {}),
        ...(layout === "vertical"
          ? {
              height: `calc(100% / ${totalLabels})`,
            }
          : {
              position: "absolute",
              width: `calc(100% / ${totalLabels})`,
              left: `calc(${index} * (100% / ${totalLabels}))`,
            }),
      }}
    >
      <div ref={ref} style={{ minWidth: "fit-content", width: "100%" }}>
        {label}
      </div>
    </div>
  );
}

const styles = stylex.create({
  container: {
    margin: 0,
    padding: 0,
  },
  labelContainerHorizontal: {
    height: tokens["size-2xs"],
    transform: "translate(1px, -2px)", // Maintain same x-axis spacing & position compared to when using Vega-Lite's xAxis.
  },
  label: {
    color: baltoTheme.reusableTextSecondary,
    fontSize: baseDimension.textSmall,
    margin: 0,
    padding: 0,
    textAlign: "center",
    whiteSpace: "nowrap",
  },
  labelHorizontal: {
    lineHeight: "17px", // Maintain same chart size compared to when using Vega-Lite's xAxis.
  },
  labelVertical: {
    alignContent: "center",
    flexGrow: 1,
    textAlign: "end",
  },
  title: {
    color: baltoTheme.reusableTextSecondary,
    fontSize: baseDimension.textRegular,
    lineHeight: "18px",
  },
  titleHorizontal: {
    transform: "translate(2px, -3px)",
  },
  titleVertical: {
    transform: "rotate(180deg)",
    writingMode: "sideways-rl",
  },
});

/**
 * Check if two labels are overlapping.
 */
function isOverlapping(
  label: LabelRect | undefined,
  nextLabel: LabelRect | undefined,
  layout: ChartLayout,
) {
  if (layout === "vertical") {
    return nextLabel && label && label.y + label.height > nextLabel.y;
  }

  return nextLabel && label && label.x + label.width > nextLabel.x;
}

const ChartXAxis = forwardRef<HTMLDivElement, ChartXAxisProps>(
  (props, forwardedRef) => {
    const { locale } = useBaltoContext();
    const { layout, className, style, width, ...otherProps } = props;
    const { data, xAxisConfig } = useChartContext("ChartXAxis");
    const labelSizeMapRef = useRef<LabelRect[]>([]);

    const formattedLabels = useMemo(() => {
      return getFormattedXAxisLabels(
        data ?? [],
        xAxisConfig ?? defaultXAxisConfig,
        locale,
      ).filter((label) => label !== "");
    }, [data, xAxisConfig, locale]);
    const [hiddenLabelIndices, setHiddenLabelIndices] = useState<number[]>([]);
    const containerRef = useRef<HTMLDivElement>(null);

    const updateHiddenLabelIndices = useDebouncedCallback((): void => {
      const hasOverlap = formattedLabels.some((_, index) =>
        isOverlapping(
          labelSizeMapRef.current[index],
          labelSizeMapRef.current[index + 1],
          layout,
        ),
      );

      if (!hasOverlap) {
        setHiddenLabelIndices([]);
        return;
      }

      let visibleLabelIndices = formattedLabels.map((_, i) => i);

      do {
        visibleLabelIndices = visibleLabelIndices.filter(
          (_visibleIndex, index) => index % 2 === 0,
        );
      } while (
        visibleLabelIndices.some((_visibleIndex, visibleLabelIndexIndex) => {
          const nextVisibleIndex =
            visibleLabelIndices[visibleLabelIndexIndex + 1];
          const nextLabel = nextVisibleIndex
            ? labelSizeMapRef.current[nextVisibleIndex]
            : undefined;

          return isOverlapping(
            labelSizeMapRef.current[_visibleIndex],
            nextLabel,
            layout,
          );
        })
      );

      setHiddenLabelIndices(
        formattedLabels
          .map((_label, i) => i)
          .filter((i) => !visibleLabelIndices.includes(i)),
      );
    }, 150);

    useLayoutEffect(() => {
      const timeoutId = updateHiddenLabelIndices();

      return () => {
        clearTimeout(timeoutId);
      };
    }, [formattedLabels, layout, updateHiddenLabelIndices, width]);

    const styleProps = useMergedStyles(
      className,
      style,
      stylex.props(styles.container),
    );
    return (
      <Flex
        direction={layout === "vertical" ? "row-reverse" : "column"}
        gap="1_5x"
        {...styleProps}
        {...otherProps}
        ref={forwardedRef}
      >
        <Flex
          direction={layout === "vertical" ? "column" : "row"}
          gap="0x"
          {...stylex.props(
            layout === "horizontal" && styles.labelContainerHorizontal,
          )}
          ref={containerRef}
        >
          {formattedLabels.map((label, i) => (
            <AxisLabel
              key={i}
              label={`${label}`}
              layout={layout}
              index={i}
              hidden={hiddenLabelIndices.includes(i)}
              totalLabels={formattedLabels.length}
              onGetSize={(size) => {
                labelSizeMapRef.current[i] = size;
              }}
            />
          ))}
        </Flex>
        {xAxisConfig?.label && (
          <Flex
            direction="row"
            gap="0x"
            align="center"
            justify="center"
            {...stylex.props(
              styles.title,
              layout === "horizontal" && styles.titleHorizontal,
              layout === "vertical" && styles.titleVertical,
            )}
          >
            {xAxisConfig?.label}
          </Flex>
        )}
      </Flex>
    );
  },
);
ChartXAxis.displayName = "ChartXAxis";

export type { ChartXAxisProps };
export { ChartXAxis };
