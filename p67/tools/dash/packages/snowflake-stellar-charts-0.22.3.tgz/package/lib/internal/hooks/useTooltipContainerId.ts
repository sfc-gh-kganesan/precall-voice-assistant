import { useBaltoContext } from "@snowflake/stellar-components";
import { useEffect } from "react";

// TODO: change to "chart-tooltip-container" after the following issue is fixed:
// https://github.com/vega/vega-tooltip/issues/1018
const TOOLTIP_CONTAINER_ID = "vg-tooltip-element";

// Vega-tooltip always creates its tooltip container under document.body.
// This hook creates/moves such tooltip container under the Balto portal and
// removes vega-tooltip's default styles.
const useTooltipContainerId = () => {
  const { portalContainer } = useBaltoContext();
  useEffect(() => {
    // Check if container already exists
    let container = document.getElementById(TOOLTIP_CONTAINER_ID);

    // If it doesn't exist, create it.
    if (!container) {
      container = document.createElement("div");
      container.id = TOOLTIP_CONTAINER_ID;
    }

    // Remove default tooltip container styles from vega-tooltip.
    container.style.font = "inherit";
    container.style.padding = "0";
    container.style.margin = "0";
    container.style.border = "none";
    container.style.outline = "none";
    container.style.boxShadow = "none";
    container.style.borderRadius = "0";
    container.style.color = "inherit";
    container.style.backgroundColor = "transparent";

    // Append (or move) the tooltip container under Balto portal.
    if (portalContainer) {
      portalContainer.appendChild(container);
    }

    return () => {};
  }, [portalContainer]);

  return TOOLTIP_CONTAINER_ID;
};

export { useTooltipContainerId };
