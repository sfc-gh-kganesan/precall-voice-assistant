import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";

import { datavizTheme } from "../generated/datavizTheme.stylex";
import type { ChartSemanticColor } from "../types";

export const chartColors = [
  baltoTheme.chart_1,
  baltoTheme.chart_2,
  baltoTheme.chart_3,
  baltoTheme.chart_4,
  baltoTheme.chart_5,
  baltoTheme.chart_6,
  baltoTheme.chart_7,
  baltoTheme.chart_8,
];

export const semanticChartColors: Record<ChartSemanticColor, string> = {
  success: datavizTheme.semanticSuccess,
  caution: datavizTheme.semanticCaution,
  critical: datavizTheme.semanticCritical,
  info: datavizTheme.semanticInfo,
  neutral: datavizTheme.semanticNeutral,
  active: datavizTheme.semanticActive,
};
