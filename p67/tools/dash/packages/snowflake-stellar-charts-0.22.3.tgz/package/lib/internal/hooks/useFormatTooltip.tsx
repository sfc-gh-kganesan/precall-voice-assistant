import { useEffectEvent } from "@react-aria/utils";
import { useBaltoContext } from "@snowflake/stellar-components";
import { renderToStaticMarkup } from "react-dom/server";

import type { DataRecord, DataRecordValue } from "../../types";
import { ChartTooltip } from "../ChartTooltip";
import type { ChartMetadata, ChartTooltipItem, XAxisConfig } from "../types";
import { defaultDataFormatter } from "../utils";

const useFormatTooltip = (
  charts: ChartMetadata[],
  xAxisConfig: XAxisConfig,
) => {
  const { locale } = useBaltoContext();

  return useEffectEvent((value: DataRecord) => {
    const getTooltipItem = (chart: ChartMetadata): ChartTooltipItem => {
      const key = chart.field as string;
      const v = value[key] as string;
      const val = chart.formatter?.(v, value) ?? v;
      let finalValue = val;
      if (chart.field2) {
        const key2 = chart.field2 as string;
        const v2 = value[key2] as string;
        const val2 = chart.formatter?.(v2, value) ?? v2;
        finalValue = `${val} - ${val2}`;
      }
      return {
        label: chart.tooltipLabel ?? chart.label ?? key,
        value: finalValue,
        chartType: chart.type,
        legendColor: chart.internalColor,
      };
    };

    const tooltipItems: ChartTooltipItem[] = [];
    for (const chart of charts) {
      // If tooltip is for points (e.g. Scatter chart), the chart field must match the key field to be shown in tooltip.
      if (value["tooltipType"] === "point" && chart.field !== value["key"]) {
        continue;
      }
      const item = getTooltipItem(chart);
      if (item.value != null) {
        tooltipItems.push(item);
      }
    }

    // Format tooltip heading.
    const heading =
      xAxisConfig.tooltipFormatter?.(
        value[xAxisConfig.field] as DataRecordValue,
      ) ??
      defaultDataFormatter(
        value[xAxisConfig.field] as DataRecordValue,
        xAxisConfig.fieldType,
        locale,
        xAxisConfig.tooltipDateFormatOptions,
      );

    // This server-side function is still available to use in client-side in React 17/18.
    // Once our minimum supported version is bumped to React 18, we can use the following instead:
    // import { createRoot } from 'react-dom/client';
    return renderToStaticMarkup(
      <ChartTooltip heading={heading} items={tooltipItems} />,
    );
  });
};

export { useFormatTooltip };
