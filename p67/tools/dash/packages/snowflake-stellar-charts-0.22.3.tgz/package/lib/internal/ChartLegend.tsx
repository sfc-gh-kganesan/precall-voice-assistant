import type { ControlledComponent } from "@snowflake/stellar-components";
import { Button, Flex, SingleLine } from "@snowflake/stellar-components";
import { tokens } from "@snowflake/stellar-tokens/tokens.stylex";
import * as stylex from "@stylexjs/stylex";
import { forwardRef } from "react";

import type { ChartMetadata } from "./types";
import type { ChartState } from "../types";
import { ChartSymbol } from "./shared/ChartSymbol";

interface ChartLegendProps extends ControlledComponent<"state", ChartState> {
  /**
   * The charts of the legend.
   */
  charts: ChartMetadata[];
}

const styles = stylex.create({
  container: {
    gap: `${tokens["space-gap-2xs"]} ${tokens["space-gap-sm"]}`,
    marginBlockEnd: tokens["space-vertical-2xs"],
  },
  legendContainer: {
    height: tokens["size-sm"], // Ensure same height between interactive and non-interactive labels.
    padding: `${tokens["space-vertical-3xs"]} ${tokens["space-horizontal-xs"]} !important`,
  },
  legendContainerUnselected: {
    opacity: 0.4,
  },
});

const ChartLegend = forwardRef<HTMLDivElement, ChartLegendProps>(
  (props, forwardedRef) => {
    const { charts, state, onStateChange, ...otherProps } = props;

    return (
      <Flex
        direction="row"
        wrap="wrap"
        {...stylex.props(styles.container)}
        {...otherProps}
        ref={forwardedRef}
      >
        {charts
          .filter((chart) => !chart.hide)
          .map((chart) => {
            const content = [
              <ChartSymbol
                key="chart-symbol"
                type={chart.type}
                color={chart.internalColor}
              />,
              <SingleLine key="single-line" variant="secondary" size="small">
                {chart.label ?? chart.field}
              </SingleLine>,
            ];
            return onStateChange === undefined ? (
              <Flex
                align="center"
                gap="0_5x"
                key={chart.id}
                {...stylex.props(styles.legendContainer)}
              >
                {content}
              </Flex>
            ) : (
              <Button
                key={chart.id}
                variant="tertiary"
                size="small"
                {...stylex.props(
                  styles.legendContainer,
                  state?.selection &&
                    state.selection.series !== undefined &&
                    state.selection.series.length > 0 &&
                    state.selection.series.includes(chart.field) === false &&
                    styles.legendContainerUnselected,
                )}
                onClick={() => {
                  const selection = {
                    ...state?.selection,
                    xAxis: undefined, // Reset axis selection when clicking on a legend item.
                    yAxis: undefined,
                  };
                  // If the legend item is already selected, unselect it.
                  if (state?.selection?.series?.includes(chart.field)) {
                    const updatedSeries = state.selection.series.filter(
                      (item) => item !== chart.field,
                    );
                    // If all legend items are deselected, reset to undefined (all selected).
                    selection.series =
                      updatedSeries.length > 0 ? updatedSeries : undefined;
                  } else {
                    selection.series = [
                      ...(state?.selection.series ?? []),
                      chart.field,
                    ];
                  }
                  onStateChange?.({ ...state, selection: selection });
                }}
              >
                {content}
              </Button>
            );
          })}
      </Flex>
    );
  },
);
ChartLegend.displayName = "ChartLegend";

export type { ChartLegendProps };
export { ChartLegend };
