import { themeDarkStyles, themeLightStyles } from "@snowflake/balto-tokens";
import type { BaltoColorScheme } from "@snowflake/stellar-components";
import { useBaltoContext } from "@snowflake/stellar-components";
import type { FieldDataType } from "@snowflake/stellar-data-tools";
import { useMemo } from "react";
import { expressionFunction } from "vega";
import type { TopLevelSpec } from "vega-lite";

import type {
  ChartInteractionType,
  ChartLayout,
  ChartPalette,
  ChartState,
  ChartVariant,
  DataRecord,
  DataRecordValue,
} from "../../types";
import type {
  ChartDataType,
  ChartMetadata,
  XAxisConfig,
  YAxisConfig,
} from "../types";
import { useVegaLiteConfig } from "./useVegaLiteConfig";
import { datavizDarkStyles } from "../../generated/datavizDark";
import { datavizLightStyles } from "../../generated/datavizLight";
import { getBarCornerRadius } from "../utils";

/**
 * Top-level spec for rendering charts in Vega-Lite.
 */
const useVegaLiteSpec = (
  chartId: string,
  chartWidth: number,
  chartViewWidth: number,
  chartViewHeight: number,
  variant: ChartVariant,
  layout: ChartLayout,
  palette: ChartPalette,
  sortedData: DataRecord[],
  allCharts: ChartMetadata[],
  xAxisConfig: XAxisConfig,
  yAxisConfig: YAxisConfig,
  state: ChartState,
  interactionType: ChartInteractionType,
): TopLevelSpec => {
  const { colorScheme } = useBaltoContext();
  const vegaConfig = useVegaLiteConfig(allCharts, palette);
  const [dataMin, dataMax] = getMinMax(sortedData, allCharts);

  return useMemo(() => {
    const defaultYAxisDomain =
      dataMin === 0 && dataMax === 0 ? [0, 1] : undefined; // undefined to let Vega-Lite infer the domain.
    const charts = allCharts.filter(
      (chart) => !chart.isReference && !chart.hide,
    );
    const referenceCharts = allCharts.filter((chart) => chart.isReference);
    const hasBarChart = charts.some((chart) => chart.type === "bar");
    const xAxisFieldType = getChartFieldType(xAxisConfig.fieldType ?? "date");
    const lineOrAreaChartPadding =
      sortedData.length > 0 && !hasBarChart && xAxisFieldType === "temporal"
        ? chartViewWidth / sortedData.length / 2
        : 0;
    const barAndBrushCornerRadius = getBarCornerRadius(
      sortedData,
      charts,
      chartWidth,
    );

    const xAxisFormatterId = `${chartId}XAxisFormaterFn`;
    const yAxisFormatterId = `${chartId}YAxisFormaterFn`;

    registerFormatters(
      xAxisConfig,
      yAxisConfig,
      xAxisFormatterId,
      yAxisFormatterId,
      dataMin === 0 && dataMax === 0,
    );

    return {
      $schema: "https://vega.github.io/schema/vega-lite/v6.json",
      width: "container",
      height: "container",
      data: { values: sortedData },
      encoding: {
        [getEncodingAxisKey("x", layout)]: {
          field: xAxisConfig.field as string,
          type: xAxisFieldType,
          sort:
            layout === "vertical" && xAxisFieldType === "temporal"
              ? "descending"
              : undefined,
          timeUnit:
            xAxisFieldType === "temporal"
              ? {
                  unit: `binned${xAxisConfig.timeUnit}`,
                  step: xAxisConfig.timeUnitStep,
                  binned: true, // Do not transform/re-bin the data.
                }
              : null,
          title: xAxisConfig.label ?? null,
          scale:
            lineOrAreaChartPadding > 0
              ? { padding: lineOrAreaChartPadding }
              : undefined,
          axis:
            variant === "minimal" || xAxisFieldType !== "quantitative"
              ? null // Remove Vega-Lite's xAxis and use our own for non-number xAxis fields.
              : {
                  labelAngle: 0,
                  labelExpr: `${xAxisFormatterId}(datum.value, datum.index)`,
                },
        },
        [getEncodingAxisKey("y", layout)]: {
          title: yAxisConfig?.label ?? null,
          axis:
            variant === "minimal"
              ? null
              : {
                  labelExpr: `${yAxisFormatterId}(datum.value)`,
                },
          scale: {
            // TODO(APPS-56048): Improve as we see more use cases around domain.
            domain: yAxisConfig.domain ?? defaultYAxisDomain,
          },
        },
        color: {
          legend: null, // Remove Vega-Lite legend and use our own.
        },
      },
      layer: [
        ...getBackgroundLayers(
          variant,
          colorScheme,
          charts,
          xAxisConfig,
          state,
          layout,
          interactionType,
          barAndBrushCornerRadius,
        ),
        ...getChartLayers(
          sortedData,
          variant,
          palette,
          colorScheme,
          state,
          layout,
          charts,
          referenceCharts,
          xAxisConfig,
          interactionType,
          barAndBrushCornerRadius,
          chartViewWidth,
          chartViewHeight,
        ),
        ...getForegroundLayers(layout, colorScheme, referenceCharts),
      ],

      config: vegaConfig,
    } as TopLevelSpec;
  }, [
    allCharts,
    chartId,
    palette,
    chartViewWidth,
    chartViewHeight,
    chartWidth,
    colorScheme,
    dataMax,
    dataMin,
    interactionType,
    layout,
    sortedData,
    state,
    variant,
    vegaConfig,
    xAxisConfig,
    yAxisConfig,
  ]);
};

function getChartLayers(
  sortedData: DataRecord[],
  variant: ChartVariant,
  palette: ChartPalette,
  colorScheme: BaltoColorScheme,
  state: ChartState,
  layout: ChartLayout,
  charts: ChartMetadata[],
  referenceCharts: ChartMetadata[],
  xAxisConfig: XAxisConfig,
  interactionType: ChartInteractionType,
  barAndBrushCornerRadius: number,
  chartViewWidth: number,
  chartViewHeight: number,
) {
  const datavizStyles =
    colorScheme === "dark" ? datavizDarkStyles : datavizLightStyles;
  // Group charts by type
  const barCharts = charts.filter((chart) => chart.type === "bar");
  const areaCharts = charts.filter((chart) => chart.type === "area");
  const lineCharts = charts.filter((chart) => chart.type === "line");
  const scatterCharts = charts.filter((chart) => chart.type === "point");
  const heatMapCharts = charts.filter((chart) => chart.type === "rect");
  const referenceBandCharts = referenceCharts.filter(
    (chart) => chart.type === "band",
  );

  const layers = [];

  // Add reference band charts
  if (referenceBandCharts.length > 0) {
    layers.push(
      ...referenceBandCharts
        .map((chart) => {
          const type = getChartFieldType(chart.fieldType ?? "number");
          const referenceBandLayer = {
            mark: { type: "area" as const }, // Not using "errorband" as it doesn't have tooltip and we don't control its opacity.
            encoding: {
              [getEncodingAxisKey("y", layout)]: {
                field: chart.field as string,
                type,
              },
              [getEncodingAxisKey("y", layout, true)]: {
                field: chart.field2,
                type,
              },
              color: { value: datavizStyles.referenceBand },
              opacity:
                interactionType === "brush"
                  ? {
                      condition: [{ param: "brushX", value: 0.15 }],
                      value: 0.2,
                    }
                  : { value: 0.3 },
            },
          };
          if (interactionType === "brush") {
            const brushLayer = {
              ...referenceBandLayer,
              transform: [{ filter: { param: "brushX" } }],
            };
            return [referenceBandLayer, brushLayer];
          }
          return referenceBandLayer;
        })
        .flat(),
    );
  }

  // Create a single layer for all bar charts so they can be stacked, grouped and mixed.
  if (barCharts.length > 0) {
    layers.push({
      mark: {
        type: "bar" as const,
        cornerRadiusEnd: barAndBrushCornerRadius,
      },
      encoding: {
        [getEncodingAxisKey("y", layout)]: {
          field: "value",
          type: getChartFieldType("number"),
          stack: true,
        },
        [`${getEncodingAxisKey("x", layout)}Offset`]: {
          field: "stackId", // Group bars by stackId.
        },
        color: {
          condition: barCharts.map((chart) => ({
            test: `datum.key === '${chart.field}'`,
            value: chart.internalColor as string,
          })),
          value: null,
        },
        opacity:
          interactionType === "select"
            ? {
                condition: [
                  { param: "clickX", value: 1 }, // Filter for XAxis.
                  {
                    test: getSelectedSeriesMatcher(state, "datum.key"), // Filter for series.
                    value: 1,
                  },
                ],
                value: 0.4,
              }
            : interactionType === "brush"
              ? {
                  condition: [{ param: "brushX", value: 1 }],
                  value: 0.4,
                }
              : undefined,
      },
      transform: [
        { fold: barCharts.map((chart) => chart.field as string) },
        { filter: "datum.value != null" }, // Filter out undefined/null values after folding.
        {
          // Generate a stackId for each bar chart so they can be grouped via the xOffset/yOffset field.
          // Use field if no stackId is provided so bars are grouped by default.
          calculate:
            barCharts
              .map(
                (chart) =>
                  `datum.key === '${chart.field}' ? '${chart.stackId ?? chart.field}' : `,
              )
              .join("") + "'none'",
          as: "stackId",
        },
      ],
    });
  }

  // Add area charts
  if (areaCharts.length > 0) {
    const nonRangedAreaCharts = areaCharts.filter(
      (c) => c.field2 === undefined,
    );
    const rangedAreaCharts = areaCharts.filter((c) => c.field2 !== undefined);
    if (nonRangedAreaCharts.length > 0 && rangedAreaCharts.length > 0) {
      throw new Error("Stacked and non-stacked area charts cannot be mixed.");
    }
    const areaChartOpacity = 0.8;
    const areaChartOpacityConfig =
      interactionType === "brush"
        ? {
            condition: [{ param: "brushX", value: areaChartOpacity }],
            value: 0.4,
          }
        : { value: areaChartOpacity };
    const areaChartBrushOpacity = state.selection.xAxisRange
      ? areaChartOpacity
      : 0;

    // Non-ranged (area charts without field2) are stacked by default and combined into a single layer.
    if (nonRangedAreaCharts.length > 0) {
      const stackedAreaChartLayer = {
        mark: { type: "area" as const },
        encoding: {
          [getEncodingAxisKey("y", layout)]: {
            field: "value",
            type: getChartFieldType("number"),
          },
          color: {
            condition: nonRangedAreaCharts.map((chart) => ({
              test: `datum.key === '${chart.field}'`,
              value: chart.internalColor as string,
            })),
            value: null,
          },
          order: { field: "stackOrder" },
          opacity: areaChartOpacityConfig,
        },
        transform: [
          { fold: nonRangedAreaCharts.map((chart) => chart.field as string) },
          {
            // Attach index to datum for stacking them from bottom to up.
            calculate:
              nonRangedAreaCharts
                .map((chart, i) => `datum.key === '${chart.field}' ? '${i}' : `)
                .join("") + "null",
            as: "stackOrder",
          },
        ],
      };
      layers.push(stackedAreaChartLayer);
      if (interactionType === "brush") {
        const brushLayer = {
          ...stackedAreaChartLayer,
          encoding: {
            ...stackedAreaChartLayer.encoding,
            opacity: { value: areaChartBrushOpacity },
          },
          transform: [
            ...stackedAreaChartLayer.transform,
            { filter: { param: "brushX" } },
          ],
        };
        layers.push(brushLayer);
      }
    }

    // Ranged (area charts with field2) are rendered as individual layers.
    if (rangedAreaCharts.length > 0) {
      layers.push(
        ...rangedAreaCharts
          .map((chart) => {
            const type = getChartFieldType(chart.fieldType ?? "number");
            const areaChartLayer = {
              mark: { type: "area" as const },
              encoding: {
                [getEncodingAxisKey("y", layout)]: { field: chart.field, type },
                [getEncodingAxisKey("y", layout, true)]: {
                  field: chart.field2,
                  type,
                },
                color: { value: chart.internalColor },
                opacity: areaChartOpacityConfig,
              },
            };
            if (interactionType === "brush") {
              const brushLayer = {
                ...areaChartLayer,
                encoding: {
                  ...areaChartLayer.encoding,
                  opacity: { value: areaChartBrushOpacity },
                },
                transform: [{ filter: { param: "brushX" } }],
              };
              return [areaChartLayer, brushLayer];
            }
            return areaChartLayer;
          })
          .flat(),
      );
    }
  }

  // Add line charts
  if (lineCharts.length > 0) {
    const hasWithFill = lineCharts.some((chart) => chart.withFill);
    if (hasWithFill && charts.length > 1) {
      throw new Error("withFill can only be used with a single Line chart.");
    }
    const hoverDotLayer = {
      mark: {
        type: "point" as const,
        shape: "circle",
        filled: true,
        size: 64, // 8px line hover dot size.
        opacity: 1,
      },
      encoding: {
        opacity: {
          condition: { value: 1, param: "hoverX", empty: false },
          value: 0,
        },
      },
    };
    layers.push(
      ...lineCharts
        .map((chart) => {
          const discreteXAxisValues = getLineChartdiscreteXAxisValues(
            sortedData,
            chart,
            xAxisConfig,
          );
          const type = getChartFieldType(chart.fieldType ?? "number");
          const lineChartLayer = {
            encoding: {
              [getEncodingAxisKey("y", layout)]: { field: chart.field, type },
              color: { value: chart.internalColor },
              opacity:
                interactionType === "select"
                  ? {
                      condition: [
                        {
                          test: getSelectedSeriesMatcher(
                            state,
                            `'${chart.field}'`,
                          ), // Filter for series.
                          value: 1,
                        },
                      ],
                      value: 0.4,
                    }
                  : interactionType === "brush"
                    ? {
                        condition: [{ param: "brushX", value: 1 }],
                        value: 0.4,
                      }
                    : undefined,
              undefined,
            },
            layer: [
              ...(chart.withFill
                ? [
                    {
                      encoding: {
                        color: {}, // Remove inherited fixed color to customize the shadow color as a gradient.
                        opacity: { value: 0.7 },
                      },
                      mark: {
                        type: "area" as const,
                        line: { color: "transparent" },
                        color: {
                          x1: 1,
                          y1: 1,
                          x2: 1,
                          y2: 0,
                          gradient: "linear" as const,
                          stops: [
                            {
                              offset: 0,
                              color: `${chart.internalColor}14`, // ~7.8% opacity of chart color.
                            },
                            {
                              offset: 1,
                              color: `${chart.internalColor}cc`, // 80% opacity of chart color.
                            },
                          ],
                        },
                      },
                    },
                  ]
                : []),
              { mark: { type: "line" as const, strokeCap: "round" as const } },
              // Render discrete points on the line chart as individual points.
              ...(discreteXAxisValues.length > 0
                ? [
                    {
                      mark: {
                        type: "point" as const,
                        shape: "circle",
                        filled: true,
                        size: 36, // 6px discrete point size.
                        opacity: 1,
                      },
                      transform: [
                        {
                          filter: {
                            field: xAxisConfig.field as string,
                            oneOf: discreteXAxisValues,
                          },
                        },
                      ],
                    },
                  ]
                : []),
              // Render an additional dot layer shown on hover.
              ...(variant !== "minimal" ? [hoverDotLayer] : []),
            ],
          };
          if (interactionType === "brush") {
            // Add a "filtered" layer that is only visible when the brush is active.
            const brushLayer = {
              ...lineChartLayer,
              transform: [{ filter: { param: "brushX" } }],
            };
            return [lineChartLayer, brushLayer];
          }
          return lineChartLayer;
        })
        .flat(),
    );
  }

  // Add all scatter charts to a single layer to allow exclusive interaction.
  if (scatterCharts.length > 0) {
    const hoverBackgroundLayer = {
      mark: {
        type: "point" as const,
        size: 100, // 10px scatter point hover ringsize.
        tooltip: { content: "data" as const },
      },
      encoding: {
        opacity: {
          condition: { value: 1, param: "hoverXY", empty: false },
          value: 0,
        },
        strokeWidth: { value: 5 },
        stroke: { value: datavizStyles.hoverBackground },
      },
      params: [
        {
          name: "hoverXY",
          select: {
            type: "point" as const,
            nearest:
              lineCharts.length === 0 &&
              areaCharts.length === 0 &&
              barCharts.length === 0,
            on: "pointerover",
            clear: "pointerout",
            encodings: ["x", "y"],
          },
        },
        {
          name: "clickXY",
          select: {
            type: "point" as const,
            on: "click",
            encodings: ["x", "y"],
          },
          value: getSelectionValue(state, xAxisConfig),
        },
        ...[
          interactionType === "brush"
            ? {
                name: "brushXY",
                select: {
                  type: "interval" as const,
                  encodings: [
                    getEncodingAxisKey("x", layout),
                    getEncodingAxisKey("y", layout),
                  ],
                  mark: getBrushMarkStyle(colorScheme, barAndBrushCornerRadius),
                  zoom: false, // TODO(APPS-58837): Support zooming.
                },
                value: {
                  x: state.selection.xAxisRange ?? [],
                  y: state.selection.yAxisRange ?? [],
                },
              }
            : [],
        ],
      ],
    };

    layers.push({
      encoding: {
        [getEncodingAxisKey("y", layout)]: {
          field: "value",
          type: getChartFieldType("number"),
        },
        color: {
          condition: scatterCharts.map((chart) => ({
            test: `datum.internalColor === '${chart.internalColor}'`,
            value: chart.internalColor as string,
          })),
          value: null,
        },
        opacity:
          interactionType === "select"
            ? {
                condition: [
                  { param: "clickXY", value: 1 }, // Dim unselected points.
                  {
                    test: getSelectedSeriesMatcher(state, "datum.key"), // Filter for series.
                    value: 1,
                  },
                ],
                value: 0.4,
              }
            : interactionType === "brush"
              ? {
                  condition: [{ param: "brushXY", value: 1 }], // Dim unbrushed points.
                  value: 0.4,
                }
              : undefined,
      },
      mark: "circle" as const,
      layer: [
        ...(variant !== "minimal" ? [hoverBackgroundLayer] : []),
        {
          mark: {
            type: "circle" as const,
            size: 36, // 6px scatter point size.
            opacity: 1,
          },
        },
      ],
      // Fold all scatter charts into a single layer for nearest hoverXY to work across them.
      transform: [
        { fold: scatterCharts.map((chart) => chart.field as string) },
        {
          calculate: "'point'",
          as: "tooltipType", // Mark the tooltip data for special handling in useFormatTooltip.
        },
        {
          // Attach color to datum for assigning it to each scatter chart.
          calculate:
            scatterCharts
              .map(
                (chart) =>
                  `datum.key === '${chart.field}' ? '${chart.internalColor as string}' : `,
              )
              .join("") + "null",
          as: "internalColor",
        },
      ],
    });
  }

  // Add heat map charts
  if (heatMapCharts.length > 0) {
    if (heatMapCharts.length > 1) {
      throw new Error(
        "Heat map charts can not be mixed with other chart types.",
      );
    }
    const sequentialColors: string[] = [
      datavizStyles.sequential_1,
      datavizStyles.sequential_2,
      datavizStyles.sequential_3,
      datavizStyles.sequential_4,
      datavizStyles.sequential_5,
      datavizStyles.sequential_6,
      datavizStyles.sequential_7,
      datavizStyles.sequential_8,
      datavizStyles.sequential_9,
      datavizStyles.sequential_10,
    ];
    const divergingColors: string[] = [
      datavizStyles.diverging_1,
      datavizStyles.diverging_2,
      datavizStyles.diverging_3,
      datavizStyles.diverging_4,
      datavizStyles.diverging_5,
      datavizStyles.diverging_6,
      datavizStyles.diverging_7,
      datavizStyles.diverging_8,
      datavizStyles.diverging_9,
      datavizStyles.diverging_10,
      datavizStyles.diverging_11,
    ];
    const colors =
      palette === "sequential" ? sequentialColors : divergingColors;

    layers.push(
      ...heatMapCharts
        .map((chart) => {
          const gridXPaddingRatio =
            chart.gridPadding === undefined || chart.gridPadding === "none"
              ? 0
              : chart.gridPadding === "standard"
                ? 0.1
                : 0.15;

          // Maintains the same cell padding ratio on the y-axis as the x-axis.
          const gridYPaddingRatio =
            chartViewHeight > 0 && chartViewWidth > 0
              ? gridXPaddingRatio * (chartViewWidth / chartViewHeight)
              : gridXPaddingRatio;

          const colorObj = {
            field: chart.field2 as string,
            type: "quantitative",
            scale: { range: colors, type: "quantize" },
            legend: null,
          };

          return [
            {
              mark: {
                type: "rect" as const,
                cornerRadius: chart.gridPadding === "spacious" ? 2 : 0,
              },
              encoding: {
                [getEncodingAxisKey("x", layout)]: {
                  field: xAxisConfig.field as string,
                  type: "nominal",
                  scale: {
                    padding: gridXPaddingRatio,
                  },
                },

                [getEncodingAxisKey("y", layout)]: {
                  field: chart.field as string,
                  type: "nominal",
                  sort: "descending", // stack the heat map cells from bottom to top along the y-axis.
                  scale: {
                    padding: gridYPaddingRatio,
                  },
                },
                color: colorObj,
                stroke: colorObj, // This removes weird gaps potentially caused by the grid.
              },
            },
          ];
        })
        .flat(),
    );
  }
  return layers;
}

function getBackgroundLayers(
  variant: ChartVariant,
  colorScheme: BaltoColorScheme,
  charts: ChartMetadata[],
  xAxisConfig: XAxisConfig,
  state: ChartState,
  layout: ChartLayout,
  interactionType: ChartInteractionType,
  barAndBrushCornerRadius: number,
) {
  if (variant === "minimal") {
    return [];
  }
  const datavizStyles =
    colorScheme === "dark" ? datavizDarkStyles : datavizLightStyles;
  const hasBarChart = charts.some((chart) => chart.type === "bar");
  const hasLineChart = charts.some((chart) => chart.type === "line");
  const hasAreaChart = charts.some((chart) => chart.type === "area");
  const scatterCharts = charts.filter((chart) => chart.type === "point");
  const hasScatterChart = scatterCharts.length > 0;

  const layers = [];
  if (hasBarChart) {
    layers.push({
      mark: {
        type: "bar" as const,
        tooltip: { content: "data" as const },
        width: { band: 0.9 }, // Keep hover bar same width as the actual bar chart.
      },
      encoding: {
        [getEncodingAxisKey("y", layout)]: null, // Remove y encoding to make hover bar fill entire height.
        opacity: {
          condition: { value: 1, param: "hoverX", empty: false },
          value: 0,
        },
        strokeWidth: { value: 8 }, // Use a transparent stroke to make the hover area wider so tooltip will flicker much less between bars.
        stroke: { value: "transparent" },
        color: { value: datavizStyles.hoverBackground },
      },
    });
  }

  if (hasLineChart || hasAreaChart) {
    layers.push({
      mark: {
        type: "rule" as const,
        tooltip: { content: "data" as const },
      },
      encoding: {
        opacity: {
          condition: { value: 1, param: "hoverX", empty: false },
          value: 0,
        },
        strokeWidth: {
          value: hasBarChart ? 0 : 1, // Hide line chart hover stroke if there is already a bar chart.
        },
        stroke: { value: datavizStyles.hoverLine },
      },
    });
  }

  if (hasScatterChart) {
    layers.push({ mark: { type: "circle" as const, opacity: 0 } }); // Placeholder layer for registering global params.
  }

  // Define all params ONCE here and add it to 1st layer to be globally available. If moved to top level,
  // they will be re-created when a child chart layer transforms data causing "duplicate signal name" error.
  const globalParams = [
    {
      name: "hoverX",
      select: {
        type: "point" as const,
        nearest: hasBarChart ? false : true,
        on: "pointerover",
        clear: "pointerout",
        encodings: [getEncodingAxisKey("x", layout)],
      },
    },
    {
      name: "clickX",
      select: {
        type: "point" as const,
        on: "click",
        encodings: [getEncodingAxisKey("x", layout)],
      },
      value: getSelectionValue(state, xAxisConfig),
    },
    ...[
      interactionType === "brush" && !hasScatterChart
        ? {
            name: "brushX",
            select: {
              type: "interval" as const,
              encodings: [getEncodingAxisKey("x", layout)],
              mark: getBrushMarkStyle(colorScheme, barAndBrushCornerRadius),
              zoom: false, // TODO(APPS-58837): Support zooming.
            },
            value: { x: state.selection.xAxisRange ?? [] },
          }
        : [],
    ],
  ];
  if (layers.length > 0) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (layers[0] as any).params = globalParams;
  }
  return layers;
}

function getSelectionValue(state: ChartState, xAxisConfig: XAxisConfig) {
  const value: Record<string, unknown> = {};
  if (state?.selection?.xAxis) {
    value[xAxisConfig.field as string] = [state.selection.xAxis];
  }
  if (state?.selection?.yAxis) {
    value["value"] = [state.selection.yAxis];
  }
  if (state?.selection?.series) {
    value["key"] = state.selection.series;
  }
  return Object.keys(value).length > 0 ? value : null;
}

function getSelectedSeriesMatcher(state: ChartState, matcherValue: string) {
  const series = state?.selection?.series ?? [];
  if (
    series.length === 0 &&
    state?.selection?.xAxis === undefined &&
    state?.selection?.yAxis === undefined
  ) {
    return "true";
  }
  const seriesArrayString = series.map((v) => `'${v}'`).join(",");
  return `indexof([${seriesArrayString}], ${matcherValue}) > -1`;
}

function getForegroundLayers(
  layout: ChartLayout,
  colorScheme: BaltoColorScheme,
  referenceCharts: ChartMetadata[],
) {
  const datavizStyles =
    colorScheme === "dark" ? datavizDarkStyles : datavizLightStyles;
  const layers = [];
  // Add reference lines on top of the chart.
  layers.push(
    ...referenceCharts
      .map((chart) => {
        const field = chart.field as string;
        const type = getChartFieldType(chart.fieldType ?? "number");
        if (chart.type === "line") {
          return {
            encoding: {
              [getEncodingAxisKey("y", layout)]: { field, type },
              color: { value: datavizStyles.referenceLine },
            },
            mark: {
              type: "line" as const,
              strokeCap: "round" as const,
              strokeDash: [4, 6],
              strokeWidth: 2,
            },
          };
        } else if (chart.type === "point") {
          return {
            encoding: {
              [getEncodingAxisKey("y", layout)]: { field, type },
              size: {
                condition: { value: 100, param: "hoverX", empty: false },
                value: 64, // 8px reference point size.
              },
            },
            mark: {
              type: "point" as const,
              opacity: 1,
              fill: datavizStyles.referenceDot,
              stroke: datavizStyles.referenceDot,
            },
          };
        }
        return null;
      })
      .filter((layer) => layer !== null),
  );
  return layers;
}

function getChartFieldType(fieldType: FieldDataType): ChartDataType {
  switch (fieldType) {
    case "number":
      return "quantitative";
    case "date":
      return "temporal";
    case "text":
    case "boolean":
    default:
      return "nominal";
  }
}

function registerFormatters(
  xAxisConfig: XAxisConfig,
  yAxisConfig: YAxisConfig,
  xAxisFormatterId: string,
  yAxisFormatterId: string,
  showOnlyZeroOnYAxis: boolean,
) {
  const xAxisFormatter = xAxisConfig.formatter ?? ((v: DataRecordValue) => v);
  const yAxisFormatter =
    yAxisConfig.formatter ??
    ((v: DataRecordValue) => {
      // Handle corner case where all values are 0, we implicitly set the domain to [0, 1] to
      // bottom-align the "0" label on YAxis and hide the "1" (and any intermediate) labels.
      if (showOnlyZeroOnYAxis) {
        return v === 0 ? v : "";
      }
      return v;
    });
  expressionFunction(xAxisFormatterId, xAxisFormatter);
  expressionFunction(yAxisFormatterId, yAxisFormatter);
}

function getEncodingAxisKey(
  axisName: "x" | "y",
  layout: ChartLayout,
  secondary = false,
): "x" | "y" | "x2" | "y2" {
  let key: "x" | "y" | "x2" | "y2" = "x";
  if (layout === "horizontal") {
    key = axisName;
  } else {
    key = axisName === "x" ? "y" : "x";
  }
  return secondary ? `${key}2` : key;
}

function getMinMax(data: DataRecord[], charts: ChartMetadata[]) {
  let min = 0;
  let max = 0;
  data.forEach((d) => {
    charts.forEach((chart) => {
      const field = chart.field as string;
      const type = getChartFieldType(chart.fieldType ?? "number");
      if (type === "quantitative") {
        const value = (d[field] as number) ?? 0;
        min = Math.min(min, value);
        max = Math.max(max, value);
      }
    });
  });
  return [min, max];
}

function getLineChartdiscreteXAxisValues(
  data: DataRecord[],
  chart: ChartMetadata,
  xAxisConfig: XAxisConfig,
): string[] | number[] {
  const discreteXAxisValues = new Set();
  const key = chart.field as string;
  for (let i = 0; i < data.length; i++) {
    if (
      data[i - 1]?.[key] == null &&
      data[i]?.[key] != null &&
      data[i + 1]?.[key] == null
    ) {
      discreteXAxisValues.add(data[i]?.[xAxisConfig.field]);
    }
  }
  return Array.from(discreteXAxisValues) as string[] | number[];
}

function getBrushMarkStyle(
  colorScheme: BaltoColorScheme,
  cornerRadius: number,
) {
  const themeStyles =
    colorScheme === "dark" ? themeDarkStyles : themeLightStyles;
  return {
    stroke: themeStyles.reusableBorderBright,
    strokeWidth: 1,
    cornerRadius,
    fillOpacity: colorScheme === "dark" ? 0.2 : 0.1,
    fill: themeStyles.reusableBorderBright,
  };
}

export { useVegaLiteSpec };
