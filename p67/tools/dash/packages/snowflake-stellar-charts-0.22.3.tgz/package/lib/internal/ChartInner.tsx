import { useEffect, useMemo } from "react";

import type { ChartMetadata } from "./types";
import { generateId } from "./utils";
import { useChartContext } from "../internal/ChartContext";

type ChartInnerProps = ChartMetadata;

const ChartInner = (props: ChartInnerProps) => {
  const stableId = useMemo(
    () => generateId(`baltoChart-${props.type}-`),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [props.id],
  );

  const { setCharts } = useChartContext("ChartInner");
  // Extract all props we want to watch for changes
  const {
    id = stableId,
    variant = "primary",
    type,
    field,
    field2,
    fieldType,
    isReference,
    semanticColor,
    hide,
    stackId,
    label,
    tooltipLabel,
    formatter,
    withFill,
    gridPadding,
  } = props;

  // Effect for updating chart data when component mounts or props change.
  useEffect(() => {
    setCharts((prevCharts) => {
      const chartIndex = prevCharts.findIndex((chart) => chart.id === id);
      const chart = {
        id,
        variant,
        type,
        field,
        field2,
        fieldType,
        isReference,
        semanticColor,
        hide,
        stackId,
        label,
        tooltipLabel,
        formatter,
        withFill,
        gridPadding,
      };

      if (chartIndex === -1) {
        return [...prevCharts, chart];
      }
      // If chart exists, update it in-place
      const updatedCharts = [...prevCharts];
      updatedCharts[chartIndex] = chart;
      return updatedCharts;
    });
  }, [
    id,
    variant,
    type,
    field,
    field2,
    fieldType,
    isReference,
    semanticColor,
    hide,
    stackId,
    label,
    tooltipLabel,
    formatter,
    withFill,
    setCharts,
    gridPadding,
  ]);

  // Separate effect for cleanup on unmount only.
  useEffect(() => {
    return () => {
      setCharts((prevCharts) => prevCharts.filter((chart) => chart.id !== id));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <></>;
};

export type { ChartInnerProps };
export { ChartInner };
