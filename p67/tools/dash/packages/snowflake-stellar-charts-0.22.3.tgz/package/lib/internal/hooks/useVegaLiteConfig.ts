import { themeDarkStyles, themeLightStyles } from "@snowflake/balto-tokens";
import { useBaltoContext } from "@snowflake/stellar-components";
import { useMemo } from "react";
import type { Config } from "vega-lite";

import { useChartColors } from "./useChartColors";
import type { ChartPalette } from "../../types";
import type { ChartMetadata } from "../types";

/**
 * Config for vega charts to be consistent with Snowflake and Balto theme.
 * Reference: https://vega.github.io/vega-lite/docs/config.html
 */
const useVegaLiteConfig = (
  charts: ChartMetadata[],
  palette: ChartPalette,
): Config => {
  const { colorScheme } = useBaltoContext();
  const chartColors = useChartColors(charts, palette);

  return useMemo(() => {
    const isDarkMode = colorScheme === "dark";
    const themeStyles =
      colorScheme === "dark" ? themeDarkStyles : themeLightStyles;

    return {
      font: themeStyles.fontFamilyBody,
      background: "transparent",
      fieldTitle: "verbal",
      autosize: { type: "fit", contains: "padding", resize: false },
      title: {
        align: "left",
        anchor: "start",
        color: themeStyles.reusableTextPrimary,
        subtitleFontStyle: "normal",
        fontWeight: themeStyles.fontWeightSemiBold,
        fontSize: 16,
        orient: "top",
        offset: 26,
      },
      header: {
        titleFontWeight: themeStyles.fontWeightRegular,
        titleFontSize: 16,
        titleColor: isDarkMode ? "#e6eaf1" : "#808495", // TODO: these colors were from snapps but not in Balto.
        titleFontStyle: "normal",
        labelFontSize: 12,
        labelFontWeight: themeStyles.fontWeightRegular,
        labelColor: isDarkMode ? "#e6eaf1" : "#808495",
        labelFontStyle: "normal",
      },
      axis: {
        labelFontSize: 12,
        labelFontWeight: themeStyles.fontWeightRegular,
        labelColor: themeStyles.reusableTextSecondary,
        labelFontStyle: "normal",
        titleFontWeight: themeStyles.fontWeightRegular,
        titleFontSize: 14,
        titleColor: themeStyles.reusableTextSecondary,
        titleFontStyle: "normal",
        ticks: false,
        gridColor: isDarkMode ? "#31333f" : "#e6eaf1",
        domain: false,
        domainWidth: 1,
        domainColor: "#e6eaf1",
        labelFlush: false,
        labelBound: false,
        labelLimit: 100,
        titlePadding: 16,
        labelPadding: 12,
        labelSeparation: 4,
        labelOverlap: true,
      },
      range: {
        category: chartColors,
      },
      view: {
        strokeWidth: 0,
        stroke: "transparent",
        continuousHeight: 150,
        continuousWidth: 400,
      },
      concat: { columns: 1 },
      facet: { columns: 1 },
      scale: {
        bandWithNestedOffsetPaddingInner: 0.1,
        offsetBandPaddingOuter: 0,
      },
      bar: {
        binSpacing: 0,
        discreteBandSize: { band: 1 },
        continuousBandSize: 1,
        timeUnitBandPosition: 0,
        timeUnitBandSize: 1,
      },
      axisDiscrete: { grid: false },
      axisXPoint: { grid: false },
      axisTemporal: { grid: false },
      axisXBand: { grid: false },
    };
  }, [chartColors, colorScheme]);
};

export { useVegaLiteConfig };
