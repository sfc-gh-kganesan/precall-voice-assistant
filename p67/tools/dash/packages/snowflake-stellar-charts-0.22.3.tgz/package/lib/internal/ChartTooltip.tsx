import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import {
  Flex,
  Label,
  Paragraph,
  useMergedStyles,
} from "@snowflake/stellar-components";
import { tokens } from "@snowflake/stellar-tokens/tokens.stylex";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";
import { forwardRef } from "react";

import { ChartSymbol } from "./shared/ChartSymbol";
import type { ChartTooltipItem } from "./types";

interface ChartTooltipProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The heading of the tooltip.
   */
  heading: string;
  /**
   * The items of the tooltip.
   */
  items?: ChartTooltipItem[] | undefined;
}

const styles = stylex.create({
  container: {
    backgroundColor: baltoTheme.surfaceLevel_2Background,
    borderColor: baltoTheme.surfaceLevel_2Background,
    borderRadius: tokens["radius-md"] /* 8 */,
    borderWidth: 1,
    boxShadow: baltoTheme.elevation_2BoxShadow,
    margin: 0,
    padding: tokens["space-vertical-md"] /* 12 */,
  },
});

const ChartTooltip = forwardRef<HTMLDivElement, ChartTooltipProps>(
  (props, forwardedRef) => {
    const { className, style, heading, items = [], ...otherProps } = props;
    const styleProps = useMergedStyles(
      className,
      style,
      stylex.props(styles.container),
    );
    return (
      <Flex
        direction="column"
        gap="1x"
        {...styleProps}
        {...otherProps}
        ref={forwardedRef}
      >
        <Paragraph variant="primary" bold>
          {heading}
        </Paragraph>
        <Flex direction="column" gap="1x">
          {items.map((item) => (
            <Flex justify="between" align="center" gap="1_5x" key={item.label}>
              <Flex align="center" gap="1x">
                <ChartSymbol type={item.chartType} color={item.legendColor} />
                <Label variant="secondary" size="small">
                  {item.label}
                </Label>
              </Flex>
              <Paragraph variant="primary" size="small">
                {item.value}
              </Paragraph>
            </Flex>
          ))}
        </Flex>
      </Flex>
    );
  },
);
ChartTooltip.displayName = "ChartTooltip";

export type { ChartTooltipProps };
export { ChartTooltip };
