import { useBaltoContext } from "@snowflake/stellar-components";
import { useMemo } from "react";

import { datavizDarkStyles } from "../../generated/datavizDark";
import { datavizLightStyles } from "../../generated/datavizLight";
import type { ChartPalette, ChartSemanticColor } from "../../types";
import type { ChartMetadata } from "../types";

// Calculate distinctive colors for each chart.
export function useChartColors(charts: ChartMetadata[], palette: ChartPalette) {
  const { colorScheme } = useBaltoContext();

  return useMemo(() => {
    const c = colorScheme === "dark" ? datavizDarkStyles : datavizLightStyles;
    const semanticColors: Record<ChartSemanticColor, string> = {
      success: c.semanticSuccess,
      caution: c.semanticCaution,
      critical: c.semanticCritical,
      info: c.semanticInfo,
      neutral: c.semanticNeutral,
      active: c.semanticActive,
    };
    const colors =
      palette === "categorical"
        ? [
            c.chart_1,
            c.chart_2,
            c.chart_3,
            c.chart_4,
            c.chart_5,
            c.chart_6,
            c.chart_7,
            c.chart_8,
          ]
        : Object.values(semanticColors);
    const dimColors =
      palette === "categorical"
        ? [
            c.chartDim_1,
            c.chartDim_2,
            c.chartDim_3,
            c.chartDim_4,
            c.chartDim_5,
            c.chartDim_6,
            c.chartDim_7,
            c.chartDim_8,
          ]
        : [];

    let i = 0;
    let j = 0;
    return charts
      .filter((chart) => !chart.hide)
      .map((chart) => {
        let color;
        if (chart.isReference) {
          if (chart.type === "line") {
            color = c.referenceLine;
          } else if (chart.type === "point") {
            color = c.referenceDot;
          } else if (chart.type === "band") {
            color = c.referenceBand;
          }
        } else if (chart.variant === "primary") {
          if (chart.semanticColor) {
            if (palette === "semantic") {
              color = semanticColors[chart.semanticColor];
            } else {
              throw new Error(
                "semanticColor must be used with semantic palette.",
              );
            }
          } else {
            color = colors[i];
            i = (i + 1) % colors.length;
          }
        } else if (chart.variant === "secondary") {
          if (palette === "semantic") {
            throw new Error("Semantic palette only supports primary variant.");
          }
          color = dimColors[j];
          j = (j + 1) % dimColors.length;
        } else {
          color = c.forecasting;
        }
        chart.internalColor = color;
        return color as string;
      });
  }, [charts, palette, colorScheme]);
}
