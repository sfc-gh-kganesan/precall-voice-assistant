import { createContext } from "@radix-ui/react-context";

import type { ChartMetadata, XAxisConfig, YAxisConfig } from "./types";
import type { DataRecord } from "../types";

interface ChartContextType {
  data: DataRecord[];
  charts: ChartMetadata[];
  setCharts: React.Dispatch<React.SetStateAction<ChartMetadata[]>>;
  xAxisConfig: XAxisConfig;
  setXAxisConfig: React.Dispatch<React.SetStateAction<XAxisConfig>>;
  yAxisConfig: YAxisConfig;
  setYAxisConfig: React.Dispatch<React.SetStateAction<YAxisConfig>>;
}

const [ChartContext, useChartContext] =
  createContext<ChartContextType>("Chart");

export { ChartContext, useChartContext };
export type { ChartContextType };
