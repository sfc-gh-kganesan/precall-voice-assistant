export type DataRecord = { [key: string]: DataRecordValue | undefined };

export type DataRecordValue =
  | string
  | number
  | boolean
  | bigint
  | Date
  | object
  | object[]
  | null;

export type ChartVariant = "regular" | "minimal" | "legendless";

export type ChartLayout = "horizontal" | "vertical";

export type ChartPalette =
  | "categorical"
  | "semantic"
  | "sequential"
  | "diverging";

export type ChartInteractionType = "select" | "brush" | undefined;

export type ChartSemanticColor =
  | "success"
  | "caution"
  | "critical"
  | "info"
  | "neutral"
  | "active";

export interface ChartState {
  selection: {
    xAxis?: string | number | undefined;
    yAxis?: string | number | undefined;
    series?: Array<string | number> | undefined;
    xAxisRange?: string[] | number[] | undefined;
    yAxisRange?: string[] | number[] | undefined;
  };
}
