import { useId } from "@react-aria/utils";
import type { ControlledComponent } from "@snowflake/stellar-components";
import { Flex } from "@snowflake/stellar-components";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";
import {
  forwardRef,
  memo,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { VegaEmbed } from "react-vega";
import { useSharedResizeObserver } from "use-shared-resize-observer";
import type { Renderers, SignalListenerHandler, SignalValue, View } from "vega";
import type { EmbedOptions, Result } from "vega-embed";
import { expressionInterpreter } from "vega-interpreter";

import { ChartContext } from "./internal/ChartContext";
import { ChartLegend } from "./internal/ChartLegend";
import { ChartXAxis } from "./internal/ChartXAxis";
import { useFormatTooltip } from "./internal/hooks/useFormatTooltip";
import { useTooltipContainerId } from "./internal/hooks/useTooltipContainerId";
import { useVegaLiteSpec } from "./internal/hooks/useVegaLiteSpec";
import type { ChartMetadata, XAxisConfig, YAxisConfig } from "./internal/types";
import { defaultXAxisConfig, defaultYAxisConfig } from "./internal/types";
import { getSortedDataByXAxis } from "./internal/utils";
import type {
  ChartInteractionType,
  ChartLayout,
  ChartPalette,
  ChartState,
  ChartVariant,
  DataRecord,
} from "./types";

interface ChartProps
  extends HTMLAttributes<HTMLDivElement>,
    Omit<ControlledComponent<"state", ChartState>, "defaultState"> {
  /**
   * The variant of the chart ("regular", "legendless", or "minimal").
   * @default "regular"
   */
  variant?: ChartVariant | undefined;
  /**
   * The layout of the chart ("horizontal" or "vertical").
   * @default "horizontal"
   */
  layout?: ChartLayout | undefined;
  /**
   * The palette of the chart ("categorical", "semantic", "sequential", or "diverging").
   * @default "sequential" for heat map, "categorical" for others.
   */
  palette?: ChartPalette | undefined;
  /**
   * The width of the chart in pixels.
   */
  width?: number | undefined;
  /**
   * The height of the chart in pixels.
   */
  height?: number | undefined;
  /**
   * The heading of the chart.
   */
  heading?: string | undefined;
  /**
   * The data of the chart.
   */
  data: DataRecord[];
  /**
   * The type of interaction to enable.
   * @default undefined
   */
  interactionType?: ChartInteractionType | undefined;
}

const chartStyles = stylex.create({
  root: {
    height: "100%",
    maxHeight: "100vh",
    maxWidth: "100vw",
    overflow: "hidden",
    width: "100%",
  },
  fixWidth: (width: number) => ({
    width,
  }),
  fixHeight: (height: number) => ({
    height,
  }),
  vegaEmbed: {
    // Force Vega's SVG wrapper to be the exact same size of the contained SVG.
    // Otherwise there is a height diff causing infitite resize observer loops.
    display: "flex",
    width: "100%",
  },
  embedWrapper: {
    minHeight: 0,
    minWidth: 0,
  },
});

const AXIS_OFFSET = 6;
const DEFAULT_STATE: ChartState = { selection: {} };

const ChartImp = forwardRef<HTMLDivElement, ChartProps>(
  (props, forwardedRef) => {
    const {
      variant = "regular",
      layout = "horizontal",
      palette = "categorical",
      width,
      height,
      data,
      children,
      state = DEFAULT_STATE,
      onStateChange,
      interactionType = onStateChange !== undefined ? "select" : undefined,
      ...otherProps
    } = props;

    // Unique ID for the chart. Needs to be a valid JS identifier to register vega.expressionFunction in global scope.
    const chartId = useId().replace(/[:-]/g, "");
    const [charts, setCharts] = useState<ChartMetadata[]>([]);
    const [xAxisConfig, setXAxisConfig] =
      useState<XAxisConfig>(defaultXAxisConfig);
    const [yAxisConfig, setYAxisConfig] =
      useState<YAxisConfig>(defaultYAxisConfig);
    const containerRef = useRef<HTMLDivElement>(null);
    // The overall dimensions of the chart including the x-axis and y-axis.
    const [dimensions, setDimensions] = useState({
      width: 0,
      height: 0,
    });

    // TODO(APPS-58529): The spacing needed for the x-axis to properly align with chart.
    // We won't need this after we create our own yAxis component too.
    // This is only set once because the yAxis size won't change after first render.
    const [yAxisSize, setYAxisSize] = useState(0);

    const [viewHeight, setViewHeight] = useState(0);

    useSharedResizeObserver({
      ref: containerRef,
      onUpdate: (entry) => {
        const width = Math.floor(entry.contentRect.width);
        const height = Math.floor(entry.contentRect.height);

        setDimensions({ width, height });
      },
    });

    const sortedData = useMemo(() => {
      return getSortedDataByXAxis(data, xAxisConfig);
    }, [data, xAxisConfig]);

    const hasLineChart = charts.some((chart) => chart.type === "line");
    const hasBarChart = charts.some((chart) => chart.type === "bar");
    const hasHeatMapChart = charts.some((chart) => chart.type === "rect");
    if (hasHeatMapChart && !["sequential", "diverging"].includes(palette)) {
      throw new Error(
        "Heat map charts must use the sequential or diverging palette.",
      );
    }

    const horizontalOffset =
      hasLineChart && !hasBarChart && xAxisConfig.fieldType === "date" ? 4 : 0;
    const resultWidth =
      dimensions.width - yAxisSize - AXIS_OFFSET - horizontalOffset;
    const vegaLiteSpec = useVegaLiteSpec(
      chartId,
      dimensions.width,
      resultWidth,
      viewHeight,
      variant,
      layout,
      palette,
      sortedData,
      charts,
      xAxisConfig,
      yAxisConfig,
      state,
      interactionType,
    );

    const tooltipContainerId = useTooltipContainerId();
    const formatTooltip = useFormatTooltip(charts, xAxisConfig);

    const clickHandler = useCallback(
      (_name: string, v: SignalValue) => {
        // This is what Vega returns today: https://github.com/vega/vega/blob/df207badc90063c7103bdec861581df83f640f27/packages/vega-selections/src/selectionResolve.js#L80-L82
        const datum = v?.["vlPoint"]?.["or"]?.[0];
        const xAxisValue = datum?.[xAxisConfig.field];
        const yAxisValue = datum?.["value"];
        const selection = {
          ...state?.selection,
          series: undefined, // Reset series selection when clicking on chart data point.
          xAxis: xAxisValue,
          yAxis: yAxisValue,
        };
        // If the new selection value (point or individual axis) is the same as the previously selected value, unselect by setting it to undefined.
        if (
          xAxisValue !== undefined &&
          yAxisValue !== undefined &&
          yAxisValue === state.selection.yAxis &&
          xAxisValue === state.selection.xAxis
        ) {
          selection.yAxis = undefined;
          selection.xAxis = undefined;
        } else if (
          yAxisValue === undefined &&
          xAxisValue === state.selection.xAxis
        ) {
          selection.xAxis = undefined;
        } else if (
          xAxisValue === undefined &&
          yAxisValue === state.selection.yAxis
        ) {
          selection.yAxis = undefined;
        }
        onStateChange?.({ ...state, selection });
      },
      [state, xAxisConfig, onStateChange],
    );

    // Cache the latest brush value and only handle it when pointerup.
    const lastBrushValueRef = useRef<SignalValue | null>(null);
    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;
      const handlePointerUp = () => {
        if (lastBrushValueRef.current) {
          const v = lastBrushValueRef.current;
          const selection = {
            ...state?.selection,
            // series: undefined, // Reset series selection when clicking on chart data point.
            // xAxis: undefined,
            // yAxis: undefined,
            xAxisRange: v[xAxisConfig.field],
            yAxisRange: v["value"],
          };

          if (selection.xAxisRange?.length > 2) {
            selection.xAxisRange = [
              selection.xAxisRange[0],
              selection.xAxisRange[selection.xAxisRange.length - 1],
            ];
          }
          onStateChange?.({ ...state, selection });
          lastBrushValueRef.current = null;
        }
      };
      container.addEventListener("pointerup", handlePointerUp);
      return () => {
        container.removeEventListener("pointerup", handlePointerUp);
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [xAxisConfig.field]);

    // For brushing, save the latest brush value and only handle it when pointerup.
    const brushHandler = (_name: string, v: SignalValue) => {
      lastBrushValueRef.current = v;
    };

    const hasScatterChart = charts.some(
      (chart) => chart.type === "point" && !chart.isReference,
    );

    const removeListenersRef = useRef<() => void>(() => {});
    const attachListeners = useCallback(
      (view: View) => {
        if (variant === "minimal") return;

        removeListenersRef.current();
        removeListenersRef.current = () => {};

        const removeListener: (() => void)[] = [];

        /**
         * Add a signal listener to the view and add a function to remove the listener when the component unmounts.
         */
        function addListener(signal: string, handler: SignalListenerHandler) {
          view.addSignalListener(signal, handler);
          removeListener.push(() => view.removeSignalListener(signal, handler));
        }

        if (hasBarChart || hasLineChart) {
          addListener("clickX", clickHandler);
        }

        if (interactionType === "brush") {
          if (hasScatterChart) {
            addListener("brushXY_x", brushHandler);
            addListener("brushXY", brushHandler);
          } else {
            addListener("brushX", brushHandler);
          }
        }

        if (hasScatterChart) {
          addListener("clickXY", clickHandler);
        }

        removeListenersRef.current = () =>
          removeListener.forEach((remove) => remove());
      },
      [
        hasBarChart,
        hasLineChart,
        hasScatterChart,
        interactionType,
        variant,
        clickHandler,
      ],
    );

    const xAxisStyles = useMemo(() => {
      return {
        opacity: yAxisSize === 0 ? 0 : 1,
        transition: "opacity 0.016s ease-in-out", // Avoid flickering when the xAxis is resized to match the chart.
        ...(layout === "vertical"
          ? {
              marginBlockStart: AXIS_OFFSET,
              marginBlockEnd: yAxisSize,
            }
          : {
              marginInlineStart: yAxisSize,
              marginInlineEnd: AXIS_OFFSET,
            }),
      };
    }, [layout, yAxisSize]);

    const vegaEmbedOptions = useMemo(() => {
      return {
        mode: "vega-lite",
        ast: true,
        actions: false,
        expr: expressionInterpreter,
        renderer: "svg",
        tooltip: {
          id: tooltipContainerId,
          anchor: "mark",
          position: ["top", "top-left", "top-right"],
          formatTooltip,
        },
      } as EmbedOptions<string, Renderers>;
    }, [tooltipContainerId, formatTooltip]);

    const onEmbed = useCallback(
      (result: Result) => {
        const viewWidth = result.view.width();
        const viewHeight = result.view.height();

        if (yAxisSize === 0) {
          const horizontalOffset =
            hasLineChart && !hasBarChart && xAxisConfig.fieldType === "date"
              ? 3
              : 0;

          const yAxisSize = Math.max(
            0,
            layout === "horizontal"
              ? dimensions.width - viewWidth - AXIS_OFFSET - horizontalOffset
              : dimensions.height - viewHeight - AXIS_OFFSET,
          );

          setYAxisSize(yAxisSize);
          setViewHeight(viewHeight);
        }

        attachListeners(result.view);
      },
      [
        attachListeners,
        hasBarChart,
        hasLineChart,
        xAxisConfig.fieldType,
        layout,
        dimensions.width,
        dimensions.height,
        yAxisSize,
      ],
    );

    return (
      <ChartContext
        data={sortedData}
        charts={charts}
        setCharts={setCharts}
        xAxisConfig={xAxisConfig}
        setXAxisConfig={setXAxisConfig}
        yAxisConfig={yAxisConfig}
        setYAxisConfig={setYAxisConfig}
      >
        <Flex
          direction="column"
          gap="0x"
          {...otherProps}
          {...stylex.props(
            chartStyles.root,
            width ? chartStyles.fixWidth(width) : null,
            height ? chartStyles.fixHeight(height) : null,
          )}
          ref={forwardedRef}
        >
          {/* TODO(SNOW-2721167): Remove this once we have legend designed for heat map charts. */}
          {variant === "regular" && !hasHeatMapChart && (
            <ChartLegend
              charts={charts}
              state={state}
              onStateChange={onStateChange}
            />
          )}
          <Flex
            direction={layout === "vertical" ? "row-reverse" : "column"}
            gap="0x"
            grow={1}
            shrink={1}
            {...stylex.props(chartStyles.embedWrapper)}
          >
            <Flex
              ref={containerRef}
              grow={1}
              shrink={1}
              {...stylex.props(chartStyles.embedWrapper)}
            >
              {dimensions.width > 0 && dimensions.height > 0 && (
                <VegaEmbed
                  spec={vegaLiteSpec}
                  {...stylex.props(chartStyles.vegaEmbed)}
                  options={vegaEmbedOptions}
                  onEmbed={onEmbed}
                />
              )}
            </Flex>
            {variant !== "minimal" && xAxisConfig.fieldType !== "number" && (
              <ChartXAxis
                layout={layout}
                style={xAxisStyles}
                width={dimensions.width}
              />
            )}
            {children}
          </Flex>
        </Flex>
      </ChartContext>
    );
  },
);

ChartImp.displayName = "ChartImp";

const Chart = memo(ChartImp);

Chart.displayName = "Chart";
export type { ChartProps };
export { Chart };
