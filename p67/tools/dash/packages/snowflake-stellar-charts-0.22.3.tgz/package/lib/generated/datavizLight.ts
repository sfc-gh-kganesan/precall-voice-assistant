/**
 * Do not edit directly, this file was auto-generated.
 */

export const datavizLightColorKeys = [
  "chart_1",
  "chart_2",
  "chart_3",
  "chart_4",
  "chart_5",
  "chart_6",
  "chart_7",
  "chart_8",
  "chartDim_1",
  "chartDim_2",
  "chartDim_3",
  "chartDim_4",
  "chartDim_5",
  "chartDim_6",
  "chartDim_7",
  "chartDim_8",
  "semanticSuccess",
  "semanticCaution",
  "semanticCritical",
  "semanticInfo",
  "semanticNeutral",
  "semanticActive",
  "sequential_1",
  "sequential_2",
  "sequential_3",
  "sequential_4",
  "sequential_5",
  "sequential_6",
  "sequential_7",
  "sequential_8",
  "sequential_9",
  "sequential_10",
  "diverging_1",
  "diverging_2",
  "diverging_3",
  "diverging_4",
  "diverging_5",
  "diverging_6",
  "diverging_7",
  "diverging_8",
  "diverging_9",
  "diverging_10",
  "diverging_11",
  "forecasting",
  "referenceLine",
  "referenceDot",
  "referenceBand",
  "hoverBackground",
  "hoverLine",
] as const;
export type DatavizLightColor = (typeof datavizLightColorKeys)[number];

export const datavizLightDimensionKeys = [] as const;
export type DatavizLightDimension = (typeof datavizLightDimensionKeys)[number];

const datavizLightValidKeys = [
  "chart_1",
  "chart_2",
  "chart_3",
  "chart_4",
  "chart_5",
  "chart_6",
  "chart_7",
  "chart_8",
  "chartDim_1",
  "chartDim_2",
  "chartDim_3",
  "chartDim_4",
  "chartDim_5",
  "chartDim_6",
  "chartDim_7",
  "chartDim_8",
  "semanticSuccess",
  "semanticCaution",
  "semanticCritical",
  "semanticInfo",
  "semanticNeutral",
  "semanticActive",
  "sequential_1",
  "sequential_2",
  "sequential_3",
  "sequential_4",
  "sequential_5",
  "sequential_6",
  "sequential_7",
  "sequential_8",
  "sequential_9",
  "sequential_10",
  "diverging_1",
  "diverging_2",
  "diverging_3",
  "diverging_4",
  "diverging_5",
  "diverging_6",
  "diverging_7",
  "diverging_8",
  "diverging_9",
  "diverging_10",
  "diverging_11",
  "forecasting",
  "referenceLine",
  "referenceDot",
  "referenceBand",
  "hoverBackground",
  "hoverLine",
] as const;
type DatavizLightValidKey = (typeof datavizLightValidKeys)[number];

export type DatavizLight = DatavizLightValidKey;

export const datavizLightStyles = {
  chart_1: "#1a6ce7",
  chart_2: "#ecb700",
  chart_3: "#51caa5",
  chart_4: "#d3132f",
  chart_5: "#7157f4",
  chart_6: "#ff7c1d",
  chart_7: "#70ddff",
  chart_8: "#d45cff",
  chartDim_1: "#b2cdf7",
  chartDim_2: "#ffe691",
  chartDim_3: "#89dbc2",
  chartDim_4: "#f9bcc5",
  chartDim_5: "#cec5fb",
  chartDim_6: "#ffbe8f",
  chartDim_7: "#bdefff",
  chartDim_8: "#edb9ff",
  semanticSuccess: "#51d9ae",
  semanticCaution: "#f8c52a",
  semanticCritical: "#ef405e",
  semanticInfo: "#3580f2",
  semanticNeutral: "#bdc4d5",
  semanticActive: "#5d6a85",
  sequential_1: "#f1f7ff",
  sequential_2: "#bbd6fe",
  sequential_3: "#86b6fc",
  sequential_4: "#5999f8",
  sequential_5: "#3580f2",
  sequential_6: "#1a6ce7",
  sequential_7: "#085bd7",
  sequential_8: "#004cbe",
  sequential_9: "#003e9a",
  sequential_10: "#002c6e",
  diverging_1: "#002c6e",
  diverging_2: "#004cbe",
  diverging_3: "#1a6ce7",
  diverging_4: "#5999f8",
  diverging_5: "#bbd6fe",
  diverging_6: "#eceef1",
  diverging_7: "#ffd1dc",
  diverging_8: "#f76a86",
  diverging_9: "#d3132f",
  diverging_10: "#a40319",
  diverging_11: "#66000e",
  /** Reserved for forecasting. Example: Cost Management - Budgets - Projected Daily Spend. */
  forecasting: "#c9cfdd",
  /** A reference line in a chart is a visual indicator—usually a straight line—added to help compare data points against a specific value or benchmark. It serves as a guide or marker to highlight key thresholds, averages, targets, or other meaningful constants.. */
  referenceLine: "#1e252f",
  /** A reference dot in a chart is a visual marker (usually a small circle or point) used to highlight a specific data value or threshold for comparison or emphasis. It doesn’t represent data from the main dataset but serves as a guide or annotation.. */
  referenceDot: "#d45cff",
  /** A reference band in a chart is a visual element used to highlight a specific range of values on the chart, usually along the x-axis or y-axis.. */
  referenceBand: "#9fabc1",
  /** This hover effect serves to emphasize the bar under the cursor, enhancing interactivity and user experience. */
  hoverBackground: "rgba(159, 171, 193, 0.2)",
  /** This line that appears on hover in a chart helps users precisely track values by aligning with the cursor, usually along the x- or y-axis, and is often paired with tooltips for easier data comparison across points.. */
  hoverLine: "rgba(159, 171, 193, 0.2)",
} as const satisfies Readonly<Record<DatavizLight, string | number>>;

export type DatavizLightTypes = {
  chart_1: string;
  chart_2: string;
  chart_3: string;
  chart_4: string;
  chart_5: string;
  chart_6: string;
  chart_7: string;
  chart_8: string;
  chartDim_1: string;
  chartDim_2: string;
  chartDim_3: string;
  chartDim_4: string;
  chartDim_5: string;
  chartDim_6: string;
  chartDim_7: string;
  chartDim_8: string;
  semanticSuccess: string;
  semanticCaution: string;
  semanticCritical: string;
  semanticInfo: string;
  semanticNeutral: string;
  semanticActive: string;
  sequential_1: string;
  sequential_2: string;
  sequential_3: string;
  sequential_4: string;
  sequential_5: string;
  sequential_6: string;
  sequential_7: string;
  sequential_8: string;
  sequential_9: string;
  sequential_10: string;
  diverging_1: string;
  diverging_2: string;
  diverging_3: string;
  diverging_4: string;
  diverging_5: string;
  diverging_6: string;
  diverging_7: string;
  diverging_8: string;
  diverging_9: string;
  diverging_10: string;
  diverging_11: string;
  /** Reserved for forecasting. Example: Cost Management - Budgets - Projected Daily Spend. */
  forecasting: string;
  /** A reference line in a chart is a visual indicator—usually a straight line—added to help compare data points against a specific value or benchmark. It serves as a guide or marker to highlight key thresholds, averages, targets, or other meaningful constants.. */
  referenceLine: string;
  /** A reference dot in a chart is a visual marker (usually a small circle or point) used to highlight a specific data value or threshold for comparison or emphasis. It doesn’t represent data from the main dataset but serves as a guide or annotation.. */
  referenceDot: string;
  /** A reference band in a chart is a visual element used to highlight a specific range of values on the chart, usually along the x-axis or y-axis.. */
  referenceBand: string;
  /** This hover effect serves to emphasize the bar under the cursor, enhancing interactivity and user experience. */
  hoverBackground: string;
  /** This line that appears on hover in a chart helps users precisely track values by aligning with the cursor, usually along the x- or y-axis, and is often paired with tooltips for easier data comparison across points.. */
  hoverLine: string;
};
