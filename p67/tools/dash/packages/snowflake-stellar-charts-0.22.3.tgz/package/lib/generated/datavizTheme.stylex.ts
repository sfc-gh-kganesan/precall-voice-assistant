/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const datavizTheme = stylex.defineVars({
  chart_1: "#1a6ce7",
  chart_2: "#ecb700",
  chart_3: "#51caa5",
  chart_4: "#d3132f",
  chart_5: "#7157f4",
  chart_6: "#ff7c1d",
  chart_7: "#70ddff",
  chart_8: "#d45cff",
  chartDim_1: "#b2cdf7",
  chartDim_2: "#ffe691",
  chartDim_3: "#89dbc2",
  chartDim_4: "#f9bcc5",
  chartDim_5: "#cec5fb",
  chartDim_6: "#ffbe8f",
  chartDim_7: "#bdefff",
  chartDim_8: "#edb9ff",
  semanticSuccess: "#51d9ae",
  semanticCaution: "#f8c52a",
  semanticCritical: "#ef405e",
  semanticInfo: "#3580f2",
  semanticNeutral: "#bdc4d5",
  semanticActive: "#5d6a85",
  sequential_1: "#f1f7ff",
  sequential_2: "#bbd6fe",
  sequential_3: "#86b6fc",
  sequential_4: "#5999f8",
  sequential_5: "#3580f2",
  sequential_6: "#1a6ce7",
  sequential_7: "#085bd7",
  sequential_8: "#004cbe",
  sequential_9: "#003e9a",
  sequential_10: "#002c6e",
  diverging_1: "#002c6e",
  diverging_2: "#004cbe",
  diverging_3: "#1a6ce7",
  diverging_4: "#5999f8",
  diverging_5: "#bbd6fe",
  diverging_6: "#eceef1",
  diverging_7: "#ffd1dc",
  diverging_8: "#f76a86",
  diverging_9: "#d3132f",
  diverging_10: "#a40319",
  diverging_11: "#66000e",
  /** Reserved for forecasting. Example: Cost Management - Budgets - Projected Daily Spend. */
  forecasting: "#c9cfdd",
  /** A reference line in a chart is a visual indicator—usually a straight line—added to help compare data points against a specific value or benchmark. It serves as a guide or marker to highlight key thresholds, averages, targets, or other meaningful constants.. */
  referenceLine: "#1e252f",
  /** A reference dot in a chart is a visual marker (usually a small circle or point) used to highlight a specific data value or threshold for comparison or emphasis. It doesn’t represent data from the main dataset but serves as a guide or annotation.. */
  referenceDot: "#d45cff",
  /** A reference band in a chart is a visual element used to highlight a specific range of values on the chart, usually along the x-axis or y-axis.. */
  referenceBand: "#9fabc1",
  /** This hover effect serves to emphasize the bar under the cursor, enhancing interactivity and user experience. */
  hoverBackground: "rgba(159, 171, 193, 0.2)",
  /** This line that appears on hover in a chart helps users precisely track values by aligning with the cursor, usually along the x- or y-axis, and is often paired with tooltips for easier data comparison across points.. */
  hoverLine: "rgba(159, 171, 193, 0.2)",
});
