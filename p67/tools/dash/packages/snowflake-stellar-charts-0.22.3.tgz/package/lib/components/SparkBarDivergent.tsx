import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { type Size, useMergedStyles } from "@snowflake/stellar-components";
import { tokens } from "@snowflake/stellar-tokens/tokens.stylex";
import * as stylex from "@stylexjs/stylex";
import { type HTMLAttributes, forwardRef } from "react";

import { chartColors, semanticChartColors } from "../internal/colors";
import type { ChartSemanticColor } from "../types";

const styles = stylex.create({
  chart: {
    boxSizing: "content-box",
    display: "flex",
    flexDirection: "row",
    height: tokens["size-sm"],
    padding: tokens["space-vertical-3xs"],
    position: "relative",
    "::after": {
      borderRightColor: baltoTheme.reusableBorderDefault,
      borderRightStyle: "solid",
      borderRightWidth: "1px",
      bottom: 0,
      content: "",
      left: "50%",
      position: "absolute",
      top: 0,
    },
  },
  small: {
    height: tokens["size-4xs"],
  },
  regular: {
    height: tokens["size-sm"],
  },
  large: {
    height: tokens["size-lg"],
  },
  bar: {
    bottom: tokens["space-vertical-3xs"],
    position: "absolute",
    top: tokens["space-vertical-3xs"],
  },
});

interface SparkBarDivergentProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The label of the spark bar divergent.
   */
  label: string;
  /**
   * The value of the spark bar divergent.
   */
  value: number;
  /**
   * The min value of the spark bar divergent.
   */
  min: number;
  /**
   * The max value of the spark bar divergent.
   */
  max: number;
  /**
   * The mid value of the spark bar divergent.
   */
  mid: number;
  /**
   * The semantic color of the spark bar divergent chart.
   */
  semanticColor?: ChartSemanticColor | undefined;

  /**
   * The height of the spark bar divergent chart.
   * small: 1x (8px)
   * regular: 3x (24px)
   * large: 5x (40px)
   * @default "regular"
   */
  size?: Extract<Size, "small" | "regular" | "large"> | undefined;
}

const SparkBarDivergent = forwardRef<HTMLDivElement, SparkBarDivergentProps>(
  (props: SparkBarDivergentProps, ref) => {
    const {
      min,
      max,
      value,
      mid = 0,
      size = "regular",
      semanticColor,
      label,
      className,
      style,
      ...rest
    } = props;

    // To calculate the width and left position of the bar, we need to calculate the relative value of the bar.
    // If the value is greater than the mid, we need to calculate the relative value of the bar from the mid to the max.
    // If the value is less than the mid, we need to calculate the relative value of the bar from the min to the mid.
    const relative = value > mid ? value / (max - mid) : value / (mid - min);
    const abs = relative < 0 ? relative * -1 : relative;
    // The width of the bar is the absolute value of the relative value divided by 2.
    // The left position of the bar is the 50% minus the absolute value of the relative value divided by 2.
    const width = value > mid ? `${(abs / 2) * 100}%` : `${(abs / 2) * 100}%`;
    const left = value > mid ? "50%" : `${50 - (abs / 2) * 100}%`;

    const styleProps = useMergedStyles(
      className,
      style,
      stylex.props(styles.chart, styles[size]),
    );

    return (
      <div
        {...rest}
        {...styleProps}
        role="graphics-document"
        aria-roledescription="visualization"
        ref={ref}
      >
        <div
          {...stylex.props(styles.bar)}
          role="graphics-symbol"
          aria-roledescription="bar"
          aria-label={label}
          style={{
            backgroundColor: semanticColor
              ? semanticChartColors[semanticColor]
              : chartColors[0],
            width,
            left,
          }}
        />
      </div>
    );
  },
);

SparkBarDivergent.displayName = "SparkBarDivergent";

export { SparkBarDivergent };
export type { SparkBarDivergentProps };
