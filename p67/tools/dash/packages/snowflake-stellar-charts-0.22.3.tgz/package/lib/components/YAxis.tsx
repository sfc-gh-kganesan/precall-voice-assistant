import { useEffect } from "react";

import { useChartContext } from "../internal/ChartContext";
import type { YAxisConfig } from "../internal/types";

type YAxisProps = YAxisConfig;

const YAxis = (props: YAxisProps) => {
  const { setYAxisConfig } = useChartContext("YAxis");
  const { label, domain, formatter } = props;

  useEffect(() => {
    setYAxisConfig({ label, domain, formatter });
    return () => {};
  }, [label, domain, formatter, setYAxisConfig]);

  return <></>;
};

export type { YAxisProps };
export { YAxis };
