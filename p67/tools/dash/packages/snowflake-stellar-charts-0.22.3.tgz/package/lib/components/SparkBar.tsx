import { type Size, useMergedStyles } from "@snowflake/stellar-components";
import { tokens } from "@snowflake/stellar-tokens/tokens.stylex";
import * as stylex from "@stylexjs/stylex";
import { type HTMLAttributes, forwardRef } from "react";

import { chartColors, semanticChartColors } from "../internal/colors";
import type { ChartSemanticColor } from "../types";

interface DynamicBarStylesProp {
  /**
   *
   */
  height: number;
  /**
   *
   */
  semanticColor?: ChartSemanticColor | undefined;
}

const styles = stylex.create({
  chart: {
    alignItems: "flex-end",
    display: "flex",
    flexDirection: "row",
    gap: tokens["space-gap-3xs"],
    maxHeight: tokens["size-2xl"],
  },
  small: {
    height: tokens["size-sm"],
  },
  regular: {
    height: tokens["size-lg"],
  },
  large: {
    height: tokens["size-2xl"],
  },
  bar: (props: DynamicBarStylesProp) => ({
    /* eslint-disable @stylexjs/valid-styles */
    backgroundColor: props.semanticColor
      ? semanticChartColors[props.semanticColor]
      : chartColors[0],
    flex: "1",
    height: `${props.height * 100}%`,
  }),
});

interface SparkBarData {
  /**
   * The value of the spark bar chart.
   */
  label: string;
  /**
   * The label of the spark bar chart.
   */
  value: number;
  /**
   * The semantic color of the spark bar chart.
   */
  semanticColor?: ChartSemanticColor | undefined;
}

interface SparkBarProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The data to display in the spark bar chart.
   */
  data: SparkBarData[];

  /**
   * The domain of the data. This is used to scale the bars to the same height.
   * @default [0, max(data.value)]
   */
  domain?: [number, number] | undefined;

  /**
   * The height of the spark bar chart.
   * small: 2.5x (20px)
   * regular: 5x (40px)
   * large: 8x (64px)
   *
   * @default "regular"
   */
  size?: Extract<Size, "small" | "regular" | "large"> | undefined;

  /**
   * The semantic color of the spark bar chart.
   */
  semanticColor?: ChartSemanticColor | undefined;
}

const SparkBar = forwardRef<HTMLDivElement, SparkBarProps>(
  (props: SparkBarProps, ref) => {
    const {
      data,
      domain,
      size = "regular",
      semanticColor,
      style,
      className,
      ...rest
    } = props;

    const values = data.map((d) => d.value);

    // If the domain is not provided, we use the min and max of the values.
    // The domain is used to scale the bars to the same height.
    const d = domain ? domain : ([0, Math.max(...values)] as const);
    const range = d[1] - d[0];

    const styleProps = useMergedStyles(
      className,
      style,
      stylex.props(styles.chart, styles[size]),
    );

    return (
      <div
        role="graphics-document"
        aria-roledescription="visualization"
        ref={ref}
        {...rest}
        {...styleProps}
      >
        {data.map((bar) => (
          <div
            {...stylex.props(
              styles.bar({
                semanticColor: bar.semanticColor ?? semanticColor,
                height: bar.value / range,
              }),
            )}
            role="graphics-symbol"
            aria-roledescription="bar"
            aria-label={bar.label}
            key={bar.label}
          />
        ))}
      </div>
    );
  },
);

SparkBar.displayName = "SparkBar";

export { SparkBar };
export type { SparkBarProps };
