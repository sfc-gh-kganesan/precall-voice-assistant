import { ChartInner } from "../internal/ChartInner";
import type { BaseChartProps } from "../internal/types";

interface LineProps extends BaseChartProps {
  /**
   * Whether to fill the area under the line.
   */
  withFill?: boolean | undefined;
}

const Line = (props: LineProps) => {
  return <ChartInner type="line" {...props} />;
};

export type { LineProps };
export { Line };
