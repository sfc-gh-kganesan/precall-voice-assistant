import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import type { Size } from "@snowflake/stellar-components";
import { tokens } from "@snowflake/stellar-tokens/tokens.stylex";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";

import { datavizTheme } from "../generated/datavizTheme.stylex";
import type { ChartSemanticColor } from "../types";

const styles = stylex.create({
  sparkStack: {
    backgroundColor: baltoTheme.reusableBorderDisabled,
    borderRadius: tokens["radius-xs"],
    display: "flex",
    flexDirection: "row",
    maxHeight: tokens["size-xl"],
    minHeight: tokens["size-4xs"],
    overflow: "hidden",
  },
  sparkStackItem: {
    backgroundColor: baltoTheme.chart_1,
    height: "100%",
    width: 0, // This is set to 0 and then updated with the width of the item.
  },
  small: {
    borderRadius: 0,
    height: tokens["size-4xs"],
  },
  regular: {
    borderRadius: tokens["radius-xs"],
    height: tokens["size-md"],
  },
  large: {
    borderRadius: tokens["radius-sm"],
    height: tokens["size-xl"],
  },
});

const colors = [
  baltoTheme.chart_1,
  baltoTheme.chart_2,
  baltoTheme.chart_3,
  baltoTheme.chart_4,
  baltoTheme.chart_5,
  baltoTheme.chart_6,
  baltoTheme.chart_7,
  baltoTheme.chart_8,
];

const semanticColors: Record<ChartSemanticColor, string> = {
  success: datavizTheme.semanticSuccess,
  caution: datavizTheme.semanticCaution,
  critical: datavizTheme.semanticCritical,
  info: datavizTheme.semanticInfo,
  neutral: datavizTheme.semanticNeutral,
  active: datavizTheme.semanticActive,
};

interface SparkStackItemProps {
  /**
   * The value of the item. It is used to calculate the width of the stack item.
   */
  value: number;
  /**
   * The label of the item.
   */
  label: string;
  /**
   * The semantic color of the item.
   */
  semanticColor?: ChartSemanticColor | undefined;
  /**
   * Whether the item is the other item. This is used when displaying categorical data and you have an "other" category.
   */
  other?: boolean | undefined;
}

export interface SparkStackProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The data to display in the spark stack. It is an array of objects with the following properties:
   * - value: The value of the item.
   * - label: The label of the item.
   * - semanticColor: (optional) The semantic color of the item.
   * - other: (optional) Whether the item is the other item. This is used when displaying categorical data and you have an "other" category.
   */
  data: SparkStackItemProps[];
  /**
   * The maximum value of the data. This can be used to show multiple SparkStacks that are proportional to each other.
   */
  max?: number | undefined;
  /**
   * The size of the spark stack. Defaults to "regular".
   * @default "regular"
   */
  size?: Extract<Size, "small" | "regular" | "large"> | undefined;

  /**
   * The height of the SparkStack.
   * min: `8px`
   * max: `48px`
   */
  height?: number | string | undefined;
}

/**
 * A `<SparkStack>` is a component that displays a stack of items with a proportional width. It is used to display categorical data that make up parts of a whole. For example, if you have a chart that shows the percentage of users that have completed a task, you can use a `<SparkStack>` to display the data.
 * @example
 * ```tsx
 * <SparkStack data={[
 *   { label: "Category A", value: 40 },
 *   { label: "Category B", value: 30 },
 *   { label: "Category C", value: 60 },
 * ]} />
 * ```
 */
export const SparkStack = ({
  data,
  max,
  size = "regular",
  height,
  ...rest
}: SparkStackProps) => {
  // Calculate the total value of the data.
  const total = max ?? data.reduce((acc, curr) => acc + curr.value, 0);

  return (
    <div
      role="graphics-document"
      style={{ height }}
      {...stylex.props(styles.sparkStack, styles[size])}
      {...rest}
    >
      {data.map((item, index) => (
        <div
          role="graphics-symbol"
          key={item.label}
          aria-label={`${item.label}: ${item.value}`}
          {...stylex.props(styles.sparkStackItem)}
          style={{
            width: `${(item.value / total) * 100}%`,
            // Sets the color of the bar stack, if the item is the other item, it uses the dim color.
            // If the item has a semantic color, it uses the semantic color.
            // If the item has no semantic color, it uses the color from the colors array.
            backgroundColor: item.other
              ? datavizTheme.semanticNeutral
              : item.semanticColor
                ? semanticColors[item.semanticColor]
                : colors[index],
          }}
        />
      ))}
    </div>
  );
};
