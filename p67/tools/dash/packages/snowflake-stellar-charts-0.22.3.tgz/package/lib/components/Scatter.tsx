import { ChartInner } from "../internal/ChartInner";
import type { BaseChartProps } from "../internal/types";

type ScatterProps = BaseChartProps;

const Scatter = (props: ScatterProps) => {
  return <ChartInner type="point" {...props} />;
};

export type { ScatterProps };
export { Scatter };
