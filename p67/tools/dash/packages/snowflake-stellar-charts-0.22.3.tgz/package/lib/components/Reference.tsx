import { ChartInner } from "../internal/ChartInner";
import type { BaseChartProps } from "../internal/types";

interface ReferenceProps extends Omit<BaseChartProps, "variant"> {
  /**
   * The variant of the reference.
   * @default "line"
   */
  variant: "line" | "point" | "band";
  /**
   * The second field of the reference.
   */
  field2?: string | undefined;
}

const Reference = (props: ReferenceProps) => {
  const { variant, ...otherProps } = props;
  return <ChartInner type={variant} isReference={true} {...otherProps} />;
};

export type { ReferenceProps };
export { Reference };
