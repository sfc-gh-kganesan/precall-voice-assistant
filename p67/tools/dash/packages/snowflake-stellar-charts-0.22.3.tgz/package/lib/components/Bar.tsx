import { ChartInner } from "../internal/ChartInner";
import type { BaseChartProps } from "../internal/types";

interface BarProps extends BaseChartProps {
  /**
   * The stack id of the bar chart.
   */
  stackId?: string | undefined;
}

const Bar = (props: BarProps) => {
  return <ChartInner type="bar" {...props} />;
};

export type { BarProps };
export { Bar };
