import { ChartInner } from "../internal/ChartInner";
import type { BaseChartProps, GridPadding } from "../internal/types";

interface HeatMapProps extends BaseChartProps {
  /**
   * The second field for the y-axis dimension of the heatmap.
   */
  field2?: string | undefined;
  /**
   * The padding of the grid.
   */
  gridPadding?: GridPadding | undefined;
}

const HeatMap = (props: HeatMapProps) => {
  return <ChartInner type="rect" {...props} />;
};

export type { HeatMapProps };
export { HeatMap };
