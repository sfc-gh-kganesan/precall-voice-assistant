import { type Size, useMergedStyles } from "@snowflake/stellar-components";
import { tokens } from "@snowflake/stellar-tokens/tokens.stylex";
import * as stylex from "@stylexjs/stylex";
import type { HTMLAttributes } from "react";
import { forwardRef, useMemo } from "react";
import { VegaEmbed } from "react-vega";
import type { EmbedOptions } from "vega-embed";
import type { TopLevelSpec } from "vega-lite";

import { chartColors, semanticChartColors } from "../internal/colors";
import type { ChartSemanticColor } from "../types";

const sizeMap: Record<
  Required<SparkLineProps>["size"],
  stylex.StyleXVar<string>
> = {
  small: tokens["size-xs"],
  regular: tokens["size-lg"],
  large: tokens["size-2xl"],
};

const styles = stylex.create({
  root: {
    height: "100%",
    maxHeight: "100vh",
    maxWidth: "100vw",
    overflow: "hidden",
    width: "100%",
  },
  embed: (height: Required<SparkLineProps>["size"]) => ({
    // Force Vega's SVG wrapper to be the exact same size of the contained SVG.
    // Otherwise there is a height diff causing infitite resize observer loops.
    display: "flex",
    height: sizeMap[height],
    width: "100%",
  }),
});

interface SparkLineProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The data to display in the spark line.
   * Because a SparkLine doesn't have any axis, the data is just an array of numbers. It can also contain null values to indicate missing data.
   */
  data: (number | null)[];

  /**
   * The size of the spark stack. Defaults to "regular".
   * @default "regular"
   */
  size?: Extract<Size, "small" | "regular" | "large"> | undefined;

  /**
   * The semantic color of the spark line.
   */
  semanticColor?: ChartSemanticColor | undefined;
}

const SparkLine = forwardRef<HTMLDivElement, SparkLineProps>(
  (props: SparkLineProps, ref) => {
    const {
      data,
      size = "regular",
      semanticColor,
      className,
      style,
      ...otherProps
    } = props;

    // Directly creating the Vega-Lite spec for this chart because
    // we know exactly what we want to do and it would be more difficult to mess with useVegaLiteSpec for this case
    const spec: TopLevelSpec = useMemo(
      () => ({
        $schema: "https://vega.github.io/schema/vega-lite/v6.json",
        width: "container",
        height: "container",
        mark: {
          type: "line",
          strokeWidth: 2,
          color: semanticColor
            ? semanticChartColors[semanticColor]
            : chartColors[0],
        },
        encoding: {
          x: {
            field: "x",
            type: "quantitative",
            axis: null,
          },
          y: {
            field: "y",
            type: "quantitative",
            axis: null,
            scale: {
              zero: false,
            },
          },
        },
        config: {
          view: {
            stroke: null,
          },
          padding: {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
          },
          background: "transparent",
        },
        data: {
          values: data.map((value, index) => ({ x: index, y: value })),
        },
      }),
      [data, semanticColor],
    );

    const vegaEmbedOptions: EmbedOptions = useMemo(
      () => ({
        mode: "vega-lite",
        ast: true,
        actions: false,
        renderer: "svg",
      }),
      [],
    );

    const styleProps = useMergedStyles(
      className,
      style,
      stylex.props(styles.root),
    );

    return (
      <div {...styleProps} {...otherProps} ref={ref}>
        <VegaEmbed
          spec={spec}
          {...stylex.props(styles.embed(size))}
          options={vegaEmbedOptions}
        />
      </div>
    );
  },
);

SparkLine.displayName = "SparkLine";

export { SparkLine };
export type { SparkLineProps };
