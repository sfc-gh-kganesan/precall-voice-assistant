import { ChartInner } from "../internal/ChartInner";
import type { BaseChartProps } from "../internal/types";

interface AreaProps extends BaseChartProps {
  /**
   * The second field of the area chart.
   */
  field2?: string | undefined;
  /**
   * The label of the second field of the area chart.
   */
  label2?: string | undefined;
  /**
   * The tooltip label of the second field of the area chart.
   */
  tooltipLabel2?: string | undefined;
}

const Area = (props: AreaProps) => {
  return <ChartInner type="area" {...props} />;
};

export type { AreaProps };
export { Area };
