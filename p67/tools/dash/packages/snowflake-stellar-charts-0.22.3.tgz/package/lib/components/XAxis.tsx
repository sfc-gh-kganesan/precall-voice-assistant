import { useEffect, useMemo } from "react";

import { useChartContext } from "../internal/ChartContext";
import type { XAxisConfig } from "../internal/types";
import { getDataInterval, getDateFormatOptions } from "../internal/utils";

type XAxisProps = Pick<
  XAxisConfig,
  "label" | "field" | "fieldType" | "formatter" | "tooltipFormatter"
>;

const XAxis = (props: XAxisProps) => {
  const { data, setXAxisConfig } = useChartContext("XAxis");
  const {
    label,
    field,
    fieldType = "date",
    formatter,
    tooltipFormatter,
  } = props;

  const interval = useMemo(
    () => getDataInterval(data, field, fieldType),
    [data, field, fieldType],
  );
  const dataFormatOptions = getDateFormatOptions(interval);

  useEffect(() => {
    setXAxisConfig({
      label,
      field,
      fieldType,
      formatter,
      tooltipFormatter,
      dateFormatOptions: dataFormatOptions.xAxis,
      tooltipDateFormatOptions: dataFormatOptions.tooltip,
      isMonthYear: dataFormatOptions.isMonthYear,
      timeUnit: dataFormatOptions.timeUnit,
      timeUnitStep: dataFormatOptions.timeUnitStep,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [label, field, fieldType, formatter, tooltipFormatter, setXAxisConfig]);

  return <></>;
};

export type { XAxisProps };
export { XAxis };
