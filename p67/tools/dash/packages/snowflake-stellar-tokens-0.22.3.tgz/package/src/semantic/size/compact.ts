import type { SemanticSize } from "./types";

export const size: SemanticSize = {
  $type: "dimension",
  "6xs": {
    $value: "{base.space.0_25x}",
    $description: "",
  },
  "5xs": {
    $value: "{base.space.0_5x}",
    $description: "",
  },
  "4xs": {
    $value: "{base.space.0_75x}",
    $description: "",
  },
  "3xs": {
    $value: "{base.space.1_5x}",
    $description: "",
  },
  "2xs": {
    $value: "{base.space.2x}",
  },
  xs: {
    $value: "{base.space.2x}",
  },
  sm: {
    $value: "{base.space.3x}",
  },
  md: {
    $value: "{base.space.3x}",
  },
  lg: {
    $value: "{base.space.4x}",
  },
  xl: {
    $value: "{base.space.5x}",
  },
  "2xl": {
    $value: "{base.space.6x}",
  },
};
