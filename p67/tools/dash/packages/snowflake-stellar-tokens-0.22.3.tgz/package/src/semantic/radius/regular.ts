import type { SemanticRadius } from "./types";

export const radius: SemanticRadius = {
  $type: "dimension",
  $description: "Semantic radius tokens",
  xs: {
    $value: "{base.space.0_5x}",
    $description: "",
  },
  sm: {
    $value: "{base.space.0_75x}",
    $description: "",
  },
  md: {
    $value: "{base.space.1x}",
    $description: "",
  },
  lg: {
    $value: "{base.space.1_5x}",
    $description: "",
  },
  xl: {
    $value: "{base.space.2x}",
    $description: "",
  },
  xxl: {
    $value: "{base.space.3x}",
    $description: "",
  },
  circle: {
    $value: "9999px",
    $description: "",
  },
};
