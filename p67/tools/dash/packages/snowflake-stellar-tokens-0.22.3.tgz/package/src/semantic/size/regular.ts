import type { SemanticSize } from "./types";

export const size: SemanticSize = {
  $type: "dimension",
  $description: "Semantic size tokens",
  "6xs": {
    $value: "{base.space.0_5x}",
    $description: "",
  },
  "5xs": {
    $value: "{base.space.0_75x}",
    $description: "",
  },
  "4xs": {
    $value: "{base.space.1x}",
    $description: "",
  },
  "3xs": {
    $value: "{base.space.1_5x}",
    $description: "",
  },
  "2xs": {
    $value: "{base.space.2x}",
    $description: "",
  },
  xs: {
    $value: "{base.space.2_5x}",
    $description: "",
  },
  sm: {
    $value: "{base.space.3x}",
    $description: "",
  },
  md: {
    $value: "{base.space.4x}",
    $description: "",
  },
  lg: {
    $value: "{base.space.5x}",
    $description: "",
  },
  xl: {
    $value: "{base.space.6x}",
    $description: "",
  },
  "2xl": {
    $value: "{base.space.8x}",
    $description: "",
  },
};
