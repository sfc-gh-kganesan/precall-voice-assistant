import type { DesignToken } from "style-dictionary/types";

import type { BaseSpaceNames } from "../../base/space";

type SpaceToken = DesignToken & {
  $value: `{base.space.${BaseSpaceNames}}`;
};

export type SpaceSizeNames =
  | "3xs"
  | "2xs"
  | "xs"
  | "sm"
  | "md"
  | "lg"
  | "xl"
  | "2xl"
  | "3xl"
  | "4xl";

export interface SemanticSpace {
  $description?: string;
  $type?: string;
  gap: {
    $description?: string;
  } & {
    [key in SpaceSizeNames]?: SpaceToken;
  };
  horizontal: {
    $description?: string;
  } & {
    [key in SpaceSizeNames]?: SpaceToken;
  };
  vertical: {
    $description?: string;
  } & {
    [key in SpaceSizeNames]?: SpaceToken;
  };
}
