import type { SemanticSpace } from "./types";

export const space: SemanticSpace = {
  gap: {
    "3xs": {
      $value: "{base.space.0_25x}",
    },
    "2xs": {
      $value: "{base.space.0_5x}",
    },
    xs: {
      $value: "{base.space.0_5x}",
    },
    sm: {
      $value: "{base.space.0_75x}",
    },
    md: {
      $value: "{base.space.1x}",
    },
    lg: {
      $value: "{base.space.1_5x}",
    },
    xl: {
      $value: "{base.space.2x}",
    },
    "2xl": {
      $value: "{base.space.2_5x}",
    },
    "3xl": {
      $value: "{base.space.3x}",
    },
    "4xl": {
      $value: "{base.space.4x}",
    },
  },
  horizontal: {
    "3xs": {
      $value: "{base.space.0_25x}",
    },
    "2xs": {
      $value: "{base.space.0_5x}",
    },
    xs: {
      $value: "{base.space.0_75x}",
    },
    sm: {
      $value: "{base.space.1x}",
    },
    md: {
      $value: "{base.space.1_5x}",
    },
    lg: {
      $value: "{base.space.1_5x}",
    },
    xl: {
      $value: "{base.space.2x}",
    },
    "2xl": {
      $value: "{base.space.2_5x}",
    },
    "3xl": {
      $value: "{base.space.3x}",
    },
    "4xl": {
      $value: "{base.space.4x}",
    },
  },
  // Vertical spacing in compact mode is slightly different from regular mode
  vertical: {
    "3xs": {
      $value: "{base.space.0x}",
    },
    "2xs": {
      $value: "{base.space.0_25x}",
    },
    xs: {
      $value: "{base.space.0_5x}",
    },
    sm: {
      $value: "{base.space.0_75x}",
    },
    md: {
      $value: "{base.space.1x}",
    },
    lg: {
      $value: "{base.space.1_5x}",
    },
    xl: {
      $value: "{base.space.2x}",
    },
    "2xl": {
      $value: "{base.space.2_5x}",
    },
    "3xl": {
      $value: "{base.space.3x}",
    },
    "4xl": {
      $value: "{base.space.4x}",
    },
  },
};
