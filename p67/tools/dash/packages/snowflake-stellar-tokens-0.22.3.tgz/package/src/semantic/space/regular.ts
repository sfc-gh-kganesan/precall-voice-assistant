import dedent from "dedent";

import type { SemanticSpace } from "./types";

export const space: SemanticSpace = {
  $type: "dimension",
  $description: "Semantic space tokens",
  gap: {
    $description: dedent`
      Scale used for gap between items in a flex, grid, or list. Values will adjust based on density mode. 

      [📖 Spacing Guidelines](https://stellar.snowflake.com/guidelines/spacing)
    `,
    "3xs": {
      $value: "{base.space.0_25x}",
      $description: dedent`
        Smallest space between content within a grouping or container.

        Example:
        - Between icon and text in very small components like tags and badges
        - Between menu item text and sublabel
        - Between checkbox/radio label and helper text
      `,
    },
    "2xs": {
      $value: "{base.space.0_5x}",
      $description: dedent`	
        Small space between content within a grouping or container.

        Examples:
        - Between icon and text for most things
        - Between input and helper text
        - Between trigger and menu
      `,
    },
    xs: {
      $value: "{base.space.0_75x}",
      $description: dedent`
        Small space between content within a grouping or container

        Examples:
        - Between menu divider and content
      `,
    },
    sm: {
      $value: "{base.space.1x}",
      $description: dedent`
        Small space between content within a grouping or container. Also used to separate the smallest groups of content on a page level.

        Examples:
        - Between label and input
        - Between radio/checkbox buttons and text
        - Between radio/checkbox group items
        - Button groups
      `,
    },
    md: {
      $value: "{base.space.1_5x}",
      $description: dedent`
        Medium space between content within a grouping or container.

        Example:
        - Between label and radio/checkbox group
      `,
    },
    lg: {
      $value: "{base.space.2x}",
      $description: dedent`
        Large space between content within a grouping or container.
        Also used as a gap to separate out smaller groups of content within a page.
      `,
    },
    xl: {
      $value: "{base.space.2_5x}",
      $description: dedent`
        Large space between content within a grouping or container.
      `,
    },
    "2xl": {
      $value: "{base.space.3x}",
      $description: dedent`
        Large space to separate out content within a section.

        Example:
        - Between form elements
      `,
    },
    "3xl": {
      $value: "{base.space.4x}",
      $description: dedent`	
        Large space to separate out sections of a page.
      `,
    },
    "4xl": {
      $value: "{base.space.5x}",
      $description: dedent`
        Largest space between content within a grouping or container.
      `,
    },
  },
  horizontal: {
    $description: dedent`
      Scale used for horizontal padding of a component. Values will adjust based on density mode.
    `,
    "3xs": {
      $value: "{base.space.0_25x}",
      $description: dedent`
        Smallest left and right padding for components and containers.
      `,
    },
    "2xs": {
      $value: "{base.space.0_5x}",
      $description: dedent`
        Small left and right padding for components and containers.
      `,
    },
    xs: {
      $value: "{base.space.0_75x}",
      $description: dedent`
        Small left and right padding for components and containers.

        Examples:
        - Code tag
        - Count badge
        - Status badge
      `,
    },
    sm: {
      $value: "{base.space.1x}",
      $description: dedent`
        Small left and right padding for components and containers.

        Examples:
        - Small and regular buttons
        - Input
        - Menu item
        - Table cell
      `,
    },
    md: {
      $value: "{base.space.1_5x}",
      $description: dedent`
        Medium left and right padding for components and containers.
      `,
    },
    lg: {
      $value: "{base.space.2x}",
      $description: dedent`
        Large left and right padding for components and containers.
      `,
    },
    xl: {
      $value: "{base.space.2_5x}",
      $description: dedent`
        Large left and right padding for components and containers.
      `,
    },
    "2xl": {
      $value: "{base.space.3x}",
      $description: dedent`
        Large left and right padding for components and containers.

        Examples:
        - Card
      `,
    },
    "3xl": {
      $value: "{base.space.4x}",
      $description: dedent`
        Large left and right padding for components and containers.

        Examples:
        - Dialog
      `,
    },
    "4xl": {
      $value: "{base.space.5x}",
      $description: dedent`
        Largest left and right padding for components and containers.
        Left and right padding for page level content.
      `,
    },
  },
  vertical: {
    $description: dedent`
      Scale used for vertical padding of a component. Values will adjust based on density mode.
    `,
    "3xs": {
      $value: "{base.space.0_25x}",
      $description: dedent`
        Smallest top and bottom padding for components and containers.
      `,
    },
    "2xs": {
      $value: "{base.space.0_5x}",
      $description: dedent`
        Small top and bottom padding for components and containers.
      `,
    },
    xs: {
      $value: "{base.space.0_75x}",
      $description: dedent`
        Small top and bottom padding for components and containers.

        Examples:
        - Padding in menu
      `,
    },
    sm: {
      $value: "{base.space.1x}",
      $description: dedent`
        Small top and bottom padding for components and containers.
      `,
    },
    md: {
      $value: "{base.space.1_5x}",
      $description: dedent`
        Medium top and bottom padding for components and containers.
      `,
    },
    lg: {
      $value: "{base.space.2x}",
      $description: dedent`
        Large top and bottom padding for components and containers.
      `,
    },
    xl: {
      $value: "{base.space.2_5x}",
      $description: dedent`
        Large top and bottom padding for components and containers.
      `,
    },
    "2xl": {
      $value: "{base.space.3x}",
      $description: dedent`
        Large top and bottom padding for components and containers.

        Examples:
        - Card
      `,
    },
    "3xl": {
      $value: "{base.space.4x}",
      $description: dedent`
        Large top and bottom padding for components and containers. Top and bottom padding for page level content.
      `,
    },
    "4xl": {
      $value: "{base.space.5x}",
      $description: dedent`
        Largest top and bottom padding for components and containers.
      `,
    },
  },
};
