import type { DesignToken } from "style-dictionary/types";

import type { BaseSpaceNames } from "../../base/space";

type RadiusToken = DesignToken & {
  $value: `{base.space.${BaseSpaceNames}}` | "9999px";
};

export type RadiusNames = "xs" | "sm" | "md" | "lg" | "xl" | "xxl" | "circle";

export type SemanticRadius = {
  $description?: string;
  $type?: string;
} & {
  [key in RadiusNames]?: RadiusToken;
};
