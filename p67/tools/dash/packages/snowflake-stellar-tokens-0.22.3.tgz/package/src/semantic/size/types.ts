import type { DesignToken } from "style-dictionary/types";

import type { BaseSpaceNames } from "../../base/space";

type SizeToken = DesignToken & {
  $value: `{base.space.${BaseSpaceNames}}`;
};

export type SizeNames =
  | "6xs"
  | "5xs"
  | "4xs"
  | "3xs"
  | "2xs"
  | "xs"
  | "sm"
  | "md"
  | "lg"
  | "xl"
  | "2xl";

export type SemanticSize = {
  $description?: string;
  $type?: string;
} & {
  [key in SizeNames]?: SizeToken;
};
