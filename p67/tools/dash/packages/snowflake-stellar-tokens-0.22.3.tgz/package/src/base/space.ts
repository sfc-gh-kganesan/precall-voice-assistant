import type { DesignToken } from "style-dictionary/types";

export type BaseSpaceNames =
  | "0x"
  | "0_25x"
  | "0_5x"
  | "0_75x"
  | "1x"
  | "1_5x"
  | "2x"
  | "2_5x"
  | "3x"
  | "4x"
  | "5x"
  | "6x"
  | "8x";

export type BaseSpace = {
  $type: "dimension";
  $description: string;
} & {
  [key in BaseSpaceNames]?: DesignToken;
};

export const space: BaseSpace = {
  $type: "dimension",
  $description: "Base space tokens",
  "0x": { $value: "0" },
  "0_25x": { $value: "2px" },
  "0_5x": { $value: "4px" },
  "0_75x": { $value: "6px" },
  "1x": { $value: "8px" },
  "1_5x": { $value: "12px" },
  "2x": { $value: "16px" },
  "2_5x": { $value: "20px" },
  "3x": { $value: "24px" },
  "4x": { $value: "32px" },
  "5x": { $value: "40px" },
  "6x": { $value: "48px" },
  "8x": { $value: "64px" },
};
