export type {
  PageNavigationBarProps,
  PageSideNavProps,
  PageProps,
} from "./Page";
export * as Page from "./Page";
