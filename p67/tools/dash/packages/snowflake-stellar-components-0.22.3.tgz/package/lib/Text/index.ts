export { Editorial } from "./Editorial";
export { Heading } from "./Heading";
export { Label } from "./Label";
export { Paragraph } from "./Paragraph";
export { Pre } from "./Pre";
export { SingleLine } from "./SingleLine";
export { Span } from "./Span";
export { textVariants } from "./types";

export type { LabelProps } from "./Label";
export type { EditorialProps } from "./Editorial";
export type { TextVariant } from "./types";
export type { ParagraphProps } from "./Paragraph";
export type { SpanProps } from "./Span";
export type { PreProps } from "./Pre";
export type { HeadingProps, HeadingSize } from "./Heading";
