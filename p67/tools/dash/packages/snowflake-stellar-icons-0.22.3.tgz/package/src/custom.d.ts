declare module "@snowflake/stellar-icons/svg/*.svg" {
  const content: string;
  export default content;
}
