import { useContext } from "react";

import { IconContext } from "./IconContext";

export function useIconContext() {
  const value = useContext(IconContext);
  return value;
}
