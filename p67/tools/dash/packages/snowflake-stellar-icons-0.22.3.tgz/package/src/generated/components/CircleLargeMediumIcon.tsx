import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CircleLargeMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path fill={iconColor} d="M15 10a5 5 0 1 1-10 0 5 5 0 0 1 10 0" />
          </>
        }
        {...props}
      />
    );
  },
);
CircleLargeMediumIcon.displayName = "CircleLargeMediumIcon";
export { CircleLargeMediumIcon };
