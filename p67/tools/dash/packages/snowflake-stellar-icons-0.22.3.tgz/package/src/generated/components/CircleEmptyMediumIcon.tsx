import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CircleEmptyMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M17.5 10a7.5 7.5 0 1 0-7.5 7.5v1.25a8.75 8.75 0 1 1 0-17.5 8.75 8.75 0 0 1 0 17.5V17.5a7.5 7.5 0 0 0 7.5-7.5"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CircleEmptyMediumIcon.displayName = "CircleEmptyMediumIcon";
export { CircleEmptyMediumIcon };
