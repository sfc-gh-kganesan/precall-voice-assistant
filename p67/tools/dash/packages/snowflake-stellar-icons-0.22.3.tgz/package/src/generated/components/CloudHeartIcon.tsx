import { forwardRef, ForwardedRef } from "react";

import { CloudHeartMediumIcon } from "./CloudHeartMediumIcon";
import { CloudHeartRegularIcon } from "./CloudHeartRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CloudHeartIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CloudHeartIcon = forwardRef(
  (
    { size = "regular", ...props }: CloudHeartIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CloudHeartRegularIcon />;

    if (size === "medium") {
      icon = <CloudHeartMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CloudHeartIcon.displayName = "CloudHeartIcon";

export type { CloudHeartIconProps };
export { CloudHeartIcon };
