import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const DataSharingIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <path
              stroke={`url(#${idPrefix}-svg-484037129__a)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M118 43h-7c-8.837 0-16 7.163-16 16v26"
            />
            <path
              stroke={`url(#${idPrefix}-svg-484037129__b)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M31 37h2c8.836 0 16 7.163 16 16v35"
            />
            <path
              stroke={`url(#${idPrefix}-svg-484037129__c)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M98 15H86c-8.837 0-16 7.163-16 16v48"
            />
            <path
              fill={`url(#${idPrefix}-svg-484037129__d)`}
              d="M63.009 75.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09l-28.535 14.925c-4.554 2.382-11.31 2.362-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
            />
            <path
              fill={`url(#${idPrefix}-svg-484037129__e)`}
              d="M63.009 64.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09l-28.535 14.925c-4.554 2.382-11.31 2.362-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
            />
            <mask
              id={`${idPrefix}-svg-484037129__g`}
              width={82}
              height={46}
              x={30}
              y={74}
              maskUnits="userSpaceOnUse"
              style={{
                maskType: "alpha",
              }}
            >
              <path
                fill={`url(#${idPrefix}-svg-484037129__f)`}
                d="M63.009 75.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09l-28.535 14.925c-4.554 2.382-11.31 2.362-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
              />
            </mask>
            <g
              filter={`url(#${idPrefix}-svg-484037129__h)`}
              mask={`url(#${idPrefix}-svg-484037129__g)`}
            >
              <path
                fill={`url(#${idPrefix}-svg-484037129__i)`}
                d="M63.009 64.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09l-28.535 14.925c-4.554 2.382-11.31 2.362-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
              />
            </g>
            <mask
              id={`${idPrefix}-svg-484037129__k`}
              width={82}
              height={46}
              x={30}
              y={63}
              maskUnits="userSpaceOnUse"
              style={{
                maskType: "alpha",
              }}
            >
              <path
                fill={`url(#${idPrefix}-svg-484037129__j)`}
                d="M63.009 64.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09l-28.535 14.925c-4.554 2.382-11.31 2.362-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
              />
            </mask>
            <g
              filter={`url(#${idPrefix}-svg-484037129__l)`}
              mask={`url(#${idPrefix}-svg-484037129__k)`}
            >
              <path
                fill={`url(#${idPrefix}-svg-484037129__m)`}
                d="M63.009 52.001c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09L79.237 93.402c-4.554 2.382-11.31 2.361-15.848-.048l-28.9-15.346c-5.539-2.942-5.524-8.171.032-11.082z"
              />
            </g>
            <path
              fill={`url(#${idPrefix}-svg-484037129__n)`}
              d="M63.009 51.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09L79.237 93.337c-4.554 2.382-11.31 2.361-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
            />
            <path
              fill={`url(#${idPrefix}-svg-484037129__o)`}
              fillRule="evenodd"
              d="M57.497 65.124c-.486.263-.49.696-.008.966l1.155.65c.482.27 1.266.276 1.752.013l9.802-5.305c.486-.263.49-.695.008-.966l-1.155-.649c-.482-.27-1.266-.276-1.752-.014zm-7.046 5.413c-.8-.45-.795-1.17.012-1.606l1.837-.994c.807-.437 2.11-.427 2.911.023.8.45.795 1.169-.012 1.606l-1.837.994c-.807.437-2.11.426-2.911-.023m6.337 3.56c-.8-.449-.795-1.168.012-1.605l1.837-.994c.807-.437 2.11-.426 2.911.023.8.45.795 1.17-.012 1.606l-1.837.994c-.807.437-2.11.427-2.911-.023m7.039-4.446c-.482-.27-.478-.703.007-.966l9.803-5.305c.486-.263 1.27-.257 1.751.014l1.156.65c.481.27.478.702-.008.965l-9.803 5.305c-.485.263-1.27.257-1.75-.014zm6.068 3.409c-.482-.27-.478-.703.007-.966l9.803-5.305c.486-.263 1.27-.257 1.751.014l1.156.65c.481.27.478.702-.008.965l-9.803 5.305c-.485.263-1.27.257-1.751-.014zm-7.038 4.447c-.8-.45-.795-1.169.013-1.606l1.836-.993c.807-.437 2.11-.427 2.912.023.8.45.794 1.168-.013 1.605l-1.837.994c-.807.437-2.11.427-2.911-.023m6.079 1.803c-.808.437-.814 1.156-.013 1.606s2.104.46 2.912.023l1.836-.994c.807-.437.813-1.155.013-1.605s-2.105-.46-2.912-.023zm7.034-3.806c-.486.263-.49.695-.008.966l1.155.649c.482.27 1.266.276 1.752.014l9.802-5.305c.486-.263.49-.696.008-.966l-1.155-.65c-.482-.27-1.266-.276-1.752-.013zm5.812 4.235c-.482-.27-.478-.703.007-.966l9.803-5.305c.486-.263 1.27-.256 1.751.014l1.156.65c.481.27.478.702-.008.965l-9.803 5.305c-.486.263-1.27.257-1.751-.014zm-7.04 4.447c-.8-.45-.794-1.169.013-1.606l1.837-.994c.807-.437 2.11-.426 2.911.023.8.45.795 1.169-.013 1.606l-1.836.994c-.807.437-2.11.426-2.911-.023"
              clipRule="evenodd"
            />
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-484037129__a`}
                x1={91.32}
                x2={104.089}
                y1={86.909}
                y2={39.733}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.161} stopColor="#86B6FC" />
                <stop offset={1} stopColor="#86B6FC" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__b`}
                x1={51.88}
                x2={29.931}
                y1={90.318}
                y2={38.054}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.161} stopColor="#86B6FC" />
                <stop offset={1} stopColor="#86B6FC" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__c`}
                x1={65.52}
                x2={88.968}
                y1={81.909}
                y2={12.699}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.161} stopColor="#86B6FC" />
                <stop offset={1} stopColor="#86B6FC" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__d`}
                x1={131.378}
                x2={135.158}
                y1={56.762}
                y2={158.693}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__e`}
                x1={132.6}
                x2={135.732}
                y1={56.775}
                y2={213.957}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__f`}
                x1={131.378}
                x2={135.158}
                y1={56.762}
                y2={158.693}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__i`}
                x1={132.6}
                x2={135.732}
                y1={56.775}
                y2={213.957}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__j`}
                x1={132.6}
                x2={135.732}
                y1={56.775}
                y2={213.957}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__m`}
                x1={82.016}
                x2={79.236}
                y1={62.521}
                y2={156.143}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__n`}
                x1={92.558}
                x2={84.753}
                y1={63.76}
                y2={98.813}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-484037129__o`}
                x1={81.771}
                x2={102.784}
                y1={92.62}
                y2={58.178}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <filter
                id={`${idPrefix}-svg-484037129__h`}
                width={95.612}
                height={58.951}
                x={23.344}
                y={60.159}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset dy={4} />
                <feGaussianBlur stdDeviation={3.5} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_881"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_881"
                  result="shape"
                />
              </filter>
              <filter
                id={`${idPrefix}-svg-484037129__l`}
                width={95.612}
                height={58.951}
                x={23.344}
                y={47.224}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset dy={4} />
                <feGaussianBlur stdDeviation={3.5} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_881"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_881"
                  result="shape"
                />
              </filter>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
DataSharingIllustration.displayName = "DataSharingIllustration";
export { DataSharingIllustration };
