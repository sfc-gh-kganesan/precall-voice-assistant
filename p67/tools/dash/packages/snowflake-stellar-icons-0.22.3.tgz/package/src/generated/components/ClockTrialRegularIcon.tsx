import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClockTrialRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M8.913 14.939A7 7 0 0 1 8 15q-.465-.002-.914-.062l.129-.989a6 6 0 0 0 1.57 0zM4.348 12.76a6 6 0 0 0 1.355.785l-.383.923a7 7 0 0 1-1.582-.916zm7.912.792c-.481.37-1.012.68-1.581.916l-.382-.923a6 6 0 0 0 1.355-.784zm-9.805-3.255c.202.487.467.942.784 1.355l-.792.609a7 7 0 0 1-.916-1.582zm12.013.382a7 7 0 0 1-.916 1.582l-.791-.609c.317-.413.582-.868.784-1.355zM2.05 7.215a6 6 0 0 0 0 1.57l-.99.128a7 7 0 0 1 0-1.827zm12.889-.129c.038.3.061.604.061.914q-.002.465-.062.913l-.989-.128a6 6 0 0 0 0-1.57zM8.5 7.5H12v1H8a.5.5 0 0 1-.5-.5V4h1zM3.24 4.348a6 6 0 0 0-.785 1.355l-.924-.383c.236-.569.546-1.1.916-1.582zm10.312-.61c.37.482.68 1.013.916 1.582l-.923.383a6 6 0 0 0-.784-1.355zM5.703 2.455a6 6 0 0 0-1.355.784l-.61-.792a7 7 0 0 1 1.582-.916zm4.976-.924c.57.236 1.1.546 1.582.916l-.609.792a6 6 0 0 0-1.355-.784zM8 1q.465.002.913.06l-.128.99a6 6 0 0 0-1.57 0l-.13-.99Q7.536 1.003 8 1"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClockTrialRegularIcon.displayName = "ClockTrialRegularIcon";
export { ClockTrialRegularIcon };
