import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CellExpandRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M13.5 9a.5.5 0 0 1 .5.5v4l-.01.101a.5.5 0 0 1-.49.4h-11a.5.5 0 0 1-.5-.5v-4a.5.5 0 0 1 .5-.5zM3 13h10v-3H3zM13.5 2a.5.5 0 0 1 .5.5v4l-.01.101a.5.5 0 0 1-.49.4h-11a.5.5 0 0 1-.5-.5v-4a.5.5 0 0 1 .5-.5zM3 6h10V3H3z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CellExpandRegularIcon.displayName = "CellExpandRegularIcon";
export { CellExpandRegularIcon };
