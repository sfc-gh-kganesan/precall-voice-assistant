import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AnswerRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="m11.354 6.354-4 4a.5.5 0 0 1-.708 0l-2-2 .708-.708L7 9.293l3.646-3.647z" />
              <path
                fillRule="evenodd"
                d="M12.5 3A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5H4.207l-1.353 1.354A.5.5 0 0 1 2 14V4.5A1.5 1.5 0 0 1 3.5 3zm-9 1a.5.5 0 0 0-.5.5v8.293l.646-.646.077-.063A.5.5 0 0 1 4 12h8.5a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.5-.5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AnswerRegularIcon.displayName = "AnswerRegularIcon";
export { AnswerRegularIcon };
