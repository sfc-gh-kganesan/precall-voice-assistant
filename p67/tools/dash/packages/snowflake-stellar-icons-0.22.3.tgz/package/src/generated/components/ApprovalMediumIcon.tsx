import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApprovalMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M15 17.5H5v-1.25h10z" />
              <path
                fillRule="evenodd"
                d="M7.567 2.685a7.7 7.7 0 0 1 4.866 0 1.54 1.54 0 0 1 1.015 1.795l-.852 3.836-.028.213c-.01.212.035.425.131.617l.426.854h3.125c.69 0 1.25.56 1.25 1.25v2.5l-.006.128a1.25 1.25 0 0 1-1.116 1.116L16.25 15H3.75l-.128-.006A1.25 1.25 0 0 1 2.5 13.75v-2.5c0-.69.56-1.25 1.25-1.25h3.125l.426-.854a1.25 1.25 0 0 0 .103-.83L6.552 4.48a1.54 1.54 0 0 1 .878-1.741zM3.75 13.75h12.5v-2.5H3.75zm8.289-9.878a6.45 6.45 0 0 0-4.078 0 .29.29 0 0 0-.19.337l.853 3.836a2.5 2.5 0 0 1-.205 1.66L8.273 10h3.454l-.146-.295a2.5 2.5 0 0 1-.205-1.66l.853-3.836a.29.29 0 0 0-.19-.337"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ApprovalMediumIcon.displayName = "ApprovalMediumIcon";
export { ApprovalMediumIcon };
