import { forwardRef, ForwardedRef } from "react";

import { ArrowSlideLeftMediumIcon } from "./ArrowSlideLeftMediumIcon";
import { ArrowSlideLeftRegularIcon } from "./ArrowSlideLeftRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ArrowSlideLeftIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowSlideLeftIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowSlideLeftIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ArrowSlideLeftRegularIcon />;

    if (size === "medium") {
      icon = <ArrowSlideLeftMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowSlideLeftIcon.displayName = "ArrowSlideLeftIcon";

export type { ArrowSlideLeftIconProps };
export { ArrowSlideLeftIcon };
