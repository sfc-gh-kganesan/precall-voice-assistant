import { forwardRef, ForwardedRef } from "react";

import { ChartPlotMediumIcon } from "./ChartPlotMediumIcon";
import { ChartPlotRegularIcon } from "./ChartPlotRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChartPlotIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChartPlotIcon = forwardRef(
  (
    { size = "regular", ...props }: ChartPlotIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChartPlotRegularIcon />;

    if (size === "medium") {
      icon = <ChartPlotMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChartPlotIcon.displayName = "ChartPlotIcon";

export type { ChartPlotIconProps };
export { ChartPlotIcon };
