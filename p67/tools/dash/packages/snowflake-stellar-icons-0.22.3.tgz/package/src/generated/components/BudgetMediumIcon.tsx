import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BudgetMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M10.625 5.918c1.05.256 1.875 1.141 1.875 2.27h-1.25c0-.556-.508-1.096-1.25-1.096s-1.25.54-1.25 1.095.508 1.095 1.25 1.095c1.329 0 2.5 1 2.5 2.345 0 1.132-.837 2.015-1.887 2.27V15h-1.25v-1.102c-1.05-.257-1.863-1.146-1.863-2.27h1.25c0 .56.501 1.095 1.238 1.095.747 0 1.262-.546 1.262-1.096 0-.555-.508-1.095-1.25-1.095-1.329 0-2.5-1-2.5-2.345 0-1.128.825-2.013 1.875-2.269V5h1.25z" />
              <path
                fillRule="evenodd"
                d="M15.625 2.5c1.035 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875H4.375A1.875 1.875 0 0 1 2.5 15.625V4.375C2.5 3.34 3.34 2.5 4.375 2.5zM4.375 3.75a.625.625 0 0 0-.625.625v11.25c0 .345.28.625.625.625h11.25c.345 0 .625-.28.625-.625V4.375a.625.625 0 0 0-.625-.625z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BudgetMediumIcon.displayName = "BudgetMediumIcon";
export { BudgetMediumIcon };
