import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartPlotMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} fillRule="evenodd" clipRule="evenodd">
              <path d="M11.875 11.25a1.875 1.875 0 1 1 0 3.75 1.875 1.875 0 0 1 0-3.75m0 1.25a.625.625 0 1 0 0 1.25.625.625 0 0 0 0-1.25m-5-5a1.875 1.875 0 1 1 0 3.75 1.875 1.875 0 0 1 0-3.75m0 1.25a.625.625 0 1 0 0 1.25.625.625 0 0 0 0-1.25M13.125 5a1.875 1.875 0 1 1 0 3.75 1.875 1.875 0 0 1 0-3.75m0 1.25a.625.625 0 1 0 0 1.25.625.625 0 0 0 0-1.25" />
              <path d="M15.625 2.5c1.035 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875H4.375A1.875 1.875 0 0 1 2.5 15.625V4.375c0-1.036.84-1.875 1.875-1.875zM4.375 3.75a.625.625 0 0 0-.625.625v11.25c0 .345.28.625.625.625h11.25c.345 0 .625-.28.625-.625V4.375a.625.625 0 0 0-.625-.625z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ChartPlotMediumIcon.displayName = "ChartPlotMediumIcon";
export { ChartPlotMediumIcon };
