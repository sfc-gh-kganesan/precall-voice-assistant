import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DownloadCloudMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="m10.625 15.365 2.683-2.683.884.884-3.75 3.748A.63.63 0 0 1 10 17.5a.63.63 0 0 1-.442-.186l-3.75-3.748.884-.884 2.683 2.683V8.124h1.25z" />
              <path d="M9.897 2.505a4.96 4.96 0 0 1 4.565 3.706 4.416 4.416 0 0 1 4.288 4.414l-.005.22A4.41 4.41 0 0 1 16.25 14.6v-1.458a3.16 3.16 0 0 0 1.234-2.203l.016-.314a3.167 3.167 0 0 0-2.843-3.15l-.323-.016q-.164 0-.318.014l-.598.06-.083-.595a3.71 3.71 0 0 0-3.324-3.172l-.347-.016a3.71 3.71 0 0 0-3.708 3.709l.005.203q.005.1.016.198l.079.742-.745-.051c-.081-.006-.135-.01-.186-.01A2.626 2.626 0 0 0 2.5 11.167l.013.268a2.62 2.62 0 0 0 1.237 1.967v1.384a3.87 3.87 0 0 1-2.495-3.42l-.005-.199c0-2 1.514-3.646 3.458-3.854A4.96 4.96 0 0 1 9.664 2.5z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
DownloadCloudMediumIcon.displayName = "DownloadCloudMediumIcon";
export { DownloadCloudMediumIcon };
