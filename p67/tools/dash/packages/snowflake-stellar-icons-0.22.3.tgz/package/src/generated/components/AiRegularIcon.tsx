import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AiRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M11.347 9.026a.491.491 0 0 1 .918 0 3.92 3.92 0 0 0 2.141 2.216l.2.078.065.023a.496.496 0 0 1 0 .935l-.207.08a3.97 3.97 0 0 0-2.19 2.314.498.498 0 0 1-.902.077l-.034-.077a3.98 3.98 0 0 0-2.398-2.394l-.077-.034a.497.497 0 0 1 .077-.9l.065-.024a3.93 3.93 0 0 0 2.26-2.097zm.459 1.289a4.9 4.9 0 0 1-1.544 1.503c.623.395 1.15.923 1.544 1.547a5 5 0 0 1 1.543-1.547 4.9 4.9 0 0 1-1.543-1.503M5.395 1.53c.258-.707 1.26-.707 1.517 0a6.46 6.46 0 0 0 3.864 3.86c.708.257.708 1.257 0 1.515l-.332.13a6.46 6.46 0 0 0-3.532 3.728c-.241.663-1.137.704-1.46.124l-.057-.124a6.46 6.46 0 0 0-3.863-3.858l-.125-.057c-.582-.323-.54-1.218.125-1.459a6.46 6.46 0 0 0 3.731-3.527zm.759.79a7.45 7.45 0 0 1-3.831 3.826 7.45 7.45 0 0 1 3.83 3.826 7.45 7.45 0 0 1 3.83-3.826 7.45 7.45 0 0 1-3.83-3.825"
                clipRule="evenodd"
              />
              <path d="M14 3h1v1h-1v1h-1V4h-1V3h1V2h1z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AiRegularIcon.displayName = "AiRegularIcon";
export { AiRegularIcon };
