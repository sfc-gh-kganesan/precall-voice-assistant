import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronUpSmallMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M9.656 7.603a.626.626 0 0 1 .786.08l3.75 3.75-.884.884L10 9.009l-3.308 3.308-.884-.884 3.75-3.75z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronUpSmallMediumIcon.displayName = "ChevronUpSmallMediumIcon";
export { ChevronUpSmallMediumIcon };
