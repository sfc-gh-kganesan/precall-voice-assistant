import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationPackageRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path
                fillRule="evenodd"
                d="M11.31 5.689a.5.5 0 0 1 .426.027l4.006 2.225A.5.5 0 0 1 16 8.38v4.895c0 .182-.1.35-.258.438l-4.006 2.226a.5.5 0 0 1-.485 0l-4.006-2.226a.5.5 0 0 1-.257-.438V8.38c0-.181.099-.35.257-.438l4.006-2.225zM7.988 12.98l3.006 1.67v-3.752l-3.006-1.67zm4.006-2.082v3.751L15 12.981V9.228zm-3.476-2.52 2.975 1.653 2.977-1.653-2.977-1.652z"
                clipRule="evenodd"
              />
              <path d="M7.753 1.315a.5.5 0 0 1 .494 0L13.75 4.44a.5.5 0 0 1 .253.435V5h-1.291L8 2.324 2.998 5.165v5.669L6 12.539v1.15l-3.749-2.128a.5.5 0 0 1-.253-.435V4.875l.005-.066a.5.5 0 0 1 .248-.369z" />
              <path d="M8 5c.615 0 1.185.186 1.661.503l-1.012.606A2 2 0 0 0 6 8v2.231a3 3 0 0 1-.999-2.23 3 3 0 0 1 3-3" />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h16v16H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationPackageRegularIcon.displayName = "ApplicationPackageRegularIcon";
export { ApplicationPackageRegularIcon };
