import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CodeCompareMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M11.25 2.5h4.375c1.035 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875H11.25v1.25H10V1.25h1.25zm0 3.75h2.5V7.5h-2.5v1.25h2.5V10h-2.5v6.25h4.375c.345 0 .625-.28.625-.625V4.375a.625.625 0 0 0-.625-.625H11.25z"
                clipRule="evenodd"
              />
              <path d="M8.759 3.75H4.375a.625.625 0 0 0-.625.625v11.25c0 .345.28.625.625.625h4.384v1.25H4.375A1.875 1.875 0 0 1 2.5 15.625V4.375C2.5 3.34 3.34 2.5 4.375 2.5h4.384z" />
              <path d="M8.759 12.5H6.25v-1.25h2.509zm0-2.5H6.25V8.75h2.509zm0-2.5H6.25V6.25h2.509z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CodeCompareMediumIcon.displayName = "CodeCompareMediumIcon";
export { CodeCompareMediumIcon };
