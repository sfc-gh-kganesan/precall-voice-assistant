import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const BoxPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              stroke={iconColor}
              strokeWidth={2}
              d="M23.151 7.255a2 2 0 0 1 1.698 0l14 6.564A2 2 0 0 1 40 15.629v16.65a2 2 0 0 1-1.15 1.81l-14 6.58a2 2 0 0 1-1.7 0l-14-6.58A2 2 0 0 1 8 32.279v-16.65a2 2 0 0 1 1.151-1.81z"
            />
            <path
              stroke={iconColor}
              strokeLinejoin="round"
              strokeWidth={2}
              d="m8.144 14.386 15.828 7.44m0 0 15.584-7.064m-15.584 7.064v19.318"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BoxPictogram.displayName = "BoxPictogram";
export { BoxPictogram };
