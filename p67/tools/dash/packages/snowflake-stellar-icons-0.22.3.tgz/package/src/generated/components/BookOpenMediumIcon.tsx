import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BookOpenMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M9.254 5.561a5.96 5.96 0 0 0-6.754.202v9.262a6.7 6.7 0 0 1 6.875-.065V5.639zm8.246.07a6.23 6.23 0 0 0-6.665-.11l-.21.127v9.342a6.95 6.95 0 0 1 6.875-.043zm1.25 9.984a.878.878 0 0 1-1.38.72 5.71 5.71 0 0 0-6.242-.192l-.802.491-.336.204-.33-.212-.715-.463a5.445 5.445 0 0 0-6.295.276.868.868 0 0 1-1.4-.685V5.577a.89.89 0 0 1 .343-.702l.23-.17a7.21 7.21 0 0 1 8.109-.195l.076.05.175-.106a7.48 7.48 0 0 1 8.183.25.9.9 0 0 1 .384.737z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BookOpenMediumIcon.displayName = "BookOpenMediumIcon";
export { BookOpenMediumIcon };
