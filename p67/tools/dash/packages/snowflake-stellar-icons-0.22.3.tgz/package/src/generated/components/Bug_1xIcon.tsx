import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const Bug_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m10.123 1 .432.253-.99 1.69c.365.445.586 1.013.586 1.633l-.013.263a2.6 2.6 0 0 1-.243.85q.433.274.793.636l2.146-1.716.625.782-2.146 1.716-.011-.013A4.5 4.5 0 0 1 11.972 9H14v1h-2.028a4.5 4.5 0 0 1-.495 1.604l1.982 1.586-.625.782-1.923-1.54A4.49 4.49 0 0 1 7.5 14a4.5 4.5 0 0 1-3.28-1.42l-1.907 1.527-.626-.78 1.933-1.548A4.5 4.5 0 0 1 3.028 10H1V9h2.028c.08-.722.33-1.392.71-1.97l-2.05-1.64.625-.78 2.064 1.652q.383-.37.846-.643a2.6 2.6 0 0 1-.21-.78L5 4.576c0-.61.213-1.171.568-1.613l-1-1.71L5 1l.432-.252.914 1.564C6.71 2.112 7.13 2 7.576 2l.263.014c.338.034.656.135.943.288l.91-1.554zM7.5 6a3.5 3.5 0 0 0-.5 6.964V8h1v4.964A3.5 3.5 0 0 0 7.5 6m.076-3a1.576 1.576 0 0 0-1.442 2.21l-.1.035a4.5 4.5 0 0 1 2.98.017l-.019-.007A1.576 1.576 0 0 0 7.576 3"
            />
          </>
        }
        {...props}
      />
    );
  },
);
Bug_1xIcon.displayName = "Bug_1xIcon";
export { Bug_1xIcon };
