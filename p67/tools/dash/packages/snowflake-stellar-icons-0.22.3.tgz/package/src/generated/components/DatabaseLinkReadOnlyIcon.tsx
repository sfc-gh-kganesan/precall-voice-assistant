import { forwardRef, ForwardedRef } from "react";

import { DatabaseLinkReadOnlyMediumIcon } from "./DatabaseLinkReadOnlyMediumIcon";
import { DatabaseLinkReadOnlyRegularIcon } from "./DatabaseLinkReadOnlyRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DatabaseLinkReadOnlyIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DatabaseLinkReadOnlyIcon = forwardRef(
  (
    { size = "regular", ...props }: DatabaseLinkReadOnlyIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DatabaseLinkReadOnlyRegularIcon />;

    if (size === "medium") {
      icon = <DatabaseLinkReadOnlyMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DatabaseLinkReadOnlyIcon.displayName = "DatabaseLinkReadOnlyIcon";

export type { DatabaseLinkReadOnlyIconProps };
export { DatabaseLinkReadOnlyIcon };
