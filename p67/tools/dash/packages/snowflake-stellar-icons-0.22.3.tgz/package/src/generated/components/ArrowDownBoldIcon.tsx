import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
import { IconProps } from "../../types";
const ArrowDownBoldIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        {...props}
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              d="M8 14a1 1 0 0 0 .707-.293l5-5-1.414-1.414L9 10.586V2H7v8.586L3.707 7.293 2.293 8.707l5 5A1 1 0 0 0 8 14"
            />
          </>
        }
      />
    );
  },
);
ArrowDownBoldIcon.displayName = "ArrowDownBoldIcon";
export { ArrowDownBoldIcon };
