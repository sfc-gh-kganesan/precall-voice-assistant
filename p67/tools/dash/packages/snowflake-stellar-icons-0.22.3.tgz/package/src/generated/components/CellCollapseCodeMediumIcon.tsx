import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CellCollapseCodeMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M16.875 6.25a.626.626 0 0 1 .625.625v10l-.012.126a.626.626 0 0 1-.613.499H3.125a.626.626 0 0 1-.625-.625v-10c0-.345.28-.625.625-.625zm-9.375 10h8.75v-5H7.5zm-3.75 0h2.5v-5h-2.5zM7.5 10h8.75V7.5H7.5zm-3.75 0h2.5V7.5h-2.5z"
                clipRule="evenodd"
              />
              <path d="M17.5 3.75h-15V2.5h15z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CellCollapseCodeMediumIcon.displayName = "CellCollapseCodeMediumIcon";
export { CellCollapseCodeMediumIcon };
