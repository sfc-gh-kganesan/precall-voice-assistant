import { forwardRef, ForwardedRef } from "react";

import { ClockTrialMediumIcon } from "./ClockTrialMediumIcon";
import { ClockTrialRegularIcon } from "./ClockTrialRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ClockTrialIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ClockTrialIcon = forwardRef(
  (
    { size = "regular", ...props }: ClockTrialIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ClockTrialRegularIcon />;

    if (size === "medium") {
      icon = <ClockTrialMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ClockTrialIcon.displayName = "ClockTrialIcon";

export type { ClockTrialIconProps };
export { ClockTrialIcon };
