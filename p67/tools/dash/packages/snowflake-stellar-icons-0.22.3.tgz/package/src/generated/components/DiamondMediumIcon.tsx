import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DiamondMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M9.544 17.01a.625.625 0 0 0 .913 0l7.93-8.496a.625.625 0 0 0 .037-.81l-3.858-4.963a.63.63 0 0 0-.494-.241l-7.746.007a.63.63 0 0 0-.475.22L1.612 7.7a.625.625 0 0 0 .019.832zm.46-1.255.067-.074 2.855-6.994h-5.59zM7.617 7.562h5.07l-2.423-3.934h-.133zm1.08-3.932-2.11.001-3.25 3.931h2.847zM3.32 8.687h2.757l1.835 4.745zm8.362-5.06 2.424 3.935h2.661l-2.968-3.937zm5.001 5.06h-2.486l-1.89 4.504z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DiamondMediumIcon.displayName = "DiamondMediumIcon";
export { DiamondMediumIcon };
