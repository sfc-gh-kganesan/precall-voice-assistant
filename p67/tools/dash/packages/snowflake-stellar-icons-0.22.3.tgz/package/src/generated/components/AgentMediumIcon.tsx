import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AgentMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} fillRule="evenodd" clipRule="evenodd">
              <path d="M9.426 4.221a.615.615 0 0 1 1.148 0 4.9 4.9 0 0 0 2.677 2.771l.25.098.08.03a.62.62 0 0 1 0 1.167l-.257.102a4.97 4.97 0 0 0-2.74 2.892c-.184.513-.878.545-1.126.096l-.043-.097a4.97 4.97 0 0 0-2.997-2.993l-.097-.042a.622.622 0 0 1 .097-1.126l.081-.03a4.9 4.9 0 0 0 2.826-2.62zM10 5.833a6.2 6.2 0 0 1-1.93 1.88A6.2 6.2 0 0 1 10 9.645a6.2 6.2 0 0 1 1.93-1.934A6.2 6.2 0 0 1 10 5.832" />
              <path d="M10 1.25a8.75 8.75 0 1 1-6.346 14.77l-.018-.018A8.75 8.75 0 0 1 10 1.25m0 12.5c-1.956 0-3.782.56-5.323 1.532A7.48 7.48 0 0 0 10 17.5c2.08 0 3.962-.848 5.321-2.217A9.95 9.95 0 0 0 10 13.75M10 2.5a7.5 7.5 0 0 0-6.132 11.818A11.2 11.2 0 0 1 10 12.5c2.261 0 4.366.67 6.13 1.818A7.46 7.46 0 0 0 17.5 10 7.5 7.5 0 0 0 10 2.5" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AgentMediumIcon.displayName = "AgentMediumIcon";
export { AgentMediumIcon };
