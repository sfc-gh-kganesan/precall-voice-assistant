import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ContributionRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M4.5 1a1.998 1.998 0 0 1 .522 3.928A4 4 0 0 0 9 8.5h.565A1.999 1.999 0 0 1 13.5 9a2 2 0 0 1-3.935.5H9a5 5 0 0 1-4-2.001v3.566A1.999 1.999 0 1 1 2.5 13 2 2 0 0 1 4 11.065V4.934A1.998 1.998 0 0 1 4.5 1m0 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2m7-4a1 1 0 1 0 0 2 1 1 0 0 0 0-2m-7-6a1 1 0 1 0 0 2 1 1 0 0 0 0-2"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ContributionRegularIcon.displayName = "ContributionRegularIcon";
export { ContributionRegularIcon };
