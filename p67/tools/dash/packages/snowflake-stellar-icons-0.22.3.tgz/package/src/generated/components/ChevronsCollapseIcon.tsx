import { forwardRef, ForwardedRef } from "react";

import { ChevronsCollapseMediumIcon } from "./ChevronsCollapseMediumIcon";
import { ChevronsCollapseRegularIcon } from "./ChevronsCollapseRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronsCollapseIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronsCollapseIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronsCollapseIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronsCollapseRegularIcon />;

    if (size === "medium") {
      icon = <ChevronsCollapseMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronsCollapseIcon.displayName = "ChevronsCollapseIcon";

export type { ChevronsCollapseIconProps };
export { ChevronsCollapseIcon };
