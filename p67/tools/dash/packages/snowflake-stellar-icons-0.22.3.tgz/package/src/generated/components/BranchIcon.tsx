import { forwardRef, ForwardedRef } from "react";

import { BranchMediumIcon } from "./BranchMediumIcon";
import { BranchRegularIcon } from "./BranchRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BranchIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BranchIcon = forwardRef(
  (
    { size = "regular", ...props }: BranchIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BranchRegularIcon />;

    if (size === "medium") {
      icon = <BranchMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BranchIcon.displayName = "BranchIcon";

export type { BranchIconProps };
export { BranchIcon };
