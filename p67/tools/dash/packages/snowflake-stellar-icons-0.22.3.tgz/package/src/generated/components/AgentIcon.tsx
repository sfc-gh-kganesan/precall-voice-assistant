import { forwardRef, ForwardedRef } from "react";

import { AgentMediumIcon } from "./AgentMediumIcon";
import { AgentRegularIcon } from "./AgentRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AgentIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AgentIcon = forwardRef(
  (
    { size = "regular", ...props }: AgentIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AgentRegularIcon />;

    if (size === "medium") {
      icon = <AgentMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AgentIcon.displayName = "AgentIcon";

export type { AgentIconProps };
export { AgentIcon };
