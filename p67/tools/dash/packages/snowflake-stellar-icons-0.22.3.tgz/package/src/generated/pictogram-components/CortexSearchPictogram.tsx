import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const CortexSearchPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M43.5 12a1.333 1.333 0 0 1-1.333 1.333 5.333 5.333 0 0 0-5.334 5.334 1.333 1.333 0 1 1-2.666 0 5.333 5.333 0 0 0-5.334-5.334 1.333 1.333 0 1 1 0-2.666 5.333 5.333 0 0 0 5.334-5.334 1.333 1.333 0 1 1 2.666 0 5.333 5.333 0 0 0 5.334 5.334A1.333 1.333 0 0 1 43.5 12m-6.519-1.481A7.3 7.3 0 0 0 39.111 12a7.33 7.33 0 0 0-3.611 3.612A7.33 7.33 0 0 0 31.888 12 7.33 7.33 0 0 0 35.5 8.388c.36.786.859 1.508 1.481 2.13"
              clipRule="evenodd"
            />
            <path
              fill={iconColor}
              d="M21.231 7c1.3 0 2.564.163 3.769.47v2.075A13.2 13.2 0 0 0 21.231 9C13.924 9 8 14.924 8 22.231s5.924 13.231 13.231 13.231c7.05 0 12.81-5.513 13.209-12.462h2.003a15.17 15.17 0 0 1-3.758 9.27l10.023 10.023a1 1 0 0 1-1.415 1.415L31.271 33.685a15.17 15.17 0 0 1-10.04 3.777C12.819 37.462 6 30.642 6 22.231 6 13.819 12.82 7 21.231 7"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CortexSearchPictogram.displayName = "CortexSearchPictogram";
export { CortexSearchPictogram };
