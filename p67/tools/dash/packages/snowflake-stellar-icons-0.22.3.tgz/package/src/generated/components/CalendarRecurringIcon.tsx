import { forwardRef, ForwardedRef } from "react";

import { CalendarRecurringMediumIcon } from "./CalendarRecurringMediumIcon";
import { CalendarRecurringRegularIcon } from "./CalendarRecurringRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CalendarRecurringIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CalendarRecurringIcon = forwardRef(
  (
    { size = "regular", ...props }: CalendarRecurringIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CalendarRecurringRegularIcon />;

    if (size === "medium") {
      icon = <CalendarRecurringMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CalendarRecurringIcon.displayName = "CalendarRecurringIcon";

export type { CalendarRecurringIconProps };
export { CalendarRecurringIcon };
