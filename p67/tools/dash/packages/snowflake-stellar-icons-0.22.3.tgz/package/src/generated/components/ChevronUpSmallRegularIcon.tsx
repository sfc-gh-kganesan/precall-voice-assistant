import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronUpSmallRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.725 6.082a.5.5 0 0 1 .629.064l3 3-.707.707L8 7.207 5.354 9.853l-.708-.707 3-3z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronUpSmallRegularIcon.displayName = "ChevronUpSmallRegularIcon";
export { ChevronUpSmallRegularIcon };
