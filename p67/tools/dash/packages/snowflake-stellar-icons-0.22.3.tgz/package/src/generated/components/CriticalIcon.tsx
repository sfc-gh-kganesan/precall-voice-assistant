import { forwardRef, ForwardedRef } from "react";

import { CriticalMediumIcon } from "./CriticalMediumIcon";
import { CriticalRegularIcon } from "./CriticalRegularIcon";

import { Critical_1xIcon } from "./Critical_1xIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";
import { IconWith1x } from "../../IconWith1x";

interface CriticalIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CriticalIcon = forwardRef(
  (
    { size = "regular", ...props }: CriticalIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = (
      <IconWith1x icon1x={Critical_1xIcon} icon2x={CriticalRegularIcon} />
    );

    if (size === "medium") {
      icon = <CriticalMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CriticalIcon.displayName = "CriticalIcon";

export type { CriticalIconProps };
export { CriticalIcon };
