import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const AddTilesIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <rect
              width={59}
              height={53}
              x={135.059}
              y={43.186}
              fill={`url(#${idPrefix}-svg-1132966455__a)`}
              rx={10}
              transform="rotate(89.748 135.059 43.186)"
            />
            <path
              fill={`url(#${idPrefix}-svg-1132966455__b)`}
              fillRule="evenodd"
              d="M103.614 89.359a1 1 0 0 0 1.004.995l3.863-.017a1 1 0 0 0 .996-1.004l-.128-29.058a1 1 0 0 0-1.005-.995l-3.862.017a1 1 0 0 0-.996 1.004zm-8.393.025a1 1 0 0 0 1.004.996l3.863-.017a1 1 0 0 0 .995-1.005l-.101-22.963a1 1 0 0 0-1.004-.995l-3.863.016a1 1 0 0 0-.995 1.005zm16.745-.078a1 1 0 0 0 1.004.995l3.863-.017a1 1 0 0 0 .996-1.004l-.086-19.606a1 1 0 0 0-1.005-.995l-3.863.017a1 1 0 0 0-.995 1.004zm9.318.941a1 1 0 0 1-1.004-.996l-.039-8.802a1 1 0 0 1 .996-1.005l3.863-.017a1 1 0 0 1 1.004.996l.039 8.803a1 1 0 0 1-.996 1.004z"
              clipRule="evenodd"
            />
            <mask
              id={`${idPrefix}-svg-1132966455__d`}
              width={54}
              height={60}
              x={82}
              y={43}
              maskUnits="userSpaceOnUse"
              style={{
                maskType: "alpha",
              }}
            >
              <rect
                width={59}
                height={53}
                x={135.059}
                y={43.186}
                fill={`url(#${idPrefix}-svg-1132966455__c)`}
                rx={10}
                transform="rotate(89.748 135.059 43.186)"
              />
            </mask>
            <g
              filter={`url(#${idPrefix}-svg-1132966455__e)`}
              mask={`url(#${idPrefix}-svg-1132966455__d)`}
            >
              <g filter={`url(#${idPrefix}-svg-1132966455__f)`}>
                <rect
                  width={59}
                  height={53}
                  x={42.53}
                  y={118.172}
                  fill={`url(#${idPrefix}-svg-1132966455__g)`}
                  rx={10}
                  transform="rotate(-89.23 42.53 118.172)"
                />
              </g>
            </g>
            <rect
              width={59}
              height={53}
              x={42.792}
              y={118.159}
              fill={`url(#${idPrefix}-svg-1132966455__h)`}
              rx={10}
              transform="rotate(-89.23 42.792 118.159)"
            />
            <path
              fill={`url(#${idPrefix}-svg-1132966455__i)`}
              d="M51.87 71.021c-5.713-.076-6.96 11.742-8.579 19.896l-.145 10.789 52.973.712.461-34.33c-12.017 1.31-3.489 27.725-15.42 26.555-5.407-.53-4.832-9.154-15.978-9.304-8.235-.11-6.88-14.231-13.313-14.318"
            />
            <rect
              width={17}
              height={17}
              x={24.982}
              y={13.114}
              fill={`url(#${idPrefix}-svg-1132966455__j)`}
              rx={4}
            />
            <path
              fill={`url(#${idPrefix}-svg-1132966455__k)`}
              fillRule="evenodd"
              d="M32.184 25.965a1 1 0 0 0 1 1h.5a1 1 0 0 0 1-1v-3.298h3.149a1 1 0 0 0 1-1v-.5a1 1 0 0 0-1-1h-3.15v-3.053a1 1 0 0 0-1-1h-.5a1 1 0 0 0-1 1v3.053h-3.201a1 1 0 0 0-1 1v.5a1 1 0 0 0 1 1h3.202z"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-1132966455__l)`}
              fillRule="evenodd"
              d="M34.874 35.088a2 2 0 0 0-3.384 0l-5.075 8.05a9 9 0 0 0-.17.28H15.683a9 9 0 0 0-9 9v41a9 9 0 0 0 9 9h36a9 9 0 0 0 9-9v-41a9 9 0 0 0-9-9H40.118a8 8 0 0 0-.17-.28z"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-1132966455__m)`}
              d="M17.066 80.119c-4.615-5.143-8.846 5.476-10.384 11.428v7.857h54v-25c-12.231 1.072-18 20-23.539 20-5.538 0-3.923-12.143-9-7.5s-5.308-.357-11.077-6.785"
              opacity={0.4}
            />
            <path
              stroke={`url(#${idPrefix}-svg-1132966455__n)`}
              strokeLinecap="round"
              strokeWidth={3}
              d="M6.682 78.418c1.788-6.134 6.774-18.4 12.408-18.4 7.042 0 6.036 18.4 15.09 18.4s11.01-10.953 17.383-10.953c6.371 0 7.042 8.8 8.719 8.8"
            />
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__a`}
                x1={141.493}
                x2={229.594}
                y1={58.214}
                y2={72.278}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#EAF2FF" />
                <stop offset={1} stopColor="#76AEFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__b`}
                x1={97.004}
                x2={116.188}
                y1={50.382}
                y2={87.225}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#7AB2FF" stopOpacity={0} />
                <stop offset={0} stopColor="#7AB2FF" stopOpacity={0} />
                <stop offset={1} stopColor="#7AB2FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__c`}
                x1={141.493}
                x2={229.594}
                y1={58.214}
                y2={72.278}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#EAF2FF" />
                <stop offset={1} stopColor="#76AEFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__g`}
                x1={104.03}
                x2={58.648}
                y1={93.672}
                y2={287.98}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.182} stopColor="#EAF2FF" />
                <stop offset={1} stopColor="#76AEFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__h`}
                x1={99.493}
                x2={-4.858}
                y1={156.353}
                y2={80.911}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#EAF2FF" />
                <stop offset={1} stopColor="#76AEFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__i`}
                x1={76.146}
                x2={67.039}
                y1={48.625}
                y2={101.617}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0} stopColor="#66A2FF" />
                <stop offset={0.932} stopColor="#66A2FF" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__j`}
                x1={34.677}
                x2={54.816}
                y1={15.079}
                y2={47.317}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__k`}
                x1={30.03}
                x2={23.619}
                y1={25.786}
                y2={10.693}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__l`}
                x1={37.479}
                x2={65.951}
                y1={42.046}
                y2={89.687}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__m`}
                x1={17.402}
                x2={18.449}
                y1={79.472}
                y2={96.734}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.021} stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1132966455__n`}
                x1={58.942}
                x2={6.84}
                y1={79.771}
                y2={76.142}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.005} stopColor="#fff" stopOpacity={0} />
                <stop offset={0.443} stopColor="#fff" />
                <stop offset={0.609} stopColor="#fff" />
                <stop offset={0.97} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <filter
                id={`${idPrefix}-svg-1132966455__e`}
                width={77.521}
                height={83.44}
                x={36.663}
                y={37.311}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset dx={6} dy={-10} />
                <feGaussianBlur stdDeviation={6} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.6 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_98"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_98"
                  result="shape"
                />
              </filter>
              <filter
                id={`${idPrefix}-svg-1132966455__f`}
                width={91.521}
                height={97.44}
                x={15.663}
                y={32.311}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset dx={-8} dy={-8} />
                <feGaussianBlur stdDeviation={9.5} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_98"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_98"
                  result="shape"
                />
              </filter>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
AddTilesIllustration.displayName = "AddTilesIllustration";
export { AddTilesIllustration };
