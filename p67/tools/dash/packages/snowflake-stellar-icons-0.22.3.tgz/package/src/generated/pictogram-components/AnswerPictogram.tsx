import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const AnswerPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              d="m33.412 17.086-1.326-1.498-11.38 10.076-4.792-4.242-1.326 1.497 5.455 4.83a1 1 0 0 0 1.326 0z"
            />
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M8 7.5a4 4 0 0 0-4 4V32a4 4 0 0 0 4 4h8.62a2 2 0 0 1 1.519.698L22.51 41.8a2 2 0 0 0 2.984.06l4.848-5.22a2 2 0 0 1 1.465-.64H40a4 4 0 0 0 4-4V11.5a4 4 0 0 0-4-4zm-2 4a2 2 0 0 1 2-2h32a2 2 0 0 1 2 2V32a2 2 0 0 1-2 2h-8.192a4 4 0 0 0-2.931 1.278l-4.847 5.22-4.373-5.101A4 4 0 0 0 16.62 34H8a2 2 0 0 1-2-2z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
AnswerPictogram.displayName = "AnswerPictogram";
export { AnswerPictogram };
