import { forwardRef, ForwardedRef } from "react";

import { ClassicConsoleMediumIcon } from "./ClassicConsoleMediumIcon";
import { ClassicConsoleRegularIcon } from "./ClassicConsoleRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ClassicConsoleIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ClassicConsoleIcon = forwardRef(
  (
    { size = "regular", ...props }: ClassicConsoleIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ClassicConsoleRegularIcon />;

    if (size === "medium") {
      icon = <ClassicConsoleMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ClassicConsoleIcon.displayName = "ClassicConsoleIcon";

export type { ClassicConsoleIconProps };
export { ClassicConsoleIcon };
