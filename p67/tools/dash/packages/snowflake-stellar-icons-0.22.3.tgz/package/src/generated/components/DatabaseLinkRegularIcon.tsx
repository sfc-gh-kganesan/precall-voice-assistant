import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabaseLinkRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path d="M10 11H8.096a2.011 2.011 0 0 0 0 4.02H10v1H8.096a3.01 3.01 0 0 1 0-6.02H10zm2.99-1a3.011 3.011 0 0 1 0 6.02h-1.93v-1h1.93a2.01 2.01 0 1 0 0-4.02h-1.93v-1z" />
              <path d="M13 13.5H8v-1h5z" />
              <path
                fillRule="evenodd"
                d="M8.001 2c1.303 0 2.509.263 3.406.71.868.434 1.595 1.126 1.595 2.039q0 .086-.008.169.008.09.008.182V8h-1V6.427a4 4 0 0 1-.595.36c-.897.447-2.103.71-3.406.71-1.304 0-2.509-.262-3.406-.71A4 4 0 0 1 4 6.426v6.351c-.594-.489-1-1.127-1-1.878V5.1q0-.095.008-.186A2 2 0 0 1 3 4.75c0-.912.727-1.605 1.595-2.038C5.492 2.263 6.697 2 8 2m0 1c-1.17 0-2.207.275-2.933.694-.633.366-.966.798-1.047 1.205.073.305.371.668 1.021.993.731.365 1.777.605 2.959.605s2.228-.24 2.959-.605c.65-.325.946-.688 1.02-.993-.081-.407-.413-.839-1.046-1.205-.635-.366-1.508-.623-2.5-.681z"
                clipRule="evenodd"
              />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h16v16H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
DatabaseLinkRegularIcon.displayName = "DatabaseLinkRegularIcon";
export { DatabaseLinkRegularIcon };
