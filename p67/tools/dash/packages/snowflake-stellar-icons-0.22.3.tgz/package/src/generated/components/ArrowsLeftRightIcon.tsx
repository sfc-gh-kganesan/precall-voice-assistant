import { forwardRef, ForwardedRef } from "react";

import { ArrowsLeftRightMediumIcon } from "./ArrowsLeftRightMediumIcon";
import { ArrowsLeftRightRegularIcon } from "./ArrowsLeftRightRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ArrowsLeftRightIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowsLeftRightIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowsLeftRightIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ArrowsLeftRightRegularIcon />;

    if (size === "medium") {
      icon = <ArrowsLeftRightMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowsLeftRightIcon.displayName = "ArrowsLeftRightIcon";

export type { ArrowsLeftRightIconProps };
export { ArrowsLeftRightIcon };
