import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartPieMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10 1.25a8.75 8.75 0 1 1 0 17.5 8.75 8.75 0 0 1 0-17.5m-.625 1.278A7.499 7.499 0 0 0 10 17.5a7.5 7.5 0 0 0 6.974-10.259l-6.661 3.847a.625.625 0 0 1-.938-.541zm1.25 6.936 5.794-3.346a7.5 7.5 0 0 0-5.794-3.59z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartPieMediumIcon.displayName = "ChartPieMediumIcon";
export { ChartPieMediumIcon };
