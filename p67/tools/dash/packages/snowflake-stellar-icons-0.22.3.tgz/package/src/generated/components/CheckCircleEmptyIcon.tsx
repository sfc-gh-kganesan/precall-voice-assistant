import { forwardRef, ForwardedRef } from "react";

import { CheckCircleEmptyMediumIcon } from "./CheckCircleEmptyMediumIcon";
import { CheckCircleEmptySmallIcon } from "./CheckCircleEmptySmallIcon";

import { IconProps } from "../../types";

interface CheckCircleEmptyIconProps extends IconProps {
  size?: "medium" | "small";
}

const CheckCircleEmptyIcon = forwardRef(
  (
    { size = "small", ...props }: CheckCircleEmptyIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    if (size === "small") {
      return <CheckCircleEmptySmallIcon ref={ref} {...props} />;
    }

    return <CheckCircleEmptyMediumIcon ref={ref} {...props} />;
  },
);

CheckCircleEmptyIcon.displayName = "CheckCircleEmptyIcon";

export type { CheckCircleEmptyIconProps };
export { CheckCircleEmptyIcon };
