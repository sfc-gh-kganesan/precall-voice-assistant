import { forwardRef, ForwardedRef } from "react";

import { ArrowsUpDownMediumIcon } from "./ArrowsUpDownMediumIcon";
import { ArrowsUpDownRegularIcon } from "./ArrowsUpDownRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ArrowsUpDownIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowsUpDownIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowsUpDownIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ArrowsUpDownRegularIcon />;

    if (size === "medium") {
      icon = <ArrowsUpDownMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowsUpDownIcon.displayName = "ArrowsUpDownIcon";

export type { ArrowsUpDownIconProps };
export { ArrowsUpDownIcon };
