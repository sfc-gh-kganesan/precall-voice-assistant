import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BugMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="m13.014 2.771.54.316-1.01 1.724c.422.545.675 1.228.675 1.971l-.017.329a3.3 3.3 0 0 1-.133.636q.48.336.876.765l2.103-1.682.782.976-2.15 1.718c.34.604.566 1.279.65 1.998h2.183v1.25h-2.185a5.3 5.3 0 0 1-.648 1.997l2.15 1.719-.782.977-2.103-1.684A5.35 5.35 0 0 1 10 17.513l-.276-.007a5.35 5.35 0 0 1-3.672-1.723l-2.1 1.682-.782-.977 2.147-1.719a5.3 5.3 0 0 1-.646-1.997H2.486v-1.25h2.185a5.3 5.3 0 0 1 .647-1.997L3.17 7.806l.781-.976 2.102 1.682q.395-.43.875-.767a3.2 3.2 0 0 1-.131-.634l-.017-.329c0-.742.254-1.424.676-1.969l-1.01-1.726.54-.316.54-.315.89 1.523A3.2 3.2 0 0 1 10 3.562l.328.017c.453.046.876.188 1.254.402l.892-1.525zM10 8.031a4.117 4.117 0 0 0-.625 8.185V9.464h1.25v6.752A4.117 4.117 0 0 0 10 8.03m0-3.219a1.97 1.97 0 0 0-1.937 2.33A5.3 5.3 0 0 1 10 6.78l.276.007a5.3 5.3 0 0 1 1.656.354q.035-.175.037-.36a1.97 1.97 0 0 0-1.97-1.97"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BugMediumIcon.displayName = "BugMediumIcon";
export { BugMediumIcon };
