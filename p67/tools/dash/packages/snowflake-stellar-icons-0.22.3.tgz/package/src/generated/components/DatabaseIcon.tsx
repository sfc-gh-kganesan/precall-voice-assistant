import { forwardRef, ForwardedRef } from "react";

import { DatabaseMediumIcon } from "./DatabaseMediumIcon";
import { DatabaseRegularIcon } from "./DatabaseRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DatabaseIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DatabaseIcon = forwardRef(
  (
    { size = "regular", ...props }: DatabaseIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DatabaseRegularIcon />;

    if (size === "medium") {
      icon = <DatabaseMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DatabaseIcon.displayName = "DatabaseIcon";

export type { DatabaseIconProps };
export { DatabaseIcon };
