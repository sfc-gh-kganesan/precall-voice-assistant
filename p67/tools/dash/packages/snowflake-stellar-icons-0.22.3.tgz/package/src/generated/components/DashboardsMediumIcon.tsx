import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DashboardsMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M15.625 2.5c1.035 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875H4.375A1.875 1.875 0 0 1 2.5 15.625V4.375C2.5 3.34 3.34 2.5 4.375 2.5zM3.75 15.625c0 .345.28.625.625.625h5V12.5H3.75zm6.875-6.875v7.5h5c.345 0 .625-.28.625-.625V8.75zm-6.25-5a.625.625 0 0 0-.625.625v6.875h5.625v-7.5zm6.25 3.75h5.625V4.375a.625.625 0 0 0-.625-.625h-5z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DashboardsMediumIcon.displayName = "DashboardsMediumIcon";
export { DashboardsMediumIcon };
