import { forwardRef, ForwardedRef } from "react";

import { CommaMediumIcon } from "./CommaMediumIcon";
import { CommaRegularIcon } from "./CommaRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CommaIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CommaIcon = forwardRef(
  (
    { size = "regular", ...props }: CommaIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CommaRegularIcon />;

    if (size === "medium") {
      icon = <CommaMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CommaIcon.displayName = "CommaIcon";

export type { CommaIconProps };
export { CommaIcon };
