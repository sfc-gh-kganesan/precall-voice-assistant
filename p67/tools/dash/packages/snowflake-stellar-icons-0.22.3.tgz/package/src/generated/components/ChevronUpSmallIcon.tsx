import { forwardRef, ForwardedRef } from "react";

import { ChevronUpSmallMediumIcon } from "./ChevronUpSmallMediumIcon";
import { ChevronUpSmallRegularIcon } from "./ChevronUpSmallRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronUpSmallIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronUpSmallIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronUpSmallIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronUpSmallRegularIcon />;

    if (size === "medium") {
      icon = <ChevronUpSmallMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronUpSmallIcon.displayName = "ChevronUpSmallIcon";

export type { ChevronUpSmallIconProps };
export { ChevronUpSmallIcon };
