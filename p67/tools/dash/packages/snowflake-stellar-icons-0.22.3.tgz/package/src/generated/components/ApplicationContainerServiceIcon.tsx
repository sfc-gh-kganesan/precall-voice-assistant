import { forwardRef, ForwardedRef } from "react";

import { ApplicationContainerServiceMediumIcon } from "./ApplicationContainerServiceMediumIcon";
import { ApplicationContainerServiceRegularIcon } from "./ApplicationContainerServiceRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ApplicationContainerServiceIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ApplicationContainerServiceIcon = forwardRef(
  (
    { size = "regular", ...props }: ApplicationContainerServiceIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ApplicationContainerServiceRegularIcon />;

    if (size === "medium") {
      icon = <ApplicationContainerServiceMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ApplicationContainerServiceIcon.displayName = "ApplicationContainerServiceIcon";

export type { ApplicationContainerServiceIconProps };
export { ApplicationContainerServiceIcon };
