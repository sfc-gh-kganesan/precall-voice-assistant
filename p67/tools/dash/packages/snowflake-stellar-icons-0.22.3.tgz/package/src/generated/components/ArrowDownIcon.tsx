import { forwardRef, ForwardedRef } from "react";

import { ArrowDownMediumIcon } from "./ArrowDownMediumIcon";
import { ArrowDownRegularIcon } from "./ArrowDownRegularIcon";

import { ArrowDown_1xIcon } from "./ArrowDown_1xIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";
import { IconWith1x } from "../../IconWith1x";

interface ArrowDownIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowDownIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowDownIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = (
      <IconWith1x icon1x={ArrowDown_1xIcon} icon2x={ArrowDownRegularIcon} />
    );

    if (size === "medium") {
      icon = <ArrowDownMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowDownIcon.displayName = "ArrowDownIcon";

export type { ArrowDownIconProps };
export { ArrowDownIcon };
