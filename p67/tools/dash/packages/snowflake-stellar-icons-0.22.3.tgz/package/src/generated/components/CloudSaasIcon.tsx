import { forwardRef, ForwardedRef } from "react";

import { CloudSaasMediumIcon } from "./CloudSaasMediumIcon";
import { CloudSaasRegularIcon } from "./CloudSaasRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CloudSaasIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CloudSaasIcon = forwardRef(
  (
    { size = "regular", ...props }: CloudSaasIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CloudSaasRegularIcon />;

    if (size === "medium") {
      icon = <CloudSaasMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CloudSaasIcon.displayName = "CloudSaasIcon";

export type { CloudSaasIconProps };
export { CloudSaasIcon };
