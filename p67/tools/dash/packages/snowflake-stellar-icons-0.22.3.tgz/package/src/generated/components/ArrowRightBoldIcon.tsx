import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
import { IconProps } from "../../types";
const ArrowRightBoldIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        {...props}
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              d="M14 8a1 1 0 0 1-.293.707l-5 5-1.414-1.414L10.586 9H2V7h8.586L7.293 3.707l1.414-1.414 5 5A1 1 0 0 1 14 8"
            />
          </>
        }
      />
    );
  },
);
ArrowRightBoldIcon.displayName = "ArrowRightBoldIcon";
export { ArrowRightBoldIcon };
