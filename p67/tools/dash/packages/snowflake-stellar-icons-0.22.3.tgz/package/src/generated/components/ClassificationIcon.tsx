import { forwardRef, ForwardedRef } from "react";

import { ClassificationMediumIcon } from "./ClassificationMediumIcon";
import { ClassificationRegularIcon } from "./ClassificationRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ClassificationIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ClassificationIcon = forwardRef(
  (
    { size = "regular", ...props }: ClassificationIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ClassificationRegularIcon />;

    if (size === "medium") {
      icon = <ClassificationMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ClassificationIcon.displayName = "ClassificationIcon";

export type { ClassificationIconProps };
export { ClassificationIcon };
