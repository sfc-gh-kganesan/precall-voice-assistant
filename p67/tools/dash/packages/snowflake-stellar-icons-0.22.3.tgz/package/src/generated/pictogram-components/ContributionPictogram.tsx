import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const ContributionPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M34.5 18a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11M31 23.5a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0"
              clipRule="evenodd"
            />
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M19.874 24h2.136a12.46 12.46 0 0 0 3.737 8.423l-5.816 6.932 1.532 1.285 5.818-6.934A12.44 12.44 0 0 0 34.5 36C41.404 36 47 30.404 47 23.5S41.404 11 34.5 11c-6.396 0-11.67 4.804-12.41 11h-2.216a4.002 4.002 0 0 0-7.748 0H8.874A4.002 4.002 0 0 0 1 23a4 4 0 0 0 7.874 1h3.252a4.002 4.002 0 0 0 7.748 0M34.5 13C28.701 13 24 17.701 24 23.5S28.701 34 34.5 34 45 29.299 45 23.5 40.299 13 34.5 13M5 21a2 2 0 1 0 0 4 2 2 0 0 0 0-4m11 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ContributionPictogram.displayName = "ContributionPictogram";
export { ContributionPictogram };
