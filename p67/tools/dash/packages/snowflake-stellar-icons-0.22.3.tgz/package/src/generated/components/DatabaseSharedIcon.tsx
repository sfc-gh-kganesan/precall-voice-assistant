import { forwardRef, ForwardedRef } from "react";

import { DatabaseSharedMediumIcon } from "./DatabaseSharedMediumIcon";
import { DatabaseSharedRegularIcon } from "./DatabaseSharedRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DatabaseSharedIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DatabaseSharedIcon = forwardRef(
  (
    { size = "regular", ...props }: DatabaseSharedIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DatabaseSharedRegularIcon />;

    if (size === "medium") {
      icon = <DatabaseSharedMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DatabaseSharedIcon.displayName = "DatabaseSharedIcon";

export type { DatabaseSharedIconProps };
export { DatabaseSharedIcon };
