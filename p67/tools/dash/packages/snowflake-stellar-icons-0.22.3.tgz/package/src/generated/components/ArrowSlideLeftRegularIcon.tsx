import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowSlideLeftRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M4.5 8a.5.5 0 0 0 .146.354l4.5 4.5.708-.707L6.207 8.5H14v-1H6.207l3.647-3.646-.708-.708-4.5 4.5A.5.5 0 0 0 4.5 8M3 14V2H2v12z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowSlideLeftRegularIcon.displayName = "ArrowSlideLeftRegularIcon";
export { ArrowSlideLeftRegularIcon };
