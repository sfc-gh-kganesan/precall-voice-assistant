import { forwardRef, ForwardedRef } from "react";

import { AwsMediumIcon } from "./AwsMediumIcon";
import { AwsRegularIcon } from "./AwsRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AwsIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AwsIcon = forwardRef(
  (
    { size = "regular", ...props }: AwsIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AwsRegularIcon />;

    if (size === "medium") {
      icon = <AwsMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AwsIcon.displayName = "AwsIcon";

export type { AwsIconProps };
export { AwsIcon };
