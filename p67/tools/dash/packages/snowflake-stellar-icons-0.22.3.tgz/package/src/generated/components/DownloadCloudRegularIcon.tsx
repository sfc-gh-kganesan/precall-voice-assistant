import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DownloadCloudRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="m8.5 12.292 2.146-2.146.707.706-3 3A.5.5 0 0 1 8 14a.5.5 0 0 1-.354-.148l-3-3 .708-.707L7.5 12.293V6.499h1z" />
              <path d="M7.918 2.004a3.97 3.97 0 0 1 3.651 2.965A3.533 3.533 0 0 1 15 8.5l-.004.176A3.53 3.53 0 0 1 13 11.68v-1.166a2.53 2.53 0 0 0 .987-1.763L14 8.5c0-1.312-.997-2.39-2.274-2.52l-.26-.013q-.13 0-.253.012l-.479.047-.066-.475a2.97 2.97 0 0 0-2.66-2.538L7.732 3a2.967 2.967 0 0 0-2.966 2.967l.004.163q.004.08.012.158l.064.594-.596-.041a2 2 0 0 0-.15-.008 2.1 2.1 0 0 0-2.1 2.1l.01.215A2.1 2.1 0 0 0 3 10.722v1.107a3.1 3.1 0 0 1-1.996-2.736L1 8.933a3.1 3.1 0 0 1 2.767-3.082A3.967 3.967 0 0 1 7.73 2z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
DownloadCloudRegularIcon.displayName = "DownloadCloudRegularIcon";
export { DownloadCloudRegularIcon };
