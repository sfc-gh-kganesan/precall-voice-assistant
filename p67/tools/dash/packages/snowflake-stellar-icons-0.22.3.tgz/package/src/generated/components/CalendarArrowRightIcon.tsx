import { forwardRef, ForwardedRef } from "react";

import { CalendarArrowRightMediumIcon } from "./CalendarArrowRightMediumIcon";
import { CalendarArrowRightRegularIcon } from "./CalendarArrowRightRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CalendarArrowRightIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CalendarArrowRightIcon = forwardRef(
  (
    { size = "regular", ...props }: CalendarArrowRightIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CalendarArrowRightRegularIcon />;

    if (size === "medium") {
      icon = <CalendarArrowRightMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CalendarArrowRightIcon.displayName = "CalendarArrowRightIcon";

export type { CalendarArrowRightIconProps };
export { CalendarArrowRightIcon };
