import { forwardRef, ForwardedRef } from "react";

import { ChartLineMediumIcon } from "./ChartLineMediumIcon";
import { ChartLineRegularIcon } from "./ChartLineRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChartLineIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChartLineIcon = forwardRef(
  (
    { size = "regular", ...props }: ChartLineIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChartLineRegularIcon />;

    if (size === "medium") {
      icon = <ChartLineMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChartLineIcon.displayName = "ChartLineIcon";

export type { ChartLineIconProps };
export { ChartLineIcon };
