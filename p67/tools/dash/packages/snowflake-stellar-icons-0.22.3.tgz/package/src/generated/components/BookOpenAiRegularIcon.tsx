import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BookOpenAiRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M11.037 7.87a.667.667 0 0 1 1.246 0 5.33 5.33 0 0 0 2.91 3.011l.27.106.09.032a.674.674 0 0 1 0 1.269 5.4 5.4 0 0 0-3.258 3.253c-.2.557-.953.591-1.223.104l-.047-.104a5.4 5.4 0 0 0-3.257-3.253.674.674 0 0 1 0-1.269l.088-.032a5.33 5.33 0 0 0 3.07-2.848zm.623 1.044a6.33 6.33 0 0 1-2.829 2.746 6.4 6.4 0 0 1 2.83 2.833 6.4 6.4 0 0 1 2.828-2.834 6.33 6.33 0 0 1-2.829-2.745"
                clipRule="evenodd"
              />
              <path d="M8.146 3.562a5.99 5.99 0 0 1 6.546.2.72.72 0 0 1 .308.59v3.649h-1V4.504a4.98 4.98 0 0 0-5.332-.088l-.168.102v3.483h-1V4.509l-.097-.061A4.77 4.77 0 0 0 2 4.608v7.412a5.36 5.36 0 0 1 4-.646v1.032a4.36 4.36 0 0 0-3.88.745.694.694 0 0 1-1.12-.549V4.46c0-.218.102-.426.274-.56l.184-.137a5.77 5.77 0 0 1 6.487-.155l.06.039z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BookOpenAiRegularIcon.displayName = "BookOpenAiRegularIcon";
export { BookOpenAiRegularIcon };
