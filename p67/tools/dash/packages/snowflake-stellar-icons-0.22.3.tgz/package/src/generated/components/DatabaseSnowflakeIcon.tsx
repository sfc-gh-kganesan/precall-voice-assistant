import { forwardRef, ForwardedRef } from "react";

import { DatabaseSnowflakeMediumIcon } from "./DatabaseSnowflakeMediumIcon";
import { DatabaseSnowflakeRegularIcon } from "./DatabaseSnowflakeRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DatabaseSnowflakeIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DatabaseSnowflakeIcon = forwardRef(
  (
    { size = "regular", ...props }: DatabaseSnowflakeIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DatabaseSnowflakeRegularIcon />;

    if (size === "medium") {
      icon = <DatabaseSnowflakeMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DatabaseSnowflakeIcon.displayName = "DatabaseSnowflakeIcon";

export type { DatabaseSnowflakeIconProps };
export { DatabaseSnowflakeIcon };
