import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DollarSignRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M8.5 3.522q.579.062 1.05.29.65.31 1.024.857.374.542.39 1.245h-1.21q-.065-.606-.536-.938-.472-.337-1.186-.337-.51 0-.885.17-.373.167-.58.462a1.13 1.13 0 0 0-.203.66q0 .312.138.538.142.225.37.38.231.149.495.25.264.099.507.163l.813.222q.397.103.815.277t.775.46.578.709q.222.422.222 1.01 0 .743-.365 1.319-.36.575-1.05.908a3.4 3.4 0 0 1-1.162.309V14h-1v-1.525a3.5 3.5 0 0 1-1.116-.287 2.5 2.5 0 0 1-1.068-.882q-.386-.577-.426-1.366h1.258q.038.475.293.79.26.31.662.464.405.15.89.15.531 0 .944-.175a1.6 1.6 0 0 0 .659-.494q.24-.321.239-.747 0-.389-.211-.636a1.6 1.6 0 0 0-.564-.41 5.3 5.3 0 0 0-.8-.285l-.983-.282q-.998-.285-1.583-.84-.58-.555-.58-1.467 0-.754.389-1.318.39-.563 1.056-.875.434-.206.941-.277V2h1z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DollarSignRegularIcon.displayName = "DollarSignRegularIcon";
export { DollarSignRegularIcon };
