import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CriticalRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M12 8.5H4v-1h8z" />
              <path
                fillRule="evenodd"
                d="M10.584 1.005a1 1 0 0 1 .608.288l3.515 3.515a1 1 0 0 1 .293.707v4.97l-.005.099a1 1 0 0 1-.288.608l-3.515 3.515a1 1 0 0 1-.608.288l-.099.005h-4.97l-.099-.005a1 1 0 0 1-.535-.222l-.073-.066-3.515-3.515a1 1 0 0 1-.288-.608L1 10.485v-4.97a1 1 0 0 1 .227-.634l.066-.073 3.515-3.515A1 1 0 0 1 5.515 1h4.97zM2 5.515v4.97L5.515 14h4.97L14 10.485v-4.97L10.485 2h-4.97z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CriticalRegularIcon.displayName = "CriticalRegularIcon";
export { CriticalRegularIcon };
