import { forwardRef, ForwardedRef } from "react";

import { ClockMediumIcon } from "./ClockMediumIcon";
import { ClockRegularIcon } from "./ClockRegularIcon";

import { Clock_1xIcon } from "./Clock_1xIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";
import { IconWith1x } from "../../IconWith1x";

interface ClockIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ClockIcon = forwardRef(
  (
    { size = "regular", ...props }: ClockIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <IconWith1x icon1x={Clock_1xIcon} icon2x={ClockRegularIcon} />;

    if (size === "medium") {
      icon = <ClockMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ClockIcon.displayName = "ClockIcon";

export type { ClockIconProps };
export { ClockIcon };
