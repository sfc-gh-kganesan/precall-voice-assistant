import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ColumnSlashMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="m16.509 15.625-.884.884-1.875-1.875v2.241a.625.625 0 0 1-.625.625h-5l-.126-.012a.625.625 0 0 1-.499-.613V8.384L3.491 4.375l.884-.884zm-7.759.625h3.75v-2.866l-3.75-3.75z"
                clipRule="evenodd"
              />
              <path d="M13.125 2.5c.345 0 .625.28.625.625v8.225L12.5 10.1V3.75H8.75v2.6L7.5 5.1V3.125c0-.345.28-.625.625-.625z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ColumnSlashMediumIcon.displayName = "ColumnSlashMediumIcon";
export { ColumnSlashMediumIcon };
