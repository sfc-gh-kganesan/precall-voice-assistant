import { forwardRef, ForwardedRef } from "react";

import { ArrayMediumIcon } from "./ArrayMediumIcon";
import { ArrayRegularIcon } from "./ArrayRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ArrayIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrayIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrayIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ArrayRegularIcon />;

    if (size === "medium") {
      icon = <ArrayMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrayIcon.displayName = "ArrayIcon";

export type { ArrayIconProps };
export { ArrayIcon };
