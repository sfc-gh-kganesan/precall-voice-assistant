import { forwardRef, ForwardedRef } from "react";

import { CellCollapseMediumIcon } from "./CellCollapseMediumIcon";
import { CellCollapseRegularIcon } from "./CellCollapseRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CellCollapseIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CellCollapseIcon = forwardRef(
  (
    { size = "regular", ...props }: CellCollapseIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CellCollapseRegularIcon />;

    if (size === "medium") {
      icon = <CellCollapseMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CellCollapseIcon.displayName = "CellCollapseIcon";

export type { CellCollapseIconProps };
export { CellCollapseIcon };
