import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
const ClearSmallIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              d="m8.707 8 3.147-3.146-.707-.708L8 7.293 4.854 4.146l-.707.708L7.293 8l-3.147 3.146.708.708L8 8.707l3.146 3.147.708-.707z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClearSmallIcon.displayName = "ClearSmallIcon";
export { ClearSmallIcon };
