import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DataSharingRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M8 1a2.5 2.5 0 0 1 2.5 2.5c0 .033-.005.067-.006.1a5.5 5.5 0 0 1 2.96 5.59 2.5 2.5 0 1 1-2.72 4.079A5.46 5.46 0 0 1 8 14a5.47 5.47 0 0 1-2.735-.73 2.5 2.5 0 1 1-2.72-4.08 5.5 5.5 0 0 1 2.96-5.59L5.5 3.5A2.5 2.5 0 0 1 8 1m-4.5 9a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3m2.258-5.4A4.5 4.5 0 0 0 3.528 9a2.5 2.5 0 0 1 2.29 3.43 4.47 4.47 0 0 0 4.363 0A2.5 2.5 0 0 1 12.47 9q.029-.247.03-.501c0-1.669-.91-3.122-2.259-3.9a2.497 2.497 0 0 1-4.483 0M12.5 10a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3M8 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataSharingRegularIcon.displayName = "DataSharingRegularIcon";
export { DataSharingRegularIcon };
