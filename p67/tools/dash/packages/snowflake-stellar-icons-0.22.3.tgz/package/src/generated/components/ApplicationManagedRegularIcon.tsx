import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationManagedRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M11.862 7.52a.5.5 0 0 1 .276 0l3.5 1A.5.5 0 0 1 16 9v2.5c0 .58-.304 1.114-.658 1.55-.363.448-.835.863-1.287 1.21a15 15 0 0 1-1.658 1.092l-.117.065-.032.018-.009.005h-.003v.001a.5.5 0 0 1-.455.01v-.002h-.004l-.008-.006-.033-.016-.118-.06a13 13 0 0 1-1.666-1.04c-.455-.34-.931-.75-1.297-1.21C8.295 12.663 8 12.111 8 11.5V9a.5.5 0 0 1 .362-.48zM9 9.377V11.5c0 .289.144.624.438.995.291.365.69.717 1.11 1.029.416.309.836.567 1.153.749.11.063.209.115.288.158q.125-.07.297-.175c.319-.195.74-.469 1.16-.79.422-.324.825-.683 1.119-1.045.301-.372.435-.684.435-.921V9.377l-3-.857z"
                clipRule="evenodd"
              />
              <path d="M7.753 1.315a.5.5 0 0 1 .494 0L13.75 4.44a.5.5 0 0 1 .253.435V7h-1V5.165L8 2.325l-5.002 2.84v5.669L7 13.108v1.15L2.251 11.56a.5.5 0 0 1-.253-.435v-6.25l.005-.066a.5.5 0 0 1 .248-.369z" />
              <path d="M8 5c1.306 0 2.413.836 2.825 2H9.73A1.998 1.998 0 1 0 7 9.73v1.095A2.998 2.998 0 0 1 8 5" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationManagedRegularIcon.displayName = "ApplicationManagedRegularIcon";
export { ApplicationManagedRegularIcon };
