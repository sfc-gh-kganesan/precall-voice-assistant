import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DragHandleMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.5 13.75a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m5 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m-5-5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m5 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m-5-5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m5 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DragHandleMediumIcon.displayName = "DragHandleMediumIcon";
export { DragHandleMediumIcon };
