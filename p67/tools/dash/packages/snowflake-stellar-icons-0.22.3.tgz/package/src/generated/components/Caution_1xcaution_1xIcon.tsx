import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const Caution_1xcaution_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M6.178 1.909c.565-1.055 2.079-1.055 2.644 0l5.83 10.883A1.5 1.5 0 0 1 13.33 15H1.67a1.5 1.5 0 0 1-1.322-2.208zm1.762.473a.5.5 0 0 0-.88 0L1.23 13.264a.5.5 0 0 0 .44.736h11.66a.5.5 0 0 0 .44-.736zM7.5 11a.5.5 0 1 1 0 1 .5.5 0 0 1 0-1m.5-1H7V6h1z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
Caution_1xcaution_1xIcon.displayName = "Caution_1xcaution_1xIcon";
export { Caution_1xcaution_1xIcon };
