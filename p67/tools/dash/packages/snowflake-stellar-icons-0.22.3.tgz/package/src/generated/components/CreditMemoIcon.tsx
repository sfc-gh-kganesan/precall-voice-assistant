import { forwardRef, ForwardedRef } from "react";

import { CreditMemoMediumIcon } from "./CreditMemoMediumIcon";
import { CreditMemoRegularIcon } from "./CreditMemoRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CreditMemoIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CreditMemoIcon = forwardRef(
  (
    { size = "regular", ...props }: CreditMemoIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CreditMemoRegularIcon />;

    if (size === "medium") {
      icon = <CreditMemoMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CreditMemoIcon.displayName = "CreditMemoIcon";

export type { CreditMemoIconProps };
export { CreditMemoIcon };
