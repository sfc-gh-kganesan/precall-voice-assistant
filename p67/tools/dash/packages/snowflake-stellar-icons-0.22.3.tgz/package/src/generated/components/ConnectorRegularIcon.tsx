import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ConnectorRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M3.5 3a2.5 2.5 0 0 1 2.45 2H7a1.5 1.5 0 0 1 1.5 1.5v3a.5.5 0 0 0 .5.5h1.05a2.501 2.501 0 1 1 0 1H9a1.5 1.5 0 0 1-1.5-1.5v-3A.5.5 0 0 0 7 6H5.95A2.501 2.501 0 1 1 3.5 3m9 6a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3m-9-5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ConnectorRegularIcon.displayName = "ConnectorRegularIcon";
export { ConnectorRegularIcon };
