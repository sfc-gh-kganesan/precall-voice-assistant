import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrayRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M5 3H3v10h2v1H2.5a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H5zm8.5-1a.5.5 0 0 1 .5.5v11a.5.5 0 0 1-.5.5H11v-1h2V3h-2V2z" />
              <path d="M5 7a1 1 0 1 1 0 2 1 1 0 0 1 0-2m3 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2m3 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ArrayRegularIcon.displayName = "ArrayRegularIcon";
export { ArrayRegularIcon };
