import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CommaRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.86 5c.597 0 1.126.282 1.466.719.953 1.177.855 3.798-1.493 4.992-.86.437-1.155-.457-.493-1.16.228-.241.442-.518.632-.837q-.055.005-.112.006a1.86 1.86 0 1 1 0-3.72"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CommaRegularIcon.displayName = "CommaRegularIcon";
export { CommaRegularIcon };
