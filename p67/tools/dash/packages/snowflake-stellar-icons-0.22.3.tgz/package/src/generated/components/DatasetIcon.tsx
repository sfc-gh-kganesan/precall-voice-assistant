import { forwardRef, ForwardedRef } from "react";

import { DatasetMediumIcon } from "./DatasetMediumIcon";
import { DatasetRegularIcon } from "./DatasetRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DatasetIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DatasetIcon = forwardRef(
  (
    { size = "regular", ...props }: DatasetIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DatasetRegularIcon />;

    if (size === "medium") {
      icon = <DatasetMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DatasetIcon.displayName = "DatasetIcon";

export type { DatasetIconProps };
export { DatasetIcon };
