import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CellCollapseRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path fill={iconColor} d="M14 6H2v1h12zm0 3H2v1h12z" />
          </>
        }
        {...props}
      />
    );
  },
);
CellCollapseRegularIcon.displayName = "CellCollapseRegularIcon";
export { CellCollapseRegularIcon };
