import { forwardRef, ForwardedRef } from "react";

import { DatabaseLinkMediumIcon } from "./DatabaseLinkMediumIcon";
import { DatabaseLinkRegularIcon } from "./DatabaseLinkRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DatabaseLinkIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DatabaseLinkIcon = forwardRef(
  (
    { size = "regular", ...props }: DatabaseLinkIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DatabaseLinkRegularIcon />;

    if (size === "medium") {
      icon = <DatabaseLinkMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DatabaseLinkIcon.displayName = "DatabaseLinkIcon";

export type { DatabaseLinkIconProps };
export { DatabaseLinkIcon };
