import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabaseSharedRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M14 6a2 2 0 1 1-1.337 3.484l-1.725 1.035A2 2 0 0 1 11 11q-.002.249-.062.48l1.725 1.035a2 2 0 1 1-.553.834l-1.648-.989c-.365.393-.884.64-1.462.64a2 2 0 1 1 1.462-3.361l1.648-.989A2 2 0 0 1 14 6m0 7a1 1 0 1 0 0 2 1 1 0 0 0 0-2m-5-3a1 1 0 1 0 0 2 1 1 0 0 0 0-2m5-3a1 1 0 1 0 0 2 1 1 0 0 0 0-2"
                clipRule="evenodd"
              />
              <path d="M8.001 2c1.303 0 2.509.263 3.406.71.868.434 1.595 1.126 1.595 2.039q0 .086-.008.169l.003.081-1.05-.002q.02-.049.034-.098c-.082-.407-.414-.839-1.047-1.205-.635-.366-1.508-.623-2.5-.681L8 3c-1.17 0-2.207.275-2.933.694-.633.366-.966.798-1.047 1.205.073.305.371.668 1.021.993.731.365 1.777.605 2.959.605a7.8 7.8 0 0 0 1.999-.25v1.027A9 9 0 0 1 8 7.497c-1.304 0-2.509-.262-3.406-.71A4 4 0 0 1 4 6.426V10.9c0 .45.31.944 1 1.363v1.13a5 5 0 0 1-.432-.221C3.678 12.658 3 11.872 3 10.9V5.1q0-.095.008-.186A2 2 0 0 1 3 4.75c0-.912.727-1.605 1.595-2.038C5.492 2.263 6.697 2 8 2" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
DatabaseSharedRegularIcon.displayName = "DatabaseSharedRegularIcon";
export { DatabaseSharedRegularIcon };
