import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronUpRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m2.646 10.147 5-5a.5.5 0 0 1 .708 0l5 5-.707.707L8 6.207l-4.646 4.647z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronUpRegularIcon.displayName = "ChevronUpRegularIcon";
export { ChevronUpRegularIcon };
