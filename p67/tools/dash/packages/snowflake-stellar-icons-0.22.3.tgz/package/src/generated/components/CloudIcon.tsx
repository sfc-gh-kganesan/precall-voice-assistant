import { forwardRef, ForwardedRef } from "react";

import { CloudMediumIcon } from "./CloudMediumIcon";
import { CloudRegularIcon } from "./CloudRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CloudIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CloudIcon = forwardRef(
  (
    { size = "regular", ...props }: CloudIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CloudRegularIcon />;

    if (size === "medium") {
      icon = <CloudMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CloudIcon.displayName = "CloudIcon";

export type { CloudIconProps };
export { CloudIcon };
