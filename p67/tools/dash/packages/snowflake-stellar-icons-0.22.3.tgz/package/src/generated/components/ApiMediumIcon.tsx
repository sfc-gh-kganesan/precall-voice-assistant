import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApiMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10.319 2.131a4.37 4.37 0 0 1 3.726 2.881A3.75 3.75 0 0 1 17.5 8.75l-.005.193a3.73 3.73 0 0 1-1 2.356c.223.095.38.317.38.576v1.957a2.498 2.498 0 0 1-.625 4.918 2.5 2.5 0 0 1-.625-4.918V12.5h-2.5v-.002h-2.5v1.334A2.498 2.498 0 0 1 10 18.75a2.5 2.5 0 0 1-.625-4.918v-1.334h-3.08l-.045.002H4.375v1.332a2.498 2.498 0 0 1-.625 4.918 2.5 2.5 0 0 1-.625-4.918v-1.957c0-.345.28-.625.625-.625a3.1 3.1 0 0 1-.61-1.555l-.015-.32a3.125 3.125 0 0 1 2.438-3.048 4.375 4.375 0 0 1 4.371-4.213zM3.75 15a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5M10 15a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m6.25 0a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5M9.934 3.364a3.126 3.126 0 0 0-3.109 3.449l.07.676-.68.012c-1.02.019-1.84.85-1.84 1.874l.01.192a1.874 1.874 0 0 0 1.852 1.682h.008l.04-.001h7.475a2.5 2.5 0 0 0 2.477-2.243l.013-.255a2.5 2.5 0 0 0-2.5-2.5c-.034 0-.06.002-.136.006l-.522.028-.12-.509a3.125 3.125 0 0 0-2.763-2.399z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ApiMediumIcon.displayName = "ApiMediumIcon";
export { ApiMediumIcon };
