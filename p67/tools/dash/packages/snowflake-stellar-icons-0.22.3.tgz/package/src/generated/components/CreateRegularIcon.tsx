import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CreateRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8 3H3.5a.5.5 0 0 0-.5.5v9.036a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V8h1v4.536a1.5 1.5 0 0 1-1.5 1.5h-9a1.5 1.5 0 0 1-1.5-1.5V3.5A1.5 1.5 0 0 1 3.5 2H8z" />
              <path
                fillRule="evenodd"
                d="M10.719 2.44a1.5 1.5 0 0 1 2.12 0l.708.706a1.5 1.5 0 0 1 0 2.122L8.703 10.11a1.5 1.5 0 0 1-.586.363l-2.959.986a.502.502 0 0 1-.633-.633l.988-2.958a1.5 1.5 0 0 1 .362-.587zM6.582 7.99a.5.5 0 0 0-.12.196l-.671 2.008 2.01-.669a.5.5 0 0 0 .196-.12l3.358-3.36L9.94 4.63zm5.55-4.844a.5.5 0 0 0-.706 0l-.778.778 1.414 1.414.778-.777a.5.5 0 0 0 0-.707z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CreateRegularIcon.displayName = "CreateRegularIcon";
export { CreateRegularIcon };
