import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AccountTeamRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M12.5 10a1.5 1.5 0 0 1 1.5 1.5V14h-1v-2.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5V14H2v-2.5A1.5 1.5 0 0 1 3.5 10z" />
              <path
                fillRule="evenodd"
                d="M8 2a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7m0 1a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AccountTeamRegularIcon.displayName = "AccountTeamRegularIcon";
export { AccountTeamRegularIcon };
