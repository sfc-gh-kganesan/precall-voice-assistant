import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CellCollapseResultRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M14 14H2v-1h12zM7.354 4.857 5.707 6.504 7.354 8.15l-.708.707-2.353-2.353L6.646 4.15zm4.353 1.647L9.354 8.857l-.708-.707 1.647-1.646-1.647-1.647.708-.707z" />
              <path
                fillRule="evenodd"
                d="M13.5 2a.5.5 0 0 1 .5.5v8l-.01.1a.5.5 0 0 1-.49.4h-11a.5.5 0 0 1-.5-.5v-8a.5.5 0 0 1 .5-.5zM3 10h10V3H3z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CellCollapseResultRegularIcon.displayName = "CellCollapseResultRegularIcon";
export { CellCollapseResultRegularIcon };
