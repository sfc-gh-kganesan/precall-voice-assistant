import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CheckMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m17.326 6.058-9.018 9.375a.626.626 0 0 1-.877.023l-5.357-5 .852-.913 4.908 4.58 8.59-8.932z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CheckMediumIcon.displayName = "CheckMediumIcon";
export { CheckMediumIcon };
