import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabaseMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10.001 2.5c1.63 0 3.136.328 4.258.889 1.084.541 1.993 1.407 1.993 2.547q.001.108-.01.211.01.112.01.228v7.277l-.007.168-.001.014-.001.014c-.101 1.153-.96 2.072-2.058 2.678-.977.538-2.228.88-3.593.958l-.59.017c-1.644 0-3.162-.384-4.292-1.036-1.112-.643-1.96-1.625-1.96-2.84v-7.25q0-.118.01-.232a2 2 0 0 1-.01-.207c0-1.14.91-2.006 1.993-2.547 1.122-.56 2.629-.889 4.258-.889m5.001 5.533a5.3 5.3 0 0 1-.743.45c-1.122.56-2.628.888-4.258.888s-3.136-.328-4.258-.888A5.3 5.3 0 0 1 5 8.033v5.593c0 .58.412 1.224 1.335 1.757.908.524 2.203.868 3.666.868l.524-.014c1.203-.069 2.266-.37 3.057-.806.915-.504 1.36-1.123 1.413-1.685l.007-.147zm-5-4.283c-1.464 0-2.76.344-3.667.868-.792.458-1.207.996-1.31 1.506.093.38.465.835 1.277 1.24.915.457 2.222.757 3.7.757 1.477 0 2.784-.3 3.698-.757.812-.405 1.183-.86 1.276-1.24-.103-.51-.517-1.049-1.309-1.506-.794-.458-1.884-.78-3.125-.852z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DatabaseMediumIcon.displayName = "DatabaseMediumIcon";
export { DatabaseMediumIcon };
