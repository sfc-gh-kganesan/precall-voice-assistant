import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowSlideRightRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M11.5 8a.5.5 0 0 1-.146.354l-4.5 4.5-.708-.707L9.793 8.5H2v-1h7.793L6.146 3.854l.708-.708 4.5 4.5A.5.5 0 0 1 11.5 8m1.5 6V2h1v12z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowSlideRightRegularIcon.displayName = "ArrowSlideRightRegularIcon";
export { ArrowSlideRightRegularIcon };
