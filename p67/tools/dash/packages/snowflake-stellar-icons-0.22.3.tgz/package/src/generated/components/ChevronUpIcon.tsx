import { forwardRef, ForwardedRef } from "react";

import { ChevronUpMediumIcon } from "./ChevronUpMediumIcon";
import { ChevronUpRegularIcon } from "./ChevronUpRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronUpIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronUpIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronUpIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronUpRegularIcon />;

    if (size === "medium") {
      icon = <ChevronUpMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronUpIcon.displayName = "ChevronUpIcon";

export type { ChevronUpIconProps };
export { ChevronUpIcon };
