import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const CalendarPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              stroke={iconColor}
              strokeLinecap="round"
              strokeWidth={2}
              d="M35.636 12.83H13a4 4 0 0 0-4 4v17.53a4 4 0 0 0 4 4h22.636a4 4 0 0 0 4-4V16.83a4 4 0 0 0-4-4ZM16.659 9v7.659M31.976 9v7.659"
            />
            <path
              fill={iconColor}
              d="M15.823 20.466h4.167v4h-4.167zM15.735 27.591h4.167v4h-4.167zM23.158 20.466h4.167v4h-4.167zM23.069 27.591h4.167v4h-4.167zM30.492 20.466h4.167v4h-4.167zM30.404 27.591h4.167v4h-4.167z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CalendarPictogram.displayName = "CalendarPictogram";
export { CalendarPictogram };
