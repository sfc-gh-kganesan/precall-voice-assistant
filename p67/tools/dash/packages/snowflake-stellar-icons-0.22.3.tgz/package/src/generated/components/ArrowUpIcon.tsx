import { forwardRef, ForwardedRef } from "react";

import { ArrowUpMediumIcon } from "./ArrowUpMediumIcon";
import { ArrowUpRegularIcon } from "./ArrowUpRegularIcon";

import { ArrowUp_1xIcon } from "./ArrowUp_1xIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";
import { IconWith1x } from "../../IconWith1x";

interface ArrowUpIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowUpIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowUpIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = (
      <IconWith1x icon1x={ArrowUp_1xIcon} icon2x={ArrowUpRegularIcon} />
    );

    if (size === "medium") {
      icon = <ArrowUpMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowUpIcon.displayName = "ArrowUpIcon";

export type { ArrowUpIconProps };
export { ArrowUpIcon };
