import { forwardRef, ForwardedRef } from "react";

import { ApplicationLinkMediumIcon } from "./ApplicationLinkMediumIcon";
import { ApplicationLinkRegularIcon } from "./ApplicationLinkRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ApplicationLinkIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ApplicationLinkIcon = forwardRef(
  (
    { size = "regular", ...props }: ApplicationLinkIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ApplicationLinkRegularIcon />;

    if (size === "medium") {
      icon = <ApplicationLinkMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ApplicationLinkIcon.displayName = "ApplicationLinkIcon";

export type { ApplicationLinkIconProps };
export { ApplicationLinkIcon };
