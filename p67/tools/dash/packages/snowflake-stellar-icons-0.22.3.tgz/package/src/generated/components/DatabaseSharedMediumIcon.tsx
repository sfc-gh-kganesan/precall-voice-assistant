import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabaseSharedMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M17.5 7.5a2.5 2.5 0 0 1 0 5 2.5 2.5 0 0 1-1.671-.645l-2.156 1.293c.048.193.077.394.077.602s-.03.408-.077.6l2.156 1.293a2.5 2.5 0 1 1-.691 1.043l-2.06-1.236a2.5 2.5 0 0 1-1.828.8 2.5 2.5 0 0 1 0-5 2.5 2.5 0 0 1 1.827.798l2.06-1.235A2.5 2.5 0 0 1 17.5 7.5m0 8.75a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m-6.25-3.75a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m6.25-3.75a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"
                clipRule="evenodd"
              />
              <path d="M10.001 2.5c1.63 0 3.136.328 4.258.889 1.084.541 1.993 1.407 1.993 2.547q.001.108-.01.211.004.051.004.102l-1.312-.003a1 1 0 0 0 .042-.122c-.103-.51-.517-1.049-1.309-1.506-.794-.458-1.884-.78-3.125-.852l-.54-.016c-1.464 0-2.76.344-3.667.868-.792.458-1.207.996-1.31 1.506.093.38.465.835 1.277 1.24.915.457 2.222.757 3.7.757A9.7 9.7 0 0 0 12.5 7.81v1.284a11.2 11.2 0 0 1-2.499.278c-1.63 0-3.136-.328-4.258-.888A5.3 5.3 0 0 1 5 8.033v5.593c0 .56.388 1.18 1.25 1.702v1.413a6 6 0 0 1-.54-.276c-1.112-.643-1.96-1.625-1.96-2.84v-7.25q0-.118.01-.232a2 2 0 0 1-.01-.207c0-1.14.91-2.006 1.993-2.547 1.122-.56 2.629-.889 4.258-.889" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
DatabaseSharedMediumIcon.displayName = "DatabaseSharedMediumIcon";
export { DatabaseSharedMediumIcon };
