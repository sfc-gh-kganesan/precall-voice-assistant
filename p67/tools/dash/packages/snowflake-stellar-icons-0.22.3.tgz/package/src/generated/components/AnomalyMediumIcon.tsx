import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AnomalyMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M10 5c.287 0 .537.195.606.474L12.988 15h5.762v1.25H12.5a.626.626 0 0 1-.607-.474L10 8.203l-1.894 7.573a.626.626 0 0 1-.606.474H6.272a.63.63 0 0 1-.443-.186l-2.04-2.058-2.101 2.065-.876-.892 2.545-2.5.099-.079a.624.624 0 0 1 .782.085L6.532 15h.48l2.381-9.526A.626.626 0 0 1 10 5" />
              <path d="M15.625 9.688a.938.938 0 1 1 0 1.875.938.938 0 0 1 0-1.876m.625-5.937a.626.626 0 0 1 .616.728l-.625 3.75a.625.625 0 0 1-1.233 0l-.625-3.75A.625.625 0 0 1 15 3.75z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AnomalyMediumIcon.displayName = "AnomalyMediumIcon";
export { AnomalyMediumIcon };
