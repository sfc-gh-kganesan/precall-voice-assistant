import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AccountTeamMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M15.625 12.5c1.035 0 1.875.84 1.875 1.875V17.5h-1.25v-3.125a.625.625 0 0 0-.625-.625H4.375a.625.625 0 0 0-.625.625V17.5H2.5v-3.125c0-1.036.84-1.875 1.875-1.875z" />
              <path
                fillRule="evenodd"
                d="M10 2.5a4.375 4.375 0 1 1 0 8.75 4.375 4.375 0 0 1 0-8.75m0 1.25A3.125 3.125 0 1 0 10 10a3.125 3.125 0 0 0 0-6.25"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AccountTeamMediumIcon.displayName = "AccountTeamMediumIcon";
export { AccountTeamMediumIcon };
