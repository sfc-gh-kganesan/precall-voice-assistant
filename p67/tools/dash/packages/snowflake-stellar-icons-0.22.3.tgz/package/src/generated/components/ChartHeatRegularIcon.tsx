import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartHeatRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M10.75 9.5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5M5.25 4a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m5.5 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5" />
              <path
                fillRule="evenodd"
                d="M12.5 2A1.5 1.5 0 0 1 14 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 12.5v-9A1.5 1.5 0 0 1 3.5 2zM3 8.5v4a.5.5 0 0 0 .5.5h4V8.5zm5.5 0V13h4a.5.5 0 0 0 .5-.5v-4zM3.5 3a.5.5 0 0 0-.5.5v4h4.5V3zm5 4.5H13v-4a.5.5 0 0 0-.5-.5h-4z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ChartHeatRegularIcon.displayName = "ChartHeatRegularIcon";
export { ChartHeatRegularIcon };
