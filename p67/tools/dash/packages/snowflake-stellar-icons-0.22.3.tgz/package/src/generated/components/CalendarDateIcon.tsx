import { forwardRef, ForwardedRef } from "react";

import { CalendarDateMediumIcon } from "./CalendarDateMediumIcon";
import { CalendarDateRegularIcon } from "./CalendarDateRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CalendarDateIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CalendarDateIcon = forwardRef(
  (
    { size = "regular", ...props }: CalendarDateIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CalendarDateRegularIcon />;

    if (size === "medium") {
      icon = <CalendarDateMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CalendarDateIcon.displayName = "CalendarDateIcon";

export type { CalendarDateIconProps };
export { CalendarDateIcon };
