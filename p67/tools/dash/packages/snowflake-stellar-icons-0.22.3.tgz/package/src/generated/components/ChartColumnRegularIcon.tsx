import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartColumnRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M11 5.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-3l-.098-.01A.5.5 0 0 1 11 12.5zm3 6.5V6h-2v6zM6 3.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9l-.01.1a.5.5 0 0 1-.49.4h-3l-.098-.01A.5.5 0 0 1 6 12.5zM9 12V4H7v8zM1 7.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-.5.5h-3l-.098-.01A.5.5 0 0 1 1 12.5zM4 12V8H2v4z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartColumnRegularIcon.displayName = "ChartColumnRegularIcon";
export { ChartColumnRegularIcon };
