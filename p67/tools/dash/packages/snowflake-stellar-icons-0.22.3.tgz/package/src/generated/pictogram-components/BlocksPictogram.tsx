import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const BlocksPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M22.765 5.423a2 2 0 0 1 2 0l7.906 4.564a2 2 0 0 1 1 1.732v9.084l.097.052 7.906 4.565a2 2 0 0 1 1 1.732v9.129a2 2 0 0 1-1 1.732l-7.906 4.564a2 2 0 0 1-2 0l-7.772-4.486-7.771 4.486a2 2 0 0 1-2 0l-7.906-4.564a2 2 0 0 1-1-1.732v-9.129a2 2 0 0 1 1-1.732l7.551-4.36a2 2 0 0 1-.011-.212V11.72a2 2 0 0 1 1-1.732zm.097 23.076v7.782q0 .075.006.152l-6.686 3.86v-8.06zm2.263 7.934 6.6 3.81v-7.988l-.028-.015-6.566-3.83v7.87q0 .077-.006.153m.783-9.885 6.86-3.96 6.942 4.008-7.005 3.916zm14.766 1.8-6.95 3.885v8.06l6.95-4.012zm-18.686-1.652-6.94-4.007-6.683 3.859 6.798 3.964zm.733-2.09v-7.784l-.027-.015-6.835-3.986v7.87q.189.063.366.165zm2 .254V16.8l6.95-3.885v7.933zm-1.02-9.78 7.006-3.917-6.942-4.008-6.86 3.96zm-9.519 17.175-.027-.015-6.836-3.987v8.028l6.863 3.962z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BlocksPictogram.displayName = "BlocksPictogram";
export { BlocksPictogram };
