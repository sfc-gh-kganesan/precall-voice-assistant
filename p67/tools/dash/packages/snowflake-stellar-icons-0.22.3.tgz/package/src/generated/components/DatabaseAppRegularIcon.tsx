import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabaseAppRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path
                fillRule="evenodd"
                d="M11.5 9a2 2 0 1 1 0 4 2 2 0 0 1 0-4m0 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2"
                clipRule="evenodd"
              />
              <path
                fillRule="evenodd"
                d="M11.386 6.014a.5.5 0 0 1 .338.039l4 2A.5.5 0 0 1 16 8.5v5a.5.5 0 0 1-.276.447l-4 2a.5.5 0 0 1-.448 0l-4-2A.5.5 0 0 1 7 13.5v-5l.005-.07a.5.5 0 0 1 .271-.377l4-2zM8 8.809v4.381l3.5 1.75 3.5-1.75V8.81l-3.5-1.75z"
                clipRule="evenodd"
              />
              <path d="M8.001 2c1.303 0 2.509.263 3.406.71.868.434 1.595 1.126 1.595 2.039q0 .086-.008.169l.003.081h-1.05a1 1 0 0 0 .034-.1c-.082-.407-.414-.839-1.047-1.205-.635-.366-1.508-.623-2.5-.681L8 3c-1.17 0-2.207.275-2.933.694-.633.366-.966.798-1.047 1.205.072.298.359.65.979.97v1.096a5 5 0 0 1-.405-.179A4 4 0 0 1 4 6.426V10.9c0 .45.31.944 1 1.363v1.13a5 5 0 0 1-.432-.221C3.678 12.658 3 11.872 3 10.9V5.1q0-.095.008-.186A2 2 0 0 1 3 4.75c0-.912.727-1.605 1.595-2.038C5.492 2.263 6.697 2 8 2" />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h16v16H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
DatabaseAppRegularIcon.displayName = "DatabaseAppRegularIcon";
export { DatabaseAppRegularIcon };
