import { forwardRef, ForwardedRef } from "react";

import { AiFillMediumIcon } from "./AiFillMediumIcon";
import { AiFillRegularIcon } from "./AiFillRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AiFillIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AiFillIcon = forwardRef(
  (
    { size = "regular", ...props }: AiFillIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AiFillRegularIcon />;

    if (size === "medium") {
      icon = <AiFillMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AiFillIcon.displayName = "AiFillIcon";

export type { AiFillIconProps };
export { AiFillIcon };
