import { forwardRef, ForwardedRef } from "react";

import { CommentMediumIcon } from "./CommentMediumIcon";
import { CommentRegularIcon } from "./CommentRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CommentIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CommentIcon = forwardRef(
  (
    { size = "regular", ...props }: CommentIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CommentRegularIcon />;

    if (size === "medium") {
      icon = <CommentMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CommentIcon.displayName = "CommentIcon";

export type { CommentIconProps };
export { CommentIcon };
