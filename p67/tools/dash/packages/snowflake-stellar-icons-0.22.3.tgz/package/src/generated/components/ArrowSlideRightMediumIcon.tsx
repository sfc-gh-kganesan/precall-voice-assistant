import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowSlideRightMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M14.375 10a.63.63 0 0 1-.183.442l-5.625 5.625-.884-.884 4.558-4.558H2.5v-1.25h9.741L7.683 4.817l.884-.884 5.625 5.625a.63.63 0 0 1 .183.442m1.875 7.5v-15h1.25v15z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowSlideRightMediumIcon.displayName = "ArrowSlideRightMediumIcon";
export { ArrowSlideRightMediumIcon };
