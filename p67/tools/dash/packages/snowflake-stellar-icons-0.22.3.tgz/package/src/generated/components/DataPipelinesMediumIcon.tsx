import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DataPipelinesMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M17.5 2.5c.69 0 1.25.56 1.25 1.25V7.5a1.25 1.25 0 0 1-1.122 1.244l-.128.006h-3.75l-.128-.006a1.25 1.25 0 0 1-1.116-1.116L12.5 7.5V6.25h-1.25a.625.625 0 0 0-.625.625V8.75c0 .481-.183.918-.481 1.25.298.332.481.769.481 1.25v1.875c0 .345.28.625.625.625h1.25V12.5c0-.69.56-1.25 1.25-1.25h3.75c.69 0 1.25.56 1.25 1.25v3.75a1.25 1.25 0 0 1-1.122 1.244l-.128.006h-3.75l-.128-.006a1.25 1.25 0 0 1-1.116-1.116l-.006-.128V15h-1.25a1.875 1.875 0 0 1-1.875-1.875V11.25a.625.625 0 0 0-.625-.625H7.5v1.25a1.25 1.25 0 0 1-1.122 1.244l-.128.006H2.5l-.128-.006a1.25 1.25 0 0 1-1.116-1.116l-.006-.128v-3.75c0-.69.56-1.25 1.25-1.25h3.75c.69 0 1.25.56 1.25 1.25v1.25h1.25c.345 0 .625-.28.625-.625V6.875c0-1.036.84-1.875 1.875-1.875h1.25V3.75c0-.69.56-1.25 1.25-1.25zm-3.75 13.75h3.75V12.5h-3.75zM2.5 11.875h3.75v-3.75H2.5zM13.75 7.5h3.75V3.75h-3.75z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataPipelinesMediumIcon.displayName = "DataPipelinesMediumIcon";
export { DataPipelinesMediumIcon };
