import { forwardRef, ForwardedRef } from "react";

import { DownloadMediumIcon } from "./DownloadMediumIcon";
import { DownloadRegularIcon } from "./DownloadRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DownloadIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DownloadIcon = forwardRef(
  (
    { size = "regular", ...props }: DownloadIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DownloadRegularIcon />;

    if (size === "medium") {
      icon = <DownloadMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DownloadIcon.displayName = "DownloadIcon";

export type { DownloadIconProps };
export { DownloadIcon };
