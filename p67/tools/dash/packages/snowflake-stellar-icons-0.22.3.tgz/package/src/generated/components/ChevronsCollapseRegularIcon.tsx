import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronsCollapseRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.725 9.582a.5.5 0 0 1 .629.064l4 4-.707.707L8 10.708l-3.646 3.646-.708-.707 4-4zm4.629-7.228-4 4a.5.5 0 0 1-.708 0l-4-4 .708-.708L8 5.293l3.646-3.647z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronsCollapseRegularIcon.displayName = "ChevronsCollapseRegularIcon";
export { ChevronsCollapseRegularIcon };
