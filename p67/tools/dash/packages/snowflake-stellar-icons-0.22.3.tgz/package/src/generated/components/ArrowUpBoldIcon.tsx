import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
import { IconProps } from "../../types";
const ArrowUpBoldIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        {...props}
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              d="M8 2a1 1 0 0 1 .707.293l5 5-1.414 1.414L9 5.414V14H7V5.414L3.707 8.707 2.293 7.293l5-5A1 1 0 0 1 8 2"
            />
          </>
        }
      />
    );
  },
);
ArrowUpBoldIcon.displayName = "ArrowUpBoldIcon";
export { ArrowUpBoldIcon };
