import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronDownSmallMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m14.817 8.567-4.31 3.75a.796.796 0 0 1-1.015 0l-4.309-3.75L6.2 7.683l3.8 3.308 3.8-3.308z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronDownSmallMediumIcon.displayName = "ChevronDownSmallMediumIcon";
export { ChevronDownSmallMediumIcon };
