import { forwardRef, ForwardedRef } from "react";

import { AnswerMediumIcon } from "./AnswerMediumIcon";
import { AnswerRegularIcon } from "./AnswerRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AnswerIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AnswerIcon = forwardRef(
  (
    { size = "regular", ...props }: AnswerIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AnswerRegularIcon />;

    if (size === "medium") {
      icon = <AnswerMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AnswerIcon.displayName = "AnswerIcon";

export type { AnswerIconProps };
export { AnswerIcon };
