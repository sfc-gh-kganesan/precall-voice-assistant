import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ColumnSlashRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="m13.207 12.5-.707.707-1.5-1.5V13.5a.5.5 0 0 1-.5.5h-4l-.1-.01a.5.5 0 0 1-.4-.49V6.707L2.793 3.5l.707-.707zM7 13h3v-2.293l-3-3z"
                clipRule="evenodd"
              />
              <path d="M10.5 2a.5.5 0 0 1 .5.5v6.58l-1-1V3H7v2.08l-1-1V2.5a.5.5 0 0 1 .5-.5z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ColumnSlashRegularIcon.displayName = "ColumnSlashRegularIcon";
export { ColumnSlashRegularIcon };
