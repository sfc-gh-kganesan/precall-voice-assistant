import { forwardRef, ForwardedRef } from "react";

import { ArrowLeftMediumIcon } from "./ArrowLeftMediumIcon";
import { ArrowLeftRegularIcon } from "./ArrowLeftRegularIcon";

import { ArrowLeft_1xIcon } from "./ArrowLeft_1xIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";
import { IconWith1x } from "../../IconWith1x";

interface ArrowLeftIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowLeftIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowLeftIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = (
      <IconWith1x icon1x={ArrowLeft_1xIcon} icon2x={ArrowLeftRegularIcon} />
    );

    if (size === "medium") {
      icon = <ArrowLeftMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowLeftIcon.displayName = "ArrowLeftIcon";

export type { ArrowLeftIconProps };
export { ArrowLeftIcon };
