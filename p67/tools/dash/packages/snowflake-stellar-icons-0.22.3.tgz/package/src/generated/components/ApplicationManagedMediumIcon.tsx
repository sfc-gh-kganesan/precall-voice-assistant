import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationManagedMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M14.828 9.4a.63.63 0 0 1 .344 0l4.375 1.25a.625.625 0 0 1 .453.6v3.125c0 .724-.38 1.393-.823 1.939-.453.559-1.043 1.077-1.609 1.51a18 18 0 0 1-2.218 1.447l-.04.022-.01.006-.005.002a.63.63 0 0 1-.568.012l-.002-.002h-.003l-.011-.007-.04-.02-.148-.076a16 16 0 0 1-2.082-1.3c-.57-.423-1.165-.937-1.622-1.511-.451-.568-.819-1.258-.819-2.022V11.25c0-.279.185-.524.453-.6zm-3.578 2.32v2.654c0 .361.18.78.548 1.244.363.456.863.896 1.387 1.285a15 15 0 0 0 1.802 1.134 17 17 0 0 0 1.82-1.206c.527-.404 1.032-.854 1.399-1.306.377-.465.544-.854.544-1.151V11.72L15 10.65z"
                clipRule="evenodd"
              />
              <path d="M9.691 1.644a.63.63 0 0 1 .618 0l6.877 3.907a.63.63 0 0 1 .316.543V8.75h-1.25V6.456L10 2.906l-6.252 3.55v7.087l5.002 2.841v1.438l-5.936-3.371a.63.63 0 0 1-.316-.544V6.094l.006-.083a.63.63 0 0 1 .31-.46z" />
              <path d="M10 6.25a3.75 3.75 0 0 1 3.531 2.5h-1.368A2.497 2.497 0 0 0 7.5 10c0 .925.504 1.73 1.25 2.162v1.37A3.748 3.748 0 0 1 10 6.25" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationManagedMediumIcon.displayName = "ApplicationManagedMediumIcon";
export { ApplicationManagedMediumIcon };
