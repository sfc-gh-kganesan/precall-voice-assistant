import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChatHeartRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} fillRule="evenodd" clipRule="evenodd">
              <path d="M7.975 5.753a1.964 1.964 0 0 1 2.653.133c.786.795.731 1.947.027 2.787-.415.495-1.232 1.207-2.407 2.12a.5.5 0 0 1-.621-.005c-1.13-.915-1.92-1.624-2.332-2.115-.704-.84-.758-1.992.027-2.787a1.963 1.963 0 0 1 2.653-.133m1.941.836a.965.965 0 0 0-1.377 0L8.33 6.8a.5.5 0 0 1-.71-.001l-.21-.211a.964.964 0 0 0-1.376 0c-.367.372-.398.933.028 1.441.309.37.93.94 1.884 1.725.997-.789 1.636-1.358 1.943-1.725.425-.508.395-1.069.027-1.441" />
              <path d="M12.5 3A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5H5.138l-2.381 1.429A.5.5 0 0 1 2 14V4.5A1.5 1.5 0 0 1 3.5 3zm-9 1a.5.5 0 0 0-.5.5v8.617l1.743-1.046.06-.031A.5.5 0 0 1 5 12h7.5a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.5-.5z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ChatHeartRegularIcon.displayName = "ChatHeartRegularIcon";
export { ChatHeartRegularIcon };
