import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudHeartMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M9.91 8.915a2.866 2.866 0 0 1 4.066.118c1.156 1.214 1.086 2.966.033 4.27-.64.791-1.91 1.942-3.759 3.434a.626.626 0 0 1-.794-.008c-1.78-1.493-3.01-2.64-3.644-3.426-1.054-1.304-1.123-3.056.034-4.27a2.865 2.865 0 0 1 4.064-.118m3.161.98a1.62 1.62 0 0 0-2.379 0l-.33.344a.626.626 0 0 1-.904 0l-.328-.344a1.62 1.62 0 0 0-2.38 0c-.656.69-.688 1.728.035 2.622.508.629 1.525 1.595 3.082 2.918 1.622-1.327 2.665-2.293 3.17-2.918.723-.894.691-1.932.034-2.622"
                clipRule="evenodd"
              />
              <path d="M10.087 2.518a4.96 4.96 0 0 1 4.209 3.179 5 5 0 0 1 4.454 4.97 4.99 4.99 0 0 1-2.5 4.322v-1.533a3.73 3.73 0 0 0 1.25-2.79 3.75 3.75 0 0 0-3.675-3.748l-.466-.01-.124-.448A3.71 3.71 0 0 0 9.98 3.763l-.316-.013a3.71 3.71 0 0 0-3.708 3.709v.007l.001.039.007.586-.584.044A3.125 3.125 0 0 0 2.5 11.25c0 1.021.492 1.925 1.25 2.495v1.45a4.36 4.36 0 0 1-2.5-3.945 4.375 4.375 0 0 1 3.479-4.282A4.96 4.96 0 0 1 9.664 2.5z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CloudHeartMediumIcon.displayName = "CloudHeartMediumIcon";
export { CloudHeartMediumIcon };
