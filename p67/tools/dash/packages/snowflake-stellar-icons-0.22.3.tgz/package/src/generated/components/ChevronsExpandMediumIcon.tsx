import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronsExpandMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m15.442 13.567-5 5a.625.625 0 0 1-.884 0l-5-5 .884-.884L10 17.241l4.558-4.558zM10 1.25c.166 0 .325.066.442.183l5 5-.884.884L10 2.759 5.442 7.317l-.884-.884 5-5 .095-.078A.63.63 0 0 1 10 1.25"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronsExpandMediumIcon.displayName = "ChevronsExpandMediumIcon";
export { ChevronsExpandMediumIcon };
