import { forwardRef, ForwardedRef } from "react";

import { DatabaseAppMediumIcon } from "./DatabaseAppMediumIcon";
import { DatabaseAppRegularIcon } from "./DatabaseAppRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DatabaseAppIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DatabaseAppIcon = forwardRef(
  (
    { size = "regular", ...props }: DatabaseAppIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DatabaseAppRegularIcon />;

    if (size === "medium") {
      icon = <DatabaseAppMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DatabaseAppIcon.displayName = "DatabaseAppIcon";

export type { DatabaseAppIconProps };
export { DatabaseAppIcon };
