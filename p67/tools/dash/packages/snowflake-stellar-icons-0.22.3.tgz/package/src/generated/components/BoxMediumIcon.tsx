import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BoxMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M8.993 1.775a1.88 1.88 0 0 1 2.014 0l6.204 3.948c.18.114.289.314.289.527v6.814c0 .641-.327 1.238-.868 1.582l-6.296 4.006-.08.043a.63.63 0 0 1-.592-.043l-6.296-4.006a1.88 1.88 0 0 1-.868-1.582V6.25c0-.213.11-.413.29-.527zM3.75 13.065c0 .213.11.412.29.526l5.335 3.396V10.97L3.75 7.39zm10.59-4.461.027 3.493-1.244.788-.027-3.49-2.471 1.574v6.018l5.336-3.396a.63.63 0 0 0 .289-.527V7.39zM4.29 6.25 10 9.884l2.357-1.501-5.663-3.664zm6.046-3.42a.63.63 0 0 0-.672 0l-1.81 1.15 5.663 3.665 2.195-1.395z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BoxMediumIcon.displayName = "BoxMediumIcon";
export { BoxMediumIcon };
