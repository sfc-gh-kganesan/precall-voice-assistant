import { forwardRef, ForwardedRef } from "react";

import { ApplicationManagedMediumIcon } from "./ApplicationManagedMediumIcon";
import { ApplicationManagedRegularIcon } from "./ApplicationManagedRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ApplicationManagedIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ApplicationManagedIcon = forwardRef(
  (
    { size = "regular", ...props }: ApplicationManagedIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ApplicationManagedRegularIcon />;

    if (size === "medium") {
      icon = <ApplicationManagedMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ApplicationManagedIcon.displayName = "ApplicationManagedIcon";

export type { ApplicationManagedIconProps };
export { ApplicationManagedIcon };
