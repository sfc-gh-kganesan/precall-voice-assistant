import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronRightSmallRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m6.854 11.354 3-3a.5.5 0 0 0 0-.708l-3-3-.708.708L8.793 8l-2.647 2.646z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronRightSmallRegularIcon.displayName = "ChevronRightSmallRegularIcon";
export { ChevronRightSmallRegularIcon };
