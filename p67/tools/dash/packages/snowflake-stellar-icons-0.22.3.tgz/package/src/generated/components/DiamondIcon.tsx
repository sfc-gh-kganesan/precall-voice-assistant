import { forwardRef, ForwardedRef } from "react";

import { DiamondMediumIcon } from "./DiamondMediumIcon";
import { DiamondRegularIcon } from "./DiamondRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DiamondIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DiamondIcon = forwardRef(
  (
    { size = "regular", ...props }: DiamondIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DiamondRegularIcon />;

    if (size === "medium") {
      icon = <DiamondMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DiamondIcon.displayName = "DiamondIcon";

export type { DiamondIconProps };
export { DiamondIcon };
