import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartAreaRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M12.5 2A1.5 1.5 0 0 1 14 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 12.5v-9A1.5 1.5 0 0 1 3.5 2zM3 10.707V12.5a.5.5 0 0 0 .5.5H5V8.707zM6 13h1.5V9.207L6 7.707zm5-5.293V13h1.5a.5.5 0 0 0 .5-.5V5.707zM9.207 9.5a1 1 0 0 1-.707.293V13H10V8.707zM3.5 3a.5.5 0 0 0-.5.5v5.793L5.293 7a1 1 0 0 1 1.414 0L8.5 8.793l4.5-4.5V3.5a.5.5 0 0 0-.5-.5z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartAreaRegularIcon.displayName = "ChartAreaRegularIcon";
export { ChartAreaRegularIcon };
