import { forwardRef, ForwardedRef } from "react";

import { ApiMediumIcon } from "./ApiMediumIcon";
import { ApiRegularIcon } from "./ApiRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ApiIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ApiIcon = forwardRef(
  (
    { size = "regular", ...props }: ApiIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ApiRegularIcon />;

    if (size === "medium") {
      icon = <ApiMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ApiIcon.displayName = "ApiIcon";

export type { ApiIconProps };
export { ApiIcon };
