import { forwardRef, ForwardedRef } from "react";

import { ChartHeatMediumIcon } from "./ChartHeatMediumIcon";
import { ChartHeatRegularIcon } from "./ChartHeatRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChartHeatIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChartHeatIcon = forwardRef(
  (
    { size = "regular", ...props }: ChartHeatIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChartHeatRegularIcon />;

    if (size === "medium") {
      icon = <ChartHeatMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChartHeatIcon.displayName = "ChartHeatIcon";

export type { ChartHeatIconProps };
export { ChartHeatIcon };
