import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudSaasMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M16.64 11.016a1.094 1.094 0 1 1 0 2.187 1.094 1.094 0 0 1 0-2.187" />
              <path
                fillRule="evenodd"
                d="M19.375 8.75c.345 0 .625.28.625.625v5.304c0 .169-.068.33-.19.448l-4.666 4.54a.625.625 0 0 1-.878-.006L9.09 14.484a.625.625 0 0 1 0-.884l4.667-4.667.095-.078a.63.63 0 0 1 .347-.105zm-8.96 5.292 4.298 4.298 4.037-3.926V10h-4.293z"
                clipRule="evenodd"
              />
              <path d="M9.897 3.755a4.96 4.96 0 0 1 4.565 3.706q.24.007.472.039h-1.766a3.71 3.71 0 0 0-3.157-2.484L9.664 5a3.71 3.71 0 0 0-3.708 3.709l.005.203q.005.1.016.198l.079.742-.745-.051c-.081-.006-.135-.01-.186-.01A2.626 2.626 0 0 0 2.5 12.417l.013.268a2.625 2.625 0 0 0 2.612 2.356H7.5v1.25H5.125a3.875 3.875 0 0 1-3.87-3.675l-.005-.199c0-2 1.514-3.646 3.458-3.854A4.96 4.96 0 0 1 9.664 3.75z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CloudSaasMediumIcon.displayName = "CloudSaasMediumIcon";
export { CloudSaasMediumIcon };
