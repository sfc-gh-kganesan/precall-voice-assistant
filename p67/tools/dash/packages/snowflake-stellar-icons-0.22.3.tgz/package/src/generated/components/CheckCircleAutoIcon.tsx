import { forwardRef, ForwardedRef } from "react";

import { CheckCircleAutoMediumIcon } from "./CheckCircleAutoMediumIcon";
import { CheckCircleAutoRegularIcon } from "./CheckCircleAutoRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CheckCircleAutoIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CheckCircleAutoIcon = forwardRef(
  (
    { size = "regular", ...props }: CheckCircleAutoIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CheckCircleAutoRegularIcon />;

    if (size === "medium") {
      icon = <CheckCircleAutoMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CheckCircleAutoIcon.displayName = "CheckCircleAutoIcon";

export type { CheckCircleAutoIconProps };
export { CheckCircleAutoIcon };
