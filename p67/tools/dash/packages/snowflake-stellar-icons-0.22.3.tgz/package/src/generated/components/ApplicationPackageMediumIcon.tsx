import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationPackageMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path
                fillRule="evenodd"
                d="M14.137 7.11a.63.63 0 0 1 .533.035l5.008 2.782c.198.11.322.32.322.547v6.119a.63.63 0 0 1-.322.547l-5.008 2.782a.63.63 0 0 1-.606 0L9.056 17.14a.63.63 0 0 1-.32-.547v-6.12c0-.226.122-.436.32-.546l5.008-2.782zm-4.152 9.116 3.758 2.087v-4.691l-3.758-2.088zm5.008-2.604v4.69l3.757-2.086v-4.692zm-4.346-3.15 3.72 2.067 3.72-2.067-3.72-2.065z"
                clipRule="evenodd"
              />
              <path d="M9.691 1.644a.63.63 0 0 1 .618 0l6.877 3.907a.63.63 0 0 1 .316.543v.156H15.89L10 2.905 3.748 6.456v7.086L7.5 15.674v1.438L2.814 14.45a.63.63 0 0 1-.316-.544V6.094l.006-.083a.63.63 0 0 1 .31-.46z" />
              <path d="M10 6.25a3.73 3.73 0 0 1 2.076.629l-1.264.758A2.5 2.5 0 0 0 7.5 10v2.788A3.74 3.74 0 0 1 6.25 10 3.75 3.75 0 0 1 10 6.25" />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h20v20H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationPackageMediumIcon.displayName = "ApplicationPackageMediumIcon";
export { ApplicationPackageMediumIcon };
