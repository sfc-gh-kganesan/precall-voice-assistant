import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const DiamondPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M34.966 7H12.458a3 3 0 0 0-2.526 1.382L5.474 15.34a3 3 0 0 0 .096 3.378L21.25 40.369a3 3 0 0 0 4.862-.003l15.634-21.663a3 3 0 0 0 .11-3.347L37.51 8.41A3 3 0 0 0 34.966 7m-6.248 2h6.248a1 1 0 0 1 .848.47l4.065 6.497H31.01zm-2.106 0h-5.601l-2.198 6.967h10.092zm-7.698 0h-6.456a1 1 0 0 0-.842.46l-4.169 6.507h9.269zM7.496 17.967l13.86 19.142-4.784-19.142zm32.314 0L25.949 37.173l5.219-19.206zm-21.177 0h10.462L23.646 38.02z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DiamondPictogram.displayName = "DiamondPictogram";
export { DiamondPictogram };
