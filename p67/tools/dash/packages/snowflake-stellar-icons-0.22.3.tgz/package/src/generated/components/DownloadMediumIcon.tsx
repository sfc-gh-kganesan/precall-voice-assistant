import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DownloadMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M10 14.375a.63.63 0 0 0 .442-.183l5.625-5.625-.884-.884-4.558 4.558V2.5h-1.25v9.741L4.817 7.683l-.884.884 5.625 5.625a.63.63 0 0 0 .442.183m7.5 1.875h-15v1.25h15z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DownloadMediumIcon.displayName = "DownloadMediumIcon";
export { DownloadMediumIcon };
