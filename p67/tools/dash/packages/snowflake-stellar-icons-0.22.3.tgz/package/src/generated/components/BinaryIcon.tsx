import { forwardRef, ForwardedRef } from "react";

import { BinaryMediumIcon } from "./BinaryMediumIcon";
import { BinaryRegularIcon } from "./BinaryRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BinaryIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BinaryIcon = forwardRef(
  (
    { size = "regular", ...props }: BinaryIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BinaryRegularIcon />;

    if (size === "medium") {
      icon = <BinaryMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BinaryIcon.displayName = "BinaryIcon";

export type { BinaryIconProps };
export { BinaryIcon };
