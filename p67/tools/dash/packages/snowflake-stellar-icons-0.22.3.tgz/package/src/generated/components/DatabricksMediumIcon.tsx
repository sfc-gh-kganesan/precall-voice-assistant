import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabricksMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M17.552 13.908v-2.863l-.3-.194-7.207 4.063-6.832-3.87V9.382l6.832 3.83 7.544-4.217V6.17l-.3-.194-7.244 4.101-6.57-3.714 6.57-3.714 5.292 2.979.413-.232v-.31l-5.705-3.211L2.5 6.092v.426l7.545 4.256 6.831-3.87v1.703l-6.831 3.87L2.8 8.374l-.3.193v2.864l7.545 4.217 6.831-3.83v1.663l-6.831 3.87L2.8 13.288l-.3.193v.426l7.545 4.217z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DatabricksMediumIcon.displayName = "DatabricksMediumIcon";
export { DatabricksMediumIcon };
