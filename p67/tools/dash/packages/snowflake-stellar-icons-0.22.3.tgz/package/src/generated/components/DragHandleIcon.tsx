import { forwardRef, ForwardedRef } from "react";

import { DragHandleMediumIcon } from "./DragHandleMediumIcon";
import { DragHandleRegularIcon } from "./DragHandleRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DragHandleIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DragHandleIcon = forwardRef(
  (
    { size = "regular", ...props }: DragHandleIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DragHandleRegularIcon />;

    if (size === "medium") {
      icon = <DragHandleMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DragHandleIcon.displayName = "DragHandleIcon";

export type { DragHandleIconProps };
export { DragHandleIcon };
