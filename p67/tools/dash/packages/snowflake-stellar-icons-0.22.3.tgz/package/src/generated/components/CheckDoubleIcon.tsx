import { forwardRef, ForwardedRef } from "react";

import { CheckDoubleMediumIcon } from "./CheckDoubleMediumIcon";
import { CheckDoubleRegularIcon } from "./CheckDoubleRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CheckDoubleIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CheckDoubleIcon = forwardRef(
  (
    { size = "regular", ...props }: CheckDoubleIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CheckDoubleRegularIcon />;

    if (size === "medium") {
      icon = <CheckDoubleMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CheckDoubleIcon.displayName = "CheckDoubleIcon";

export type { CheckDoubleIconProps };
export { CheckDoubleIcon };
