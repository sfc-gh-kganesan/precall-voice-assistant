import { forwardRef, ForwardedRef } from "react";

import { BellMediumIcon } from "./BellMediumIcon";
import { BellRegularIcon } from "./BellRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BellIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BellIcon = forwardRef(
  (
    { size = "regular", ...props }: BellIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BellRegularIcon />;

    if (size === "medium") {
      icon = <BellMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BellIcon.displayName = "BellIcon";

export type { BellIconProps };
export { BellIcon };
