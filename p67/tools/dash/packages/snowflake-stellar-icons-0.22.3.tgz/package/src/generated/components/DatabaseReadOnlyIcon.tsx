import { forwardRef, ForwardedRef } from "react";

import { DatabaseReadOnlyMediumIcon } from "./DatabaseReadOnlyMediumIcon";
import { DatabaseReadOnlyRegularIcon } from "./DatabaseReadOnlyRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DatabaseReadOnlyIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DatabaseReadOnlyIcon = forwardRef(
  (
    { size = "regular", ...props }: DatabaseReadOnlyIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DatabaseReadOnlyRegularIcon />;

    if (size === "medium") {
      icon = <DatabaseReadOnlyMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DatabaseReadOnlyIcon.displayName = "DatabaseReadOnlyIcon";

export type { DatabaseReadOnlyIconProps };
export { DatabaseReadOnlyIcon };
