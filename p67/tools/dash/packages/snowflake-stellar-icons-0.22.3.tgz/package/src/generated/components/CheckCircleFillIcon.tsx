import { forwardRef, ForwardedRef } from "react";

import { CheckCircleFillMediumIcon } from "./CheckCircleFillMediumIcon";
import { CheckCircleFillRegularIcon } from "./CheckCircleFillRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CheckCircleFillIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CheckCircleFillIcon = forwardRef(
  (
    { size = "regular", ...props }: CheckCircleFillIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CheckCircleFillRegularIcon />;

    if (size === "medium") {
      icon = <CheckCircleFillMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CheckCircleFillIcon.displayName = "CheckCircleFillIcon";

export type { CheckCircleFillIconProps };
export { CheckCircleFillIcon };
