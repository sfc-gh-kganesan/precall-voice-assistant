import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CheckCircleFillMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10 1.25a8.75 8.75 0 1 1 0 17.5 8.75 8.75 0 0 1 0-17.5M8.546 12.817 5.453 9.57l-.906.862 3.572 3.75a.625.625 0 0 0 .926-.024l6.43-7.5-.95-.813z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CheckCircleFillMediumIcon.displayName = "CheckCircleFillMediumIcon";
export { CheckCircleFillMediumIcon };
