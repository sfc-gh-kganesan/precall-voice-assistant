import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DataPipelines_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M14 2a1 1 0 0 1 1 1v3a1 1 0 0 1-.898.995L14 7h-3l-.102-.005a1 1 0 0 1-.893-.892L10 6V5H8.5a.5.5 0 0 0-.5.5c0 .385-.146.734-.385 1 .239.266.385.615.385 1v3a.5.5 0 0 0 .5.5H10v-1a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v3a1 1 0 0 1-.898.995L14 14h-3l-.102-.005a1 1 0 0 1-.893-.893L10 13v-1H8.5A1.5 1.5 0 0 1 7 10.5v-3a.5.5 0 0 0-.5-.5H6v1a1 1 0 0 1-.897.995L5 9H2l-.103-.005a1 1 0 0 1-.892-.892L1 8V5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1h.5a.5.5 0 0 0 .5-.5A1.5 1.5 0 0 1 8.5 4H10V3a1 1 0 0 1 1-1zm-3 11h3v-3h-3zM2 8h3V5H2zm9-2h3V3h-3z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataPipelines_1xIcon.displayName = "DataPipelines_1xIcon";
export { DataPipelines_1xIcon };
