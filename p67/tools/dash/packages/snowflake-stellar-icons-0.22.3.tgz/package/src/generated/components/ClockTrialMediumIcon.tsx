import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClockTrialMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M11.141 18.673A9 9 0 0 1 10 18.75q-.58-.002-1.143-.077l.162-1.236a7.6 7.6 0 0 0 1.962 0zM5.435 15.95a7.5 7.5 0 0 0 1.694.981l-.479 1.154a8.7 8.7 0 0 1-1.977-1.145zm9.891.99a8.7 8.7 0 0 1-1.978 1.145l-.477-1.154a7.5 7.5 0 0 0 1.694-.98zM3.069 12.871c.252.609.583 1.178.98 1.694l-.99.76a8.7 8.7 0 0 1-1.145-1.977zm15.016.477a8.7 8.7 0 0 1-1.145 1.978l-.99-.76a7.5 7.5 0 0 0 .981-1.695zM2.563 9.019a7.6 7.6 0 0 0 0 1.962l-1.237.16A9 9 0 0 1 1.25 10q.001-.581.076-1.143zm16.11-.162q.075.563.077 1.143-.002.581-.077 1.141l-1.236-.16a7.6 7.6 0 0 0 0-1.962zm-8.048.518H15v1.25h-5A.625.625 0 0 1 9.375 10V5h1.25zM4.05 5.435a7.5 7.5 0 0 0-.981 1.694L1.914 6.65A8.7 8.7 0 0 1 3.06 4.673zm12.89-.762a8.7 8.7 0 0 1 1.145 1.977l-1.154.479a7.5 7.5 0 0 0-.98-1.694zM7.129 3.069a7.5 7.5 0 0 0-1.694.98l-.762-.99A8.7 8.7 0 0 1 6.65 1.914zm6.219-1.155a8.7 8.7 0 0 1 1.978 1.145l-.76.99a7.5 7.5 0 0 0-1.695-.98zM10 1.25q.581.001 1.141.076l-.16 1.237a7.6 7.6 0 0 0-1.962 0l-.162-1.237A9 9 0 0 1 10 1.25"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClockTrialMediumIcon.displayName = "ClockTrialMediumIcon";
export { ClockTrialMediumIcon };
