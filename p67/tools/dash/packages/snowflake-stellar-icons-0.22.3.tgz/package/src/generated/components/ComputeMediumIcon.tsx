import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ComputeMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M11.39 1.48a.624.624 0 0 1 1.106.457L11.939 7.5h4.31a.625.625 0 0 1 .485 1.02l-8.125 10a.624.624 0 0 1-1.106-.457L8.06 12.5H3.75a.625.625 0 0 1-.485-1.02zm-6.328 9.77H8.75a.626.626 0 0 1 .621.687l-.419 4.176 5.985-7.363H11.25a.626.626 0 0 1-.622-.687l.418-4.177z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ComputeMediumIcon.displayName = "ComputeMediumIcon";
export { ComputeMediumIcon };
