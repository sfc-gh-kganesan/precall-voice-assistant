import { AccountPictogram } from "./AccountPictogram";
import { AdvertisingOptimizationPictogram } from "./AdvertisingOptimizationPictogram";
import { AiModelPictogram } from "./AiModelPictogram";
import { AiPictogram } from "./AiPictogram";
import { AlertCirclePictogram } from "./AlertCirclePictogram";
import { AnomalyPictogram } from "./AnomalyPictogram";
import { AnswerPictogram } from "./AnswerPictogram";
import { ApplicationPictogram } from "./ApplicationPictogram";
import { BlocksPictogram } from "./BlocksPictogram";
import { BookPictogram } from "./BookPictogram";
import { BooleanPictogram } from "./BooleanPictogram";
import { BoxPictogram } from "./BoxPictogram";
import { CalendarPictogram } from "./CalendarPictogram";
import { ChartCircleAnalysisPictogram } from "./ChartCircleAnalysisPictogram";
import { ChartFinancialPictogram } from "./ChartFinancialPictogram";
import { ChartPictogram } from "./ChartPictogram";
import { ClassificationPictogram } from "./ClassificationPictogram";
import { CodePictogram } from "./CodePictogram";
import { ComputePictogram } from "./ComputePictogram";
import { ConnectorPictogram } from "./ConnectorPictogram";
import { ContributionPictogram } from "./ContributionPictogram";
import { CortexSearchPictogram } from "./CortexSearchPictogram";
import { DashboardPictogram } from "./DashboardPictogram";
import { DataCleanRoomPictogram } from "./DataCleanRoomPictogram";
import { DataEngineeringPictogram } from "./DataEngineeringPictogram";
import { DataPreviewPictogram } from "./DataPreviewPictogram";
import { DataPictogram } from "./DataPictogram";
import { DatabasePictogram } from "./DatabasePictogram";
import { DiamondPictogram } from "./DiamondPictogram";
import { EconomicImpactPictogram } from "./EconomicImpactPictogram";
import { EditAiPictogram } from "./EditAiPictogram";
import { EditCreatePictogram } from "./EditCreatePictogram";
import { EmptyFolderPictogram } from "./EmptyFolderPictogram";
import { EnergyPictogram } from "./EnergyPictogram";
import { EnvironmentPictogram } from "./EnvironmentPictogram";
import { FileFormatPictogram } from "./FileFormatPictogram";
import { FilePictogram } from "./FilePictogram";
import { FiltersPictogram } from "./FiltersPictogram";
import { FingerprintCheckmarkPictogram } from "./FingerprintCheckmarkPictogram";
import { FingerprintPictogram } from "./FingerprintPictogram";
import { FolderPictogram } from "./FolderPictogram";
import { ForecastingPictogram } from "./ForecastingPictogram";
import { GearPictogram } from "./GearPictogram";
import { GeneralEmptyStatePictogram } from "./GeneralEmptyStatePictogram";
import { GeneralErrorPictogram } from "./GeneralErrorPictogram";
import { GovernmentPictogram } from "./GovernmentPictogram";
import { HealthCommercialPictogram } from "./HealthCommercialPictogram";
import { HealthMedicinePictogram } from "./HealthMedicinePictogram";
import { HealthSciencePictogram } from "./HealthSciencePictogram";
import { LanguagePictogram } from "./LanguagePictogram";
import { LegalPictogram } from "./LegalPictogram";
import { ListingDraftPictogram } from "./ListingDraftPictogram";
import { ListingExamplePictogram } from "./ListingExamplePictogram";
import { ListingPictogram } from "./ListingPictogram";
import { LlmPictogram } from "./LlmPictogram";
import { LocationPictogram } from "./LocationPictogram";
import { LockClosedPictogram } from "./LockClosedPictogram";
import { LookupTablePictogram } from "./LookupTablePictogram";
import { LoudspeakerPictogram } from "./LoudspeakerPictogram";
import { MachineLearningPictogram } from "./MachineLearningPictogram";
import { MagnetPictogram } from "./MagnetPictogram";
import { MarketAnalysisPictogram } from "./MarketAnalysisPictogram";
import { MarketplaceInternalPictogram } from "./MarketplaceInternalPictogram";
import { MarketplacePictogram } from "./MarketplacePictogram";
import { MediaPictogram } from "./MediaPictogram";
import { ObjectPictogram } from "./ObjectPictogram";
import { OnboardingPictogram } from "./OnboardingPictogram";
import { OrganizationPictogram } from "./OrganizationPictogram";
import { PackagePictogram } from "./PackagePictogram";
import { PersonalInfoPictogram } from "./PersonalInfoPictogram";
import { PinBuildingPictogram } from "./PinBuildingPictogram";
import { PinDataPictogram } from "./PinDataPictogram";
import { PinGlobePictogram } from "./PinGlobePictogram";
import { PinMapPictogram } from "./PinMapPictogram";
import { PinPictogram } from "./PinPictogram";
import { PlusSquarePictogram } from "./PlusSquarePictogram";
import { PricingAnalysisPictogram } from "./PricingAnalysisPictogram";
import { PublicPictogram } from "./PublicPictogram";
import { QuantitativeAnalysisPictogram } from "./QuantitativeAnalysisPictogram";
import { QueryPreviewPictogram } from "./QueryPreviewPictogram";
import { RiskAnalysisPictogram } from "./RiskAnalysisPictogram";
import { RolePictogram } from "./RolePictogram";
import { ScalePictogram } from "./ScalePictogram";
import { SchemaPictogram } from "./SchemaPictogram";
import { ScriptFilePictogram } from "./ScriptFilePictogram";
import { SearchPictogram } from "./SearchPictogram";
import { SentimentPictogram } from "./SentimentPictogram";
import { ShieldCheckmarkPictogram } from "./ShieldCheckmarkPictogram";
import { ShieldLockPictogram } from "./ShieldLockPictogram";
import { SportPictogram } from "./SportPictogram";
import { SqlPictogram } from "./SqlPictogram";
import { StreamlitAppsPictogram } from "./StreamlitAppsPictogram";
import { SubscriberPictogram } from "./SubscriberPictogram";
import { SummaryPictogram } from "./SummaryPictogram";
import { TablePictogram } from "./TablePictogram";
import { TeamPictogram } from "./TeamPictogram";
import { TransportationPictogram } from "./TransportationPictogram";
import { TravelPictogram } from "./TravelPictogram";
import { UploadPictogram } from "./UploadPictogram";
import { WarehousePictogram } from "./WarehousePictogram";
import { WarningTrianglePictogram } from "./WarningTrianglePictogram";
import { WeatherPictogram } from "./WeatherPictogram";
import { WorksheetPictogram } from "./WorksheetPictogram";
import { WritingHandPictogram } from "./WritingHandPictogram";

export type PictogramType =
  | typeof AccountPictogram
  | typeof AdvertisingOptimizationPictogram
  | typeof AiModelPictogram
  | typeof AiPictogram
  | typeof AlertCirclePictogram
  | typeof AnomalyPictogram
  | typeof AnswerPictogram
  | typeof ApplicationPictogram
  | typeof BlocksPictogram
  | typeof BookPictogram
  | typeof BooleanPictogram
  | typeof BoxPictogram
  | typeof CalendarPictogram
  | typeof ChartCircleAnalysisPictogram
  | typeof ChartFinancialPictogram
  | typeof ChartPictogram
  | typeof ClassificationPictogram
  | typeof CodePictogram
  | typeof ComputePictogram
  | typeof ConnectorPictogram
  | typeof ContributionPictogram
  | typeof CortexSearchPictogram
  | typeof DashboardPictogram
  | typeof DataCleanRoomPictogram
  | typeof DataEngineeringPictogram
  | typeof DataPreviewPictogram
  | typeof DataPictogram
  | typeof DatabasePictogram
  | typeof DiamondPictogram
  | typeof EconomicImpactPictogram
  | typeof EditAiPictogram
  | typeof EditCreatePictogram
  | typeof EmptyFolderPictogram
  | typeof EnergyPictogram
  | typeof EnvironmentPictogram
  | typeof FileFormatPictogram
  | typeof FilePictogram
  | typeof FiltersPictogram
  | typeof FingerprintCheckmarkPictogram
  | typeof FingerprintPictogram
  | typeof FolderPictogram
  | typeof ForecastingPictogram
  | typeof GearPictogram
  | typeof GeneralEmptyStatePictogram
  | typeof GeneralErrorPictogram
  | typeof GovernmentPictogram
  | typeof HealthCommercialPictogram
  | typeof HealthMedicinePictogram
  | typeof HealthSciencePictogram
  | typeof LanguagePictogram
  | typeof LegalPictogram
  | typeof ListingDraftPictogram
  | typeof ListingExamplePictogram
  | typeof ListingPictogram
  | typeof LlmPictogram
  | typeof LocationPictogram
  | typeof LockClosedPictogram
  | typeof LookupTablePictogram
  | typeof LoudspeakerPictogram
  | typeof MachineLearningPictogram
  | typeof MagnetPictogram
  | typeof MarketAnalysisPictogram
  | typeof MarketplaceInternalPictogram
  | typeof MarketplacePictogram
  | typeof MediaPictogram
  | typeof ObjectPictogram
  | typeof OnboardingPictogram
  | typeof OrganizationPictogram
  | typeof PackagePictogram
  | typeof PersonalInfoPictogram
  | typeof PinBuildingPictogram
  | typeof PinDataPictogram
  | typeof PinGlobePictogram
  | typeof PinMapPictogram
  | typeof PinPictogram
  | typeof PlusSquarePictogram
  | typeof PricingAnalysisPictogram
  | typeof PublicPictogram
  | typeof QuantitativeAnalysisPictogram
  | typeof QueryPreviewPictogram
  | typeof RiskAnalysisPictogram
  | typeof RolePictogram
  | typeof ScalePictogram
  | typeof SchemaPictogram
  | typeof ScriptFilePictogram
  | typeof SearchPictogram
  | typeof SentimentPictogram
  | typeof ShieldCheckmarkPictogram
  | typeof ShieldLockPictogram
  | typeof SportPictogram
  | typeof SqlPictogram
  | typeof StreamlitAppsPictogram
  | typeof SubscriberPictogram
  | typeof SummaryPictogram
  | typeof TablePictogram
  | typeof TeamPictogram
  | typeof TransportationPictogram
  | typeof TravelPictogram
  | typeof UploadPictogram
  | typeof WarehousePictogram
  | typeof WarningTrianglePictogram
  | typeof WeatherPictogram
  | typeof WorksheetPictogram
  | typeof WritingHandPictogram;
