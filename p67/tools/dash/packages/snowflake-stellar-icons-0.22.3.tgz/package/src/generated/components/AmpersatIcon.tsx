import { forwardRef, ForwardedRef } from "react";

import { AmpersatMediumIcon } from "./AmpersatMediumIcon";
import { AmpersatRegularIcon } from "./AmpersatRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AmpersatIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AmpersatIcon = forwardRef(
  (
    { size = "regular", ...props }: AmpersatIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AmpersatRegularIcon />;

    if (size === "medium") {
      icon = <AmpersatMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AmpersatIcon.displayName = "AmpersatIcon";

export type { AmpersatIconProps };
export { AmpersatIcon };
