import { forwardRef, ForwardedRef } from "react";

import { ColumnMultipleMediumIcon } from "./ColumnMultipleMediumIcon";
import { ColumnMultipleRegularIcon } from "./ColumnMultipleRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ColumnMultipleIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ColumnMultipleIcon = forwardRef(
  (
    { size = "regular", ...props }: ColumnMultipleIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ColumnMultipleRegularIcon />;

    if (size === "medium") {
      icon = <ColumnMultipleMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ColumnMultipleIcon.displayName = "ColumnMultipleIcon";

export type { ColumnMultipleIconProps };
export { ColumnMultipleIcon };
