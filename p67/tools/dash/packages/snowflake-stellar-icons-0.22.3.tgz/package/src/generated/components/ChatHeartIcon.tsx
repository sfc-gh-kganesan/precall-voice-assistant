import { forwardRef, ForwardedRef } from "react";

import { ChatHeartMediumIcon } from "./ChatHeartMediumIcon";
import { ChatHeartRegularIcon } from "./ChatHeartRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChatHeartIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChatHeartIcon = forwardRef(
  (
    { size = "regular", ...props }: ChatHeartIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChatHeartRegularIcon />;

    if (size === "medium") {
      icon = <ChatHeartMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChatHeartIcon.displayName = "ChatHeartIcon";

export type { ChatHeartIconProps };
export { ChatHeartIcon };
