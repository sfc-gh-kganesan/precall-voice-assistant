import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const ApplicationPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="m23.97 29.454-4.76 8.287A7.96 7.96 0 0 1 8.3 40.665c-3.82-2.217-5.133-7.117-2.933-10.947L16.978 9.503a7.96 7.96 0 0 1 10.574-3.107 8 8 0 0 1 3.367 3.156l11.702 20.163a7.96 7.96 0 0 1-2.924 10.91c-3.83 2.2-8.73.887-10.946-2.933zM26.884 8.31a6.04 6.04 0 0 1 2.203 8.22L17.476 36.745a5.96 5.96 0 0 1-8.172 2.19 6.04 6.04 0 0 1-2.203-8.22l11.611-20.216a5.96 5.96 0 0 1 8.172-2.19m4.872 6.67a8 8 0 0 1-.935 2.546l-5.7 9.925 5.36 9.237a6.04 6.04 0 0 0 8.22 2.203 5.96 5.96 0 0 0 2.19-8.172z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationPictogram.displayName = "ApplicationPictogram";
export { ApplicationPictogram };
