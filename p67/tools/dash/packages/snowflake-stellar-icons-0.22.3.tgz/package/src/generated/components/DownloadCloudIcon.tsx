import { forwardRef, ForwardedRef } from "react";

import { DownloadCloudMediumIcon } from "./DownloadCloudMediumIcon";
import { DownloadCloudRegularIcon } from "./DownloadCloudRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DownloadCloudIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DownloadCloudIcon = forwardRef(
  (
    { size = "regular", ...props }: DownloadCloudIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DownloadCloudRegularIcon />;

    if (size === "medium") {
      icon = <DownloadCloudMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DownloadCloudIcon.displayName = "DownloadCloudIcon";

export type { DownloadCloudIconProps };
export { DownloadCloudIcon };
