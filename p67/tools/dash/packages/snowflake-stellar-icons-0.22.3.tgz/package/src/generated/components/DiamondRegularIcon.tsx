import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DiamondRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M7.635 13.608a.5.5 0 0 0 .73 0l6.344-6.797a.5.5 0 0 0 .03-.648l-3.086-3.97A.5.5 0 0 0 11.257 2l-6.196.005a.5.5 0 0 0-.38.176L1.289 6.16a.5.5 0 0 0 .015.665zm.368-1.004.053-.06L10.34 6.95H5.868zM6.093 6.05h4.057L8.21 2.903h-.106zm.865-3.146-1.69.001L2.67 6.05h2.278zM2.655 6.95h2.206l1.467 3.796zm6.69-4.048 1.939 3.148h2.129L11.038 2.9zm4 4.048h-1.989l-1.511 3.603z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DiamondRegularIcon.displayName = "DiamondRegularIcon";
export { DiamondRegularIcon };
