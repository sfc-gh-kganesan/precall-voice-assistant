import { forwardRef, ForwardedRef } from "react";

import { ActivityMediumIcon } from "./ActivityMediumIcon";
import { ActivityRegularIcon } from "./ActivityRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ActivityIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ActivityIcon = forwardRef(
  (
    { size = "regular", ...props }: ActivityIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ActivityRegularIcon />;

    if (size === "medium") {
      icon = <ActivityMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ActivityIcon.displayName = "ActivityIcon";

export type { ActivityIconProps };
export { ActivityIcon };
