import { forwardRef, ForwardedRef } from "react";

import { CalendarArrowLeftMediumIcon } from "./CalendarArrowLeftMediumIcon";
import { CalendarArrowLeftRegularIcon } from "./CalendarArrowLeftRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CalendarArrowLeftIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CalendarArrowLeftIcon = forwardRef(
  (
    { size = "regular", ...props }: CalendarArrowLeftIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CalendarArrowLeftRegularIcon />;

    if (size === "medium") {
      icon = <CalendarArrowLeftMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CalendarArrowLeftIcon.displayName = "CalendarArrowLeftIcon";

export type { CalendarArrowLeftIconProps };
export { CalendarArrowLeftIcon };
