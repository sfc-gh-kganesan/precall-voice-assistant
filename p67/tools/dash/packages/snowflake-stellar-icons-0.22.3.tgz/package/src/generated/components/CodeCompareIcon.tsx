import { forwardRef, ForwardedRef } from "react";

import { CodeCompareMediumIcon } from "./CodeCompareMediumIcon";
import { CodeCompareRegularIcon } from "./CodeCompareRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CodeCompareIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CodeCompareIcon = forwardRef(
  (
    { size = "regular", ...props }: CodeCompareIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CodeCompareRegularIcon />;

    if (size === "medium") {
      icon = <CodeCompareMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CodeCompareIcon.displayName = "CodeCompareIcon";

export type { CodeCompareIconProps };
export { CodeCompareIcon };
