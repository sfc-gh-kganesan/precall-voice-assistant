import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CheckDoubleMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m13.567 6.067-7.5 7.5a.625.625 0 0 1-.884 0l-3.125-3.125.884-.884 2.683 2.683 7.058-7.058zm5 0-7.5 7.5a.625.625 0 0 1-.884 0l-1.25-1.25.884-.884.808.808 7.058-7.058z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CheckDoubleMediumIcon.displayName = "CheckDoubleMediumIcon";
export { CheckDoubleMediumIcon };
