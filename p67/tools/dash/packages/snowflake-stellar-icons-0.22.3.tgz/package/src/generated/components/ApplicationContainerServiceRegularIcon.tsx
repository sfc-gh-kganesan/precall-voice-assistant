import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationContainerServiceRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path
                fillRule="evenodd"
                d="M13.5 7a.5.5 0 0 1 .5.5V11h1.5a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5v-4a.5.5 0 0 1 .5-.5H8V7.5a.5.5 0 0 1 .5-.5zM7 15h3.5v-3H7zm4.5 0H15v-3h-3.5zM9 11h4V8H9z"
                clipRule="evenodd"
              />
              <path d="M7.753 1.315a.5.5 0 0 1 .494 0L13.75 4.44a.5.5 0 0 1 .253.435V6h-1v-.835L8 2.325l-5.002 2.84v5.669L5 11.971v1.15l-2.749-1.56a.5.5 0 0 1-.253-.435V4.875l.005-.066a.5.5 0 0 1 .248-.369z" />
              <path d="M8 5a3 3 0 0 1 2.231 1H8a1.997 1.997 0 0 0-1 3.73V10H5.769A3 3 0 0 1 5 8a3 3 0 0 1 3-3" />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h16v16H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationContainerServiceRegularIcon.displayName =
  "ApplicationContainerServiceRegularIcon";
export { ApplicationContainerServiceRegularIcon };
