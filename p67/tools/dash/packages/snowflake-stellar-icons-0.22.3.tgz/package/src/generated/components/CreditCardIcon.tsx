import { forwardRef, ForwardedRef } from "react";

import { CreditCardMediumIcon } from "./CreditCardMediumIcon";
import { CreditCardRegularIcon } from "./CreditCardRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CreditCardIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CreditCardIcon = forwardRef(
  (
    { size = "regular", ...props }: CreditCardIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CreditCardRegularIcon />;

    if (size === "medium") {
      icon = <CreditCardMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CreditCardIcon.displayName = "CreditCardIcon";

export type { CreditCardIconProps };
export { CreditCardIcon };
