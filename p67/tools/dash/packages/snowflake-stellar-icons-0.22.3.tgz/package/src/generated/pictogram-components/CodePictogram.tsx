import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const CodePictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              stroke={iconColor}
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19.368 17.053 13 24l6.368 6.948"
            />
            <path
              fill={iconColor}
              d="m29.369 31.623 6.368-6.947a1 1 0 0 0 0-1.352l-6.368-6.947-1.475 1.351L33.644 24l-5.75 6.272z"
            />
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M6 14a8 8 0 0 1 8-8h20a8 8 0 0 1 8 8v20a8 8 0 0 1-8 8H14a8 8 0 0 1-8-8zm8-6h20a6 6 0 0 1 6 6v20a6 6 0 0 1-6 6H14a6 6 0 0 1-6-6V14a6 6 0 0 1 6-6"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CodePictogram.displayName = "CodePictogram";
export { CodePictogram };
