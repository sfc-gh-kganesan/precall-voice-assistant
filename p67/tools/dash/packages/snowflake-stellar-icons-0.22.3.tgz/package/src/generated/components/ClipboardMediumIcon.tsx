import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClipboardMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M14.375 3.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-8.75a1.875 1.875 0 0 1-1.875-1.875V5.625c0-1.035.84-1.875 1.875-1.875H7.5a2.5 2.5 0 0 1 2.5-2.5l.255.013a2.5 2.5 0 0 1 2.232 2.232l.013.255zm-3.125 0a1.25 1.25 0 0 0-2.5 0zM5.625 5A.625.625 0 0 0 5 5.625v11.25c0 .345.28.625.625.625h8.75c.345 0 .625-.28.625-.625V5.625A.625.625 0 0 0 14.375 5h-.625v3.125a.626.626 0 0 1-.5.613l-.125.012h-6.25l-.126-.012a.626.626 0 0 1-.499-.613V5zM7.5 7.5h5V5h-5z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClipboardMediumIcon.displayName = "ClipboardMediumIcon";
export { ClipboardMediumIcon };
