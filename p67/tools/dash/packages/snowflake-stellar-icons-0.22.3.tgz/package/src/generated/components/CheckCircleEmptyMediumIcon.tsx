import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
const CheckCircleEmptyMediumIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        ref={ref}
        svgContent={
          <>
            <g clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path
                fill={iconColor}
                d="M18.75 10A8.75 8.75 0 1 0 10 18.75V20C4.477 20 0 15.523 0 10S4.477 0 10 0s10 4.477 10 10-4.477 10-10 10v-1.25A8.75 8.75 0 0 0 18.75 10"
              />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h20v20H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
CheckCircleEmptyMediumIcon.displayName = "CheckCircleEmptyMediumIcon";
export { CheckCircleEmptyMediumIcon };
