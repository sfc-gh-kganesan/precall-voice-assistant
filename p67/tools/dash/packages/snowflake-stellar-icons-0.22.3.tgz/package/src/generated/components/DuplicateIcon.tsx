import { forwardRef, ForwardedRef } from "react";

import { DuplicateMediumIcon } from "./DuplicateMediumIcon";
import { DuplicateRegularIcon } from "./DuplicateRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DuplicateIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DuplicateIcon = forwardRef(
  (
    { size = "regular", ...props }: DuplicateIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DuplicateRegularIcon />;

    if (size === "medium") {
      icon = <DuplicateMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DuplicateIcon.displayName = "DuplicateIcon";

export type { DuplicateIconProps };
export { DuplicateIcon };
