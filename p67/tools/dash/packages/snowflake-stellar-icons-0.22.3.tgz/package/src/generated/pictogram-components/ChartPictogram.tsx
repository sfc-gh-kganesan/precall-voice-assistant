import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const ChartPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <rect
              width={8.459}
              height={28.421}
              x={20.77}
              y={9.789}
              stroke={iconColor}
              strokeLinejoin="round"
              strokeWidth={2}
              rx={1}
            />
            <rect
              width={8.459}
              height={17.594}
              x={7.714}
              y={20.616}
              stroke={iconColor}
              strokeLinejoin="round"
              strokeWidth={2}
              rx={1}
            />
            <rect
              width={8.459}
              height={23.008}
              x={33.827}
              y={15.203}
              stroke={iconColor}
              strokeLinejoin="round"
              strokeWidth={2}
              rx={1}
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartPictogram.displayName = "ChartPictogram";
export { ChartPictogram };
