import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowUp_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.5 2a.5.5 0 0 1 .354.146l5 5-.707.708L8 3.707V14H7V3.707L2.854 7.854l-.708-.708 5-5A.5.5 0 0 1 7.5 2"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowUp_1xIcon.displayName = "ArrowUp_1xIcon";
export { ArrowUp_1xIcon };
