import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowLeftRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M2 8a.5.5 0 0 1 .146-.354l5-5 .708.708L3.707 7.5H14v1H3.707l4.147 4.147-.708.707-5-5A.5.5 0 0 1 2 8"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowLeftRegularIcon.displayName = "ArrowLeftRegularIcon";
export { ArrowLeftRegularIcon };
