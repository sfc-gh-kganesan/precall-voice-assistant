import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AnswerMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="m14.192 7.942-5 5a.625.625 0 0 1-.884 0l-2.5-2.5.884-.884 2.058 2.058 4.558-4.558z" />
              <path
                fillRule="evenodd"
                d="M15.625 3.75c1.035 0 1.875.84 1.875 1.875v8.75c0 1.036-.84 1.875-1.875 1.875H5.259l-1.692 1.692A.625.625 0 0 1 2.5 17.5V5.625c0-1.036.84-1.875 1.875-1.875zM4.375 5a.625.625 0 0 0-.625.625v10.366l.808-.808.095-.078A.63.63 0 0 1 5 15h10.625c.345 0 .625-.28.625-.625v-8.75A.625.625 0 0 0 15.625 5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AnswerMediumIcon.displayName = "AnswerMediumIcon";
export { AnswerMediumIcon };
