import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabricksRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M14.041 11.126v-2.29l-.24-.155-5.765 3.25L2.57 8.836V7.505l5.465 3.064 6.035-3.374v-2.26l-.24-.154-5.795 3.28-5.255-2.97 5.255-2.972 4.234 2.383.33-.185v-.248L8.036 1.5 2 4.874v.34L8.036 8.62 13.5 5.524v1.362L8.036 9.98 2.24 6.7 2 6.855v2.29l6.036 3.374L13.5 9.455v1.33l-5.465 3.096-5.796-3.25-.24.155v.34L8.036 14.5z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DatabricksRegularIcon.displayName = "DatabricksRegularIcon";
export { DatabricksRegularIcon };
