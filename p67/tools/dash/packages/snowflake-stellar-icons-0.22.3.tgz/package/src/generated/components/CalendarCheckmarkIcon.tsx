import { forwardRef, ForwardedRef } from "react";

import { CalendarCheckmarkMediumIcon } from "./CalendarCheckmarkMediumIcon";
import { CalendarCheckmarkRegularIcon } from "./CalendarCheckmarkRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CalendarCheckmarkIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CalendarCheckmarkIcon = forwardRef(
  (
    { size = "regular", ...props }: CalendarCheckmarkIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CalendarCheckmarkRegularIcon />;

    if (size === "medium") {
      icon = <CalendarCheckmarkMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CalendarCheckmarkIcon.displayName = "CalendarCheckmarkIcon";

export type { CalendarCheckmarkIconProps };
export { CalendarCheckmarkIcon };
