import { forwardRef, ForwardedRef } from "react";

import { DeploymentMediumIcon } from "./DeploymentMediumIcon";
import { DeploymentRegularIcon } from "./DeploymentRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DeploymentIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DeploymentIcon = forwardRef(
  (
    { size = "regular", ...props }: DeploymentIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DeploymentRegularIcon />;

    if (size === "medium") {
      icon = <DeploymentMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DeploymentIcon.displayName = "DeploymentIcon";

export type { DeploymentIconProps };
export { DeploymentIcon };
