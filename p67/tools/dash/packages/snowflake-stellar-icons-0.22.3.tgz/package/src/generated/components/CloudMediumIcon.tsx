import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M17.5 11.875a3.167 3.167 0 0 0-2.843-3.15l-.323-.016q-.164 0-.318.014l-.598.06-.083-.595a3.71 3.71 0 0 0-3.324-3.172L9.664 5a3.71 3.71 0 0 0-3.708 3.709l.005.203q.005.1.016.198l.079.742-.745-.051c-.081-.006-.135-.01-.186-.01A2.626 2.626 0 0 0 2.5 12.417l.013.268a2.625 2.625 0 0 0 2.612 2.356h9.193l.189-.004a3.17 3.17 0 0 0 2.977-2.848zm1.245.22a4.417 4.417 0 0 1-4.185 4.19l-.015.002-.196.005H5.125a3.875 3.875 0 0 1-3.87-3.676l-.005-.199c0-2 1.514-3.646 3.458-3.854A4.96 4.96 0 0 1 9.664 3.75l.233.005a4.96 4.96 0 0 1 4.565 3.706 4.416 4.416 0 0 1 4.288 4.414z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CloudMediumIcon.displayName = "CloudMediumIcon";
export { CloudMediumIcon };
