import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AzureRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M10 2.5a.6.6 0 0 1 .33.103.56.56 0 0 1 .206.271l3.435 9.9a.54.54 0 0 1-.077.497.58.58 0 0 1-.459.23H9.477a.58.58 0 0 0 .46-.23.54.54 0 0 0 .076-.497l-3.434-9.9a.55.55 0 0 0-.363-.348.6.6 0 0 0-.173-.025zm-4.603.565a.87.87 0 0 0 .416.252l1.727 4.98-.167.482H5.53a1.16 1.16 0 0 0-.636.19v.001c-.142.094-.26.216-.344.358l-.074.149a1.07 1.07 0 0 0 .282 1.208h-.001l1.487 1.35-.377 1.09a.55.55 0 0 1-.364.348.6.6 0 0 1-.173.026H2.566a.58.58 0 0 1-.46-.228.54.54 0 0 1-.077-.497z" />
              <path d="M9.082 12.745a.87.87 0 0 0-.377.365l-3.354-3.044a.25.25 0 0 1-.064-.278.26.26 0 0 1 .096-.117.27.27 0 0 1 .146-.044h2.472z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AzureRegularIcon.displayName = "AzureRegularIcon";
export { AzureRegularIcon };
