import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowStopDown_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.5 11.5a.5.5 0 0 0 .354-.146l4.5-4.5-.707-.708L8 9.793V2H7v7.793L3.354 6.146l-.708.708 4.5 4.5a.5.5 0 0 0 .354.146M14 13H1v1h13z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowStopDown_1xIcon.displayName = "ArrowStopDown_1xIcon";
export { ArrowStopDown_1xIcon };
