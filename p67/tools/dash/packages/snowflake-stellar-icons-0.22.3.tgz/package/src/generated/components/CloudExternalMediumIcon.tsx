import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudExternalMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M9.897 3.755q.052.003.103.008v1.252L9.664 5a3.71 3.71 0 0 0-3.708 3.709l.005.203q.005.1.016.198l.079.742-.745-.051c-.081-.006-.135-.01-.186-.01A2.626 2.626 0 0 0 2.5 12.417l.013.268a2.625 2.625 0 0 0 2.612 2.356h9.193l.189-.004a3.17 3.17 0 0 0 2.977-2.848l.016-.314c0-.702-.23-1.35-.616-1.875h1.448a4.4 4.4 0 0 1 .418 1.875l-.005.22a4.417 4.417 0 0 1-4.185 4.19l-.015.002-.196.005H5.125a3.875 3.875 0 0 1-3.87-3.676l-.005-.199c0-2 1.514-3.646 3.458-3.854A4.96 4.96 0 0 1 9.664 3.75z" />
              <path d="M16.875 2.5c.345 0 .625.28.625.625V8.75h-1.25V4.634l-6.433 6.433-.884-.884 6.433-6.433H11.25V2.5z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CloudExternalMediumIcon.displayName = "CloudExternalMediumIcon";
export { CloudExternalMediumIcon };
