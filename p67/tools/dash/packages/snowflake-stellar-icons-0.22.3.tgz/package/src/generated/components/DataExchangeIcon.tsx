import { forwardRef, ForwardedRef } from "react";

import { DataExchangeMediumIcon } from "./DataExchangeMediumIcon";
import { DataExchangeRegularIcon } from "./DataExchangeRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DataExchangeIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DataExchangeIcon = forwardRef(
  (
    { size = "regular", ...props }: DataExchangeIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DataExchangeRegularIcon />;

    if (size === "medium") {
      icon = <DataExchangeMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DataExchangeIcon.displayName = "DataExchangeIcon";

export type { DataExchangeIconProps };
export { DataExchangeIcon };
