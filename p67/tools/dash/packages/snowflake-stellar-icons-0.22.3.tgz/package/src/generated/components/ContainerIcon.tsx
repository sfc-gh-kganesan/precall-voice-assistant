import { forwardRef, ForwardedRef } from "react";

import { ContainerMediumIcon } from "./ContainerMediumIcon";
import { ContainerRegularIcon } from "./ContainerRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ContainerIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ContainerIcon = forwardRef(
  (
    { size = "regular", ...props }: ContainerIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ContainerRegularIcon />;

    if (size === "medium") {
      icon = <ContainerMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ContainerIcon.displayName = "ContainerIcon";

export type { ContainerIconProps };
export { ContainerIcon };
