import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowStopLeft_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M4.5 7.5a.5.5 0 0 0 .146.354l4.5 4.5.708-.707L6.207 8H14V7H6.207l3.647-3.646-.708-.708-4.5 4.5A.5.5 0 0 0 4.5 7.5M3 14V1H2v13z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowStopLeft_1xIcon.displayName = "ArrowStopLeft_1xIcon";
export { ArrowStopLeft_1xIcon };
