import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowRightCurvedMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M17.5 10.625a.63.63 0 0 1-.183.442l-5 5-.884-.884 3.933-3.933H4.375A1.875 1.875 0 0 1 2.5 9.375V2.5h1.25v6.875c0 .345.28.625.625.625h10.991l-3.933-3.933.884-.884 5 5a.63.63 0 0 1 .183.442"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowRightCurvedMediumIcon.displayName = "ArrowRightCurvedMediumIcon";
export { ArrowRightCurvedMediumIcon };
