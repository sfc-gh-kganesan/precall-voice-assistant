import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CommentMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M11.25 11.25h-5V10h5zm2.5-2.5h-7.5V7.5h7.5z" />
              <path
                fillRule="evenodd"
                d="M15.625 3.75c1.035 0 1.875.84 1.875 1.875v8.75c0 1.036-.84 1.875-1.875 1.875H6.422l-2.976 1.786A.625.625 0 0 1 2.5 17.5V5.625c0-1.036.84-1.875 1.875-1.875zM4.375 5a.625.625 0 0 0-.625.625v10.772l2.179-1.308.074-.039A.6.6 0 0 1 6.25 15h9.375c.345 0 .625-.28.625-.625v-8.75A.625.625 0 0 0 15.625 5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CommentMediumIcon.displayName = "CommentMediumIcon";
export { CommentMediumIcon };
