import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CautionFill_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M6.178 1.909c.566-1.055 2.079-1.055 2.645 0l5.83 10.883A1.5 1.5 0 0 1 13.33 15H1.67a1.5 1.5 0 0 1-1.322-2.208zm1.322 9.09A.5.5 0 1 0 7.5 12a.5.5 0 0 0 0-1M7 6v4h1V6z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CautionFill_1xIcon.displayName = "CautionFill_1xIcon";
export { CautionFill_1xIcon };
