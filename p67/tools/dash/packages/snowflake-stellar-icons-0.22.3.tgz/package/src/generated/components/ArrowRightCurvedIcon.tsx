import { forwardRef, ForwardedRef } from "react";

import { ArrowRightCurvedMediumIcon } from "./ArrowRightCurvedMediumIcon";
import { ArrowRightCurvedRegularIcon } from "./ArrowRightCurvedRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ArrowRightCurvedIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowRightCurvedIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowRightCurvedIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ArrowRightCurvedRegularIcon />;

    if (size === "medium") {
      icon = <ArrowRightCurvedMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowRightCurvedIcon.displayName = "ArrowRightCurvedIcon";

export type { ArrowRightCurvedIconProps };
export { ArrowRightCurvedIcon };
