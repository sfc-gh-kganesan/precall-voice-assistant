import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DashboardsRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M12.5 2A1.5 1.5 0 0 1 14 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 12.5v-9A1.5 1.5 0 0 1 3.5 2zM3 12.5a.5.5 0 0 0 .5.5h4v-3H3zM8.5 7v6h4a.5.5 0 0 0 .5-.5V7zm-5-4a.5.5 0 0 0-.5.5V9h4.5V3zm5 3H13V3.5a.5.5 0 0 0-.5-.5h-4z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DashboardsRegularIcon.displayName = "DashboardsRegularIcon";
export { DashboardsRegularIcon };
