import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AiReadyRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M4.6 10.01a.5.5 0 0 1 .365.308 6.6 6.6 0 0 1 3.117-.228l1.91.318a1 1 0 0 1 .834.953l.727-.3a2.15 2.15 0 0 1 2.617.793.914.914 0 0 1-.307 1.3l-3 1.714a1 1 0 0 1-.496.132H2.5a.5.5 0 0 1-.49-.4L2 14.5v-4a.5.5 0 0 1 .5-.5h2zM3 14h1v-3H3zm3.993-3c-.604 0-1.204.097-1.777.288L5 11.359V14h5.367l2.915-1.666a1.15 1.15 0 0 0-1.345-.35l-1.86.773c-.239.155-.52.244-.817.244H7v-1h2.26a.5.5 0 0 0 .185-.038l-.008-.023.148-.062a.5.5 0 0 0 .145-.21l.098-.273-1.91-.318A5.6 5.6 0 0 0 6.993 11"
                clipRule="evenodd"
              />
              <path d="M13.001 8h1v1h-1v1h-1V9h-1V8h1V7h1z" />
              <path
                fillRule="evenodd"
                d="M7.447 1.619a.593.593 0 0 1 1.107 0 4.73 4.73 0 0 0 2.582 2.673l.241.094.078.028a.598.598 0 0 1 0 1.126l-.249.097a4.8 4.8 0 0 0-2.642 2.79c-.178.494-.846.525-1.085.091l-.042-.091A4.8 4.8 0 0 0 4.546 5.54l-.092-.043a.598.598 0 0 1 .092-1.083l.078-.028a4.73 4.73 0 0 0 2.725-2.529zm.554 1.158a5.73 5.73 0 0 1-2.269 2.205 5.8 5.8 0 0 1 2.269 2.27 5.8 5.8 0 0 1 2.268-2.27A5.73 5.73 0 0 1 8 2.777"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AiReadyRegularIcon.displayName = "AiReadyRegularIcon";
export { AiReadyRegularIcon };
