import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowSlideLeftMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M5.625 10c0 .166.066.325.183.442l5.625 5.625.884-.884-4.558-4.558H17.5v-1.25H7.759l4.558-4.558-.884-.884-5.625 5.625a.63.63 0 0 0-.183.442M3.75 17.5v-15H2.5v15z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowSlideLeftMediumIcon.displayName = "ArrowSlideLeftMediumIcon";
export { ArrowSlideLeftMediumIcon };
