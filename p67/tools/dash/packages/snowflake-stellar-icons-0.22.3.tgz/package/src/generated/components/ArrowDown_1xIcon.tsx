import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowDown_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.5 14a.5.5 0 0 0 .354-.146l5-5-.707-.708L8 12.293V2H7v10.293L2.854 8.146l-.708.708 5 5A.5.5 0 0 0 7.5 14"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowDown_1xIcon.displayName = "ArrowDown_1xIcon";
export { ArrowDown_1xIcon };
