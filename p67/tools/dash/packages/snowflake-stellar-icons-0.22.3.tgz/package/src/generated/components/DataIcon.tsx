import { forwardRef, ForwardedRef } from "react";

import { DataMediumIcon } from "./DataMediumIcon";
import { DataRegularIcon } from "./DataRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DataIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DataIcon = forwardRef(
  (
    { size = "regular", ...props }: DataIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DataRegularIcon />;

    if (size === "medium") {
      icon = <DataMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DataIcon.displayName = "DataIcon";

export type { DataIconProps };
export { DataIcon };
