import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronLeftSmallRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m9.146 11.354-3-3a.5.5 0 0 1 0-.708l3-3 .708.708L7.207 8l2.647 2.646z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronLeftSmallRegularIcon.displayName = "ChevronLeftSmallRegularIcon";
export { ChevronLeftSmallRegularIcon };
