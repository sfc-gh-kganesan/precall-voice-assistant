import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowUpMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M10 2.5c.166 0 .325.066.442.183l6.25 6.25-.884.884-5.183-5.183V17.5h-1.25V4.634L4.192 9.817l-.884-.884 6.25-6.25A.63.63 0 0 1 10 2.5"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowUpMediumIcon.displayName = "ArrowUpMediumIcon";
export { ArrowUpMediumIcon };
