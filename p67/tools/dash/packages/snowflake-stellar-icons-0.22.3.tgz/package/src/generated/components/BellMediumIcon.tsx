import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BellMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8.75 16.25c0 .133.062.268.286.4.236.138.589.225.964.225.376 0 .728-.087.964-.226.224-.131.286-.266.286-.399h1.25c0 .7-.417 1.19-.902 1.476-.473.278-1.058.399-1.598.399s-1.125-.121-1.598-.4c-.485-.284-.902-.775-.902-1.475z" />
              <path
                fillRule="evenodd"
                d="M10.09 2.5a5.983 5.983 0 0 1 5.982 5.983v1.384c0 .173.07.34.198.458l.892.832c.33.307.516.738.516 1.188v2.03c0 .345-.28.625-.625.625H3.125a.625.625 0 0 1-.625-.625v-1.796c0-.626.313-1.212.835-1.56l.494-.328a.63.63 0 0 0 .279-.52V8.483A5.98 5.98 0 0 1 10.089 2.5m0 1.25a4.73 4.73 0 0 0-4.732 4.733v1.688c0 .627-.314 1.212-.835 1.56l-.495.328a.63.63 0 0 0-.278.52v1.171h12.678v-1.405a.38.38 0 0 0-.118-.274l-.892-.833a1.88 1.88 0 0 1-.596-1.371V8.483a4.733 4.733 0 0 0-4.733-4.733"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BellMediumIcon.displayName = "BellMediumIcon";
export { BellMediumIcon };
