import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DocAiModelBuildRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M13.143 8c.946 0 1.714.727 1.714 1.622l-.002.019c.65.102 1.145.635 1.145 1.278v2.162h-.006q.005.054.006.109c0 .644-.497 1.176-1.148 1.277-.048.854-.794 1.533-1.71 1.533A1.76 1.76 0 0 1 12 15.584a1.76 1.76 0 0 1-1.143.416c-.915 0-1.662-.679-1.71-1.533C8.496 14.365 8 13.833 8 13.19q0-.055.006-.109H8V10.92c0-.643.495-1.176 1.144-1.278l-.001-.019C9.143 8.727 9.91 8 10.857 8c.44 0 .84.158 1.143.415A1.76 1.76 0 0 1 13.143 8m-2.286 1c-.445 0-.711.327-.714.617v.012a1 1 0 0 1-.843.999c-.187.03-.277.152-.296.25l-.004.04v.588h1.286v1H9v.48q.01.09.002.182L9 13.194l.004.035c.02.098.109.22.297.25a1 1 0 0 1 .844.931c.016.281.282.59.712.59.196 0 .368-.07.495-.179a1 1 0 0 1 .148-.103V9.28a1 1 0 0 1-.146-.102.75.75 0 0 0-.354-.165zm2.286 0c-.197 0-.37.07-.497.178a1 1 0 0 1-.146.102v5.438q.077.045.146.103c.128.109.3.179.497.179.429 0 .695-.308.711-.59l.01-.088a1 1 0 0 1 .835-.843c.188-.03.278-.152.297-.25l.004-.035-.002-.026a1 1 0 0 1 .002-.183v-.48h-1.28v-1H15v-.586c0-.102-.087-.256-.3-.29a1 1 0 0 1-.844-1V9.61c-.007-.289-.271-.611-.713-.611"
                clipRule="evenodd"
              />
              <path d="M11.5 1A1.5 1.5 0 0 1 13 2.5V6h-1V2.5a.5.5 0 0 0-.5-.5h-7a.5.5 0 0 0-.5.5v11a.5.5 0 0 0 .5.5H7v1H4.5A1.5 1.5 0 0 1 3 13.5v-11A1.5 1.5 0 0 1 4.5 1z" />
              <path d="M8 8H5V7h3zm3-2H5V5h6z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
DocAiModelBuildRegularIcon.displayName = "DocAiModelBuildRegularIcon";
export { DocAiModelBuildRegularIcon };
