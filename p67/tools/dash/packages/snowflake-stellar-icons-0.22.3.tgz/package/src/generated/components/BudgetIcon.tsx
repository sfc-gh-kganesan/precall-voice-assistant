import { forwardRef, ForwardedRef } from "react";

import { BudgetMediumIcon } from "./BudgetMediumIcon";
import { BudgetRegularIcon } from "./BudgetRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BudgetIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BudgetIcon = forwardRef(
  (
    { size = "regular", ...props }: BudgetIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BudgetRegularIcon />;

    if (size === "medium") {
      icon = <BudgetMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BudgetIcon.displayName = "BudgetIcon";

export type { BudgetIconProps };
export { BudgetIcon };
