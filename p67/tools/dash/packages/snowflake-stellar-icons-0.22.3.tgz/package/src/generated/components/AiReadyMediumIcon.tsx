import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AiReadyMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M5.75 12.512c.21.043.38.19.456.386a8.3 8.3 0 0 1 3.896-.286l2.388.398a1.25 1.25 0 0 1 1.043 1.192l.908-.376a2.69 2.69 0 0 1 3.271.992c.367.55.191 1.297-.383 1.625l-3.75 2.142a1.25 1.25 0 0 1-.62.165H3.125a.626.626 0 0 1-.613-.5l-.012-.125v-5c0-.345.28-.625.625-.625h2.5zm-2 4.988H5v-3.75H3.75zm4.991-3.75c-.755 0-1.505.121-2.221.36l-.27.09v3.3h6.709l3.644-2.084a1.44 1.44 0 0 0-1.682-.437l-2.326.966a1.87 1.87 0 0 1-1.02.305H8.75V15h2.825q.122-.002.232-.048l-.011-.028.185-.078a.6.6 0 0 0 .182-.261l.122-.342-2.388-.398a7 7 0 0 0-1.156-.095"
                clipRule="evenodd"
              />
              <path d="M16.251 10h1.25v1.25h-1.25v1.25h-1.25v-1.25h-1.25V10h1.25V8.75h1.25z" />
              <path
                fillRule="evenodd"
                d="M9.31 2.024c.241-.633 1.14-.634 1.382 0a5.9 5.9 0 0 0 3.228 3.34l.301.118.098.036c.66.237.66 1.17 0 1.407l-.311.12a6 6 0 0 0-3.302 3.488c-.223.618-1.059.657-1.358.115l-.052-.115a5.99 5.99 0 0 0-3.614-3.608l-.114-.054c-.542-.298-.504-1.13.114-1.353l.098-.036a5.92 5.92 0 0 0 3.406-3.16zM10 3.472a7.16 7.16 0 0 1-2.835 2.756A7.24 7.24 0 0 1 10 9.066a7.24 7.24 0 0 1 2.835-2.838A7.16 7.16 0 0 1 10 3.472"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AiReadyMediumIcon.displayName = "AiReadyMediumIcon";
export { AiReadyMediumIcon };
