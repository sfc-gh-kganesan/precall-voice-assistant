import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CheckCircleAutoMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M10 1.25a8.75 8.75 0 1 1-8.66 7.5h1.266A7.5 7.5 0 1 0 8.75 2.605V1.34A9 9 0 0 1 10 1.25" />
              <path d="m14.84 7.294-5.625 6.25a.627.627 0 0 1-.907.023l-3.125-3.125.884-.884 2.657 2.658 5.186-5.76zM3.844 1.807a.453.453 0 0 1 .847 0 3.63 3.63 0 0 0 2.166 2.12l.06.022a.458.458 0 0 1 0 .863A3.68 3.68 0 0 0 4.7 7.026a.46.46 0 0 1-.865 0A3.68 3.68 0 0 0 1.62 4.812a.458.458 0 0 1 0-.863l.06-.022a3.63 3.63 0 0 0 2.165-2.12" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CheckCircleAutoMediumIcon.displayName = "CheckCircleAutoMediumIcon";
export { CheckCircleAutoMediumIcon };
