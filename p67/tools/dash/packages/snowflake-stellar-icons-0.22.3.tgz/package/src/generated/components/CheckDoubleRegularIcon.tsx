import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CheckDoubleRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m10.854 4.854-6 6a.5.5 0 0 1-.708 0l-2.5-2.5.708-.708L4.5 9.793l5.647-5.647zm4 0-6 6a.5.5 0 0 1-.708 0l-1-1 .708-.708.646.647 5.647-5.647z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CheckDoubleRegularIcon.displayName = "CheckDoubleRegularIcon";
export { CheckDoubleRegularIcon };
