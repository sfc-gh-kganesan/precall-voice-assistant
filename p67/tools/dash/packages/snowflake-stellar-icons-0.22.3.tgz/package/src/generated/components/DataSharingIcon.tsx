import { forwardRef, ForwardedRef } from "react";

import { DataSharingMediumIcon } from "./DataSharingMediumIcon";
import { DataSharingRegularIcon } from "./DataSharingRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DataSharingIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DataSharingIcon = forwardRef(
  (
    { size = "regular", ...props }: DataSharingIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DataSharingRegularIcon />;

    if (size === "medium") {
      icon = <DataSharingMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DataSharingIcon.displayName = "DataSharingIcon";

export type { DataSharingIconProps };
export { DataSharingIcon };
