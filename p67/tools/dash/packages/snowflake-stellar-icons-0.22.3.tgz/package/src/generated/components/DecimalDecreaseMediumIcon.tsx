import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DecimalDecreaseMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="m11.067 13.572-1.433 1.433h6.616v1.25H9.634l1.433 1.433-.884.884-2.5-2.5a.627.627 0 0 1 0-.884l2.5-2.5zM5 8.75a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5" />
              <path
                fillRule="evenodd"
                d="M10.625 2.5c1.726 0 3.125 1.4 3.125 3.125v2.5l-.016.32a3.126 3.126 0 0 1-6.218 0l-.016-.32v-2.5C7.5 3.899 8.9 2.5 10.625 2.5m0 1.25c-1.036 0-1.875.84-1.875 1.875v2.5a1.875 1.875 0 0 0 3.75 0v-2.5c0-1.036-.84-1.875-1.875-1.875"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
DecimalDecreaseMediumIcon.displayName = "DecimalDecreaseMediumIcon";
export { DecimalDecreaseMediumIcon };
