import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowUpCurvedMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M9.375 2.5c.166 0 .325.066.442.183l5 5-.884.884L10 4.634v10.991c0 .345.28.625.625.625H17.5v1.25h-6.875a1.875 1.875 0 0 1-1.875-1.875V4.634L4.817 8.567l-.884-.884 5-5a.63.63 0 0 1 .442-.183"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowUpCurvedMediumIcon.displayName = "ArrowUpCurvedMediumIcon";
export { ArrowUpCurvedMediumIcon };
