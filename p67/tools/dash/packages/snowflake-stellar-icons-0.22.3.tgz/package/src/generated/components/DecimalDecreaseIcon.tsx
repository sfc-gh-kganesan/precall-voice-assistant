import { forwardRef, ForwardedRef } from "react";

import { DecimalDecreaseMediumIcon } from "./DecimalDecreaseMediumIcon";
import { DecimalDecreaseRegularIcon } from "./DecimalDecreaseRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DecimalDecreaseIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DecimalDecreaseIcon = forwardRef(
  (
    { size = "regular", ...props }: DecimalDecreaseIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DecimalDecreaseRegularIcon />;

    if (size === "medium") {
      icon = <DecimalDecreaseMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DecimalDecreaseIcon.displayName = "DecimalDecreaseIcon";

export type { DecimalDecreaseIconProps };
export { DecimalDecreaseIcon };
