import { forwardRef, ForwardedRef } from "react";

import { ColumnSlashMediumIcon } from "./ColumnSlashMediumIcon";
import { ColumnSlashRegularIcon } from "./ColumnSlashRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ColumnSlashIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ColumnSlashIcon = forwardRef(
  (
    { size = "regular", ...props }: ColumnSlashIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ColumnSlashRegularIcon />;

    if (size === "medium") {
      icon = <ColumnSlashMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ColumnSlashIcon.displayName = "ColumnSlashIcon";

export type { ColumnSlashIconProps };
export { ColumnSlashIcon };
