import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const DataCleanRoomPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M12.377 21.697a2 2 0 0 1-1.501.66h-.054a5.822 5.822 0 1 0 0 11.643H14v-2c0-2.713 1.982-5.005 4.703-5.747v-2.071c0-2.862 2.768-5.182 6.182-5.182s6.182 2.32 6.182 5.182v2.07c2.722.742 4.706 3.034 4.706 5.748v1.87a8.43 8.43 0 0 0-2.021-16.711 2 2 0 0 1-2.012-1.334 9.74 9.74 0 0 0-9.185-6.505c-5.376 0-9.733 4.357-9.733 9.732q0 .552.06 1.085a2 2 0 0 1-.505 1.56m23.396 14.198c5.056-.721 8.943-5.069 8.943-10.324 0-5.76-4.669-10.43-10.429-10.43q-.333 0-.66.021C32.022 10.594 27.67 7.32 22.554 7.32c-6.245 0-11.352 4.88-11.712 11.036a12 12 0 0 0 .051 2h-.071A7.825 7.825 0 0 0 3 28.178 7.82 7.82 0 0 0 10.822 36H14v1.682c0 3.313 2.958 6 6.607 6h8.559c3.649 0 6.607-2.687 6.607-6zM28.68 26v-1.818c0-1.758-1.7-3.182-3.796-3.182s-3.796 1.424-3.796 3.182V26zm-12.479 6c0-2.21 1.972-4 4.405-4h8.559c2.432 0 4.404 1.79 4.404 4v5.682c0 2.209-1.972 4-4.404 4h-8.56c-2.432 0-4.404-1.791-4.404-4zm8.59 2.831A1.998 1.998 0 0 0 23.998 31a1.998 1.998 0 0 0-.76 3.844l-.83 2.878a1 1 0 0 0 .96 1.277h1.302a1 1 0 0 0 .96-1.28z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataCleanRoomPictogram.displayName = "DataCleanRoomPictogram";
export { DataCleanRoomPictogram };
