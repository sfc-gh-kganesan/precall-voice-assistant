import { forwardRef, ForwardedRef } from "react";

import { ApplicationDatabaseMediumIcon } from "./ApplicationDatabaseMediumIcon";
import { ApplicationDatabaseRegularIcon } from "./ApplicationDatabaseRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ApplicationDatabaseIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ApplicationDatabaseIcon = forwardRef(
  (
    { size = "regular", ...props }: ApplicationDatabaseIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ApplicationDatabaseRegularIcon />;

    if (size === "medium") {
      icon = <ApplicationDatabaseMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ApplicationDatabaseIcon.displayName = "ApplicationDatabaseIcon";

export type { ApplicationDatabaseIconProps };
export { ApplicationDatabaseIcon };
