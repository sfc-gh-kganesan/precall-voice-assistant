import { forwardRef, ForwardedRef } from "react";

import { AiMediumIcon } from "./AiMediumIcon";
import { AiRegularIcon } from "./AiRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AiIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AiIcon = forwardRef(
  (
    { size = "regular", ...props }: AiIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AiRegularIcon />;

    if (size === "medium") {
      icon = <AiMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AiIcon.displayName = "AiIcon";

export type { AiIconProps };
export { AiIcon };
