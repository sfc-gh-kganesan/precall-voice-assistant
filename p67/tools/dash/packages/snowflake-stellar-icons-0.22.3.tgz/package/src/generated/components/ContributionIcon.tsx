import { forwardRef, ForwardedRef } from "react";

import { ContributionMediumIcon } from "./ContributionMediumIcon";
import { ContributionRegularIcon } from "./ContributionRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ContributionIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ContributionIcon = forwardRef(
  (
    { size = "regular", ...props }: ContributionIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ContributionRegularIcon />;

    if (size === "medium") {
      icon = <ContributionMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ContributionIcon.displayName = "ContributionIcon";

export type { ContributionIconProps };
export { ContributionIcon };
