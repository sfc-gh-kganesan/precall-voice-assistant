import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const BooleanPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path fill={iconColor} d="M26.007 33V15h-2v18z" />
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M16.879 17.524c-2.286 0-4.129 1.907-4.129 4.247v5.262c0 2.34 1.843 4.248 4.129 4.248s4.128-1.907 4.128-4.248v-5.262c0-2.34-1.843-4.247-4.128-4.247m2.157 4.247v5.262c0 1.237-.971 2.229-2.157 2.229s-2.157-.992-2.157-2.229v-5.262c0-1.236.971-2.228 2.157-2.228s2.157.992 2.157 2.228"
              clipRule="evenodd"
            />
            <path
              fill={iconColor}
              d="M33.336 17.524h-1.971v1.35c0 .274-.052.466-.121.604a.84.84 0 0 1-.258.305c-.233.172-.541.24-.731.24h-1.248v2.018h1.248c.31 0 .705-.055 1.11-.205v6.617h-2.358v2.018h6.686v-2.018h-2.357z"
            />
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M6 14a8 8 0 0 1 8-8h20a8 8 0 0 1 8 8v20a8 8 0 0 1-8 8H14a8 8 0 0 1-8-8zm8-6h20a6 6 0 0 1 6 6v20a6 6 0 0 1-6 6H14a6 6 0 0 1-6-6V14a6 6 0 0 1 6-6"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BooleanPictogram.displayName = "BooleanPictogram";
export { BooleanPictogram };
