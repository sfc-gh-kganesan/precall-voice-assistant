import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ColumnMultipleRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M11 3.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9l-.01.1a.5.5 0 0 1-.49.4h-3l-.098-.01A.5.5 0 0 1 11 12.5zm3 8.5V4h-2v8zM6 3.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9l-.01.1a.5.5 0 0 1-.49.4h-3l-.098-.01A.5.5 0 0 1 6 12.5zM9 12V4H7v8zM1 3.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9l-.01.1a.5.5 0 0 1-.49.4h-3l-.098-.01A.5.5 0 0 1 1 12.5zM4 12V4H2v8z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ColumnMultipleRegularIcon.displayName = "ColumnMultipleRegularIcon";
export { ColumnMultipleRegularIcon };
