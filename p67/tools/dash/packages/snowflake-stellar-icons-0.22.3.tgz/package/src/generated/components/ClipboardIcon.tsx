import { forwardRef, ForwardedRef } from "react";

import { ClipboardMediumIcon } from "./ClipboardMediumIcon";
import { ClipboardRegularIcon } from "./ClipboardRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ClipboardIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ClipboardIcon = forwardRef(
  (
    { size = "regular", ...props }: ClipboardIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ClipboardRegularIcon />;

    if (size === "medium") {
      icon = <ClipboardMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ClipboardIcon.displayName = "ClipboardIcon";

export type { ClipboardIconProps };
export { ClipboardIcon };
