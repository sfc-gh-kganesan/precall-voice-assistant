import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M13 2a2 2 0 1 1-.396 3.96l-1.211 2.606a2 2 0 1 1-3.114.419L7.013 7.721a2 2 0 0 1-1.433.233l-1.27 2.54c.423.366.69.903.69 1.506a2 2 0 1 1-1.582-1.956l1.269-2.538A2 2 0 1 1 8 6c0 .37-.104.716-.28 1.014l1.265 1.264a2 2 0 0 1 1.536-.208l1.184-2.548A2 2 0 0 1 13 2M3 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2m7-2a1 1 0 1 0 0 2 1 1 0 0 0 0-2M6 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2m7-2a1 1 0 1 0 0 2 1 1 0 0 0 0-2"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartRegularIcon.displayName = "ChartRegularIcon";
export { ChartRegularIcon };
