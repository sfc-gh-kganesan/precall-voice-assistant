import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrayMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M6.25 3.75h-2.5v12.5h2.5v1.25H3.125a.625.625 0 0 1-.625-.625V3.125c0-.345.28-.625.625-.625H6.25zM16.875 2.5c.345 0 .625.28.625.625v13.75c0 .345-.28.625-.625.625H13.75v-1.25h2.5V3.75h-2.5V2.5z" />
              <path d="M6.25 8.75a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m3.75 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5m3.75 0a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ArrayMediumIcon.displayName = "ArrayMediumIcon";
export { ArrayMediumIcon };
