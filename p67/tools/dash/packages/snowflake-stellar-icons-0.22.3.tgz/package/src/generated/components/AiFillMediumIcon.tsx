import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AiFillMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M14.183 11.282a.614.614 0 0 1 1.148 0 4.9 4.9 0 0 0 2.927 2.868l.08.028a.62.62 0 0 1 0 1.169 4.97 4.97 0 0 0-2.996 2.993.622.622 0 0 1-1.17 0 4.97 4.97 0 0 0-2.997-2.993.62.62 0 0 1 0-1.169l.081-.028a4.9 4.9 0 0 0 2.927-2.868m-7.44-9.368c.322-.885 1.575-.885 1.897 0a8.07 8.07 0 0 0 4.83 4.822c.885.322.885 1.573 0 1.894a8.07 8.07 0 0 0-4.83 4.823c-.322.885-1.575.885-1.897 0A8.07 8.07 0 0 0 1.914 8.63c-.885-.322-.885-1.572 0-1.894a8.07 8.07 0 0 0 4.83-4.822M17.5 3.75h1.25V5H17.5v1.25h-1.25V5H15V3.75h1.25V2.5h1.25z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
AiFillMediumIcon.displayName = "AiFillMediumIcon";
export { AiFillMediumIcon };
