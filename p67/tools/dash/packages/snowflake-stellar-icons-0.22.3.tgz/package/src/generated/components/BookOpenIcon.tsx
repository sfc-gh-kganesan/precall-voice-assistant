import { forwardRef, ForwardedRef } from "react";

import { BookOpenMediumIcon } from "./BookOpenMediumIcon";
import { BookOpenRegularIcon } from "./BookOpenRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BookOpenIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BookOpenIcon = forwardRef(
  (
    { size = "regular", ...props }: BookOpenIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BookOpenRegularIcon />;

    if (size === "medium") {
      icon = <BookOpenMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BookOpenIcon.displayName = "BookOpenIcon";

export type { BookOpenIconProps };
export { BookOpenIcon };
