import { forwardRef, ForwardedRef } from "react";

import { CalendarPlusMediumIcon } from "./CalendarPlusMediumIcon";
import { CalendarPlusRegularIcon } from "./CalendarPlusRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CalendarPlusIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CalendarPlusIcon = forwardRef(
  (
    { size = "regular", ...props }: CalendarPlusIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CalendarPlusRegularIcon />;

    if (size === "medium") {
      icon = <CalendarPlusMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CalendarPlusIcon.displayName = "CalendarPlusIcon";

export type { CalendarPlusIconProps };
export { CalendarPlusIcon };
