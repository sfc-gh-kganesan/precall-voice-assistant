import { forwardRef, ForwardedRef } from "react";

import { ChevronDownMediumIcon } from "./ChevronDownMediumIcon";
import { ChevronDownRegularIcon } from "./ChevronDownRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronDownIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronDownIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronDownIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronDownRegularIcon />;

    if (size === "medium") {
      icon = <ChevronDownMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronDownIcon.displayName = "ChevronDownIcon";

export type { ChevronDownIconProps };
export { ChevronDownIcon };
