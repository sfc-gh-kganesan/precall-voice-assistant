import { forwardRef, ForwardedRef } from "react";

import { CreateMediumIcon } from "./CreateMediumIcon";
import { CreateRegularIcon } from "./CreateRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CreateIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CreateIcon = forwardRef(
  (
    { size = "regular", ...props }: CreateIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CreateRegularIcon />;

    if (size === "medium") {
      icon = <CreateMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CreateIcon.displayName = "CreateIcon";

export type { CreateIconProps };
export { CreateIcon };
