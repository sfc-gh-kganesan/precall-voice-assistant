import { forwardRef, ForwardedRef } from "react";

import { AccountTeamMediumIcon } from "./AccountTeamMediumIcon";
import { AccountTeamRegularIcon } from "./AccountTeamRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AccountTeamIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AccountTeamIcon = forwardRef(
  (
    { size = "regular", ...props }: AccountTeamIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AccountTeamRegularIcon />;

    if (size === "medium") {
      icon = <AccountTeamMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AccountTeamIcon.displayName = "AccountTeamIcon";

export type { AccountTeamIconProps };
export { AccountTeamIcon };
