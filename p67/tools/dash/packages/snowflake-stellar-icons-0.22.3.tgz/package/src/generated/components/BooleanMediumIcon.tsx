import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BooleanMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M14.375 13.125a1.25 1.25 0 1 1 0 2.5h-3.75a1.25 1.25 0 1 1 0-2.5z" />
              <path
                fillRule="evenodd"
                d="M14.375 11.25a3.125 3.125 0 1 1 0 6.25h-8.75a3.125 3.125 0 1 1 0-6.25zm-8.75 1.25a1.875 1.875 0 0 0 0 3.75h8.75a1.875 1.875 0 0 0 0-3.75z"
                clipRule="evenodd"
              />
              <path d="M9.375 4.375a1.25 1.25 0 1 1 0 2.5h-3.75a1.25 1.25 0 1 1 0-2.5z" />
              <path
                fillRule="evenodd"
                d="M14.375 2.5a3.125 3.125 0 1 1 0 6.25h-8.75a3.125 3.125 0 1 1 0-6.25zm-8.75 1.25a1.875 1.875 0 0 0 0 3.75h8.75a1.875 1.875 0 0 0 0-3.75z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BooleanMediumIcon.displayName = "BooleanMediumIcon";
export { BooleanMediumIcon };
