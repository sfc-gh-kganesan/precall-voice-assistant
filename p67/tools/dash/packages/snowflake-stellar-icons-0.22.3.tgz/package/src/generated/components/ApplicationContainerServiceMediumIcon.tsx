import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationContainerServiceMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M16.875 8.75c.345 0 .625.28.625.625v4.375h1.875c.345 0 .625.28.625.625v5c0 .345-.28.625-.625.625H8.125a.625.625 0 0 1-.625-.625v-5c0-.345.28-.625.625-.625H10V9.375c0-.345.28-.625.625-.625zm-8.125 10h4.375V15H8.75zm5.625 0h4.375V15h-4.375zm-3.125-5h5V10h-5z"
                clipRule="evenodd"
              />
              <path d="M9.691 1.644a.63.63 0 0 1 .618 0l6.877 3.907a.63.63 0 0 1 .316.543V7.5h-1.25V6.456L10 2.906l-6.252 3.55v7.086l2.502 1.421v1.438l-3.436-1.95a.63.63 0 0 1-.316-.544V6.094l.006-.083a.63.63 0 0 1 .31-.46z" />
              <path d="M10 6.25c1.11 0 2.103.484 2.79 1.25H10A2.5 2.5 0 0 0 7.5 10c0 .925.504 1.73 1.25 2.162v.338H7.21a3.73 3.73 0 0 1-.96-2.5A3.75 3.75 0 0 1 10 6.25" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationContainerServiceMediumIcon.displayName =
  "ApplicationContainerServiceMediumIcon";
export { ApplicationContainerServiceMediumIcon };
