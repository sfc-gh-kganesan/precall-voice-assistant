import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const ChartFinancialPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10 35.824v5.462h5v-5.462zm-2 5.462c0 1.006.895 1.82 2 1.82h5c1.105 0 2-.814 2-1.82v-5.462c0-1.005-.895-1.82-2-1.82h-5c-1.105 0-2 .815-2 1.82zM21.5 29.452v11.834h5V29.452zm-2 11.834c0 1.006.895 1.82 2 1.82h5c1.105 0 2-.814 2-1.82V29.452c0-1.006-.895-1.821-2-1.821h-5c-1.105 0-2 .815-2 1.82zM33 23.11v18.092h5V23.11zm-2 18.092c0 1.052.895 1.905 2 1.905h5c1.105 0 2-.853 2-1.905V23.11c0-1.052-.895-1.904-2-1.904h-5c-1.105 0-2 .853-2 1.904z"
              clipRule="evenodd"
            />
            <path
              fill={iconColor}
              d="M20 12.675c0-1.725 1.26-3.175 2.965-3.586V8h1.976v1.09c1.705.41 2.965 1.86 2.965 3.585h-1.977c0-1.022-.885-1.851-1.976-1.851-1.092 0-1.977.829-1.977 1.851s.885 1.851 1.977 1.851c2.183 0 3.953 1.658 3.953 3.703 0 1.725-1.26 3.175-2.965 3.585v1.009h-1.976v-1.009C21.26 21.405 20 19.955 20 18.23h1.976c0 1.022.885 1.851 1.977 1.851 1.091 0 1.976-.829 1.976-1.851s-.885-1.851-1.976-1.851C21.77 16.378 20 14.72 20 12.675"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartFinancialPictogram.displayName = "ChartFinancialPictogram";
export { ChartFinancialPictogram };
