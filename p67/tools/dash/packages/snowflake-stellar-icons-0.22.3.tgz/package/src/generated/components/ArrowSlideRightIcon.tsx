import { forwardRef, ForwardedRef } from "react";

import { ArrowSlideRightMediumIcon } from "./ArrowSlideRightMediumIcon";
import { ArrowSlideRightRegularIcon } from "./ArrowSlideRightRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ArrowSlideRightIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowSlideRightIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowSlideRightIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ArrowSlideRightRegularIcon />;

    if (size === "medium") {
      icon = <ArrowSlideRightMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowSlideRightIcon.displayName = "ArrowSlideRightIcon";

export type { ArrowSlideRightIconProps };
export { ArrowSlideRightIcon };
