import { forwardRef, ForwardedRef } from "react";

import { ColumnSingleMediumIcon } from "./ColumnSingleMediumIcon";
import { ColumnSingleRegularIcon } from "./ColumnSingleRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ColumnSingleIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ColumnSingleIcon = forwardRef(
  (
    { size = "regular", ...props }: ColumnSingleIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ColumnSingleRegularIcon />;

    if (size === "medium") {
      icon = <ColumnSingleMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ColumnSingleIcon.displayName = "ColumnSingleIcon";

export type { ColumnSingleIconProps };
export { ColumnSingleIcon };
