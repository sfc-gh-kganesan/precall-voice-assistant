import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AgentRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} fillRule="evenodd" clipRule="evenodd">
              <path d="M7.541 3.377c.16-.42.757-.42.918 0a3.93 3.93 0 0 0 2.142 2.217l.2.078.064.023a.496.496 0 0 1 0 .935l-.206.08a3.97 3.97 0 0 0-2.191 2.314.498.498 0 0 1-.902.078l-.034-.078A3.97 3.97 0 0 0 5.135 6.63l-.078-.034a.497.497 0 0 1 .078-.9l.064-.024A3.93 3.93 0 0 0 7.46 3.575zM8 4.666A4.9 4.9 0 0 1 6.456 6.17c.623.395 1.15.923 1.544 1.547A5 5 0 0 1 9.544 6.17 4.9 4.9 0 0 1 8 4.666" />
              <path d="M8 1a7 7 0 1 1-5.077 11.816l-.014-.014A7 7 0 0 1 8 1m0 10a7.96 7.96 0 0 0-4.259 1.226A5.98 5.98 0 0 0 8 14a5.98 5.98 0 0 0 4.257-1.773A7.96 7.96 0 0 0 8 11m0-9a6 6 0 0 0-4.905 9.454A8.96 8.96 0 0 1 8 10a8.95 8.95 0 0 1 4.903 1.454A6 6 0 0 0 8 2" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AgentRegularIcon.displayName = "AgentRegularIcon";
export { AgentRegularIcon };
