import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CodeCompareRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M9 2h3.5A1.5 1.5 0 0 1 14 3.5v9a1.5 1.5 0 0 1-1.5 1.5H9v1H8V1h1zm0 3h2v1H9v1h2v1H9v5h3.5a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5H9z"
                clipRule="evenodd"
              />
              <path d="M7.007 3H3.5a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h3.507v1H3.5A1.5 1.5 0 0 1 2 12.5v-9A1.5 1.5 0 0 1 3.5 2h3.507z" />
              <path d="M7.007 10H5V9h2.007zm0-2H5V7h2.007zm0-2H5V5h2.007z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CodeCompareRegularIcon.displayName = "CodeCompareRegularIcon";
export { CodeCompareRegularIcon };
