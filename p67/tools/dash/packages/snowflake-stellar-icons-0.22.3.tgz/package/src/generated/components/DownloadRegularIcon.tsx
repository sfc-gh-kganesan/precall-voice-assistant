import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DownloadRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M8 11.5a.5.5 0 0 0 .354-.146l4.5-4.5-.707-.708L8.5 9.793V2h-1v7.793L3.854 6.146l-.708.708 4.5 4.5A.5.5 0 0 0 8 11.5m6 1.5H2v1h12z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DownloadRegularIcon.displayName = "DownloadRegularIcon";
export { DownloadRegularIcon };
