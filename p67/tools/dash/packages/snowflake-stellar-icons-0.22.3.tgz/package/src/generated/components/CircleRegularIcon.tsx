import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CircleRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path fill={iconColor} d="M10 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0" />
          </>
        }
        {...props}
      />
    );
  },
);
CircleRegularIcon.displayName = "CircleRegularIcon";
export { CircleRegularIcon };
