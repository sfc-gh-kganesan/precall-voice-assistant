import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowUpRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M8 2a.5.5 0 0 1 .354.146l5 5-.707.708L8.5 3.707V14h-1V3.707L3.354 7.854l-.708-.708 5-5A.5.5 0 0 1 8 2"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowUpRegularIcon.displayName = "ArrowUpRegularIcon";
export { ArrowUpRegularIcon };
