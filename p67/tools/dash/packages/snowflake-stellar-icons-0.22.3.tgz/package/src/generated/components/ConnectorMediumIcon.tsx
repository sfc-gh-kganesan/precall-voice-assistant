import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ConnectorMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M4.375 3.75a3.126 3.126 0 0 1 3.063 2.5H8.75c1.036 0 1.875.84 1.875 1.875v3.75c0 .345.28.625.625.625h1.312a3.126 3.126 0 1 1 0 1.25H11.25a1.875 1.875 0 0 1-1.875-1.875v-3.75A.625.625 0 0 0 8.75 7.5H7.438a3.126 3.126 0 0 1-6.188-.625c0-1.726 1.4-3.125 3.125-3.125m11.25 7.5a1.875 1.875 0 1 0 0 3.75 1.875 1.875 0 0 0 0-3.75M4.375 5a1.875 1.875 0 1 0 0 3.75 1.875 1.875 0 0 0 0-3.75"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ConnectorMediumIcon.displayName = "ConnectorMediumIcon";
export { ConnectorMediumIcon };
