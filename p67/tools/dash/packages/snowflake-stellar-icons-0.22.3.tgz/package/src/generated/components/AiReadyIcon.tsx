import { forwardRef, ForwardedRef } from "react";

import { AiReadyMediumIcon } from "./AiReadyMediumIcon";
import { AiReadyRegularIcon } from "./AiReadyRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AiReadyIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AiReadyIcon = forwardRef(
  (
    { size = "regular", ...props }: AiReadyIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AiReadyRegularIcon />;

    if (size === "medium") {
      icon = <AiReadyMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AiReadyIcon.displayName = "AiReadyIcon";

export type { AiReadyIconProps };
export { AiReadyIcon };
