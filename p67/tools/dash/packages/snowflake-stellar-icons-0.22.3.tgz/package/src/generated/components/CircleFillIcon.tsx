import { forwardRef, ForwardedRef } from "react";

import { CircleFillMediumIcon } from "./CircleFillMediumIcon";
import { CircleFillRegularIcon } from "./CircleFillRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CircleFillIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CircleFillIcon = forwardRef(
  (
    { size = "regular", ...props }: CircleFillIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CircleFillRegularIcon />;

    if (size === "medium") {
      icon = <CircleFillMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CircleFillIcon.displayName = "CircleFillIcon";

export type { CircleFillIconProps };
export { CircleFillIcon };
