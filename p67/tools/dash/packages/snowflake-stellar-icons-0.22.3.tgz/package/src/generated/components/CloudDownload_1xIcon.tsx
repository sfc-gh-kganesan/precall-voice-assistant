import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudDownload_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m8 12.292 2.146-2.146.707.706-3 3A.5.5 0 0 1 7.5 14a.5.5 0 0 1-.354-.148l-3-3 .708-.707L7 12.293V6.499h1zM7 2a4 4 0 0 1 3.872 3.004Q10.936 5 11 5a4 4 0 0 1 1 7.874v-1.049A2.998 2.998 0 0 0 11 6q-.236 0-.456.033l-.504.077-.067-.506a3 3 0 1 0-5.943.826l.082.577L3.53 7H3.5a2.5 2.5 0 0 0-.5 4.95v1.014a3.5 3.5 0 0 1 .001-6.929L3 6a4 4 0 0 1 4-4"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CloudDownload_1xIcon.displayName = "CloudDownload_1xIcon";
export { CloudDownload_1xIcon };
