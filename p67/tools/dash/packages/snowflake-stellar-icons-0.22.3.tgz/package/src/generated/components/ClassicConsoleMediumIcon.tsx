import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClassicConsoleMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M16.25 17.5H3.75v-1.25h12.5zm-12.5-1.25H2.5V3.75h1.25zm13.75 0h-1.25V3.75h1.25zm-3.75-2.5h-5V12.5h5zM7.5 12.5H6.25v-1.25H7.5zm1.25-1.25H7.5V10h1.25zM10 10H8.75V8.75H10zM8.75 8.75H7.5V7.5h1.25zM7.5 7.5H6.25V6.25H7.5zm8.75-3.75H3.75V2.5h12.5z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClassicConsoleMediumIcon.displayName = "ClassicConsoleMediumIcon";
export { ClassicConsoleMediumIcon };
