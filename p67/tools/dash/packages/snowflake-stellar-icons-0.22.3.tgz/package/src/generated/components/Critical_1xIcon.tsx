import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const Critical_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M10.192 0a1 1 0 0 1 .707.293l3.808 3.808a1 1 0 0 1 .293.707v5.384l-.005.099a1 1 0 0 1-.288.608l-3.808 3.808a1 1 0 0 1-.608.288l-.099.005H4.808l-.099-.005a1 1 0 0 1-.535-.222l-.073-.066-3.808-3.808A1 1 0 0 1 0 10.192V4.808a1 1 0 0 1 .227-.634L.293 4.1 4.101.293a1 1 0 0 1 .608-.288L4.808 0zM1 4.808v5.384L4.808 14h5.384L14 10.192V4.808L10.192 1H4.808zM12 8H3V7h9z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
Critical_1xIcon.displayName = "Critical_1xIcon";
export { Critical_1xIcon };
