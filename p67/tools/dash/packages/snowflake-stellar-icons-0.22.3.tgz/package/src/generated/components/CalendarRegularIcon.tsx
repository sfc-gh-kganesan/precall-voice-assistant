import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CalendarRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M6 3h4V2h1v1h1.5A1.5 1.5 0 0 1 14 4.5v8a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 12.5v-8A1.5 1.5 0 0 1 3.5 3H5V2h1zm-3 9.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7H3zM3.5 4a.5.5 0 0 0-.5.5V6h10V4.5a.5.5 0 0 0-.5-.5H11v1h-1V4H6v1H5V4z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CalendarRegularIcon.displayName = "CalendarRegularIcon";
export { CalendarRegularIcon };
