import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CheckCircleFillRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M8 1a7 7 0 1 1 0 14A7 7 0 0 1 8 1m-1.163 9.254L4.362 7.655l-.724.69 2.857 3a.5.5 0 0 0 .741-.02l5.144-6-.76-.65z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CheckCircleFillRegularIcon.displayName = "CheckCircleFillRegularIcon";
export { CheckCircleFillRegularIcon };
