import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClearMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m16.692 4.208-5.802 5.8 5.792 5.793-.885.884-5.79-5.791-5.792 5.79-.884-.883 5.791-5.791L3.32 4.208l.884-.884 5.802 5.801 5.802-5.8z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClearMediumIcon.displayName = "ClearMediumIcon";
export { ClearMediumIcon };
