import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudSaasRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M13.313 8.813a.875.875 0 1 1 0 1.75.875.875 0 0 1 0-1.75" />
              <path
                fillRule="evenodd"
                d="M15.5 7a.5.5 0 0 1 .5.5v4.243a.5.5 0 0 1-.151.359l-3.734 3.631a.5.5 0 0 1-.702-.005l-4.142-4.141a.5.5 0 0 1 0-.707l3.734-3.734.076-.062A.5.5 0 0 1 11.358 7zm-7.168 4.233 3.438 3.439 3.23-3.14V8h-3.435z"
                clipRule="evenodd"
              />
              <path d="M7.918 3.004a3.97 3.97 0 0 1 3.651 2.965q.192.005.378.031h-1.413A2.97 2.97 0 0 0 8.01 4.013L7.73 4a2.967 2.967 0 0 0-2.966 2.967l.004.163q.004.08.012.158l.064.594-.596-.041a2 2 0 0 0-.15-.008A2.1 2.1 0 0 0 2 9.933l.01.215a2.1 2.1 0 0 0 2.09 1.885H6v1H4.1a3.1 3.1 0 0 1-3.096-2.94L1 9.933a3.1 3.1 0 0 1 2.767-3.082A3.967 3.967 0 0 1 7.73 3z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CloudSaasRegularIcon.displayName = "CloudSaasRegularIcon";
export { CloudSaasRegularIcon };
