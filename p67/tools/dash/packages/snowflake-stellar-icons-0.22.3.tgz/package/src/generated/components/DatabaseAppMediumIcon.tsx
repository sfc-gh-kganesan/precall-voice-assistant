import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabaseAppMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path
                fillRule="evenodd"
                d="M14.375 11.25a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5m0 1.25a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"
                clipRule="evenodd"
              />
              <path
                fillRule="evenodd"
                d="M14.232 7.517a.62.62 0 0 1 .423.049l5 2.5a.63.63 0 0 1 .345.559v6.25a.63.63 0 0 1-.346.56l-5 2.5a.63.63 0 0 1-.559 0l-5-2.5a.63.63 0 0 1-.345-.56v-6.25l.006-.088a.63.63 0 0 1 .34-.471l5-2.5zM10 11.011v5.477l4.375 2.188 4.375-2.188v-5.477l-4.375-2.188z"
                clipRule="evenodd"
              />
              <path d="M10.001 2.5c1.63 0 3.136.328 4.258.889 1.084.541 1.993 1.407 1.993 2.547q.001.108-.01.211.004.051.004.102h-1.312a1 1 0 0 0 .042-.125c-.103-.51-.517-1.049-1.309-1.506-.794-.458-1.884-.78-3.125-.852l-.54-.016c-1.464 0-2.76.344-3.667.868-.792.458-1.207.996-1.31 1.506.09.372.45.812 1.225 1.211v1.371a7 7 0 0 1-.507-.223A5.3 5.3 0 0 1 5 8.033v5.593c0 .56.388 1.18 1.25 1.702v1.413a6 6 0 0 1-.54-.276c-1.112-.643-1.96-1.625-1.96-2.84v-7.25q0-.118.01-.232a2 2 0 0 1-.01-.207c0-1.14.91-2.006 1.993-2.547 1.122-.56 2.629-.889 4.258-.889" />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h20v20H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
DatabaseAppMediumIcon.displayName = "DatabaseAppMediumIcon";
export { DatabaseAppMediumIcon };
