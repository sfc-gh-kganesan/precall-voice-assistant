import { forwardRef, ForwardedRef } from "react";

import { CloudExternalMediumIcon } from "./CloudExternalMediumIcon";
import { CloudExternalRegularIcon } from "./CloudExternalRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CloudExternalIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CloudExternalIcon = forwardRef(
  (
    { size = "regular", ...props }: CloudExternalIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CloudExternalRegularIcon />;

    if (size === "medium") {
      icon = <CloudExternalMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CloudExternalIcon.displayName = "CloudExternalIcon";

export type { CloudExternalIconProps };
export { CloudExternalIcon };
