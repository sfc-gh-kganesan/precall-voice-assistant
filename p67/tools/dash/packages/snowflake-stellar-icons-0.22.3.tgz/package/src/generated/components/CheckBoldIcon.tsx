import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
import { IconProps } from "../../types";
const CheckBoldIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        {...props}
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              d="m13.22 5.193-6.213 6.5a1 1 0 0 1-1.403.038l-3.287-3L3.683 7.27l2.565 2.328 5.531-5.79z"
            />
          </>
        }
      />
    );
  },
);
CheckBoldIcon.displayName = "CheckBoldIcon";
export { CheckBoldIcon };
