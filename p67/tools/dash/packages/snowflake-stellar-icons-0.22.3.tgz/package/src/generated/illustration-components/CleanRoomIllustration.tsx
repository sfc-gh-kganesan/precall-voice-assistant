import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const CleanRoomIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <path
              stroke={`url(#${idPrefix}-svg-2600750475__a)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M41 39.017h2.412c8.836 0 16 7.163 16 16v48.841"
            />
            <path
              stroke={`url(#${idPrefix}-svg-2600750475__b)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M99.648 45.02h-.81c-8.837 0-16 7.163-16 16v39.235"
            />
            <path
              stroke={`url(#${idPrefix}-svg-2600750475__c)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M71 11.5V68"
            />
            <foreignObject width={41.617} height={41.617} x={13} y={13.611}>
              <div
                style={{
                  backdropFilter: "blur(4px)",
                  clipPath: `url(#${idPrefix}-svg-2600750475__d)`,
                  height: "100%",
                  width: "100%",
                }}
              />
            </foreignObject>
            <rect
              width={25.616}
              height={25.616}
              x={46.616}
              y={47.228}
              fill={`url(#${idPrefix}-svg-2600750475__e)`}
              data-figma-bg-blur-radius={8}
              rx={9}
              transform="rotate(-180 46.616 47.228)"
            />
            <path
              fill={`url(#${idPrefix}-svg-2600750475__f)`}
              fillRule="evenodd"
              d="M33.39 33.42a3.28 3.28 0 1 0-.023-6.56 3.28 3.28 0 0 0 .023 6.56m5.676 8.899c.97-.004 1.764-.805 1.498-1.738-.703-2.463-2.885-5.144-7.077-5.129s-6.355 2.71-7.04 5.18c-.26.934.54 1.73 1.51 1.726l5.554-.02z"
              clipRule="evenodd"
            />
            <foreignObject width={41.617} height={41.617} x={49.824} y={-1}>
              <div
                style={{
                  backdropFilter: "blur(4px)",
                  clipPath: `url(#${idPrefix}-svg-2600750475__g)`,
                  height: "100%",
                  width: "100%",
                }}
              />
            </foreignObject>
            <rect
              width={25.616}
              height={25.616}
              x={83.44}
              y={32.617}
              fill={`url(#${idPrefix}-svg-2600750475__h)`}
              data-figma-bg-blur-radius={8}
              rx={9}
              transform="rotate(-180 83.44 32.617)"
            />
            <foreignObject width={41.617} height={41.617} x={88.248} y={19.215}>
              <div
                style={{
                  backdropFilter: "blur(4px)",
                  clipPath: `url(#${idPrefix}-svg-2600750475__i)`,
                  height: "100%",
                  width: "100%",
                }}
              />
            </foreignObject>
            <rect
              width={25.616}
              height={25.616}
              x={121.865}
              y={52.831}
              fill={`url(#${idPrefix}-svg-2600750475__j)`}
              data-figma-bg-blur-radius={8}
              rx={9}
              transform="rotate(-180 121.865 52.831)"
            />
            <path
              fill={`url(#${idPrefix}-svg-2600750475__k)`}
              fillRule="evenodd"
              d="M70.277 18.855a3.28 3.28 0 1 0-.024-6.56 3.28 3.28 0 0 0 .024 6.56m5.676 8.9c.97-.004 1.763-.806 1.497-1.738-.702-2.464-2.884-5.144-7.076-5.13s-6.355 2.711-7.04 5.18c-.26.934.54 1.73 1.51 1.727l5.554-.02z"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-2600750475__l)`}
              fillRule="evenodd"
              d="M108.92 38.69a3.28 3.28 0 1 0-.023-6.56 3.28 3.28 0 0 0 .023 6.56m5.676 8.899c.97-.004 1.764-.805 1.498-1.738-.703-2.463-2.885-5.144-7.077-5.129s-6.355 2.71-7.04 5.18c-.259.934.54 1.73 1.51 1.726l5.555-.02z"
              clipRule="evenodd"
            />
            <rect
              width={55.755}
              height={83.299}
              x={112.299}
              y={59}
              fill={`url(#${idPrefix}-svg-2600750475__m)`}
              rx={10}
              transform="rotate(89.962 112.299 59)"
            />
            <path
              fill={`url(#${idPrefix}-svg-2600750475__n)`}
              fillRule="evenodd"
              d="M63.618 101.821a1 1 0 0 0 1.004.995l6.011-.026a1 1 0 0 0 .996-1.004L71.52 77.1a1 1 0 0 0-1.004-.995l-6.011.026a1 1 0 0 0-.996 1.004zm-11.471.041a1 1 0 0 0 1.004.995l6.011-.026a1 1 0 0 0 .996-1.005l-.086-19.448a1 1 0 0 0-1.004-.996l-6.011.026a1 1 0 0 0-.996 1.005zm23.887.89a1 1 0 0 1-1.004-.996l-.073-16.564a1 1 0 0 1 .995-1.004l6.012-.026a1 1 0 0 1 1.004.995l.073 16.564a1 1 0 0 1-.996 1.004zm-33.918-.158a1 1 0 0 1-1.005-.995l-.031-7.2a1 1 0 0 1 .995-1.005l6.011-.026a1 1 0 0 1 1.005.995l.032 7.2a1 1 0 0 1-.996 1.005zm45.277.093a1 1 0 0 1-1.005-.996l-.032-7.282a1 1 0 0 1 .996-1.004l6.011-.026a1 1 0 0 1 1.005.995l.032 7.282a1 1 0 0 1-.996 1.005z"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-2600750475__o)`}
              d="M94.96 87.305c5.159-1.369 11.004-5.757 14.441-8.745a3.384 3.384 0 0 1 4.406 0c3.438 2.989 9.282 7.376 14.441 8.745 1.601.425 2.97 1.775 2.867 3.429-1.278 20.401-15.354 30.601-19.511 30.601s-18.23-10.2-19.51-30.6c-.104-1.654 1.265-3.005 2.866-3.43"
            />
            <path
              fill={`url(#${idPrefix}-svg-2600750475__p)`}
              d="M113.584 100.189a3.995 3.995 0 0 0-1.587-7.663 3.995 3.995 0 0 0-1.522 7.688l-1.661 5.756a2 2 0 0 0 1.923 2.554l2.603-.001a2 2 0 0 0 1.919-2.557z"
            />
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__a`}
                x1={62.358}
                x2={30.291}
                y1={106.806}
                y2={45.375}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#4F96FD" />
                <stop offset={1} stopColor="#E5F0FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__b`}
                x1={80.148}
                x2={106.36}
                y1={102.766}
                y2={48.943}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#4F96FD" />
                <stop offset={1} stopColor="#E5F0FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__c`}
                x1={73.88}
                x2={50.761}
                y1={70.39}
                y2={17.004}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#4F96FD" />
                <stop offset={1} stopColor="#E5F0FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__e`}
                x1={59.425}
                x2={59.425}
                y1={60.036}
                y2={10.11}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__f`}
                x1={33.521}
                x2={33.576}
                y1={26.763}
                y2={42.242}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#1054FB" />
                <stop offset={1} stopColor="#77AFFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__h`}
                x1={96.248}
                x2={96.248}
                y1={45.425}
                y2={-4.501}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__j`}
                x1={134.673}
                x2={134.673}
                y1={65.64}
                y2={15.714}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__k`}
                x1={70.408}
                x2={70.463}
                y1={12.199}
                y2={27.678}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#1054FB" />
                <stop offset={1} stopColor="#77AFFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__l`}
                x1={109.051}
                x2={109.106}
                y1={32.033}
                y2={47.512}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#1054FB" />
                <stop offset={1} stopColor="#77AFFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__m`}
                x1={120.122}
                x2={183.354}
                y1={83.145}
                y2={79.46}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#EAF2FF" />
                <stop offset={1} stopColor="#76AEFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__n`}
                x1={54.672}
                x2={66.601}
                y1={68.486}
                y2={104.77}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#7AB2FF" stopOpacity={0} />
                <stop offset={0} stopColor="#7AB2FF" stopOpacity={0} />
                <stop offset={1} stopColor="#7AB2FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__o`}
                x1={138}
                x2={83.936}
                y1={118.026}
                y2={91.668}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-2600750475__p`}
                x1={112}
                x2={123.384}
                y1={101.616}
                y2={68.826}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <clipPath
                id={`${idPrefix}-svg-2600750475__d`}
                transform="translate(-13 -13.611)"
              >
                <rect
                  width={25.616}
                  height={25.616}
                  x={46.616}
                  y={47.228}
                  rx={9}
                  transform="rotate(-180 46.616 47.228)"
                />
              </clipPath>
              <clipPath
                id={`${idPrefix}-svg-2600750475__g`}
                transform="translate(-49.824 1)"
              >
                <rect
                  width={25.616}
                  height={25.616}
                  x={83.44}
                  y={32.617}
                  rx={9}
                  transform="rotate(-180 83.44 32.617)"
                />
              </clipPath>
              <clipPath
                id={`${idPrefix}-svg-2600750475__i`}
                transform="translate(-88.248 -19.215)"
              >
                <rect
                  width={25.616}
                  height={25.616}
                  x={121.865}
                  y={52.831}
                  rx={9}
                  transform="rotate(-180 121.865 52.831)"
                />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
CleanRoomIllustration.displayName = "CleanRoomIllustration";
export { CleanRoomIllustration };
