import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationDatabaseMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path
                fillRule="evenodd"
                d="M15 8.75c2.761 0 5 1.4 5 3.125v4.531c0 2.071-2.239 3.75-5 3.75s-5-1.679-5-3.75v-4.531c0-1.726 2.239-3.125 5-3.125m3.75 5.187C17.834 14.587 16.495 15 15 15s-2.834-.414-3.75-1.063v2.47c0 .553.297 1.15.964 1.65.669.502 1.65.85 2.786.85s2.117-.348 2.786-.85c.667-.5.964-1.097.964-1.65zm-4.186-3.924a6 6 0 0 0-.815.105c-.645.126-1.2.343-1.623.607-.346.217-.565.435-.698.634a.95.95 0 0 0-.178.516c0 .276.183.716.877 1.15.676.423 1.69.725 2.873.725s2.197-.302 2.874-.725c.693-.434.876-.874.876-1.15s-.183-.716-.876-1.15C17.197 10.302 16.183 10 15 10q-.222 0-.436.013"
                clipRule="evenodd"
              />
              <path d="M9.691 1.644a.63.63 0 0 1 .618 0l6.877 3.907a.63.63 0 0 1 .316.543v1.41h-.045l-1.205-.002V6.456L10 2.906l-6.252 3.55v7.087l5.002 2.841v1.438l-5.936-3.371a.63.63 0 0 1-.316-.544V6.094l.006-.083a.63.63 0 0 1 .31-.46z" />
              <path d="M10 6.25c1.109 0 2.101.485 2.788 1.25h-.044v.005l-1.378.403A2.5 2.5 0 0 0 7.5 10c0 .925.504 1.73 1.25 2.162v1.37A3.747 3.747 0 0 1 10 6.25" />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h20v20H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationDatabaseMediumIcon.displayName = "ApplicationDatabaseMediumIcon";
export { ApplicationDatabaseMediumIcon };
