import { forwardRef, ForwardedRef } from "react";

import { DecimalIncreaseMediumIcon } from "./DecimalIncreaseMediumIcon";
import { DecimalIncreaseRegularIcon } from "./DecimalIncreaseRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DecimalIncreaseIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DecimalIncreaseIcon = forwardRef(
  (
    { size = "regular", ...props }: DecimalIncreaseIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DecimalIncreaseRegularIcon />;

    if (size === "medium") {
      icon = <DecimalIncreaseMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DecimalIncreaseIcon.displayName = "DecimalIncreaseIcon";

export type { DecimalIncreaseIconProps };
export { DecimalIncreaseIcon };
