import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronDownSmallRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m11.853 6.854-3.447 3a.64.64 0 0 1-.812 0l-3.448-3 .813-.708L8 8.793l3.041-2.647z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronDownSmallRegularIcon.displayName = "ChevronDownSmallRegularIcon";
export { ChevronDownSmallRegularIcon };
