import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudUpload_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.5 6.499c.133 0 .26.055.354.148l3 3-.707.707L8 8.207V14H7V8.207l-2.146 2.146-.708-.707 3-2.999A.5.5 0 0 1 7.5 6.5M7 2a4 4 0 0 1 3.872 3.004Q10.936 5 11 5a4 4 0 0 1 0 8v-1a3 3 0 1 0-.456-5.967l-.504.077-.067-.506a3 3 0 1 0-5.943.826l.082.577L3.53 7H3.5a2.5 2.5 0 0 0 0 5H4v1h-.5a3.5 3.5 0 0 1-.499-6.965L3 6a4 4 0 0 1 4-4"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CloudUpload_1xIcon.displayName = "CloudUpload_1xIcon";
export { CloudUpload_1xIcon };
