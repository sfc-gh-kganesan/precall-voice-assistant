import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ActivityRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M6.013 2a.5.5 0 0 1 .445.3l3.565 10.143 2.028-5.162.035-.061A.5.5 0 0 1 12.5 7H15v1h-2.187l-2.364 5.853a.5.5 0 0 1-.907-.018L5.97 3.678 3.947 8.724A.5.5 0 0 1 3.5 9H1V8h2.191l2.362-5.723.037-.062A.5.5 0 0 1 6.013 2"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ActivityRegularIcon.displayName = "ActivityRegularIcon";
export { ActivityRegularIcon };
