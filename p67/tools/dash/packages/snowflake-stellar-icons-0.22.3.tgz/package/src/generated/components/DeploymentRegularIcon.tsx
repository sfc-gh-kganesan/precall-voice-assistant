import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DeploymentRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} fillRule="evenodd" clipRule="evenodd">
              <path d="M5.095 11.026c.78.781.685 1.693-.096 2.474l-.077.07C4.082 14.264 2 14 2 14l-.032-.359c-.04-.633-.052-1.94.462-2.564l.07-.076c.781-.781 1.815-.756 2.596.025m-.707.707c-.237-.236-.451-.303-.605-.306-.148-.002-.352.055-.577.28-.018.019-.085.11-.147.345a4 4 0 0 0-.103.783c-.003.071-.001.142-.002.21q.103.002.21-.001a4 4 0 0 0 .783-.104c.235-.061.326-.129.345-.147.274-.274.337-.48.343-.586.005-.084-.016-.242-.247-.474m6.615-6.697A1.5 1.5 0 1 1 8.88 7.157a1.5 1.5 0 0 1 2.123-2.121m-.707.707a.5.5 0 1 0-.708.708.5.5 0 0 0 .708-.708" />
              <path d="M14.003 2.99a10 10 0 0 1-1.662 5.522l-.342.517v4.562c0 1.335-1.613 2.005-2.559 1.062l-1.908-1.9-.003.002-4.243-4.243.002-.004-1.943-1.95c-.943-.946-.273-2.559 1.062-2.559H7.15l.273-.19A10 10 0 0 1 13.155 2h.848zm-1 .014a9 9 0 0 0-5.008 1.624l-.621.435a9 9 0 0 0-2.75 3.079l-.102.188.18.181 2.826 2.828.001-.002.198.197a9 9 0 0 0 3.438-3.057l.342-.517a9 9 0 0 0 1.497-4.956M2.408 5a.5.5 0 0 0-.354.853l1.734 1.74a10 10 0 0 1 2.065-2.594zM11 10.3a10 10 0 0 1-2.53 1.975l1.677 1.67a.5.5 0 0 0 .853-.353z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
DeploymentRegularIcon.displayName = "DeploymentRegularIcon";
export { DeploymentRegularIcon };
