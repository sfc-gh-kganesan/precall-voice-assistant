import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowsUpDownRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.143 5.854 4.996 3.707V14h-1V3.707L1.85 5.854l-.707-.708 3-3a.5.5 0 0 1 .707 0l3 3zm4.711 8a.5.5 0 0 1-.707 0l-3-3 .707-.707L11 12.293V2h1v10.293l2.146-2.146.707.707z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowsUpDownRegularIcon.displayName = "ArrowsUpDownRegularIcon";
export { ArrowsUpDownRegularIcon };
