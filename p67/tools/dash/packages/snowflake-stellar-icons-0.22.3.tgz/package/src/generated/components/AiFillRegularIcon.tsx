import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AiFillRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M11.347 9.025a.491.491 0 0 1 .918 0 3.93 3.93 0 0 0 2.341 2.295l.065.023a.496.496 0 0 1 0 .934 3.98 3.98 0 0 0-2.398 2.395.497.497 0 0 1-.935 0 3.97 3.97 0 0 0-2.398-2.395.496.496 0 0 1 0-.934l.065-.023a3.93 3.93 0 0 0 2.342-2.295M5.395 1.531c.257-.707 1.26-.707 1.517 0a6.46 6.46 0 0 0 3.863 3.858c.709.257.709 1.258 0 1.515a6.46 6.46 0 0 0-3.863 3.859c-.258.707-1.26.707-1.517 0A6.46 6.46 0 0 0 1.53 6.904c-.708-.257-.708-1.258 0-1.515A6.46 6.46 0 0 0 5.395 1.53M14 3h1v1h-1v1h-1V4h-1V3h1V2h1z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
AiFillRegularIcon.displayName = "AiFillRegularIcon";
export { AiFillRegularIcon };
