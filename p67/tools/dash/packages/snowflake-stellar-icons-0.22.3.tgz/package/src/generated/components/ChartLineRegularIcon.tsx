import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartLineRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M3 9.293 5.293 7a1 1 0 0 1 1.414 0L8.5 8.793l4.147-4.147.707.708L9.207 9.5a1 1 0 0 1-1.414 0L6 7.707l-3 3V13h10.5v1h-11a.5.5 0 0 1-.5-.5V2h1z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartLineRegularIcon.displayName = "ChartLineRegularIcon";
export { ChartLineRegularIcon };
