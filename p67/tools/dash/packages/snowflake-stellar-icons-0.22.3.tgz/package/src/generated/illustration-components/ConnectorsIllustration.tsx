import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const ConnectorsIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <path
              stroke={`url(#${idPrefix}-svg-305616353__a)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M46 38c0 7.732 6.268 14 14 14h18"
            />
            <path
              stroke={`url(#${idPrefix}-svg-305616353__b)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M19 36v12c0 8.837 7.163 16 16 16h48"
            />
            <rect
              width={51.328}
              height={51.328}
              x={80}
              y={37}
              fill={`url(#${idPrefix}-svg-305616353__c)`}
              rx={8}
            />
            <rect
              width={22}
              height={22}
              x={36}
              y={23}
              fill={`url(#${idPrefix}-svg-305616353__d)`}
              rx={6}
            />
            <path
              stroke={`url(#${idPrefix}-svg-305616353__e)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M46 89c0-7.732 6.268-14 14-14h18"
            />
            <rect
              width={22}
              height={22}
              x={36}
              y={82}
              fill={`url(#${idPrefix}-svg-305616353__f)`}
              rx={6}
            />
            <rect
              width={22}
              height={22}
              x={10}
              y={52}
              fill={`url(#${idPrefix}-svg-305616353__g)`}
              rx={6}
            />
            <g
              fill="#fff"
              fillRule="evenodd"
              clipPath={`url(#${idPrefix}-svg-305616353__h)`}
              clipRule="evenodd"
            >
              <path d="m107.159 63.237-.979.98a.335.335 0 0 1-.474 0l-.98-.98a.336.336 0 0 1 0-.474l.98-.98a.335.335 0 0 1 .474 0l.979.98a.334.334 0 0 1 0 .474m2.049-1.233-2.269-2.27a1.41 1.41 0 0 0-1.993 0l-2.269 2.27a1.41 1.41 0 0 0 0 1.993l2.269 2.269a1.41 1.41 0 0 0 1.993 0l2.269-2.27a1.41 1.41 0 0 0 0-1.992M102.173 47a2.023 2.023 0 0 0-2.023 2.023v4.189l-3.656-2.11a2.023 2.023 0 0 0-2.023 3.503l6.418 3.706a2.023 2.023 0 0 0 3.307-1.563v-7.725A2.023 2.023 0 0 0 102.173 47M100.582 63.768a2 2 0 0 0 .069-.196l.023-.08q.013-.056.024-.113l.014-.08q.009-.055.013-.11l.007-.088q.002-.05.002-.101 0-.05-.002-.1a3 3 0 0 0-.034-.279 2 2 0 0 0-.047-.193 2 2 0 0 0-.161-.39l-.025-.05-.012-.017a2 2 0 0 0-.072-.111l-.039-.059q-.037-.047-.076-.095l-.053-.062q-.035-.038-.071-.073-.036-.037-.073-.071l-.063-.053q-.046-.04-.095-.076l-.058-.04a2 2 0 0 0-.11-.071l-.019-.012-6.69-3.862a2.023 2.023 0 1 0-2.022 3.504L94.667 63l-3.655 2.11a2.023 2.023 0 1 0 2.023 3.504l6.69-3.862.017-.012q.056-.033.11-.071l.06-.04q.048-.037.094-.076.032-.025.063-.053.037-.034.073-.07l.071-.074.052-.062q.04-.047.077-.095l.039-.059q.038-.054.072-.11l.012-.019.025-.049q.029-.052.055-.107zM102.173 67.23c-.488 0-.935.172-1.284.46l-6.418 3.705a2.023 2.023 0 0 0 2.023 3.504l3.656-2.11v4.188a2.023 2.023 0 1 0 4.046 0v-7.724a2.023 2.023 0 0 0-2.023-2.023M117.414 71.395l-6.417-3.705a2.023 2.023 0 0 0-3.307 1.563v7.724a2.023 2.023 0 0 0 4.046 0v-4.189l3.655 2.11a2.024 2.024 0 0 0 2.023-3.503M120.874 65.11 117.219 63l3.655-2.11a2.023 2.023 0 0 0-2.023-3.504l-6.69 3.862-.018.012-.11.071-.059.04q-.049.037-.095.076-.032.026-.063.053-.037.034-.072.07-.037.036-.072.074l-.052.062q-.04.047-.076.095l-.04.059-.072.11-.011.019-.025.049q-.03.052-.055.107-.02.044-.038.087-.019.044-.035.092-.018.052-.034.104-.012.04-.022.08a2 2 0 0 0-.025.113l-.014.08a4 4 0 0 0-.019.199 2 2 0 0 0 .006.289l.013.11.014.08q.01.057.025.112.01.04.022.08.015.053.034.105.016.046.035.092a2 2 0 0 0 .093.194l.025.05.011.017q.034.057.072.111l.04.059q.037.048.076.095.026.03.052.063.035.037.072.072.035.037.072.071.031.027.063.053.046.04.095.076l.059.04q.054.038.11.071l.018.012 6.69 3.862a2.023 2.023 0 0 0 2.023-3.504M118.154 51.842a2.02 2.02 0 0 0-2.763-.74l-3.655 2.11v-4.189a2.023 2.023 0 0 0-4.046 0v7.724a2.023 2.023 0 0 0 3.307 1.563l6.417-3.705a2.02 2.02 0 0 0 .74-2.763" />
            </g>
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-305616353__a`}
                x1={79.454}
                x2={44.849}
                y1={54.24}
                y2={42.516}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.161} stopColor="#86B6FC" />
                <stop offset={1} stopColor="#86B6FC" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-305616353__b`}
                x1={85.909}
                x2={16.699}
                y1={68.48}
                y2={45.032}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.161} stopColor="#86B6FC" />
                <stop offset={1} stopColor="#86B6FC" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-305616353__c`}
                x1={109.273}
                x2={128.059}
                y1={42.934}
                y2={82.669}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-305616353__d`}
                x1={41.545}
                x2={75.373}
                y1={5.505}
                y2={58.265}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.198} stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-305616353__e`}
                x1={79.454}
                x2={44.849}
                y1={72.76}
                y2={84.484}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.161} stopColor="#86B6FC" />
                <stop offset={1} stopColor="#86B6FC" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-305616353__f`}
                x1={41.545}
                x2={75.373}
                y1={64.505}
                y2={117.265}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.198} stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-305616353__g`}
                x1={15.545}
                x2={49.373}
                y1={34.505}
                y2={87.265}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.198} stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <clipPath id={`${idPrefix}-svg-305616353__h`}>
                <path fill="#fff" d="M90 47h32v32H90z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
ConnectorsIllustration.displayName = "ConnectorsIllustration";
export { ConnectorsIllustration };
