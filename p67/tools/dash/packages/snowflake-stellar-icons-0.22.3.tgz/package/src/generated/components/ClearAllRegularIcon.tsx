import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClearAllRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M13.573 4.414a1.5 1.5 0 0 0-2.598-1.5L9.2 5.99a2.5 2.5 0 0 0-2.958 1.12l-.5.866-.01.024-3.637 5.246a.5.5 0 0 0 .41.784l9 .036a.5.5 0 0 0 .5-.5l.002-2.438.297-.517a2.5 2.5 0 0 0-.506-3.122zm-2.566 8.65-1.73-.007.73-1.266-.866-.5-1.016 1.761-1.574-.006 1.224-2.121-.866-.5-1.5 2.598.034.018-1.984-.007 2.87-4.141 4.678 2.7zm1.517-9.832a.5.5 0 0 1 .183.682l-2.25 3.898.431.25.131.083c.616.444.807 1.293.42 1.966l-.144.25-4.312-2.533.125-.218a1.5 1.5 0 0 1 1.913-.619l.136.07.434.25 2.25-3.896a.5.5 0 0 1 .683-.183"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClearAllRegularIcon.displayName = "ClearAllRegularIcon";
export { ClearAllRegularIcon };
