import { forwardRef, ForwardedRef } from "react";

import { ArrowUpCurvedMediumIcon } from "./ArrowUpCurvedMediumIcon";
import { ArrowUpCurvedRegularIcon } from "./ArrowUpCurvedRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ArrowUpCurvedIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowUpCurvedIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowUpCurvedIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ArrowUpCurvedRegularIcon />;

    if (size === "medium") {
      icon = <ArrowUpCurvedMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowUpCurvedIcon.displayName = "ArrowUpCurvedIcon";

export type { ArrowUpCurvedIconProps };
export { ArrowUpCurvedIcon };
