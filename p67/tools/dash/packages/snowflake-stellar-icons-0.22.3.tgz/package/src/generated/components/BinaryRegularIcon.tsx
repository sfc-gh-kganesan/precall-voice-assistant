import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BinaryRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M9 13H8V3h1z" />
              <path
                fillRule="evenodd"
                d="M3.5 4A2.5 2.5 0 0 1 6 6.5v3a2.5 2.5 0 0 1-5 0v-3A2.5 2.5 0 0 1 3.5 4m0 1A1.5 1.5 0 0 0 2 6.5v3a1.5 1.5 0 0 0 3 0v-3A1.5 1.5 0 0 0 3.5 5"
                clipRule="evenodd"
              />
              <path d="M13.5 4a.5.5 0 0 1 .5.5V11h1v1h-3v-1h1V5h-1V4z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BinaryRegularIcon.displayName = "BinaryRegularIcon";
export { BinaryRegularIcon };
