import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CellExpandMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M16.875 11.25a.625.625 0 0 1 .625.626v5l-.012.125a.626.626 0 0 1-.613.5H3.125a.626.626 0 0 1-.625-.626v-5c0-.345.28-.624.625-.624zm-13.125 5h12.5V12.5H3.75zM16.875 2.5a.625.625 0 0 1 .625.625v5l-.012.126a.626.626 0 0 1-.613.5H3.125a.626.626 0 0 1-.625-.626v-5c0-.345.28-.625.625-.625zM3.75 7.5h12.5V3.75H3.75z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CellExpandMediumIcon.displayName = "CellExpandMediumIcon";
export { CellExpandMediumIcon };
