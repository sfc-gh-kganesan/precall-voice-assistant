import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CellCollapseMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M17.5 7.5h-15v1.25h15zm0 3.75h-15v1.25h15z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CellCollapseMediumIcon.displayName = "CellCollapseMediumIcon";
export { CellCollapseMediumIcon };
