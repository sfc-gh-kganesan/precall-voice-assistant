import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowUpCurvedRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.5 2a.5.5 0 0 1 .354.146l4 4-.707.708L8 3.707V12.5a.5.5 0 0 0 .5.5H14v1H8.5A1.5 1.5 0 0 1 7 12.5V3.707L3.854 6.854l-.708-.708 4-4A.5.5 0 0 1 7.5 2"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowUpCurvedRegularIcon.displayName = "ArrowUpCurvedRegularIcon";
export { ArrowUpCurvedRegularIcon };
