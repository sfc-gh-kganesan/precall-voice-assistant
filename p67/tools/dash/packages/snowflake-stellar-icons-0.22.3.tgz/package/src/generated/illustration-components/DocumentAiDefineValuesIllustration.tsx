import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const DocumentAiDefineValuesIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <rect
              width={87.83}
              height={41.226}
              x={115}
              y={113}
              fill={`url(#${idPrefix}-svg-3900236555__a)`}
              rx={10}
              transform="rotate(-180 115 113)"
            />
            <path
              fill={`url(#${idPrefix}-svg-3900236555__b)`}
              d="M100.657 97.01c0-.99-.803-1.793-1.792-1.793H57.638c-.99 0-1.792.802-1.792 1.792v2.858c0 .99.802 1.792 1.792 1.792h41.227c.99 0 1.792-.802 1.792-1.792z"
            />
            <path
              fill={`url(#${idPrefix}-svg-3900236555__c)`}
              d="M85.484 85.217c0-.99-.803-1.793-1.793-1.793H57.638c-.99 0-1.792.803-1.792 1.793v2.858c0 .99.802 1.792 1.792 1.792h26.053c.99 0 1.793-.802 1.793-1.792z"
            />
            <rect
              width={27.783}
              height={26.887}
              x={20}
              y={78.943}
              fill={`url(#${idPrefix}-svg-3900236555__d)`}
              rx={6}
            />
            <path
              fill={`url(#${idPrefix}-svg-3900236555__e)`}
              d="M29.859 85.717a.5.5 0 0 1 .5-.5h7.066a.5.5 0 0 1 .5.5v1.689a.5.5 0 0 1-.5.5h-2.19v8.962h2.19a.5.5 0 0 1 .5.5v1.689a.5.5 0 0 1-.5.5h-7.066a.5.5 0 0 1-.5-.5v-1.69a.5.5 0 0 1 .5-.5h2.188v-8.961H30.36a.5.5 0 0 1-.5-.5z"
            />
            <rect
              width={88}
              height={41.306}
              x={115}
              y={62.721}
              fill={`url(#${idPrefix}-svg-3900236555__f)`}
              rx={10}
              transform="rotate(-180 115 62.72)"
            />
            <path
              fill={`url(#${idPrefix}-svg-3900236555__g)`}
              fillOpacity={0.8}
              d="M61.044 31.292c0-.992-.804-1.796-1.796-1.796h-17.88c-.992 0-1.796.804-1.796 1.796v5.656c0 .992.804 1.796 1.796 1.796h17.88c.992 0 1.796-.804 1.796-1.796z"
            />
            <path
              fill={`url(#${idPrefix}-svg-3900236555__h)`}
              fillOpacity={0.8}
              d="M100.633 29.496c.992 0 1.796.804 1.796 1.796v5.656c0 .992-.804 1.796-1.796 1.796H67.408a1.796 1.796 0 0 1-1.796-1.796v-5.656c0-.992.805-1.796 1.796-1.796z"
            />
            <path
              fill={`url(#${idPrefix}-svg-3900236555__i)`}
              fillOpacity={0.8}
              d="M100.633 43.863c.992 0 1.796.804 1.796 1.796v7.184c0 .992-.804 1.796-1.796 1.796H41.368a1.796 1.796 0 0 1-1.796-1.796v-7.184c0-.992.804-1.796 1.796-1.796z"
            />
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-3900236555__a`}
                x1={193.42}
                x2={148.161}
                y1={-39.807}
                y2={200.382}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#EAF2FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3900236555__b`}
                x1={63.467}
                x2={93.704}
                y1={66.396}
                y2={134.091}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3900236555__c`}
                x1={63.467}
                x2={93.704}
                y1={66.396}
                y2={134.091}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3900236555__d`}
                x1={27.209}
                x2={51.61}
                y1={116.725}
                y2={93.477}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3900236555__e`}
                x1={28.066}
                x2={58.538}
                y1={103.59}
                y2={44.887}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3900236555__f`}
                x1={106.02}
                x2={340.152}
                y1={69.006}
                y2={95.965}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#EAF2FF" />
                <stop offset={1} stopColor="#76AEFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3900236555__g`}
                x1={56.633}
                x2={80.878}
                y1={69.904}
                y2={-3.728}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#91BDFF" />
                <stop offset={1} stopColor="#91BDFF" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3900236555__h`}
                x1={56.633}
                x2={80.878}
                y1={69.904}
                y2={-3.728}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#91BDFF" />
                <stop offset={1} stopColor="#91BDFF" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3900236555__i`}
                x1={56.633}
                x2={80.878}
                y1={69.904}
                y2={-3.728}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#91BDFF" />
                <stop offset={1} stopColor="#91BDFF" stopOpacity={0} />
              </linearGradient>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
DocumentAiDefineValuesIllustration.displayName =
  "DocumentAiDefineValuesIllustration";
export { DocumentAiDefineValuesIllustration };
