import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BudgetRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8.5 4.734c.84.205 1.5.913 1.5 1.816H9c0-.444-.406-.876-1-.876s-1 .432-1 .876.406.876 1 .876c1.063 0 2 .8 2 1.876 0 .906-.67 1.612-1.51 1.816V12h-1v-.882C6.65 10.913 6 10.201 6 9.302h1c0 .448.401.877.99.877.598 0 1.01-.437 1.01-.877 0-.444-.406-.876-1-.876-1.063 0-2-.8-2-1.876 0-.903.66-1.61 1.5-1.816V4h1z" />
              <path
                fillRule="evenodd"
                d="M12.5 2A1.5 1.5 0 0 1 14 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 12.5v-9A1.5 1.5 0 0 1 3.5 2zm-9 1a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BudgetRegularIcon.displayName = "BudgetRegularIcon";
export { BudgetRegularIcon };
