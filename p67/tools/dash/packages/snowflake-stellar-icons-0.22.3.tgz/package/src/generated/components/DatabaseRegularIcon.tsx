import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabaseRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M8.001 2c1.303 0 2.509.263 3.406.71.868.434 1.595 1.126 1.595 2.039q0 .086-.008.169.008.09.008.182v5.822l-.006.134v.011l-.002.011c-.08.923-.767 1.658-1.646 2.143-.782.43-1.783.704-2.874.766L8 14.001c-1.315 0-2.53-.307-3.433-.83C3.678 12.659 3 11.873 3 10.902V5.1q0-.095.008-.186A2 2 0 0 1 3 4.75c0-.912.727-1.605 1.595-2.038C5.492 2.263 6.697 2 8 2m4.001 4.427a4 4 0 0 1-.595.36c-.897.447-2.103.71-3.406.71-1.304 0-2.509-.262-3.406-.71A4 4 0 0 1 4 6.426V10.9c0 .464.33.98 1.068 1.407.726.419 1.762.694 2.933.694l.419-.012c.962-.055 1.813-.296 2.445-.644.732-.404 1.089-.898 1.131-1.348l.006-.118zM8.001 3c-1.17 0-2.207.275-2.933.694-.633.366-.966.798-1.047 1.205.073.305.371.668 1.021.993.731.365 1.777.605 2.959.605s2.228-.24 2.959-.605c.65-.325.946-.688 1.02-.993-.081-.407-.413-.839-1.046-1.205-.635-.366-1.508-.623-2.5-.681z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DatabaseRegularIcon.displayName = "DatabaseRegularIcon";
export { DatabaseRegularIcon };
