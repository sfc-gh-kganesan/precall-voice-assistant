import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CreditCardMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8.75 13.75h-5V12.5h5z" />
              <path
                fillRule="evenodd"
                d="M16.875 3.75c1.035 0 1.875.84 1.875 1.875v8.75c0 1.036-.84 1.875-1.875 1.875H3.125a1.875 1.875 0 0 1-1.875-1.875v-8.75c0-1.036.84-1.875 1.875-1.875zM2.5 8.75v5.625c0 .345.28.625.625.625h13.75c.345 0 .625-.28.625-.625V8.75zM3.125 5a.625.625 0 0 0-.625.625v.625h15v-.625A.625.625 0 0 0 16.875 5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CreditCardMediumIcon.displayName = "CreditCardMediumIcon";
export { CreditCardMediumIcon };
