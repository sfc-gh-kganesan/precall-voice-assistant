import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ConditionMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="m10.441 9.192-3.125 3.125a.626.626 0 0 1-.884 0l-1.875-1.875.884-.884 1.433 1.434 2.683-2.684z" />
              <path
                fillRule="evenodd"
                d="M11.173 4.191a1.876 1.876 0 0 1 2.652 0l4.482 4.482c.732.733.732 1.92 0 2.652l-4.482 4.482a1.876 1.876 0 0 1-2.652 0L10 14.634 8.826 15.81a1.877 1.877 0 0 1-2.653 0l-4.482-4.483a1.876 1.876 0 0 1 0-2.651l4.482-4.483a1.877 1.877 0 0 1 2.653 0l1.173 1.173zm-3.23.885a.627.627 0 0 0-.886 0L2.575 9.558a.627.627 0 0 0 0 .884l4.482 4.483a.63.63 0 0 0 .885 0l4.483-4.483a.626.626 0 0 0 0-.884zm4.998-.001a.627.627 0 0 0-.884 0l-1.174 1.174 2.426 2.426a1.876 1.876 0 0 1 0 2.651l-2.425 2.424 1.173 1.174c.244.243.64.243.884 0l4.482-4.483a.626.626 0 0 0 0-.884z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ConditionMediumIcon.displayName = "ConditionMediumIcon";
export { ConditionMediumIcon };
