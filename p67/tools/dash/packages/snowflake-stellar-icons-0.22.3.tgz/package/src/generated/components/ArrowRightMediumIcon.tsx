import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowRightMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M17.5 10a.63.63 0 0 1-.183.442l-6.25 6.25-.884-.884 5.183-5.183H2.5v-1.25h12.866l-5.183-5.183.884-.884 6.25 6.25A.63.63 0 0 1 17.5 10"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowRightMediumIcon.displayName = "ArrowRightMediumIcon";
export { ArrowRightMediumIcon };
