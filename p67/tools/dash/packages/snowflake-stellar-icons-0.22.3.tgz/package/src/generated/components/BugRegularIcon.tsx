import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BugRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="m10.411 2.217.432.253-.808 1.379c.338.436.54.982.54 1.577l-.013.262a2.6 2.6 0 0 1-.107.51q.384.268.701.612l1.683-1.346.625.781-1.72 1.374c.271.483.453 1.023.52 1.599h1.747v1h-1.748a4.3 4.3 0 0 1-.519 1.597l1.72 1.375-.625.782-1.683-1.347A4.28 4.28 0 0 1 8 14.011l-.22-.006a4.28 4.28 0 0 1-2.938-1.379l-1.68 1.346-.626-.782 1.718-1.375a4.3 4.3 0 0 1-.517-1.597H1.99v-1h1.748a4.3 4.3 0 0 1 .518-1.598l-1.72-1.375.625-.781L4.843 6.81q.316-.344.7-.614a2.6 2.6 0 0 1-.106-.508l-.013-.262c0-.594.203-1.14.54-1.575L5.158 2.47l.432-.253.432-.252.712 1.219A2.56 2.56 0 0 1 8 2.85l.263.013c.362.037.7.15 1.003.322l.713-1.22zM8 6.425a3.293 3.293 0 0 0-.5 6.548V7.57h1v5.402A3.294 3.294 0 0 0 8 6.425M8 3.85a1.577 1.577 0 0 0-1.55 1.863A4.3 4.3 0 0 1 8 5.425l.22.006c.466.023.911.123 1.326.283.017-.094.03-.19.03-.288 0-.87-.706-1.576-1.576-1.576"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BugRegularIcon.displayName = "BugRegularIcon";
export { BugRegularIcon };
