import { forwardRef, ForwardedRef } from "react";

import { ClearMediumIcon } from "./ClearMediumIcon";
import { ClearRegularIcon } from "./ClearRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ClearIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ClearIcon = forwardRef(
  (
    { size = "regular", ...props }: ClearIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ClearRegularIcon />;

    if (size === "medium") {
      icon = <ClearMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ClearIcon.displayName = "ClearIcon";

export type { ClearIconProps };
export { ClearIcon };
