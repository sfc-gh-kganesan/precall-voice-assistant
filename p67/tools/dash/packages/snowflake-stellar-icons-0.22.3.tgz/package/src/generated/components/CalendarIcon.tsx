import { forwardRef, ForwardedRef } from "react";

import { CalendarMediumIcon } from "./CalendarMediumIcon";
import { CalendarRegularIcon } from "./CalendarRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CalendarIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CalendarIcon = forwardRef(
  (
    { size = "regular", ...props }: CalendarIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CalendarRegularIcon />;

    if (size === "medium") {
      icon = <CalendarMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CalendarIcon.displayName = "CalendarIcon";

export type { CalendarIconProps };
export { CalendarIcon };
