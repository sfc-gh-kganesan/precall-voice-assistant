import { forwardRef, ForwardedRef } from "react";

import { ColumnFilterMediumIcon } from "./ColumnFilterMediumIcon";
import { ColumnFilterRegularIcon } from "./ColumnFilterRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ColumnFilterIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ColumnFilterIcon = forwardRef(
  (
    { size = "regular", ...props }: ColumnFilterIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ColumnFilterRegularIcon />;

    if (size === "medium") {
      icon = <ColumnFilterMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ColumnFilterIcon.displayName = "ColumnFilterIcon";

export type { ColumnFilterIconProps };
export { ColumnFilterIcon };
