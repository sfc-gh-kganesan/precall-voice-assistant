import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatasetMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M14.375 2.5c1.036 0 1.875.84 1.875 1.875v3.49l1.068 1.068a.63.63 0 0 1 .183.442v6.251c0 1.036-.84 1.875-1.875 1.875H10.62a1.875 1.875 0 0 1-1.875-1.875V15h-4.37A1.875 1.875 0 0 1 2.5 13.125v-8.75c0-1.036.84-1.875 1.875-1.875zM10.62 6.25a.625.625 0 0 0-.625.625v8.751c0 .345.28.625.625.625h5.006c.345 0 .625-.28.625-.625V10h-1.876c-.97 0-1.77-.739-1.865-1.685l-.01-.191V6.25zM3.75 7.5v5.625c0 .345.28.625.625.625h4.37V7.5zm10 .625c0 .345.28.625.625.625h.992L13.75 7.133zM4.375 3.75a.625.625 0 0 0-.625.625V6.25h5.104C9.11 5.522 9.804 5 10.62 5h2.505c.166 0 .325.066.442.183L15 6.615v-2.24a.625.625 0 0 0-.625-.625z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DatasetMediumIcon.displayName = "DatasetMediumIcon";
export { DatasetMediumIcon };
