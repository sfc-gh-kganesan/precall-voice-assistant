import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
import { IconProps } from "../../types";
const ChevronDownBoldIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        {...props}
        ref={ref}
        svgContent={
          <>
            <path
              stroke={iconColor}
              strokeLinejoin="round"
              strokeWidth={2}
              d="m3 5.5 5 5 5-5"
            />
          </>
        }
      />
    );
  },
);
ChevronDownBoldIcon.displayName = "ChevronDownBoldIcon";
export { ChevronDownBoldIcon };
