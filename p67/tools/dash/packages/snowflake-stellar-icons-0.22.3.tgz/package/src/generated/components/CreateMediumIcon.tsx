import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CreateMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M10 3.75H4.375a.626.626 0 0 0-.625.625V15.67c0 .345.28.625.625.625h11.25c.345 0 .625-.28.625-.625V10h1.25v5.67c0 1.035-.84 1.875-1.875 1.875H4.375A1.876 1.876 0 0 1 2.5 15.67V4.375C2.5 3.34 3.34 2.5 4.375 2.5H10z" />
              <path
                fillRule="evenodd"
                d="M13.398 3.05a1.875 1.875 0 0 1 2.652 0l.884.883c.731.732.731 1.92 0 2.651l-6.055 6.055a1.9 1.9 0 0 1-.732.453l-3.7 1.233a.627.627 0 0 1-.79-.791L6.89 9.836c.092-.276.247-.527.453-.733zm-5.17 6.937a.6.6 0 0 0-.15.245l-.84 2.51 2.514-.835a.6.6 0 0 0 .244-.152l4.197-4.199-1.767-1.767zm6.938-6.054a.625.625 0 0 0-.884 0l-.973.972 1.768 1.767.973-.971a.626.626 0 0 0 0-.884z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CreateMediumIcon.displayName = "CreateMediumIcon";
export { CreateMediumIcon };
