import { forwardRef, ForwardedRef } from "react";

import { DeleteMediumIcon } from "./DeleteMediumIcon";
import { DeleteRegularIcon } from "./DeleteRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DeleteIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DeleteIcon = forwardRef(
  (
    { size = "regular", ...props }: DeleteIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DeleteRegularIcon />;

    if (size === "medium") {
      icon = <DeleteMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DeleteIcon.displayName = "DeleteIcon";

export type { DeleteIconProps };
export { DeleteIcon };
