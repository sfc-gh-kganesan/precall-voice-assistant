import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowDownRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M8 14a.5.5 0 0 0 .354-.146l5-5-.707-.708L8.5 12.293V2h-1v10.293L3.354 8.146l-.708.708 5 5A.5.5 0 0 0 8 14"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowDownRegularIcon.displayName = "ArrowDownRegularIcon";
export { ArrowDownRegularIcon };
