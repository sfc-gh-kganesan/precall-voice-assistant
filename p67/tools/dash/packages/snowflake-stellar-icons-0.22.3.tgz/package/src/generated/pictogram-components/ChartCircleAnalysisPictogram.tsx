import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const ChartCircleAnalysisPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M5.48 18.268a2 2 0 0 1-.456-1.61A14 14 0 0 1 16.658 5.024 2 2 0 0 1 18.968 7v2.467a2 2 0 0 1-1.61 1.961 7.57 7.57 0 0 0-5.93 5.93 2 2 0 0 1-1.961 1.61H7a2 2 0 0 1-1.52-.7m1.52-1.3q.163-1.034.494-2a12.02 12.02 0 0 1 7.474-7.474q.967-.331 2-.494v2.467a9.57 9.57 0 0 0-7.501 7.5zM23.864 11.466a2 2 0 0 1-1.61-1.961V7.038a2 2 0 0 1 2.31-1.976 14 14 0 0 1 11.633 11.633 2 2 0 0 1-1.976 2.31h-2.466a2 2 0 0 1-1.962-1.61 7.57 7.57 0 0 0-5.93-5.929m.39-4.428q1.033.163 2 .494a12.02 12.02 0 0 1 7.473 7.474q.331.966.494 2h-2.466a9.57 9.57 0 0 0-7.501-7.501zM9.466 21.823a2 2 0 0 1 1.962 1.61 7.57 7.57 0 0 0 5.93 5.93 2 2 0 0 1 1.61 1.96v2.467a2 2 0 0 1-2.31 1.976A14 14 0 0 1 5.024 24.133 2 2 0 0 1 7 21.823zm-1.972 4a12 12 0 0 1-.494-2h2.466a9.57 9.57 0 0 0 7.502 7.5v2.467a12 12 0 0 1-2-.494 12.02 12.02 0 0 1-7.474-7.473M21.725 30.825a9.04 9.04 0 1 1 16.126 5.612l5.513 5.513-1.414 1.414-5.506-5.506a9.04 9.04 0 0 1-14.72-7.033m9.039-7.04a7.04 7.04 0 1 0 0 14.08 7.04 7.04 0 0 0 0-14.08"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartCircleAnalysisPictogram.displayName = "ChartCircleAnalysisPictogram";
export { ChartCircleAnalysisPictogram };
