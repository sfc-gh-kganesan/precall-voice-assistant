import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const ComputePictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              stroke={iconColor}
              strokeLinejoin="round"
              strokeWidth={2}
              d="M28.2 8.512c0-2.483-3.282-3.456-4.681-1.387L13.43 22.1c-1.128 1.667.09 3.896 2.128 3.896l7.621.072v12.467c0 2.483 3.356 3.385 4.756 1.316l9.633-14.961c1.128-1.667-.09-3.896-2.128-3.896h-7.24z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ComputePictogram.displayName = "ComputePictogram";
export { ComputePictogram };
