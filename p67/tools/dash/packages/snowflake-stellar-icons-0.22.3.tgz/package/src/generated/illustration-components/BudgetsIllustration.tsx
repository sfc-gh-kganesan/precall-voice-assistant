import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const BudgetsIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <rect
              width={77}
              height={116}
              x={129}
              y={19}
              fill={`url(#${idPrefix}-svg-3897636455__a)`}
              rx={10}
              transform="rotate(90 129 19)"
            />
            <mask
              id={`${idPrefix}-svg-3897636455__c`}
              width={116}
              height={77}
              x={13}
              y={19}
              maskUnits="userSpaceOnUse"
              style={{
                maskType: "alpha",
              }}
            >
              <rect
                width={77}
                height={116}
                x={129}
                y={19}
                fill={`url(#${idPrefix}-svg-3897636455__b)`}
                rx={10}
                transform="rotate(90 129 19)"
              />
            </mask>
            <g
              filter={`url(#${idPrefix}-svg-3897636455__d)`}
              mask={`url(#${idPrefix}-svg-3897636455__c)`}
            >
              <path
                fill={`url(#${idPrefix}-svg-3897636455__e)`}
                d="M9 114.064a9 9 0 0 1-9-9v-41a9 9 0 0 1 9-9h36a9 9 0 0 1 9 9v41a9 9 0 0 1-9 9z"
              />
            </g>
            <path
              fill={`url(#${idPrefix}-svg-3897636455__f)`}
              fillRule="evenodd"
              d="M27.577 31.476a4.774 4.774 0 0 0 1.192 9.393 2.386 2.386 0 0 1 2.385 2.388 2.386 2.386 0 0 1-2.385 2.387 2.386 2.386 0 0 1-2.384-2.387H24a4.774 4.774 0 0 0 3.577 4.621v2.584h2.384v-2.584a4.774 4.774 0 0 0-1.192-9.393 2.386 2.386 0 0 1-2.384-2.388 2.386 2.386 0 0 1 2.384-2.387 2.386 2.386 0 0 1 2.385 2.387h2.384a4.774 4.774 0 0 0-3.576-4.621V29h-2.385z"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-3897636455__g)`}
              fillRule="evenodd"
              d="M116 42.5a.5.5 0 0 1-.5.5h-71a.5.5 0 0 1 0-1h71a.5.5 0 0 1 .5.5m0 11a.5.5 0 0 1-.5.5h-71a.5.5 0 0 1 0-1h71a.5.5 0 0 1 .5.5m-72 11a.5.5 0 0 0 .5.5h71a.5.5 0 0 0 0-1h-71a.5.5 0 0 0-.5.5"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-3897636455__h)`}
              fillRule="evenodd"
              d="M50 81a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H51a1 1 0 0 1-1-1zm26 0a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H77a1 1 0 0 1-1-1zm27-1a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1z"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-3897636455__i)`}
              d="M9 108a9 9 0 0 1-9-9V64a9 9 0 0 1 9-9h36a9 9 0 0 1 9 9v35a9 9 0 0 1-9 9z"
            />
            <rect
              width={35.99}
              height={5.863}
              fill={`url(#${idPrefix}-svg-3897636455__j)`}
              rx={1}
              transform="translate(9.008 90)skewX(-.02)"
            />
            <rect
              width={19.511}
              height={5.863}
              fill={`url(#${idPrefix}-svg-3897636455__k)`}
              rx={1}
              transform="translate(9.008 90)skewX(-.02)"
            />
            <path
              fill={`url(#${idPrefix}-svg-3897636455__l)`}
              fillRule="evenodd"
              d="M9 70.281a3.281 3.281 0 0 1 6.563 0v.938a3.281 3.281 0 0 1-6.563 0zm3.281-1.406c-.776 0-1.406.63-1.406 1.406v.938a1.406 1.406 0 0 0 2.813 0v-.938c0-.776-.63-1.406-1.407-1.406m5.156 9.844a3.281 3.281 0 0 1 6.563 0v.937a3.281 3.281 0 1 1-6.562 0zm3.282-1.406c-.777 0-1.407.63-1.407 1.406v.937a1.406 1.406 0 1 0 2.813 0v-.937c0-.777-.63-1.406-1.406-1.406m-9.909 5.624L20.298 67h2.182l-9.486 15.938z"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-3897636455__m)`}
              fillRule="evenodd"
              d="M74.132 70.084a1 1 0 0 0 1.004.995L79 71.062a1 1 0 0 0 .996-1.004L79.867 41a1 1 0 0 0-1.004-.996L75 40.021a1 1 0 0 0-.996 1.005zm-11.999.11a1 1 0 0 0 1.004.995L67 71.172a1 1 0 0 0 .996-1.004l-.101-22.964a1 1 0 0 0-1.005-.995l-3.862.017a1 1 0 0 0-.996 1.004zm23.956-.079a1 1 0 0 0 1.005.996l3.862-.017a1 1 0 0 0 .996-1.004l-.086-19.606a1 1 0 0 0-1.004-.995l-3.863.017a1 1 0 0 0-.996 1.004zm12.915.941a1 1 0 0 1-1.005-.995l-.038-8.803a1 1 0 0 1 .995-1.005l3.863-.017a1 1 0 0 1 1.004.996l.039 8.803a1 1 0 0 1-.995 1.004z"
              clipRule="evenodd"
            />
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__a`}
                x1={149.275}
                x2={262.321}
                y1={55.878}
                y2={72.218}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#EAF2FF" />
                <stop offset={1} stopColor="#76AEFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__b`}
                x1={149.275}
                x2={262.321}
                y1={55.878}
                y2={72.218}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#EAF2FF" />
                <stop offset={1} stopColor="#76AEFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__e`}
                x1={30.797}
                x2={53.584}
                y1={61.884}
                y2={105.997}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__f`}
                x1={24}
                x2={36.653}
                y1={29}
                y2={33.413}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#6AA3FF" stopOpacity={0} />
                <stop offset={1} stopColor="#6AA3FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__g`}
                x1={30.5}
                x2={93.547}
                y1={42}
                y2={101.659}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#91BDFF" stopOpacity={0} />
                <stop offset={0.408} stopColor="#91BDFF" />
                <stop offset={1} stopColor="#91BDFF" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__h`}
                x1={116}
                x2={30}
                y1={59.5}
                y2={89.5}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#6AA3FF" stopOpacity={0} />
                <stop offset={1} stopColor="#6AA3FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__i`}
                x1={27}
                x2={52.102}
                y1={50.216}
                y2={101.016}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__j`}
                x1={-44.962}
                x2={58.48}
                y1={34.02}
                y2={47.394}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__k`}
                x1={9.755}
                x2={9.051}
                y1={4.5}
                y2={-0.264}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__l`}
                x1={15.375}
                x2={22.96}
                y1={79.788}
                y2={62.322}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3897636455__m`}
                x1={63.915}
                x2={83.1}
                y1={31.18}
                y2={68.023}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#C2D8FB" />
                <stop offset={0} stopColor="#C0D7FB" />
                <stop offset={1} stopColor="#7AB2FF" />
              </linearGradient>
              <filter
                id={`${idPrefix}-svg-3897636455__d`}
                width={90}
                height={95}
                x={-15}
                y={30.064}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset dx={3} dy={-7} />
                <feGaussianBlur stdDeviation={9} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_277"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_277"
                  result="shape"
                />
              </filter>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
BudgetsIllustration.displayName = "BudgetsIllustration";
export { BudgetsIllustration };
