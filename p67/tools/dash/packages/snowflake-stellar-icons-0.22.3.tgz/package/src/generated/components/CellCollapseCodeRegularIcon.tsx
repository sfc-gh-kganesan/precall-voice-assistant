import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CellCollapseCodeRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M13.5 5a.5.5 0 0 1 .5.5v8l-.01.1a.5.5 0 0 1-.49.4h-11a.5.5 0 0 1-.5-.5v-8a.5.5 0 0 1 .5-.5zM6 13h7V9H6zm-3 0h2V9H3zm3-5h7V6H6zM3 8h2V6H3z"
                clipRule="evenodd"
              />
              <path d="M14 3H2V2h12z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CellCollapseCodeRegularIcon.displayName = "CellCollapseCodeRegularIcon";
export { CellCollapseCodeRegularIcon };
