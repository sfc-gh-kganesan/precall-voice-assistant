import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronLeftMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m12.683 16.692-6.25-6.25a.625.625 0 0 1 0-.884l6.25-6.25.884.884L7.759 10l5.808 5.808z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronLeftMediumIcon.displayName = "ChevronLeftMediumIcon";
export { ChevronLeftMediumIcon };
