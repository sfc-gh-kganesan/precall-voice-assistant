import { forwardRef, ForwardedRef } from "react";

import { ChartMediumIcon } from "./ChartMediumIcon";
import { ChartRegularIcon } from "./ChartRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChartIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChartIcon = forwardRef(
  (
    { size = "regular", ...props }: ChartIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChartRegularIcon />;

    if (size === "medium") {
      icon = <ChartMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChartIcon.displayName = "ChartIcon";

export type { ChartIconProps };
export { ChartIcon };
