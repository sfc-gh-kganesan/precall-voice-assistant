import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const AiModelPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M18.508 9a5.5 5.5 0 1 1 10.223 2.82l7.457 7.457a5.5 5.5 0 1 1 .07 9.488l-7.486 7.486a5.5 5.5 0 1 1-9.538.014L11.74 28.77a5.5 5.5 0 1 1 .07-9.499l7.466-7.465A5.5 5.5 0 0 1 18.508 9m5.5-3.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7m-3.412 7.814-7.278 7.279A5.48 5.48 0 0 1 14.5 24a5.48 5.48 0 0 1-1.232 3.47l7.266 7.266a5.48 5.48 0 0 1 3.474-1.236c1.312 0 2.516.46 3.461 1.226l7.264-7.265A5.48 5.48 0 0 1 33.508 24c0-1.283.44-2.463 1.175-3.399l-7.276-7.277a5.48 5.48 0 0 1-3.4 1.176 5.48 5.48 0 0 1-3.41-1.186M9 20.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7M20.508 39a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0m18.5-18.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
AiModelPictogram.displayName = "AiModelPictogram";
export { AiModelPictogram };
