import { forwardRef, ForwardedRef } from "react";

import { BookOpenAiMediumIcon } from "./BookOpenAiMediumIcon";
import { BookOpenAiRegularIcon } from "./BookOpenAiRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BookOpenAiIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BookOpenAiIcon = forwardRef(
  (
    { size = "regular", ...props }: BookOpenAiIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BookOpenAiRegularIcon />;

    if (size === "medium") {
      icon = <BookOpenAiMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BookOpenAiIcon.displayName = "BookOpenAiIcon";

export type { BookOpenAiIconProps };
export { BookOpenAiIcon };
