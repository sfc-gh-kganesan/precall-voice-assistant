import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CalendarRecurringMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M13.754 11.252a3.76 3.76 0 0 1-3.767 3.755 3.76 3.76 0 0 1-2.518-.963v.579H6.22v-2.167c0-.345.28-.625.625-.625H9.02v1.25h-.751c.45.419 1.053.676 1.718.676a2.51 2.51 0 0 0 2.517-2.505zM9.987 7.498c.967 0 1.85.364 2.517.961v-.578h1.25v2.167c0 .345-.28.625-.625.625h-2.176v-1.25h.751a2.52 2.52 0 0 0-1.717-.675 2.51 2.51 0 0 0-2.518 2.504H6.22a3.76 3.76 0 0 1 3.768-3.754" />
              <path
                fillRule="evenodd"
                d="M7.5 3.75h5V2.5h1.25v1.25h1.875c1.035 0 1.875.84 1.875 1.875v10c0 1.035-.84 1.875-1.875 1.875H4.375A1.875 1.875 0 0 1 2.5 15.625v-10c0-1.036.84-1.875 1.875-1.875H6.25V2.5H7.5zM4.375 5a.625.625 0 0 0-.625.625v10c0 .345.28.625.625.625h11.25c.345 0 .625-.28.625-.625v-10A.625.625 0 0 0 15.625 5H13.75v1.25H12.5V5h-5v1.25H6.25V5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CalendarRecurringMediumIcon.displayName = "CalendarRecurringMediumIcon";
export { CalendarRecurringMediumIcon };
