import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowDownMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M10 17.5a.63.63 0 0 0 .442-.183l6.25-6.25-.884-.884-5.183 5.183V2.5h-1.25v12.866l-5.183-5.183-.884.884 6.25 6.25A.63.63 0 0 0 10 17.5"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowDownMediumIcon.displayName = "ArrowDownMediumIcon";
export { ArrowDownMediumIcon };
