import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ColumnFilterMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8.125 2.5c.345 0 .625.28.625.625V5H7.5V3.75H3.75v12.5H7.5V12.5h1.25v4.375a.625.625 0 0 1-.625.625h-5l-.126-.012a.625.625 0 0 1-.499-.613V3.125c0-.345.28-.625.625-.625z" />
              <path
                fillRule="evenodd"
                d="M18.715 6.25c.52 0 .813.6.491 1.01L15 12.615v4.261c0 .345-.28.625-.625.625h-2.5a.625.625 0 0 1-.625-.625v-4.263L7.045 7.261a.625.625 0 0 1 .492-1.011zm-6.482 5.59c.173.22.267.492.267.772v3.638h1.25v-3.636c0-.28.094-.553.267-.773L17.43 7.5H8.822z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ColumnFilterMediumIcon.displayName = "ColumnFilterMediumIcon";
export { ColumnFilterMediumIcon };
