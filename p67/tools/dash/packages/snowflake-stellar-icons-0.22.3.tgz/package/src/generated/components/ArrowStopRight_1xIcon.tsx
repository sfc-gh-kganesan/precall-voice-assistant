import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowStopRight_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M11.5 7.5a.5.5 0 0 1-.146.354l-4.5 4.5-.708-.707L9.793 8H2V7h7.793L6.146 3.354l.708-.708 4.5 4.5a.5.5 0 0 1 .146.354M13 14V1h1v13z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowStopRight_1xIcon.displayName = "ArrowStopRight_1xIcon";
export { ArrowStopRight_1xIcon };
