import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ContributionMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M5.625 1.25a2.497 2.497 0 0 1 .653 4.91 5 5 0 0 0 4.972 4.465h.707a2.498 2.498 0 0 1 4.918.625 2.5 2.5 0 0 1-4.918.625h-.707a6.24 6.24 0 0 1-5-2.501v4.458a2.498 2.498 0 0 1-.625 4.918A2.5 2.5 0 0 1 5 13.832V6.167a2.497 2.497 0 0 1 .625-4.917m0 13.75a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m8.75-5a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m-8.75-7.5a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ContributionMediumIcon.displayName = "ContributionMediumIcon";
export { ContributionMediumIcon };
