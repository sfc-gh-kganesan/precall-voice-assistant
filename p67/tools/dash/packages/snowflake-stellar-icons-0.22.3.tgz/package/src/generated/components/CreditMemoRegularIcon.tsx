import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CreditMemoRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8 9.25a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5M8.5 8h-1V4h1z" />
              <path
                fillRule="evenodd"
                d="M12.5 1a.5.5 0 0 1 .5.5v13a.5.5 0 0 1-.777.416L11 14.101l-1.223.815a.5.5 0 0 1-.554 0L8 14.101l-1.223.815a.5.5 0 0 1-.554 0L5 14.101l-1.223.815A.5.5 0 0 1 3 14.5v-13a.5.5 0 0 1 .5-.5zM4 13.565l.723-.481a.5.5 0 0 1 .554 0l1.223.814 1.223-.814a.5.5 0 0 1 .554 0l1.223.814 1.223-.814a.5.5 0 0 1 .554 0l.723.481V2H4z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CreditMemoRegularIcon.displayName = "CreditMemoRegularIcon";
export { CreditMemoRegularIcon };
