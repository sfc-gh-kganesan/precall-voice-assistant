import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CriticalFill_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M10.192 0a1 1 0 0 1 .707.293l3.808 3.808a1 1 0 0 1 .293.707v5.384a1 1 0 0 1-.293.707l-3.808 3.808a1 1 0 0 1-.707.293H4.808a1 1 0 0 1-.707-.293L.293 10.899A1 1 0 0 1 0 10.192V4.808A1 1 0 0 1 .293 4.1L4.101.293A1 1 0 0 1 4.808 0zM3 7v1h9V7z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CriticalFill_1xIcon.displayName = "CriticalFill_1xIcon";
export { CriticalFill_1xIcon };
