import { forwardRef, ForwardedRef } from "react";

import { ChartStackedMediumIcon } from "./ChartStackedMediumIcon";
import { ChartStackedRegularIcon } from "./ChartStackedRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChartStackedIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChartStackedIcon = forwardRef(
  (
    { size = "regular", ...props }: ChartStackedIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChartStackedRegularIcon />;

    if (size === "medium") {
      icon = <ChartStackedMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChartStackedIcon.displayName = "ChartStackedIcon";

export type { ChartStackedIconProps };
export { ChartStackedIcon };
