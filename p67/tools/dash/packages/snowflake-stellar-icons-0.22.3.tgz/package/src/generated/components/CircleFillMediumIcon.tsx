import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CircleFillMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M18.75 10a8.75 8.75 0 1 1-17.5 0 8.75 8.75 0 0 1 17.5 0"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CircleFillMediumIcon.displayName = "CircleFillMediumIcon";
export { CircleFillMediumIcon };
