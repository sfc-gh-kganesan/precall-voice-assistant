import { forwardRef, ForwardedRef } from "react";

import { ComputePoolMediumIcon } from "./ComputePoolMediumIcon";
import { ComputePoolRegularIcon } from "./ComputePoolRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ComputePoolIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ComputePoolIcon = forwardRef(
  (
    { size = "regular", ...props }: ComputePoolIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ComputePoolRegularIcon />;

    if (size === "medium") {
      icon = <ComputePoolMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ComputePoolIcon.displayName = "ComputePoolIcon";

export type { ComputePoolIconProps };
export { ComputePoolIcon };
