import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AzureMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M12.5 3.125a.73.73 0 0 1 .414.13.7.7 0 0 1 .256.338l4.293 12.374a.67.67 0 0 1-.095.621.73.73 0 0 1-.574.287h-4.947a.73.73 0 0 0 .574-.287.68.68 0 0 0 .096-.62L8.223 3.592a.69.69 0 0 0-.453-.435.7.7 0 0 0-.216-.032zm-5.753.707c.137.148.315.26.52.314l2.158 6.225-.209.603H6.912c-.284 0-.561.084-.796.238-.177.117-.324.27-.43.448l-.092.186a1.34 1.34 0 0 0-.063.809c.063.269.208.513.415.701l-.001.001 1.859 1.687-.472 1.362a.7.7 0 0 1-.259.34.7.7 0 0 1-.412.128H3.207a.72.72 0 0 1-.574-.286.67.67 0 0 1-.096-.62z" />
              <path d="M11.353 15.931a1.1 1.1 0 0 0-.472.457L6.69 12.582a.32.32 0 0 1-.08-.348.32.32 0 0 1 .12-.146.33.33 0 0 1 .183-.054H10z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AzureMediumIcon.displayName = "AzureMediumIcon";
export { AzureMediumIcon };
