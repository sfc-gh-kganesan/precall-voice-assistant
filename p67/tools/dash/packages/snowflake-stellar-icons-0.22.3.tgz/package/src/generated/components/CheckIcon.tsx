import { forwardRef, ForwardedRef } from "react";

import { CheckMediumIcon } from "./CheckMediumIcon";
import { CheckRegularIcon } from "./CheckRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CheckIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CheckIcon = forwardRef(
  (
    { size = "regular", ...props }: CheckIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CheckRegularIcon />;

    if (size === "medium") {
      icon = <CheckMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CheckIcon.displayName = "CheckIcon";

export type { CheckIconProps };
export { CheckIcon };
