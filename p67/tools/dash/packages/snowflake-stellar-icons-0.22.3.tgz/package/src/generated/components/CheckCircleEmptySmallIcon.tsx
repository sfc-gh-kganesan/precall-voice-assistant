import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
const CheckCircleEmptySmallIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        ref={ref}
        svgContent={
          <>
            <g clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path
                fill={iconColor}
                d="M15 8a7 7 0 1 0-7 7v1A8 8 0 1 1 8 0a8 8 0 0 1 0 16v-1a7 7 0 0 0 7-7"
              />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h16v16H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
CheckCircleEmptySmallIcon.displayName = "CheckCircleEmptySmallIcon";
export { CheckCircleEmptySmallIcon };
