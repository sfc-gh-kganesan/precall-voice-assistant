import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CheckCircleMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="m14.84 7.294-5.625 6.25a.627.627 0 0 1-.907.023l-3.125-3.125.884-.884 2.657 2.658 5.186-5.76z" />
              <path
                fillRule="evenodd"
                d="M10 1.25a8.75 8.75 0 1 1 0 17.5 8.75 8.75 0 0 1 0-17.5m0 1.25a7.5 7.5 0 1 0 0 15 7.5 7.5 0 0 0 0-15"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CheckCircleMediumIcon.displayName = "CheckCircleMediumIcon";
export { CheckCircleMediumIcon };
