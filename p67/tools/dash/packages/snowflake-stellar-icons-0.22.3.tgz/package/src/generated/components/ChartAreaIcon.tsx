import { forwardRef, ForwardedRef } from "react";

import { ChartAreaMediumIcon } from "./ChartAreaMediumIcon";
import { ChartAreaRegularIcon } from "./ChartAreaRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChartAreaIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChartAreaIcon = forwardRef(
  (
    { size = "regular", ...props }: ChartAreaIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChartAreaRegularIcon />;

    if (size === "medium") {
      icon = <ChartAreaMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChartAreaIcon.displayName = "ChartAreaIcon";

export type { ChartAreaIconProps };
export { ChartAreaIcon };
