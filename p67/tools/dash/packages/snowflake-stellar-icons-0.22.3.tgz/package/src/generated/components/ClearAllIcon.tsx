import { forwardRef, ForwardedRef } from "react";

import { ClearAllMediumIcon } from "./ClearAllMediumIcon";
import { ClearAllRegularIcon } from "./ClearAllRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ClearAllIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ClearAllIcon = forwardRef(
  (
    { size = "regular", ...props }: ClearAllIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ClearAllRegularIcon />;

    if (size === "medium") {
      icon = <ClearAllMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ClearAllIcon.displayName = "ClearAllIcon";

export type { ClearAllIconProps };
export { ClearAllIcon };
