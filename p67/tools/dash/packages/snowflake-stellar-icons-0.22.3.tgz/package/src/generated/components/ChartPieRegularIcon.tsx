import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartPieRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M8 1a7 7 0 1 1 0 14A7 7 0 0 1 8 1m-.5 1.022A5.999 5.999 0 0 0 8 14a6 6 0 0 0 5.58-8.207L8.25 8.87a.5.5 0 0 1-.75-.432zm1 5.55 4.635-2.677A6 6 0 0 0 8.5 2.022z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartPieRegularIcon.displayName = "ChartPieRegularIcon";
export { ChartPieRegularIcon };
