import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BillingAdjustmentsRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8.5 3v.798c1.059.156 1.762.833 1.831 1.83H9.186c-.079-.459-.495-.84-1.164-.84-.615 0-.98.251-.98.685 0 .381.278.564.703.685l1.024.286c.876.252 1.623.67 1.623 1.875 0 .998-.73 1.683-1.892 1.813V11h-.972v-.894c-1.093-.19-1.848-.98-1.918-2.126h1.146c.052.66.616 1.164 1.328 1.164.668 0 1.128-.322 1.128-.8 0-.424-.321-.667-.755-.788l-1.024-.287c-.86-.243-1.58-.686-1.58-1.788 0-.867.678-1.518 1.675-1.683V3z" />
              <path
                fillRule="evenodd"
                d="M12.5 1a.5.5 0 0 1 .5.5v13a.5.5 0 0 1-.777.416L11 14.101l-1.223.815a.5.5 0 0 1-.554 0L8 14.101l-1.223.815a.5.5 0 0 1-.554 0L5 14.101l-1.223.815A.5.5 0 0 1 3 14.5v-13a.5.5 0 0 1 .5-.5zM4 13.565l.723-.481.065-.037a.5.5 0 0 1 .49.037l1.222.814 1.223-.814.065-.037a.5.5 0 0 1 .49.037l1.222.814 1.223-.814.065-.037a.5.5 0 0 1 .49.037l.722.481V2H4z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BillingAdjustmentsRegularIcon.displayName = "BillingAdjustmentsRegularIcon";
export { BillingAdjustmentsRegularIcon };
