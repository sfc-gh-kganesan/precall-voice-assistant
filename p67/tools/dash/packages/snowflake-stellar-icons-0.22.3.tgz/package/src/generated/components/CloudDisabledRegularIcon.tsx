import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudDisabledRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="m14.206 13.5-.706.707-1.26-1.26a3.5 3.5 0 0 1-.592.081l-.012.001-.156.004H4.1a3.1 3.1 0 0 1-3.096-2.94L1 9.933a3.1 3.1 0 0 1 2.767-3.082 3.94 3.94 0 0 1 .522-1.855L2.793 3.5l.706-.706zM5.032 5.74c-.17.374-.267.789-.267 1.227l.004.163q.004.08.012.158l.064.594-.596-.041a2 2 0 0 0-.15-.008A2.1 2.1 0 0 0 2 9.933l.01.215a2.1 2.1 0 0 0 2.09 1.885h7.226z"
                clipRule="evenodd"
              />
              <path d="M7.918 3.004a3.97 3.97 0 0 1 3.651 2.965A3.533 3.533 0 0 1 15 9.5l-.004.176a3.5 3.5 0 0 1-.959 2.241l-.706-.706c.361-.393.601-.899.656-1.46L14 9.5c0-1.312-.997-2.39-2.274-2.52l-.26-.013q-.13 0-.253.012l-.479.047-.066-.475a2.97 2.97 0 0 0-2.66-2.538L7.732 4c-.469 0-.911.112-1.305.306l-.739-.739A3.95 3.95 0 0 1 7.732 3z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CloudDisabledRegularIcon.displayName = "CloudDisabledRegularIcon";
export { CloudDisabledRegularIcon };
