import { forwardRef, ForwardedRef } from "react";

import { DashboardsMediumIcon } from "./DashboardsMediumIcon";
import { DashboardsRegularIcon } from "./DashboardsRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DashboardsIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DashboardsIcon = forwardRef(
  (
    { size = "regular", ...props }: DashboardsIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DashboardsRegularIcon />;

    if (size === "medium") {
      icon = <DashboardsMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DashboardsIcon.displayName = "DashboardsIcon";

export type { DashboardsIconProps };
export { DashboardsIcon };
