import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const AnomalyPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              d="m27.04 17.414 2.792-2.793 2.793 2.793L34.039 16l-2.793-2.793 2.793-2.793L32.625 9l-2.793 2.793L27.04 9l-1.414 1.414 2.793 2.793L25.625 16z"
            />
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M3 35a4 4 0 0 1 7.874-1h3.252A4.002 4.002 0 0 1 22 35a4 4 0 0 1-7.874 1h-3.252A4.002 4.002 0 0 1 3 35m4-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m9 2a2 2 0 1 1 4 0 2 2 0 0 1-4 0M37 35a4 4 0 1 1 8 0 4 4 0 0 1-8 0m4-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4"
              clipRule="evenodd"
            />
            <path
              fill={iconColor}
              d="m26.781 21.14-1.666 2.887-1.732-1 1.666-2.887zM23.448 26.914 21.78 29.8l-1.732-1 1.667-2.887zM34.495 24.027l-1.667-2.887 1.732-1 1.667 2.887zM37.828 29.8l-1.666-2.886 1.732-1L39.56 28.8z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
AnomalyPictogram.displayName = "AnomalyPictogram";
export { AnomalyPictogram };
