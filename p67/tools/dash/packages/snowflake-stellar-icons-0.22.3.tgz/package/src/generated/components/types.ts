import { ActivityIcon } from "./ActivityIcon";
import { AiIcon } from "./AiIcon";
import { AnomalyIcon } from "./AnomalyIcon";
import { AnswerIcon } from "./AnswerIcon";
import { ApiIcon } from "./ApiIcon";
import { ApplicationContainerServiceIcon } from "./ApplicationContainerServiceIcon";
import { ApplicationDatabaseIcon } from "./ApplicationDatabaseIcon";
import { ApplicationPackageIcon } from "./ApplicationPackageIcon";
import { ApplicationIcon } from "./ApplicationIcon";
import { ApprovalIcon } from "./ApprovalIcon";
import { ArrayIcon } from "./ArrayIcon";
import { ArrowDownIcon } from "./ArrowDownIcon";
import { ArrowRightCurvedIcon } from "./ArrowRightCurvedIcon";
import { ArrowRightIcon } from "./ArrowRightIcon";
import { ArrowUpCurvedIcon } from "./ArrowUpCurvedIcon";
import { ArrowUpIcon } from "./ArrowUpIcon";
import { ArrowsUpDownIcon } from "./ArrowsUpDownIcon";
import { BackfillJobIcon } from "./BackfillJobIcon";
import { BankIcon } from "./BankIcon";
import { BellIcon } from "./BellIcon";
import { BinaryIcon } from "./BinaryIcon";
import { BookClosedIcon } from "./BookClosedIcon";
import { BookOpenIcon } from "./BookOpenIcon";
import { BooleanIcon } from "./BooleanIcon";
import { BranchIcon } from "./BranchIcon";
import { BudgetIcon } from "./BudgetIcon";
import { CalendarArrowLeftIcon } from "./CalendarArrowLeftIcon";
import { CalendarArrowRightIcon } from "./CalendarArrowRightIcon";
import { CalendarCheckmarkIcon } from "./CalendarCheckmarkIcon";
import { CalendarDateIcon } from "./CalendarDateIcon";
import { CalendarPlusIcon } from "./CalendarPlusIcon";
import { CalendarRecurringIcon } from "./CalendarRecurringIcon";
import { CellCollapseCodeIcon } from "./CellCollapseCodeIcon";
import { CellCollapseResultIcon } from "./CellCollapseResultIcon";
import { CellCollapseIcon } from "./CellCollapseIcon";
import { CellExpandIcon } from "./CellExpandIcon";
import { ChartAreaIcon } from "./ChartAreaIcon";
import { ChartColumnIcon } from "./ChartColumnIcon";
import { ChartHeatIcon } from "./ChartHeatIcon";
import { ChartLineIcon } from "./ChartLineIcon";
import { ChartPieIcon } from "./ChartPieIcon";
import { ChartPlotIcon } from "./ChartPlotIcon";
import { ChartStackedIcon } from "./ChartStackedIcon";
import { CheckCircleAutoIcon } from "./CheckCircleAutoIcon";
import { CheckCircleEmptyIcon } from "./CheckCircleEmptyIcon";
import { CheckCircleIcon } from "./CheckCircleIcon";
import { CheckDoubleIcon } from "./CheckDoubleIcon";
import { CheckIcon } from "./CheckIcon";
import { ChevronDownSmallIcon } from "./ChevronDownSmallIcon";
import { ChevronDownIcon } from "./ChevronDownIcon";
import { ChevronLeftSmallIcon } from "./ChevronLeftSmallIcon";
import { ChevronLeftIcon } from "./ChevronLeftIcon";
import { ChevronRightSmallIcon } from "./ChevronRightSmallIcon";
import { ChevronRightIcon } from "./ChevronRightIcon";
import { ChevronUpIcon } from "./ChevronUpIcon";
import { ChevronsCollapseIcon } from "./ChevronsCollapseIcon";
import { ChevronsExpandIcon } from "./ChevronsExpandIcon";
import { CircleLargeIcon } from "./CircleLargeIcon";
import { CircleIcon } from "./CircleIcon";
import { ClassicConsoleIcon } from "./ClassicConsoleIcon";
import { ClassificationIcon } from "./ClassificationIcon";
import { ClearAllIcon } from "./ClearAllIcon";
import { ClearSmallIcon } from "./ClearSmallIcon";
import { ClearIcon } from "./ClearIcon";
import { ClockIcon } from "./ClockIcon";
import { CodeCompareIcon } from "./CodeCompareIcon";
import { ColumnFilterIcon } from "./ColumnFilterIcon";
import { ColumnMultipleIcon } from "./ColumnMultipleIcon";
import { ColumnSingleIcon } from "./ColumnSingleIcon";
import { CommaIcon } from "./CommaIcon";
import { CommentIcon } from "./CommentIcon";
import { ComputePoolIcon } from "./ComputePoolIcon";
import { ComputeIcon } from "./ComputeIcon";
import { ConditionIcon } from "./ConditionIcon";
import { ConnectorIcon } from "./ConnectorIcon";
import { ContributionIcon } from "./ContributionIcon";
import { CopyIcon } from "./CopyIcon";
import { CreateIcon } from "./CreateIcon";
import { CreditCardIcon } from "./CreditCardIcon";
import { CreditMemoIcon } from "./CreditMemoIcon";
import { DashboardsIcon } from "./DashboardsIcon";
import { DataPipelinesIcon } from "./DataPipelinesIcon";
import { DataSemanticIcon } from "./DataSemanticIcon";
import { DataIcon } from "./DataIcon";
import { DatabaseSharedIcon } from "./DatabaseSharedIcon";
import { DatabaseIcon } from "./DatabaseIcon";
import { DatasetIcon } from "./DatasetIcon";
import { DecimalDecreaseIcon } from "./DecimalDecreaseIcon";
import { DecimalIncreaseIcon } from "./DecimalIncreaseIcon";
import { DeleteIcon } from "./DeleteIcon";
import { DiamondIcon } from "./DiamondIcon";
import { DocAiModelBuildIcon } from "./DocAiModelBuildIcon";
import { DollarSignIcon } from "./DollarSignIcon";
import { DownloadIcon } from "./DownloadIcon";
import { DragHandleIcon } from "./DragHandleIcon";
import { EditDisabledIcon } from "./EditDisabledIcon";
import { EditIcon } from "./EditIcon";
import { EllipsisHorizontalIcon } from "./EllipsisHorizontalIcon";
import { EmailIcon } from "./EmailIcon";
import { ErrorCircleIcon } from "./ErrorCircleIcon";
import { FeatureViewIcon } from "./FeatureViewIcon";
import { FeatureIcon } from "./FeatureIcon";
import { FetchIcon } from "./FetchIcon";
import { FileFormatIcon } from "./FileFormatIcon";
import { FileIcon } from "./FileIcon";
import { FilterIcon } from "./FilterIcon";
import { FlagIcon } from "./FlagIcon";
import { FolderSharedIcon } from "./FolderSharedIcon";
import { FolderIcon } from "./FolderIcon";
import { ForecastingIcon } from "./ForecastingIcon";
import { FormatAttachmentIcon } from "./FormatAttachmentIcon";
import { FormatClearIcon } from "./FormatClearIcon";
import { FormatCodeIcon } from "./FormatCodeIcon";
import { FormatItalicIcon } from "./FormatItalicIcon";
import { FormatLinkIcon } from "./FormatLinkIcon";
import { FormatOrderedListIcon } from "./FormatOrderedListIcon";
import { FormatStrikethroughIcon } from "./FormatStrikethroughIcon";
import { FormatUnderlineIcon } from "./FormatUnderlineIcon";
import { FormatUnorderedListIcon } from "./FormatUnorderedListIcon";
import { FunctionIcon } from "./FunctionIcon";
import { GearIcon } from "./GearIcon";
import { GeometryIcon } from "./GeometryIcon";
import { GiftIcon } from "./GiftIcon";
import { GitRepositoryIcon } from "./GitRepositoryIcon";
import { GlobeIcon } from "./GlobeIcon";
import { GotoIcon } from "./GotoIcon";
import { GradCapIcon } from "./GradCapIcon";
import { GrantOptionIcon } from "./GrantOptionIcon";
import { GraphDirectionLeftRightIcon } from "./GraphDirectionLeftRightIcon";
import { GraphDirectionTopBottomIcon } from "./GraphDirectionTopBottomIcon";
import { GuidesIcon } from "./GuidesIcon";
import { HelpCircleSmallIcon } from "./HelpCircleSmallIcon";
import { HelpCircleIcon } from "./HelpCircleIcon";
import { HideIcon } from "./HideIcon";
import { HierarchyIcon } from "./HierarchyIcon";
import { HomeIcon } from "./HomeIcon";
import { IcDataTypeDatetimeIcon } from "./IcDataTypeDatetimeIcon";
import { InProgressCircleIcon } from "./InProgressCircleIcon";
import { InfoCircleSmallIcon } from "./InfoCircleSmallIcon";
import { InfoCircleIcon } from "./InfoCircleIcon";
import { InheritIcon } from "./InheritIcon";
import { InsertAtCursorIcon } from "./InsertAtCursorIcon";
import { IntegrationApiIcon } from "./IntegrationApiIcon";
import { IntegrationExternalAccessIcon } from "./IntegrationExternalAccessIcon";
import { IntegrationSecurityIcon } from "./IntegrationSecurityIcon";
import { InvoiceIcon } from "./InvoiceIcon";
import { JoinIcon } from "./JoinIcon";
import { KeyboardIcon } from "./KeyboardIcon";
import { LanguageIcon } from "./LanguageIcon";
import { LayoutIcon } from "./LayoutIcon";
import { LightbulbOffIcon } from "./LightbulbOffIcon";
import { LightbulbIcon } from "./LightbulbIcon";
import { LinkIcon } from "./LinkIcon";
import { ListIcon } from "./ListIcon";
import { ListingCompareIcon } from "./ListingCompareIcon";
import { ListingExampleIcon } from "./ListingExampleIcon";
import { ListingIcon } from "./ListingIcon";
import { LlmIcon } from "./LlmIcon";
import { LocationIcon } from "./LocationIcon";
import { LockIcon } from "./LockIcon";
import { LoudspeakerIcon } from "./LoudspeakerIcon";
import { MachineLearningModelIcon } from "./MachineLearningModelIcon";
import { MapIcon } from "./MapIcon";
import { MarketplaceInternalIcon } from "./MarketplaceInternalIcon";
import { MarketplaceIcon } from "./MarketplaceIcon";
import { MatchCaseIcon } from "./MatchCaseIcon";
import { MaximizeIcon } from "./MaximizeIcon";
import { MinimizeIcon } from "./MinimizeIcon";
import { MinusIcon } from "./MinusIcon";
import { NodeCollapseIcon } from "./NodeCollapseIcon";
import { NodeExpandIcon } from "./NodeExpandIcon";
import { NotebookIcon } from "./NotebookIcon";
import { NullIcon } from "./NullIcon";
import { NumberIcon } from "./NumberIcon";
import { ObjectIcon } from "./ObjectIcon";
import { OpenDetailsIcon } from "./OpenDetailsIcon";
import { OpenInWorksheetIcon } from "./OpenInWorksheetIcon";
import { OrganizationIcon } from "./OrganizationIcon";
import { OwnershipIcon } from "./OwnershipIcon";
import { PageFirstIcon } from "./PageFirstIcon";
import { PageLastIcon } from "./PageLastIcon";
import { PaneBottomIcon } from "./PaneBottomIcon";
import { PaneLeftIcon } from "./PaneLeftIcon";
import { PaneMiddleIcon } from "./PaneMiddleIcon";
import { PaneRightIcon } from "./PaneRightIcon";
import { PaneTopIcon } from "./PaneTopIcon";
import { ParameterIcon } from "./ParameterIcon";
import { PauseIcon } from "./PauseIcon";
import { PdfIcon } from "./PdfIcon";
import { PendingCircleIcon } from "./PendingCircleIcon";
import { PeopleIcon } from "./PeopleIcon";
import { PercentIcon } from "./PercentIcon";
import { PersonIcon } from "./PersonIcon";
import { PinFillIcon } from "./PinFillIcon";
import { PinIcon } from "./PinIcon";
import { PipeIcon } from "./PipeIcon";
import { PlaceholderIcon } from "./PlaceholderIcon";
import { PlusSquareIcon } from "./PlusSquareIcon";
import { PlusIcon } from "./PlusIcon";
import { PolicyIcon } from "./PolicyIcon";
import { ProcedureIcon } from "./ProcedureIcon";
import { ProjectsIcon } from "./ProjectsIcon";
import { PythonIcon } from "./PythonIcon";
import { RedoIcon } from "./RedoIcon";
import { RefreshAutoIcon } from "./RefreshAutoIcon";
import { RefreshManualIcon } from "./RefreshManualIcon";
import { RefreshIcon } from "./RefreshIcon";
import { RegularExpressionIcon } from "./RegularExpressionIcon";
import { RequestNotificationIcon } from "./RequestNotificationIcon";
import { ResourceGroupIcon } from "./ResourceGroupIcon";
import { ResourceTypeIcon } from "./ResourceTypeIcon";
import { RibbonIcon } from "./RibbonIcon";
import { RingIcon } from "./RingIcon";
import { RoleDatabaseIcon } from "./RoleDatabaseIcon";
import { RoleIcon } from "./RoleIcon";
import { RowsIcon } from "./RowsIcon";
import { RunIntelliIcon } from "./RunIntelliIcon";
import { RunIcon } from "./RunIcon";
import { ScaleIcon } from "./ScaleIcon";
import { SchemaIcon } from "./SchemaIcon";
import { ScoreCardIcon } from "./ScoreCardIcon";
import { SearchIndexIcon } from "./SearchIndexIcon";
import { SearchIcon } from "./SearchIcon";
import { SelectIcon } from "./SelectIcon";
import { SentimentIcon } from "./SentimentIcon";
import { SequenceIcon } from "./SequenceIcon";
import { ServiceUsageTypeIcon } from "./ServiceUsageTypeIcon";
import { SessionIcon } from "./SessionIcon";
import { ShareObjectIcon } from "./ShareObjectIcon";
import { ShareIcon } from "./ShareIcon";
import { ShieldAdminIcon } from "./ShieldAdminIcon";
import { ShieldCheckIcon } from "./ShieldCheckIcon";
import { ShieldLockIcon } from "./ShieldLockIcon";
import { ShieldIcon } from "./ShieldIcon";
import { ShowIcon } from "./ShowIcon";
import { SignInIcon } from "./SignInIcon";
import { SignOutIcon } from "./SignOutIcon";
import { SlideLeftIcon } from "./SlideLeftIcon";
import { SlideRightIcon } from "./SlideRightIcon";
import { SnowflakeIcon } from "./SnowflakeIcon";
import { SourceIcon } from "./SourceIcon";
import { SqlIcon } from "./SqlIcon";
import { StageExternalIcon } from "./StageExternalIcon";
import { StageInternalIcon } from "./StageInternalIcon";
import { StageTableIcon } from "./StageTableIcon";
import { StageUserIcon } from "./StageUserIcon";
import { StageIcon } from "./StageIcon";
import { StopIcon } from "./StopIcon";
import { StreamIcon } from "./StreamIcon";
import { StreamlitIcon } from "./StreamlitIcon";
import { SummaryIcon } from "./SummaryIcon";
import { SuspendedIcon } from "./SuspendedIcon";
import { TableDynamicIcon } from "./TableDynamicIcon";
import { TableExternalIcon } from "./TableExternalIcon";
import { TableIcebergIcon } from "./TableIcebergIcon";
import { TableLogicalIcon } from "./TableLogicalIcon";
import { TablePreviewIcon } from "./TablePreviewIcon";
import { TableSizeIcon } from "./TableSizeIcon";
import { TableIcon } from "./TableIcon";
import { TagBasedPolicyIcon } from "./TagBasedPolicyIcon";
import { TagGenericIcon } from "./TagGenericIcon";
import { TagGovernanceIcon } from "./TagGovernanceIcon";
import { TagSystemIcon } from "./TagSystemIcon";
import { TaskFinalizerIcon } from "./TaskFinalizerIcon";
import { TaskRootIcon } from "./TaskRootIcon";
import { TaskIcon } from "./TaskIcon";
import { TermsIcon } from "./TermsIcon";
import { TextIcon } from "./TextIcon";
import { ThemeIcon } from "./ThemeIcon";
import { ThumbsDownIcon } from "./ThumbsDownIcon";
import { ThumbsUpIcon } from "./ThumbsUpIcon";
import { TrendDownIcon } from "./TrendDownIcon";
import { TrendUpIcon } from "./TrendUpIcon";
import { UndoIcon } from "./UndoIcon";
import { UnknownIcon } from "./UnknownIcon";
import { UnlinkIcon } from "./UnlinkIcon";
import { UploadCloudIcon } from "./UploadCloudIcon";
import { UploadIcon } from "./UploadIcon";
import { UserProfileIcon } from "./UserProfileIcon";
import { UserIcon } from "./UserIcon";
import { VectorIcon } from "./VectorIcon";
import { ViewMaterializedIcon } from "./ViewMaterializedIcon";
import { ViewSecuredMaterializedIcon } from "./ViewSecuredMaterializedIcon";
import { ViewSecuredIcon } from "./ViewSecuredIcon";
import { ViewIcon } from "./ViewIcon";
import { WaitActionCircleIcon } from "./WaitActionCircleIcon";
import { WarehouseSnowflakeIcon } from "./WarehouseSnowflakeIcon";
import { WarehouseSnowparkIcon } from "./WarehouseSnowparkIcon";
import { WarehouseIcon } from "./WarehouseIcon";
import { WarningTriangleSmallIcon } from "./WarningTriangleSmallIcon";
import { WarningTriangleIcon } from "./WarningTriangleIcon";
import { WorksheetIcon } from "./WorksheetIcon";
import { WorkspacesIcon } from "./WorkspacesIcon";
import { WritingHandIcon } from "./WritingHandIcon";
import { XSmallIcon } from "./XSmallIcon";
import { ZoomResetIcon } from "./ZoomResetIcon";

export type IconType =
  | typeof ActivityIcon
  | typeof AiIcon
  | typeof AnomalyIcon
  | typeof AnswerIcon
  | typeof ApiIcon
  | typeof ApplicationContainerServiceIcon
  | typeof ApplicationDatabaseIcon
  | typeof ApplicationPackageIcon
  | typeof ApplicationIcon
  | typeof ApprovalIcon
  | typeof ArrayIcon
  | typeof ArrowDownIcon
  | typeof ArrowRightCurvedIcon
  | typeof ArrowRightIcon
  | typeof ArrowUpCurvedIcon
  | typeof ArrowUpIcon
  | typeof ArrowsUpDownIcon
  | typeof BackfillJobIcon
  | typeof BankIcon
  | typeof BellIcon
  | typeof BinaryIcon
  | typeof BookClosedIcon
  | typeof BookOpenIcon
  | typeof BooleanIcon
  | typeof BranchIcon
  | typeof BudgetIcon
  | typeof CalendarArrowLeftIcon
  | typeof CalendarArrowRightIcon
  | typeof CalendarCheckmarkIcon
  | typeof CalendarDateIcon
  | typeof CalendarPlusIcon
  | typeof CalendarRecurringIcon
  | typeof CellCollapseCodeIcon
  | typeof CellCollapseResultIcon
  | typeof CellCollapseIcon
  | typeof CellExpandIcon
  | typeof ChartAreaIcon
  | typeof ChartColumnIcon
  | typeof ChartHeatIcon
  | typeof ChartLineIcon
  | typeof ChartPieIcon
  | typeof ChartPlotIcon
  | typeof ChartStackedIcon
  | typeof CheckCircleAutoIcon
  | typeof CheckCircleEmptyIcon
  | typeof CheckCircleIcon
  | typeof CheckDoubleIcon
  | typeof CheckIcon
  | typeof ChevronDownSmallIcon
  | typeof ChevronDownIcon
  | typeof ChevronLeftSmallIcon
  | typeof ChevronLeftIcon
  | typeof ChevronRightSmallIcon
  | typeof ChevronRightIcon
  | typeof ChevronUpIcon
  | typeof ChevronsCollapseIcon
  | typeof ChevronsExpandIcon
  | typeof CircleLargeIcon
  | typeof CircleIcon
  | typeof ClassicConsoleIcon
  | typeof ClassificationIcon
  | typeof ClearAllIcon
  | typeof ClearSmallIcon
  | typeof ClearIcon
  | typeof ClockIcon
  | typeof CodeCompareIcon
  | typeof ColumnFilterIcon
  | typeof ColumnMultipleIcon
  | typeof ColumnSingleIcon
  | typeof CommaIcon
  | typeof CommentIcon
  | typeof ComputePoolIcon
  | typeof ComputeIcon
  | typeof ConditionIcon
  | typeof ConnectorIcon
  | typeof ContributionIcon
  | typeof CopyIcon
  | typeof CreateIcon
  | typeof CreditCardIcon
  | typeof CreditMemoIcon
  | typeof DashboardsIcon
  | typeof DataPipelinesIcon
  | typeof DataSemanticIcon
  | typeof DataIcon
  | typeof DatabaseSharedIcon
  | typeof DatabaseIcon
  | typeof DatasetIcon
  | typeof DecimalDecreaseIcon
  | typeof DecimalIncreaseIcon
  | typeof DeleteIcon
  | typeof DiamondIcon
  | typeof DocAiModelBuildIcon
  | typeof DollarSignIcon
  | typeof DownloadIcon
  | typeof DragHandleIcon
  | typeof EditDisabledIcon
  | typeof EditIcon
  | typeof EllipsisHorizontalIcon
  | typeof EmailIcon
  | typeof ErrorCircleIcon
  | typeof FeatureViewIcon
  | typeof FeatureIcon
  | typeof FetchIcon
  | typeof FileFormatIcon
  | typeof FileIcon
  | typeof FilterIcon
  | typeof FlagIcon
  | typeof FolderSharedIcon
  | typeof FolderIcon
  | typeof ForecastingIcon
  | typeof FormatAttachmentIcon
  | typeof FormatClearIcon
  | typeof FormatCodeIcon
  | typeof FormatItalicIcon
  | typeof FormatLinkIcon
  | typeof FormatOrderedListIcon
  | typeof FormatStrikethroughIcon
  | typeof FormatUnderlineIcon
  | typeof FormatUnorderedListIcon
  | typeof FunctionIcon
  | typeof GearIcon
  | typeof GeometryIcon
  | typeof GiftIcon
  | typeof GitRepositoryIcon
  | typeof GlobeIcon
  | typeof GotoIcon
  | typeof GradCapIcon
  | typeof GrantOptionIcon
  | typeof GraphDirectionLeftRightIcon
  | typeof GraphDirectionTopBottomIcon
  | typeof GuidesIcon
  | typeof HelpCircleSmallIcon
  | typeof HelpCircleIcon
  | typeof HideIcon
  | typeof HierarchyIcon
  | typeof HomeIcon
  | typeof IcDataTypeDatetimeIcon
  | typeof InProgressCircleIcon
  | typeof InfoCircleSmallIcon
  | typeof InfoCircleIcon
  | typeof InheritIcon
  | typeof InsertAtCursorIcon
  | typeof IntegrationApiIcon
  | typeof IntegrationExternalAccessIcon
  | typeof IntegrationSecurityIcon
  | typeof InvoiceIcon
  | typeof JoinIcon
  | typeof KeyboardIcon
  | typeof LanguageIcon
  | typeof LayoutIcon
  | typeof LightbulbOffIcon
  | typeof LightbulbIcon
  | typeof LinkIcon
  | typeof ListIcon
  | typeof ListingCompareIcon
  | typeof ListingExampleIcon
  | typeof ListingIcon
  | typeof LlmIcon
  | typeof LocationIcon
  | typeof LockIcon
  | typeof LoudspeakerIcon
  | typeof MachineLearningModelIcon
  | typeof MapIcon
  | typeof MarketplaceInternalIcon
  | typeof MarketplaceIcon
  | typeof MatchCaseIcon
  | typeof MaximizeIcon
  | typeof MinimizeIcon
  | typeof MinusIcon
  | typeof NodeCollapseIcon
  | typeof NodeExpandIcon
  | typeof NotebookIcon
  | typeof NullIcon
  | typeof NumberIcon
  | typeof ObjectIcon
  | typeof OpenDetailsIcon
  | typeof OpenInWorksheetIcon
  | typeof OrganizationIcon
  | typeof OwnershipIcon
  | typeof PageFirstIcon
  | typeof PageLastIcon
  | typeof PaneBottomIcon
  | typeof PaneLeftIcon
  | typeof PaneMiddleIcon
  | typeof PaneRightIcon
  | typeof PaneTopIcon
  | typeof ParameterIcon
  | typeof PauseIcon
  | typeof PdfIcon
  | typeof PendingCircleIcon
  | typeof PeopleIcon
  | typeof PercentIcon
  | typeof PersonIcon
  | typeof PinFillIcon
  | typeof PinIcon
  | typeof PipeIcon
  | typeof PlaceholderIcon
  | typeof PlusSquareIcon
  | typeof PlusIcon
  | typeof PolicyIcon
  | typeof ProcedureIcon
  | typeof ProjectsIcon
  | typeof PythonIcon
  | typeof RedoIcon
  | typeof RefreshAutoIcon
  | typeof RefreshManualIcon
  | typeof RefreshIcon
  | typeof RegularExpressionIcon
  | typeof RequestNotificationIcon
  | typeof ResourceGroupIcon
  | typeof ResourceTypeIcon
  | typeof RibbonIcon
  | typeof RingIcon
  | typeof RoleDatabaseIcon
  | typeof RoleIcon
  | typeof RowsIcon
  | typeof RunIntelliIcon
  | typeof RunIcon
  | typeof ScaleIcon
  | typeof SchemaIcon
  | typeof ScoreCardIcon
  | typeof SearchIndexIcon
  | typeof SearchIcon
  | typeof SelectIcon
  | typeof SentimentIcon
  | typeof SequenceIcon
  | typeof ServiceUsageTypeIcon
  | typeof SessionIcon
  | typeof ShareObjectIcon
  | typeof ShareIcon
  | typeof ShieldAdminIcon
  | typeof ShieldCheckIcon
  | typeof ShieldLockIcon
  | typeof ShieldIcon
  | typeof ShowIcon
  | typeof SignInIcon
  | typeof SignOutIcon
  | typeof SlideLeftIcon
  | typeof SlideRightIcon
  | typeof SnowflakeIcon
  | typeof SourceIcon
  | typeof SqlIcon
  | typeof StageExternalIcon
  | typeof StageInternalIcon
  | typeof StageTableIcon
  | typeof StageUserIcon
  | typeof StageIcon
  | typeof StopIcon
  | typeof StreamIcon
  | typeof StreamlitIcon
  | typeof SummaryIcon
  | typeof SuspendedIcon
  | typeof TableDynamicIcon
  | typeof TableExternalIcon
  | typeof TableIcebergIcon
  | typeof TableLogicalIcon
  | typeof TablePreviewIcon
  | typeof TableSizeIcon
  | typeof TableIcon
  | typeof TagBasedPolicyIcon
  | typeof TagGenericIcon
  | typeof TagGovernanceIcon
  | typeof TagSystemIcon
  | typeof TaskFinalizerIcon
  | typeof TaskRootIcon
  | typeof TaskIcon
  | typeof TermsIcon
  | typeof TextIcon
  | typeof ThemeIcon
  | typeof ThumbsDownIcon
  | typeof ThumbsUpIcon
  | typeof TrendDownIcon
  | typeof TrendUpIcon
  | typeof UndoIcon
  | typeof UnknownIcon
  | typeof UnlinkIcon
  | typeof UploadCloudIcon
  | typeof UploadIcon
  | typeof UserProfileIcon
  | typeof UserIcon
  | typeof VectorIcon
  | typeof ViewMaterializedIcon
  | typeof ViewSecuredMaterializedIcon
  | typeof ViewSecuredIcon
  | typeof ViewIcon
  | typeof WaitActionCircleIcon
  | typeof WarehouseSnowflakeIcon
  | typeof WarehouseSnowparkIcon
  | typeof WarehouseIcon
  | typeof WarningTriangleSmallIcon
  | typeof WarningTriangleIcon
  | typeof WorksheetIcon
  | typeof WorkspacesIcon
  | typeof WritingHandIcon
  | typeof XSmallIcon
  | typeof ZoomResetIcon;
