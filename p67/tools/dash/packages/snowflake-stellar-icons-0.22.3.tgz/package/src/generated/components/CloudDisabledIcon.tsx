import { forwardRef, ForwardedRef } from "react";

import { CloudDisabledMediumIcon } from "./CloudDisabledMediumIcon";
import { CloudDisabledRegularIcon } from "./CloudDisabledRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CloudDisabledIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CloudDisabledIcon = forwardRef(
  (
    { size = "regular", ...props }: CloudDisabledIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CloudDisabledRegularIcon />;

    if (size === "medium") {
      icon = <CloudDisabledMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CloudDisabledIcon.displayName = "CloudDisabledIcon";

export type { CloudDisabledIconProps };
export { CloudDisabledIcon };
