import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BackfillJobRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M3.758 3.756a6.002 6.002 0 1 1 4.134 10.24l.11-.998c1.28 0 2.559-.487 3.535-1.463a5.002 5.002 0 0 0-7.072-7.072L3.929 5H6v1H2.5a.5.5 0 0 1-.5-.5l-.002-3.424H3l.001 2.438zM5.4 12.269a5 5 0 0 0 1.608.63l-.112.997a6 6 0 0 1-2.116-.835zM3.384 9.922a5 5 0 0 0 1.082 1.612q.066.067.137.13l-.62.791a6 6 0 0 1-1.523-2.148l.463-.193z" />
              <path d="m8.5 7.792 2.354 2.354-.707.707-2.5-2.5a.5.5 0 0 1-.147-.354V5h1z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BackfillJobRegularIcon.displayName = "BackfillJobRegularIcon";
export { BackfillJobRegularIcon };
