import { forwardRef, ForwardedRef } from "react";

import { CheckCircleMediumIcon } from "./CheckCircleMediumIcon";
import { CheckCircleRegularIcon } from "./CheckCircleRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CheckCircleIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CheckCircleIcon = forwardRef(
  (
    { size = "regular", ...props }: CheckCircleIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CheckCircleRegularIcon />;

    if (size === "medium") {
      icon = <CheckCircleMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CheckCircleIcon.displayName = "CheckCircleIcon";

export type { CheckCircleIconProps };
export { CheckCircleIcon };
