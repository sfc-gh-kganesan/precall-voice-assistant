import { forwardRef, ForwardedRef } from "react";

import { DollarSignMediumIcon } from "./DollarSignMediumIcon";
import { DollarSignRegularIcon } from "./DollarSignRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DollarSignIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DollarSignIcon = forwardRef(
  (
    { size = "regular", ...props }: DollarSignIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DollarSignRegularIcon />;

    if (size === "medium") {
      icon = <DollarSignMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DollarSignIcon.displayName = "DollarSignIcon";

export type { DollarSignIconProps };
export { DollarSignIcon };
