import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ComputePoolMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} fillRule="evenodd" clipRule="evenodd">
              <path d="M12.734 6.64c.346 0 .625.28.625.626v5.468c0 .346-.28.625-.625.625H7.266a.625.625 0 0 1-.625-.625V7.266c0-.346.28-.625.625-.625zm-4.843 5.47h4.218V7.89H7.891z" />
              <path d="M8.75 3.75h2.5v-2.5h1.25v2.5h1.875c1.036 0 1.875.84 1.875 1.875V7.5h2.5v1.25h-2.5v2.5h2.5v1.25h-2.5v1.875c0 1.036-.84 1.875-1.875 1.875H12.5v2.5h-1.25v-2.5h-2.5v2.5H7.5v-2.5H5.625a1.875 1.875 0 0 1-1.875-1.875V12.5h-2.5v-1.25h2.5v-2.5h-2.5V7.5h2.5V5.625c0-1.036.84-1.875 1.875-1.875H7.5v-2.5h1.25zM5.625 5A.625.625 0 0 0 5 5.625v8.75c0 .345.28.625.625.625h8.75c.345 0 .625-.28.625-.625v-8.75A.625.625 0 0 0 14.375 5z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ComputePoolMediumIcon.displayName = "ComputePoolMediumIcon";
export { ComputePoolMediumIcon };
