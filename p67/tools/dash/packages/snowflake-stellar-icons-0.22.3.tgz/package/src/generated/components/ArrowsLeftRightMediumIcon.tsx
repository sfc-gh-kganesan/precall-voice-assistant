import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowsLeftRightMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m7.317 11.072-2.683 2.683H17.5v1.25H4.634l2.683 2.683-.884.884-3.75-3.75a.626.626 0 0 1 0-.884l3.75-3.75zm10-5.889a.625.625 0 0 1 0 .884l-3.75 3.75-.884-.884 2.683-2.683H2.5V5h12.866l-2.683-2.683.884-.884z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowsLeftRightMediumIcon.displayName = "ArrowsLeftRightMediumIcon";
export { ArrowsLeftRightMediumIcon };
