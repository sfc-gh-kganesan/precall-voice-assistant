import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const ApplicationPackagesIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <path
              stroke={`url(#${idPrefix}-svg-4275650914__a)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M71 96V43"
            />
            <path
              stroke={`url(#${idPrefix}-svg-4275650914__b)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M115.5 61V43c0-8.837-7.163-16-16-16H92"
            />
            <path
              stroke={`url(#${idPrefix}-svg-4275650914__c)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M26.5 61V43c0-8.837 7.163-16 16-16H50"
            />
            <rect
              width={54}
              height={20}
              x={45}
              y={101}
              fill={`url(#${idPrefix}-svg-4275650914__d)`}
              rx={10}
            />
            <path
              fill={`url(#${idPrefix}-svg-4275650914__e)`}
              fillRule="evenodd"
              d="M61.949 110.949a6.264 6.264 0 1 1-12.529 0 6.264 6.264 0 0 1 12.529 0M66 107a1 1 0 0 1 1-1h21a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H67a1 1 0 0 1-1-1zm1 5a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1z"
              clipRule="evenodd"
            />
            <rect
              width={54}
              height={20}
              x={86}
              y={66}
              fill={`url(#${idPrefix}-svg-4275650914__f)`}
              rx={10}
            />
            <path
              fill={`url(#${idPrefix}-svg-4275650914__g)`}
              fillRule="evenodd"
              d="M102.949 75.949a6.264 6.264 0 1 1-12.529-.001 6.264 6.264 0 0 1 12.529 0M107 72a1 1 0 0 1 1-1h21a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-21a1 1 0 0 1-1-1zm1 5a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1z"
              clipRule="evenodd"
            />
            <rect
              width={54}
              height={20}
              x={2}
              y={66}
              fill={`url(#${idPrefix}-svg-4275650914__h)`}
              rx={10}
            />
            <path
              fill={`url(#${idPrefix}-svg-4275650914__i)`}
              fillRule="evenodd"
              d="M18.949 75.949a6.264 6.264 0 1 1-12.528 0 6.264 6.264 0 0 1 12.528 0M23 72a1 1 0 0 1 1-1h21a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H24a1 1 0 0 1-1-1zm1 5a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1z"
              clipRule="evenodd"
            />
            <rect
              width={48}
              height={48}
              x={47}
              y={5}
              fill={`url(#${idPrefix}-svg-4275650914__j)`}
              rx={10}
            />
            <path
              fill={`url(#${idPrefix}-svg-4275650914__k)`}
              d="M61.818 21.38a1 1 0 0 1 0-1.789l8.288-4.144a2 2 0 0 1 1.789 0l8.288 4.144a1 1 0 0 1 0 1.79l-8.288 4.143a2 2 0 0 1-1.79 0z"
            />
            <path
              fill={`url(#${idPrefix}-svg-4275650914__l)`}
              d="M69.174 40.64a1 1 0 0 1-1.435.901l-8.401-4.053a2 2 0 0 1-1.131-1.8l-.006-9.926a1 1 0 0 1 1.447-.895l8.419 4.209a2 2 0 0 1 1.106 1.788z"
            />
            <path
              fill={`url(#${idPrefix}-svg-4275650914__m)`}
              d="M83.8 35.687a2 2 0 0 1-1.13 1.801l-8.4 4.053a1 1 0 0 1-1.435-.9l.003-9.778a2 2 0 0 1 1.105-1.787l8.41-4.209a1 1 0 0 1 1.447.895z"
            />
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__a`}
                x1={66.023}
                x2={72.167}
                y1={52.172}
                y2={89.493}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#86B6FC" stopOpacity={0} />
                <stop offset={1} stopColor="#86B6FC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__b`}
                x1={91.5}
                x2={94.817}
                y1={16.5}
                y2={58.202}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#86B6FC" stopOpacity={0} />
                <stop offset={1} stopColor="#86B6FC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__c`}
                x1={50.5}
                x2={47.183}
                y1={16.5}
                y2={58.202}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#86B6FC" stopOpacity={0} />
                <stop offset={1} stopColor="#86B6FC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__d`}
                x1={86}
                x2={84.5}
                y1={67}
                y2={162.5}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.37} stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__e`}
                x1={134.499}
                x2={60.844}
                y1={11.501}
                y2={125.659}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#91BDFF" stopOpacity={0} />
                <stop offset={1} stopColor="#91BDFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__f`}
                x1={127}
                x2={125.5}
                y1={32}
                y2={127.5}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.37} stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__g`}
                x1={114.499}
                x2={85.089}
                y1={36.001}
                y2={69.799}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#6AA3FF" stopOpacity={0} />
                <stop offset={1} stopColor="#6AA3FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__h`}
                x1={43}
                x2={41.5}
                y1={32}
                y2={127.5}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.37} stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__i`}
                x1={30.499}
                x2={1.089}
                y1={36.001}
                y2={69.799}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#6AA3FF" stopOpacity={0} />
                <stop offset={1} stopColor="#6AA3FF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__j`}
                x1={85.809}
                x2={94.943}
                y1={3.13}
                y2={50.249}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__k`}
                x1={75}
                x2={72.413}
                y1={42.5}
                y2={-19.622}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__l`}
                x1={75}
                x2={72.413}
                y1={42.5}
                y2={-19.622}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-4275650914__m`}
                x1={75}
                x2={72.413}
                y1={42.5}
                y2={-19.622}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationPackagesIllustration.displayName = "ApplicationPackagesIllustration";
export { ApplicationPackagesIllustration };
