import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AnomalyRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8 4a.5.5 0 0 1 .485.379L10.391 12H15v1h-5a.5.5 0 0 1-.485-.379L8 6.563 6.485 12.62A.5.5 0 0 1 6 13h-.982a.5.5 0 0 1-.355-.148l-1.632-1.647-1.68 1.651-.702-.712 2.037-2 .079-.064a.5.5 0 0 1 .626.068L5.226 12h.383l1.906-7.621A.5.5 0 0 1 8 4" />
              <path d="M12.5 7.75a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5M13 3a.5.5 0 0 1 .493.582l-.5 3a.5.5 0 0 1-.986 0l-.5-3A.5.5 0 0 1 12 3z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AnomalyRegularIcon.displayName = "AnomalyRegularIcon";
export { AnomalyRegularIcon };
