import { forwardRef, ForwardedRef } from "react";

import { CriticalFillMediumIcon } from "./CriticalFillMediumIcon";
import { CriticalFillRegularIcon } from "./CriticalFillRegularIcon";

import { CriticalFill_1xIcon } from "./CriticalFill_1xIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";
import { IconWith1x } from "../../IconWith1x";

interface CriticalFillIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CriticalFillIcon = forwardRef(
  (
    { size = "regular", ...props }: CriticalFillIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = (
      <IconWith1x
        icon1x={CriticalFill_1xIcon}
        icon2x={CriticalFillRegularIcon}
      />
    );

    if (size === "medium") {
      icon = <CriticalFillMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CriticalFillIcon.displayName = "CriticalFillIcon";

export type { CriticalFillIconProps };
export { CriticalFillIcon };
