import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudHeartRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M7.928 7.132a2.293 2.293 0 0 1 3.253.095c.925.97.869 2.372.026 3.416-.511.632-1.527 1.553-3.007 2.747a.5.5 0 0 1-.636-.007c-1.423-1.194-2.407-2.112-2.915-2.74-.842-1.044-.897-2.445.028-3.416a2.29 2.29 0 0 1 3.25-.095m2.529.784a1.297 1.297 0 0 0-1.903 0l-.264.275a.5.5 0 0 1-.724 0l-.262-.275a1.297 1.297 0 0 0-1.904 0c-.525.552-.55 1.382.028 2.098.406.503 1.22 1.276 2.466 2.334 1.297-1.061 2.132-1.835 2.536-2.334.578-.716.552-1.546.027-2.098"
                clipRule="evenodd"
              />
              <path d="M8.07 2.015a3.97 3.97 0 0 1 3.367 2.543A4 4 0 0 1 15 8.533a3.99 3.99 0 0 1-2 3.458v-1.226a3 3 0 0 0 1-2.232 3 3 0 0 0-2.94-2.999l-.373-.008-.1-.358a2.97 2.97 0 0 0-2.603-2.157L7.731 3a2.967 2.967 0 0 0-2.966 2.967v.036l.006.47-.467.035A2.5 2.5 0 0 0 2 9c0 .817.394 1.54 1 1.996v1.16A3.49 3.49 0 0 1 1 9a3.5 3.5 0 0 1 2.783-3.426A3.97 3.97 0 0 1 7.731 2z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CloudHeartRegularIcon.displayName = "CloudHeartRegularIcon";
export { CloudHeartRegularIcon };
