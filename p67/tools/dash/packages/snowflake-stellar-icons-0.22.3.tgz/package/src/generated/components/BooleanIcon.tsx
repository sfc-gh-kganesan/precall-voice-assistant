import { forwardRef, ForwardedRef } from "react";

import { BooleanMediumIcon } from "./BooleanMediumIcon";
import { BooleanRegularIcon } from "./BooleanRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BooleanIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BooleanIcon = forwardRef(
  (
    { size = "regular", ...props }: BooleanIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BooleanRegularIcon />;

    if (size === "medium") {
      icon = <BooleanMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BooleanIcon.displayName = "BooleanIcon";

export type { BooleanIconProps };
export { BooleanIcon };
