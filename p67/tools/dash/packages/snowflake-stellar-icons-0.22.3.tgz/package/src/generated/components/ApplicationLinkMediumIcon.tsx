import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationLinkMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path d="M12.5 13.75h-2.38a2.514 2.514 0 0 0 0 5.026h2.38v1.25h-2.38a3.763 3.763 0 1 1 0-7.526h2.38zm3.737-1.25a3.764 3.764 0 0 1 0 7.526h-2.41v-1.25h2.41a2.513 2.513 0 0 0 0-5.026h-2.41V12.5z" />
              <path d="M16.25 16.875H10v-1.25h6.25zM9.692 1.644a.63.63 0 0 1 .617 0l6.878 3.907a.63.63 0 0 1 .316.543v5.156h-1.25V6.456L10 2.906l-6.253 3.55v7.087l1.252.71v1.44L2.814 14.45a.63.63 0 0 1-.316-.544V6.094l.006-.083a.63.63 0 0 1 .31-.46z" />
              <path d="M10 6.25A3.75 3.75 0 0 1 13.75 10c0 .439-.08.859-.218 1.25h-1.368A2.5 2.5 0 1 0 7.5 10c0 .456.123.882.336 1.25h-1.37A3.7 3.7 0 0 1 6.25 10 3.75 3.75 0 0 1 10 6.25" />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h20v20H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationLinkMediumIcon.displayName = "ApplicationLinkMediumIcon";
export { ApplicationLinkMediumIcon };
