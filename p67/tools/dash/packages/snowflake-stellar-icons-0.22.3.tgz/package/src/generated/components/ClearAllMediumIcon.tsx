import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClearAllMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M16.966 5.518a1.876 1.876 0 0 0-3.248-1.875L11.5 7.486a3.13 3.13 0 0 0-3.698 1.402L7.177 9.97l-.012.03-4.546 6.557a.626.626 0 0 0 .511.98l11.25.045a.626.626 0 0 0 .627-.625l.001-3.047.372-.647a3.13 3.13 0 0 0-.633-3.902zM13.758 16.33l-2.161-.009.912-1.582-1.082-.625-1.27 2.201-1.968-.008 1.53-2.651-1.083-.625-1.875 3.247.043.023-2.48-.01 3.588-5.175 5.847 3.376zm1.897-12.29c.298.172.4.554.228.853l-2.812 4.872.54.311.163.105a1.876 1.876 0 0 1 .524 2.457l-.18.313-5.39-3.166.157-.272a1.877 1.877 0 0 1 2.39-.774l.17.087.544.314L14.8 4.268a.626.626 0 0 1 .854-.229"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClearAllMediumIcon.displayName = "ClearAllMediumIcon";
export { ClearAllMediumIcon };
