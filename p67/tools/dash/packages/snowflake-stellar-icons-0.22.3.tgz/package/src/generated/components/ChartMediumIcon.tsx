import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M16.25 2.5a2.5 2.5 0 1 1-.494 4.95l-1.515 3.258a2.5 2.5 0 1 1-3.893.524L8.768 9.65a2.48 2.48 0 0 1-1.792.292L5.39 13.117c.527.458.861 1.13.861 1.883a2.5 2.5 0 1 1-1.978-2.445l1.586-3.173A2.5 2.5 0 1 1 10 7.5c0 .463-.13.895-.35 1.267l1.582 1.58a2.5 2.5 0 0 1 1.919-.26l1.48-3.184A2.5 2.5 0 0 1 16.25 2.5M3.75 13.75a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m8.75-2.5a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m-5-5a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m8.75-2.5a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartMediumIcon.displayName = "ChartMediumIcon";
export { ChartMediumIcon };
