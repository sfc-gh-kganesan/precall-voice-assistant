import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClassicConsoleRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M13 14H3v-1h10zM3 13H2V3h1zm11 0h-1V3h1zm-3-2H7v-1h4zm-5-1H5V9h1zm1-1H6V8h1zm1-1H7V7h1zM7 7H6V6h1zM6 6H5V5h1zm7-3H3V2h10z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClassicConsoleRegularIcon.displayName = "ClassicConsoleRegularIcon";
export { ClassicConsoleRegularIcon };
