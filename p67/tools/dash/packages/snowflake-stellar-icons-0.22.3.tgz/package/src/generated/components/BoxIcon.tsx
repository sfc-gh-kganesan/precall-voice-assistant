import { forwardRef, ForwardedRef } from "react";

import { BoxMediumIcon } from "./BoxMediumIcon";
import { BoxRegularIcon } from "./BoxRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BoxIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BoxIcon = forwardRef(
  (
    { size = "regular", ...props }: BoxIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BoxRegularIcon />;

    if (size === "medium") {
      icon = <BoxMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BoxIcon.displayName = "BoxIcon";

export type { BoxIconProps };
export { BoxIcon };
