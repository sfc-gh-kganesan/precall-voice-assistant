import { forwardRef, ForwardedRef } from "react";

import { CellExpandMediumIcon } from "./CellExpandMediumIcon";
import { CellExpandRegularIcon } from "./CellExpandRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CellExpandIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CellExpandIcon = forwardRef(
  (
    { size = "regular", ...props }: CellExpandIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CellExpandRegularIcon />;

    if (size === "medium") {
      icon = <CellExpandMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CellExpandIcon.displayName = "CellExpandIcon";

export type { CellExpandIconProps };
export { CellExpandIcon };
