import { forwardRef, ForwardedRef } from "react";

import { DataSemanticMediumIcon } from "./DataSemanticMediumIcon";
import { DataSemanticRegularIcon } from "./DataSemanticRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DataSemanticIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DataSemanticIcon = forwardRef(
  (
    { size = "regular", ...props }: DataSemanticIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DataSemanticRegularIcon />;

    if (size === "medium") {
      icon = <DataSemanticMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DataSemanticIcon.displayName = "DataSemanticIcon";

export type { DataSemanticIconProps };
export { DataSemanticIcon };
