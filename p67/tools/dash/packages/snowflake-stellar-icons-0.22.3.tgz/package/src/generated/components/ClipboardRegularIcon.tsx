import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClipboardRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M11.5 3A1.5 1.5 0 0 1 13 4.5v9a1.5 1.5 0 0 1-1.5 1.5h-7A1.5 1.5 0 0 1 3 13.5v-9A1.5 1.5 0 0 1 4.5 3H6a2 2 0 0 1 2-2l.204.01A2 2 0 0 1 9.99 2.797L10 3zM9 3a1 1 0 0 0-2 0zM4.5 4a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5H11v2.5a.5.5 0 0 1-.4.49l-.1.01h-5l-.1-.01A.5.5 0 0 1 5 6.5V4zM6 6h4V4H6z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClipboardRegularIcon.displayName = "ClipboardRegularIcon";
export { ClipboardRegularIcon };
