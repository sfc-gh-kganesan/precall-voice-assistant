import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CalendarCheckmarkMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="m14.192 9.192-5 5a.625.625 0 0 1-.884 0l-2.5-2.5.884-.884 2.058 2.058 4.558-4.558z" />
              <path
                fillRule="evenodd"
                d="M7.5 3.75h5V2.5h1.25v1.25h1.875c1.035 0 1.875.84 1.875 1.875v10c0 1.035-.84 1.875-1.875 1.875H4.375A1.875 1.875 0 0 1 2.5 15.625v-10c0-1.036.84-1.875 1.875-1.875H6.25V2.5H7.5zM4.375 5a.625.625 0 0 0-.625.625v10c0 .345.28.625.625.625h11.25c.345 0 .625-.28.625-.625v-10A.625.625 0 0 0 15.625 5H13.75v1.25H12.5V5h-5v1.25H6.25V5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CalendarCheckmarkMediumIcon.displayName = "CalendarCheckmarkMediumIcon";
export { CalendarCheckmarkMediumIcon };
