import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BookClosedMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M15 1.25c.69 0 1.25.56 1.25 1.25v11.349c-1.227.851-1.227 2.7 0 3.55v1.351H6.875a3.125 3.125 0 0 1-3.125-3.125V3.75a2.5 2.5 0 0 1 2.5-2.5zm-8.125 12.5a1.875 1.875 0 0 0 0 3.75h7.758a3.46 3.46 0 0 1 0-3.75zM6.25 2.5C5.56 2.5 5 3.06 5 3.75v9.379a3.1 3.1 0 0 1 1.875-.629H7.5v-10zm2.5 10H15v-10H8.75z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BookClosedMediumIcon.displayName = "BookClosedMediumIcon";
export { BookClosedMediumIcon };
