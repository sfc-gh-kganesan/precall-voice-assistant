import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const AlertCirclePictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <circle cx={23.75} cy={32.25} r={2.25} fill={iconColor} />
            <circle cx={25} cy={24} r={18} stroke={iconColor} strokeWidth={2} />
            <path
              fill={iconColor}
              d="M25.074 27h-.648a1 1 0 0 1-.997-.923l-.846-11A1 1 0 0 1 23.58 14h2.34a1 1 0 0 1 .997 1.077l-.846 11a1 1 0 0 1-.997.923"
            />
          </>
        }
        {...props}
      />
    );
  },
);
AlertCirclePictogram.displayName = "AlertCirclePictogram";
export { AlertCirclePictogram };
