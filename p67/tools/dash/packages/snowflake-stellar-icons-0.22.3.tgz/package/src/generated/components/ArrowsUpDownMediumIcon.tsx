import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowsUpDownMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M8.928 7.317 6.245 4.634V17.5h-1.25V4.634L2.312 7.317l-.884-.884 3.75-3.75a.626.626 0 0 1 .884 0l3.75 3.75zm5.889 10a.625.625 0 0 1-.884 0l-3.75-3.75.884-.884 2.683 2.683V2.5H15v12.866l2.683-2.683.884.884z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowsUpDownMediumIcon.displayName = "ArrowsUpDownMediumIcon";
export { ArrowsUpDownMediumIcon };
