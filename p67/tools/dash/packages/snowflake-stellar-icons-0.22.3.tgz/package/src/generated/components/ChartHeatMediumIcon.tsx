import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartHeatMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M13.438 11.875a1.563 1.563 0 1 1 0 3.125 1.563 1.563 0 0 1 0-3.125M6.563 5a1.562 1.562 0 1 1 0 3.125 1.562 1.562 0 0 1 0-3.125m6.875 0a1.563 1.563 0 1 1 0 3.125 1.563 1.563 0 0 1 0-3.125" />
              <path
                fillRule="evenodd"
                d="M15.625 2.5c1.035 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875H4.375A1.875 1.875 0 0 1 2.5 15.625V4.375C2.5 3.34 3.34 2.5 4.375 2.5zM3.75 10.625v5c0 .345.28.625.625.625h5v-5.625zm6.875 0v5.625h5c.345 0 .625-.28.625-.625v-5zM4.375 3.75a.625.625 0 0 0-.625.625v5h5.625V3.75zm6.25 5.625h5.625v-5a.625.625 0 0 0-.625-.625h-5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ChartHeatMediumIcon.displayName = "ChartHeatMediumIcon";
export { ChartHeatMediumIcon };
