import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowRightCurvedRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M14 8.5a.5.5 0 0 1-.146.354l-4 4-.708-.707L12.293 9H3.5A1.5 1.5 0 0 1 2 7.5V2h1v5.5a.5.5 0 0 0 .5.5h8.793L9.146 4.854l.708-.708 4 4A.5.5 0 0 1 14 8.5"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowRightCurvedRegularIcon.displayName = "ArrowRightCurvedRegularIcon";
export { ArrowRightCurvedRegularIcon };
