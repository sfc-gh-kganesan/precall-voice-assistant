import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CalendarPlusMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M16.254 15.004H20v1.25h-3.746V20h-1.25v-3.746H11.25v-1.25h3.754V11.25h1.25z" />
              <path
                fillRule="evenodd"
                d="M7.5 3.75h5V2.5h1.25v1.25h1.875c1.035 0 1.875.84 1.875 1.875V8.75H3.75v6.875c0 .345.28.625.625.625H8.75v1.25H4.375A1.875 1.875 0 0 1 2.5 15.625v-10c0-1.036.84-1.875 1.875-1.875H6.25V2.5H7.5zM4.375 5a.625.625 0 0 0-.625.625V7.5h12.5V5.625A.625.625 0 0 0 15.625 5H13.75v1.25H12.5V5h-5v1.25H6.25V5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CalendarPlusMediumIcon.displayName = "CalendarPlusMediumIcon";
export { CalendarPlusMediumIcon };
