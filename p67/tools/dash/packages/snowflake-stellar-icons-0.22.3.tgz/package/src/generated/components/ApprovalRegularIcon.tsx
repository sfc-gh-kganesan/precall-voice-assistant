import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApprovalRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M12 14H4v-1h8z" />
              <path
                fillRule="evenodd"
                d="M6.054 2.148a6.16 6.16 0 0 1 3.892 0c.599.2.95.82.813 1.436l-.682 3.07-.022.17a1 1 0 0 0 .104.493L10.5 8H13a1 1 0 0 1 1 1v2l-.005.102c-.048.47-.422.845-.893.893L13 12H3l-.103-.005A1 1 0 0 1 2 11V9a1 1 0 0 1 1-1h2.5l.34-.683a1 1 0 0 0 .083-.664l-.682-3.07a1.23 1.23 0 0 1 .703-1.392zM3 11h10V9H3zm6.63-7.903a5.16 5.16 0 0 0-3.26 0 .23.23 0 0 0-.153.27l.682 3.07a2 2 0 0 1-.164 1.327L6.618 8h2.764l-.117-.236A2 2 0 0 1 9.1 6.436l.682-3.069a.23.23 0 0 0-.152-.27"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ApprovalRegularIcon.displayName = "ApprovalRegularIcon";
export { ApprovalRegularIcon };
