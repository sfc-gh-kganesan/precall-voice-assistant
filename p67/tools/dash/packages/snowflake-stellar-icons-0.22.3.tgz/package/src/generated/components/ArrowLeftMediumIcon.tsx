import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowLeftMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M2.5 10c0-.166.066-.325.183-.442l6.25-6.25.884.884-5.183 5.183H17.5v1.25H4.634l5.183 5.183-.884.884-6.25-6.25A.63.63 0 0 1 2.5 10"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowLeftMediumIcon.displayName = "ArrowLeftMediumIcon";
export { ArrowLeftMediumIcon };
