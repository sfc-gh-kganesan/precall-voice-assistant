import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronsCollapseMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M9.656 11.978a.626.626 0 0 1 .786.08l5 5-.884.884L10 13.384l-4.558 4.558-.884-.884 5-5zm5.786-9.036-5 5a.625.625 0 0 1-.884 0l-5-5 .884-.884L10 6.616l4.558-4.558z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronsCollapseMediumIcon.displayName = "ChevronsCollapseMediumIcon";
export { ChevronsCollapseMediumIcon };
