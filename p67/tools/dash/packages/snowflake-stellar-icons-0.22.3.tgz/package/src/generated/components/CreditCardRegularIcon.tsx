import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CreditCardRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M7 11H3v-1h4z" />
              <path
                fillRule="evenodd"
                d="M13.5 3A1.5 1.5 0 0 1 15 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 1 11.5v-7A1.5 1.5 0 0 1 2.5 3zM2 7v4.5a.5.5 0 0 0 .5.5h11a.5.5 0 0 0 .5-.5V7zm.5-3a.5.5 0 0 0-.5.5V5h12v-.5a.5.5 0 0 0-.5-.5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CreditCardRegularIcon.displayName = "CreditCardRegularIcon";
export { CreditCardRegularIcon };
