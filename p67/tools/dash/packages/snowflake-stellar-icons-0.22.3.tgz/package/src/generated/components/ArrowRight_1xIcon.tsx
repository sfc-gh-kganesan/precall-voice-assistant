import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowRight_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M14 7.5a.5.5 0 0 1-.146.354l-5 5-.708-.707L12.293 8H2V7h10.293L8.146 2.854l.708-.708 5 5A.5.5 0 0 1 14 7.5"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowRight_1xIcon.displayName = "ArrowRight_1xIcon";
export { ArrowRight_1xIcon };
