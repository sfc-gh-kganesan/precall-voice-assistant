import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CircleFillRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path fill={iconColor} d="M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0" />
          </>
        }
        {...props}
      />
    );
  },
);
CircleFillRegularIcon.displayName = "CircleFillRegularIcon";
export { CircleFillRegularIcon };
