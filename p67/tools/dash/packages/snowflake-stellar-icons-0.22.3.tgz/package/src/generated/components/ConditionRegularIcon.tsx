import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ConditionRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="m8.353 7.354-2.5 2.5a.5.5 0 0 1-.707 0l-1.5-1.5.707-.707 1.146 1.146 2.147-2.146z" />
              <path
                fillRule="evenodd"
                d="M8.939 3.353a1.5 1.5 0 0 1 2.12 0l3.587 3.586a1.5 1.5 0 0 1 0 2.12l-3.586 3.587a1.5 1.5 0 0 1-2.121 0L8 11.707l-.94.94a1.5 1.5 0 0 1-2.121 0L1.353 9.06a1.5 1.5 0 0 1 0-2.121l3.586-3.586a1.5 1.5 0 0 1 2.122 0l.938.938zm-2.585.708a.5.5 0 0 0-.708 0L2.06 7.647a.5.5 0 0 0 0 .707l3.586 3.586a.5.5 0 0 0 .708 0L9.94 8.354a.5.5 0 0 0 0-.707zm3.999-.001a.5.5 0 0 0-.707 0l-.94.94 1.94 1.94a1.5 1.5 0 0 1 0 2.12L8.708 11l.939.939a.5.5 0 0 0 .707 0l3.586-3.586a.5.5 0 0 0 0-.707z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ConditionRegularIcon.displayName = "ConditionRegularIcon";
export { ConditionRegularIcon };
