import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CommentRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M9 9H5V8h4zm2-2H5V6h6z" />
              <path
                fillRule="evenodd"
                d="M12.5 3A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5H5.138l-2.381 1.429A.5.5 0 0 1 2 14V4.5A1.5 1.5 0 0 1 3.5 3zm-9 1a.5.5 0 0 0-.5.5v8.617l1.743-1.046.06-.031A.5.5 0 0 1 5 12h7.5a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.5-.5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CommentRegularIcon.displayName = "CommentRegularIcon";
export { CommentRegularIcon };
