import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartLineMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M3.75 11.616 6.616 8.75a1.25 1.25 0 0 1 1.768 0l2.241 2.241 5.183-5.183.884.884-5.183 5.183a1.25 1.25 0 0 1-1.768 0L7.5 9.634l-3.75 3.75v2.866h13.125v1.25H3.125a.625.625 0 0 1-.625-.625V2.5h1.25z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartLineMediumIcon.displayName = "ChartLineMediumIcon";
export { ChartLineMediumIcon };
