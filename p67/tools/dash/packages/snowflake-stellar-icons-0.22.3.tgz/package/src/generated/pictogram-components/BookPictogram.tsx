import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const BookPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M37 12h2a1 1 0 0 1 1 1v29a1 1 0 0 1-1 1H14a5 5 0 0 1-5-5V10a4 4 0 0 1 4-4h23a1 1 0 0 1 1 1zm-2 0V8H13a2 2 0 1 0 0 4zm.999 2H13a4 4 0 0 1-2-.535V38a3 3 0 0 0 3 3h24V14H36"
              clipRule="evenodd"
            />
            <circle
              cx={24.5}
              cy={27.369}
              r={7.226}
              stroke={iconColor}
              strokeWidth={2}
              transform="rotate(-180 24.5 27.369)"
            />
            <path
              stroke={iconColor}
              strokeLinecap="round"
              strokeWidth={2}
              d="M24.48 24.392v-.066M24.48 30.428v-2.603"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BookPictogram.displayName = "BookPictogram";
export { BookPictogram };
