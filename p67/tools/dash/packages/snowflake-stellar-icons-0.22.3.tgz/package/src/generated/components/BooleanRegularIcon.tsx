import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BooleanRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M11.5 10.5a1 1 0 1 1 0 2h-3a1 1 0 1 1 0-2z" />
              <path
                fillRule="evenodd"
                d="M11.5 9a2.5 2.5 0 0 1 0 5h-7a2.5 2.5 0 0 1 0-5zm-7 1a1.5 1.5 0 0 0 0 3h7a1.5 1.5 0 0 0 0-3z"
                clipRule="evenodd"
              />
              <path d="M7.5 3.5a1 1 0 0 1 0 2h-3a1 1 0 0 1 0-2z" />
              <path
                fillRule="evenodd"
                d="M11.5 2a2.5 2.5 0 0 1 0 5h-7a2.5 2.5 0 0 1 0-5zm-7 1a1.5 1.5 0 1 0 0 3h7a1.5 1.5 0 0 0 0-3z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BooleanRegularIcon.displayName = "BooleanRegularIcon";
export { BooleanRegularIcon };
