import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DataExchangeRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.936 2.005a3.97 3.97 0 0 1 3.73 3.468A3.533 3.533 0 0 1 15 9l-.004.176a3.534 3.534 0 0 1-3.348 3.352l-.012.001-.156.004H11v-1h.454l.151-.004a2.53 2.53 0 0 0 2.382-2.278L14 9c0-1.312-.997-2.39-2.274-2.52l-.26-.013q-.114 0-.225.01l-.546.047.002-.547v-.019a2.966 2.966 0 0 0-2.813-2.954L7.73 3a2.967 2.967 0 0 0-2.966 2.967l.006.194q.019.289.09.56l.184.7-.72-.076A2.1 2.1 0 0 0 2 9.434l.01.214a2.1 2.1 0 0 0 2.09 1.885h3.226L5.624 9.831l.707-.707 2.523 2.522a.5.5 0 0 1 0 .707l-2.479 2.478-.707-.707 1.59-1.59H4.1a3.1 3.1 0 0 1-3.096-2.941L1 9.433a3.1 3.1 0 0 1 2.785-3.085A3.967 3.967 0 0 1 7.731 2z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataExchangeRegularIcon.displayName = "DataExchangeRegularIcon";
export { DataExchangeRegularIcon };
