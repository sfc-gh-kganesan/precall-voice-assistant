import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ContainerMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10.336 1.348a.63.63 0 0 0-.672 0L2.79 5.723a.63.63 0 0 0-.289.527v7.5c0 .214.11.413.29.527l6.874 4.375.08.043c.19.086.413.071.592-.043l6.875-4.375a.63.63 0 0 0 .289-.527v-7.5a.63.63 0 0 0-.29-.527zm5.914 12.059-5.625 3.58V10.97l5.625-3.58zm-6.875-2.438v6.018l-1.062-.676v-6.018zM7.063 9.497v6.018l-1.001-.637V8.86zM4.812 8.064v6.018l-1.062-.675V7.389zM15.71 6.25 10 9.884 4.288 6.25 10 2.616z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ContainerMediumIcon.displayName = "ContainerMediumIcon";
export { ContainerMediumIcon };
