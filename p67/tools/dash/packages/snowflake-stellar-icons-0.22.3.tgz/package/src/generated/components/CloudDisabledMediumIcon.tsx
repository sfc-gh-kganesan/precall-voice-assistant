import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CloudDisabledMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="m17.758 16.875-.883.884-1.576-1.576a4.4 4.4 0 0 1-.739.102l-.015.001-.196.005H5.125a3.875 3.875 0 0 1-3.87-3.675l-.005-.2a3.877 3.877 0 0 1 3.458-3.853c.024-.842.26-1.632.653-2.318l-1.87-1.87.883-.883zM6.29 7.174a3.7 3.7 0 0 0-.334 1.534l.005.204q.005.1.016.198l.079.742-.745-.051c-.081-.006-.135-.01-.186-.01A2.626 2.626 0 0 0 2.5 12.417l.013.268a2.626 2.626 0 0 0 2.612 2.356h9.033z"
                clipRule="evenodd"
              />
              <path d="M9.897 3.755a4.96 4.96 0 0 1 4.565 3.706 4.416 4.416 0 0 1 4.288 4.414l-.005.22a4.4 4.4 0 0 1-1.199 2.801l-.882-.883c.451-.49.751-1.123.82-1.825l.016-.313a3.167 3.167 0 0 0-2.843-3.15l-.323-.017q-.164 0-.318.015l-.598.06-.083-.595a3.71 3.71 0 0 0-3.324-3.172L9.664 5c-.586 0-1.139.14-1.632.382l-.923-.923a4.93 4.93 0 0 1 2.555-.71z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CloudDisabledMediumIcon.displayName = "CloudDisabledMediumIcon";
export { CloudDisabledMediumIcon };
