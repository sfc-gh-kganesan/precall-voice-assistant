import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApiRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M8.255 1.705a3.5 3.5 0 0 1 2.981 2.305A3 3 0 0 1 14 7l-.004.154a3 3 0 0 1-.8 1.885.5.5 0 0 1 .304.461v1.565A1.999 1.999 0 1 1 11 13a2 2 0 0 1 1.5-1.935V10h-2v-.002h-2v1.067A1.999 1.999 0 1 1 6 13a2 2 0 0 1 1.5-1.935V9.998H5.056l-.02.001L5 10H3.5v1.065A1.999 1.999 0 1 1 1 13a2 2 0 0 1 1.5-1.935V9.5A.5.5 0 0 1 3 9a2.5 2.5 0 0 1-.487-1.244L2.5 7.5a2.5 2.5 0 0 1 1.95-2.438 3.5 3.5 0 0 1 3.497-3.37zM3 12a1 1 0 1 0 0 2 1 1 0 0 0 0-2m5 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2m5 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2M7.947 2.691a2.5 2.5 0 0 0-2.487 2.76l.056.54-.544.01A1.5 1.5 0 0 0 3.5 7.5l.008.153A1.5 1.5 0 0 0 4.989 9h.007l.032-.001h5.94L11 9h.008a2 2 0 0 0 1.981-1.795L13 7a2 2 0 0 0-2-2c-.028 0-.048.002-.108.005l-.418.022-.096-.407a2.5 2.5 0 0 0-2.211-1.919z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ApiRegularIcon.displayName = "ApiRegularIcon";
export { ApiRegularIcon };
