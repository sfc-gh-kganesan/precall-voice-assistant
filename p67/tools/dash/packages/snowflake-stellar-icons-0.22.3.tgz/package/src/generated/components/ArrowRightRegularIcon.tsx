import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowRightRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M14 8a.5.5 0 0 1-.146.354l-5 5-.708-.707L12.293 8.5H2v-1h10.293L8.146 3.354l.708-.708 5 5A.5.5 0 0 1 14 8"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowRightRegularIcon.displayName = "ArrowRightRegularIcon";
export { ArrowRightRegularIcon };
