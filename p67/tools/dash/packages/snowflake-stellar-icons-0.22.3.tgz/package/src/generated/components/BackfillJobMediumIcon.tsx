import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BackfillJobMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M4.698 4.695a7.504 7.504 0 0 1 10.609 0 7.5 7.5 0 0 1-.002 10.607 7.48 7.48 0 0 1-5.44 2.194l.138-1.248a6.252 6.252 0 0 0 4.42-10.669 6.254 6.254 0 0 0-8.842 0l-.67.67h2.59V7.5H3.126a.626.626 0 0 1-.625-.625L2.5 2.594h1.25l.001 3.047zM6.75 15.336a6.2 6.2 0 0 0 2.01.788l-.14 1.246a7.5 7.5 0 0 1-2.644-1.044zm-2.52-2.933a6.2 6.2 0 0 0 1.353 2.015q.083.084.17.163l-.774.988a7.6 7.6 0 0 1-1.904-2.685l.579-.24z" />
              <path d="m10.625 9.74 2.942 2.942-.884.884-3.125-3.125A.63.63 0 0 1 9.375 10V6.25h1.25z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BackfillJobMediumIcon.displayName = "BackfillJobMediumIcon";
export { BackfillJobMediumIcon };
