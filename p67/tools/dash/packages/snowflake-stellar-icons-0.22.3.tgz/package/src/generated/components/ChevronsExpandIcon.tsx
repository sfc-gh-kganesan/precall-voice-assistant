import { forwardRef, ForwardedRef } from "react";

import { ChevronsExpandMediumIcon } from "./ChevronsExpandMediumIcon";
import { ChevronsExpandRegularIcon } from "./ChevronsExpandRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronsExpandIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronsExpandIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronsExpandIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronsExpandRegularIcon />;

    if (size === "medium") {
      icon = <ChevronsExpandMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronsExpandIcon.displayName = "ChevronsExpandIcon";

export type { ChevronsExpandIconProps };
export { ChevronsExpandIcon };
