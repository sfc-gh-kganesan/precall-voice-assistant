import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const DocumentAiIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <rect
              width={77}
              height={86.758}
              x={110}
              y={113.758}
              fill={`url(#${idPrefix}-svg-1014669526__a)`}
              rx={10}
              transform="rotate(-180 110 113.758)"
            />
            <path
              fill={`url(#${idPrefix}-svg-1014669526__b)`}
              fillRule="evenodd"
              d="M78.868 38.758a2 2 0 0 0-2-2H65.206a2 2 0 0 0-2 2v1.463a2 2 0 0 0 2 2h11.662a2 2 0 0 0 2-2zm4.89 8.055a2 2 0 0 0-2-2H60.313a2 2 0 0 0-2 2v1.464a2 2 0 0 0 2 2h21.447a2 2 0 0 0 2-2zM42.003 60.09a4 4 0 0 1 4-4H97a4 4 0 0 1 4 4v11.334a4 4 0 0 1-4 4H46.002a4 4 0 0 1-4-4zM99 94.472a2 2 0 0 1 2 2v1.64a2 2 0 0 1-2 1.999H44a2 2 0 0 1-2-2v-1.639a2 2 0 0 1 2-2zM99 84a2 2 0 0 1 2 2v1.639a2 2 0 0 1-2 2H44a2 2 0 0 1-2-2V86a2 2 0 0 1 2-2z"
              clipRule="evenodd"
            />
            <path
              stroke={`url(#${idPrefix}-svg-1014669526__c)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M21.002 72.5v12a8 8 0 0 0 8 8H35"
            />
            <path
              fill={`url(#${idPrefix}-svg-1014669526__d)`}
              d="M0 52a5 5 0 0 1 5-5h37.088a5 5 0 0 1 5 5v11.64a5 5 0 0 1-5 5H5a5 5 0 0 1-5-5z"
            />
            <path
              fill={`url(#${idPrefix}-svg-1014669526__e)`}
              fillRule="evenodd"
              d="M41 61a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h33a1 1 0 0 0 1-1zm-12-8a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h21a1 1 0 0 0 1-1z"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-1014669526__f)`}
              d="M85.824 22a6 6 0 0 1 6-6H136a6 6 0 0 1 6 6v13a6 6 0 0 1-6 6H91.824a6 6 0 0 1-6-6z"
            />
            <path
              fill={`url(#${idPrefix}-svg-1014669526__g)`}
              fillRule="evenodd"
              d="M133 22a1 1 0 0 0-1-1H95a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h37a1 1 0 0 0 1-1zm-8 9a1 1 0 0 0-1-1H95a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h29a1 1 0 0 0 1-1z"
              clipRule="evenodd"
            />
            <path
              stroke={`url(#${idPrefix}-svg-1014669526__h)`}
              strokeDasharray="1 5"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={3}
              d="M122.5 44v13.5a8 8 0 0 1-8 8h-16"
            />
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-1014669526__a`}
                x1={156.38}
                x2={306.764}
                y1={210.683}
                y2={113.274}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#EAF2FF" />
                <stop offset={1} stopColor="#76AEFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1014669526__b`}
                x1={58.976}
                x2={155.976}
                y1={20.758}
                y2={125.758}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.318} stopColor="#96C2FF" />
                <stop offset={1} stopColor="#D6E6FF" stopOpacity={0.47} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1014669526__c`}
                x1={12.502}
                x2={49.948}
                y1={58.5}
                y2={78.325}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.161} stopColor="#86B6FC" />
                <stop offset={1} stopColor="#86B6FC" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1014669526__d`}
                x1={13.734}
                x2={17.387}
                y1={28.833}
                y2={83.656}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1014669526__e`}
                x1={7.611}
                x2={44.399}
                y1={65.394}
                y2={29.241}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1014669526__f`}
                x1={102.209}
                x2={106.297}
                y1={-4.988}
                y2={58.366}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1014669526__g`}
                x1={94.666}
                x2={139.455}
                y1={40.447}
                y2={0.652}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1014669526__h`}
                x1={148.5}
                x2={83.203}
                y1={29}
                y2={62.592}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.161} stopColor="#86B6FC" />
                <stop offset={1} stopColor="#86B6FC" stopOpacity={0} />
              </linearGradient>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
DocumentAiIllustration.displayName = "DocumentAiIllustration";
export { DocumentAiIllustration };
