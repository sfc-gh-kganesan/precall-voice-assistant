import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
import { IconProps } from "../../types";
const ArrowLeftBoldIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        {...props}
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              d="M2 8a1 1 0 0 1 .293-.707l5-5 1.414 1.414L5.414 7H14v2H5.414l3.293 3.293-1.414 1.414-5-5A1 1 0 0 1 2 8"
            />
          </>
        }
      />
    );
  },
);
ArrowLeftBoldIcon.displayName = "ArrowLeftBoldIcon";
export { ArrowLeftBoldIcon };
