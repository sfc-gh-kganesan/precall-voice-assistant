import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DataSharingMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10 1.25c1.726 0 3.125 1.4 3.125 3.125 0 .042-.006.083-.007.125a6.87 6.87 0 0 1 3.757 6.125q-.002.438-.057.862a3.125 3.125 0 1 1-3.401 5.099A6.8 6.8 0 0 1 10 17.5a6.83 6.83 0 0 1-3.42-.913 3.125 3.125 0 1 1-3.4-5.1 6.87 6.87 0 0 1 3.7-6.986c0-.042-.005-.084-.005-.126 0-1.726 1.4-3.125 3.125-3.125M4.375 12.5a1.875 1.875 0 1 0 0 3.75 1.875 1.875 0 0 0 0-3.75m2.822-6.75a5.62 5.62 0 0 0-2.787 5.5 3.124 3.124 0 0 1 2.863 4.289 5.59 5.59 0 0 0 5.453-.002 3.124 3.124 0 0 1 2.861-4.287q.037-.308.038-.626a5.62 5.62 0 0 0-2.823-4.874A3.12 3.12 0 0 1 10 7.5a3.12 3.12 0 0 1-2.803-1.75m8.428 6.75a1.875 1.875 0 1 0 0 3.75 1.875 1.875 0 0 0 0-3.75M10 2.5a1.875 1.875 0 1 0 0 3.75 1.875 1.875 0 0 0 0-3.75"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataSharingMediumIcon.displayName = "DataSharingMediumIcon";
export { DataSharingMediumIcon };
