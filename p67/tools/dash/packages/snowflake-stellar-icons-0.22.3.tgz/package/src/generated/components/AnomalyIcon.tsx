import { forwardRef, ForwardedRef } from "react";

import { AnomalyMediumIcon } from "./AnomalyMediumIcon";
import { AnomalyRegularIcon } from "./AnomalyRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AnomalyIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AnomalyIcon = forwardRef(
  (
    { size = "regular", ...props }: AnomalyIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AnomalyRegularIcon />;

    if (size === "medium") {
      icon = <AnomalyMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AnomalyIcon.displayName = "AnomalyIcon";

export type { AnomalyIconProps };
export { AnomalyIcon };
