import { forwardRef, ForwardedRef } from "react";

import { CircleEmptyMediumIcon } from "./CircleEmptyMediumIcon";
import { CircleEmptyRegularIcon } from "./CircleEmptyRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CircleEmptyIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CircleEmptyIcon = forwardRef(
  (
    { size = "regular", ...props }: CircleEmptyIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CircleEmptyRegularIcon />;

    if (size === "medium") {
      icon = <CircleEmptyMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CircleEmptyIcon.displayName = "CircleEmptyIcon";

export type { CircleEmptyIconProps };
export { CircleEmptyIcon };
