import { forwardRef, ForwardedRef } from "react";

import { CopyMediumIcon } from "./CopyMediumIcon";
import { CopyRegularIcon } from "./CopyRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CopyIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CopyIcon = forwardRef(
  (
    { size = "regular", ...props }: CopyIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CopyRegularIcon />;

    if (size === "medium") {
      icon = <CopyMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CopyIcon.displayName = "CopyIcon";

export type { CopyIconProps };
export { CopyIcon };
