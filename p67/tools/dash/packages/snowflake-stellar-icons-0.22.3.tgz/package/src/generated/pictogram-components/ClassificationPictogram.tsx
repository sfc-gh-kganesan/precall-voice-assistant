import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const ClassificationPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M17.43 7a3 3 0 0 1 3-3H27a3 3 0 0 1 3 3v6.571a3 3 0 0 1-3 3H25v1.767a2 2 0 0 0 1.994 1.85H34a7 7 0 0 1 7 7V29h-2v-1.812a5 5 0 0 0-5-5h-7.006A4 4 0 0 1 25 21.656V29h-2v-7.25a4 4 0 0 1-2.002.536H14a5 5 0 0 0-5 5V29H7v-1.714a7 7 0 0 1 7-7h6.998a2 2 0 0 0 2-1.95l-.004-.148v-.866h.004v-.661H23v-.09h-2.57a3 3 0 0 1-3-3zm3-1a1 1 0 0 0-1 1v6.571a1 1 0 0 0 1 1H27a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1zM4 36.072a3 3 0 0 1 3-3h3.929a3 3 0 0 1 3 3V40a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3zm3-1a1 1 0 0 0-1 1V40a1 1 0 0 0 1 1h3.929a1 1 0 0 0 1-1v-3.928a1 1 0 0 0-1-1zM18.54 36.072a3 3 0 0 1 3-3h3.928a3 3 0 0 1 3 3V40a3 3 0 0 1-3 3h-3.929a3 3 0 0 1-3-3zm3-1a1 1 0 0 0-1 1V40a1 1 0 0 0 1 1h3.928a1 1 0 0 0 1-1v-3.928a1 1 0 0 0-1-1zM36.07 33.072a3 3 0 0 0-3 3V40a3 3 0 0 0 3 3H40a3 3 0 0 0 3-3v-3.928a3 3 0 0 0-3-3zm-1 3a1 1 0 0 1 1-1H40a1 1 0 0 1 1 1V40a1 1 0 0 1-1 1H36.07a1 1 0 0 1-1-1z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClassificationPictogram.displayName = "ClassificationPictogram";
export { ClassificationPictogram };
