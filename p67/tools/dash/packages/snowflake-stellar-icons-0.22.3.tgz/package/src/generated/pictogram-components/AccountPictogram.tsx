import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const AccountPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M23.044 7.445a5.55 5.55 0 0 0-4.357 0l-11.334 4.65-.007.004c-2.343 1.004-3.733 3.491-3.25 6.028.876 4.615 2.343 10.223 4.904 14.7 2.564 4.483 6.346 8.023 11.866 8.023 4.497 0 7.848-2.349 10.327-5.644l-.959-3.577a16.05 16.05 0 0 0-9.365-3.016c-3.753 0-7.212 1.298-9.983 3.479l-.15-.257c-2.394-4.187-3.812-9.533-4.676-14.081-.3-1.581.56-3.165 2.067-3.814L19.46 9.29l.008-.003a3.55 3.55 0 0 1 2.796 0l.008.003 11.376 4.65c1.507.65 2.367 2.233 2.067 3.814-.58 3.054-1.415 6.47-2.63 9.652l-2.62-1.513a1 1 0 0 0-1.466 1.125l3.791 14.148a1 1 0 0 0 1.832.241l2.407-4.17 2.568 3.302 1.579-1.228-2.544-3.27 4.095-1.097a1 1 0 0 0 .241-1.832l-8.13-4.694c1.343-3.437 2.236-7.101 2.842-10.291.482-2.537-.908-5.024-3.251-6.028l-.008-.004zM20.866 38.85c-3.76 0-6.642-1.981-8.884-5.075 2.462-1.986 5.544-3.162 8.887-3.162 3.346 0 6.43 1.178 8.893 3.168-2.25 3.09-5.139 5.07-8.896 5.07m10.69-10.018 2.541 9.485 1.932-3.346a1 1 0 0 1 .607-.466l3.241-.868zm-10.67-14.364a6.207 6.207 0 1 0 0 12.414 6.207 6.207 0 0 0 0-12.414m-4.206 6.207a4.207 4.207 0 1 1 8.414 0 4.207 4.207 0 0 1-8.414 0"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
AccountPictogram.displayName = "AccountPictogram";
export { AccountPictogram };
