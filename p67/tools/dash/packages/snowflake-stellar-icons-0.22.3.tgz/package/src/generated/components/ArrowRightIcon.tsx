import { forwardRef, ForwardedRef } from "react";

import { ArrowRightMediumIcon } from "./ArrowRightMediumIcon";
import { ArrowRightRegularIcon } from "./ArrowRightRegularIcon";

import { ArrowRight_1xIcon } from "./ArrowRight_1xIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";
import { IconWith1x } from "../../IconWith1x";

interface ArrowRightIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ArrowRightIcon = forwardRef(
  (
    { size = "regular", ...props }: ArrowRightIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = (
      <IconWith1x icon1x={ArrowRight_1xIcon} icon2x={ArrowRightRegularIcon} />
    );

    if (size === "medium") {
      icon = <ArrowRightMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ArrowRightIcon.displayName = "ArrowRightIcon";

export type { ArrowRightIconProps };
export { ArrowRightIcon };
