import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BookClosedRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M12 1a1 1 0 0 1 1 1v9.08c-.982.68-.981 2.159 0 2.84V15H5.5A2.5 2.5 0 0 1 3 12.5V3a2 2 0 0 1 2-2zM5.5 11a1.5 1.5 0 0 0 0 3h6.206a2.77 2.77 0 0 1 0-3zM5 2a1 1 0 0 0-1 1v7.503A2.5 2.5 0 0 1 5.5 10H6V2zm2 8h5V2H7z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BookClosedRegularIcon.displayName = "BookClosedRegularIcon";
export { BookClosedRegularIcon };
