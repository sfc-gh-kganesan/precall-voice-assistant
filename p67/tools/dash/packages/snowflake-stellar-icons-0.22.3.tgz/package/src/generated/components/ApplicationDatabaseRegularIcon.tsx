import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationDatabaseRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path
                fillRule="evenodd"
                d="M12 7c2.21 0 4 1.12 4 2.5v3.625c0 1.657-1.791 3-4 3s-4-1.343-4-3V9.5C8 8.12 9.79 7 12 7m3 4.15c-.733.52-1.804.85-3 .85s-2.267-.33-3-.85v1.975c0 .443.237.92.771 1.321.535.401 1.32.679 2.229.679.91 0 1.694-.278 2.229-.679.534-.4.77-.878.771-1.321zm-3.349-3.14a5 5 0 0 0-.652.085c-.516.1-.96.274-1.298.485-.277.174-.453.348-.558.507A.76.76 0 0 0 9 9.5c0 .221.146.573.701.92.541.338 1.352.58 2.299.58s1.758-.242 2.299-.58c.555-.347.7-.699.701-.92 0-.221-.146-.573-.701-.92C13.758 8.242 12.947 8 12 8q-.177 0-.349.01"
                clipRule="evenodd"
              />
              <path d="M7.753 1.315a.5.5 0 0 1 .494 0L13.75 4.44a.5.5 0 0 1 .253.435v1.129h-.036l-.964-.002v-.837L8 2.325l-5.002 2.84v5.669L7 13.108v1.15L2.251 11.56a.5.5 0 0 1-.253-.435v-6.25l.005-.066a.5.5 0 0 1 .248-.369z" />
              <path d="M8 5c.887 0 1.681.388 2.23 1h-.035v.004l-1.102.322A2 2 0 0 0 6 8c0 .74.403 1.384 1 1.73v1.095A2.998 2.998 0 0 1 8 5" />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h16v16H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationDatabaseRegularIcon.displayName = "ApplicationDatabaseRegularIcon";
export { ApplicationDatabaseRegularIcon };
