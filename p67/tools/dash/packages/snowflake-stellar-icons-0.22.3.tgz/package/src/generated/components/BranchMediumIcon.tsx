import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BranchMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M14.375 1.25A2.497 2.497 0 0 1 15 6.167V8.75c0 1.036-.84 1.875-1.875 1.875H6.25v3.207a2.498 2.498 0 0 1-.625 4.918A2.5 2.5 0 0 1 5 13.832V6.167a2.497 2.497 0 0 1 .625-4.917 2.497 2.497 0 0 1 .625 4.917v3.208h6.875c.345 0 .625-.28.625-.625V6.167a2.497 2.497 0 0 1 .625-4.917M5.625 15a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m0-12.5a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5m8.75 0a1.25 1.25 0 1 0 0 2.5 1.25 1.25 0 0 0 0-2.5"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BranchMediumIcon.displayName = "BranchMediumIcon";
export { BranchMediumIcon };
