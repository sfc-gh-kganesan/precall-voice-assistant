import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronUpMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m3.308 12.683 6.25-6.25a.625.625 0 0 1 .884 0l6.25 6.25-.884.884L10 7.759l-5.808 5.808z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronUpMediumIcon.displayName = "ChevronUpMediumIcon";
export { ChevronUpMediumIcon };
