import { forwardRef, ForwardedRef } from "react";

import { BugMediumIcon } from "./BugMediumIcon";
import { BugRegularIcon } from "./BugRegularIcon";

import { Bug_1xIcon } from "./Bug_1xIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";
import { IconWith1x } from "../../IconWith1x";

interface BugIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BugIcon = forwardRef(
  (
    { size = "regular", ...props }: BugIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <IconWith1x icon1x={Bug_1xIcon} icon2x={BugRegularIcon} />;

    if (size === "medium") {
      icon = <BugMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BugIcon.displayName = "BugIcon";

export type { BugIconProps };
export { BugIcon };
