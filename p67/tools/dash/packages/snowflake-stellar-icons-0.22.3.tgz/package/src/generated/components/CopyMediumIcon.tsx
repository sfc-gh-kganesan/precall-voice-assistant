import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CopyMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M13.125 2.5C14.161 2.5 15 3.34 15 4.375V6.25h.625c1.035 0 1.875.84 1.875 1.875v7.5c0 1.035-.84 1.875-1.875 1.875h-7.5a1.875 1.875 0 0 1-1.875-1.875V15H4.375A1.875 1.875 0 0 1 2.5 13.125v-8.75c0-1.036.84-1.875 1.875-1.875zm-5 5a.625.625 0 0 0-.625.625v7.5c0 .345.28.625.625.625h7.5c.345 0 .625-.28.625-.625v-7.5a.625.625 0 0 0-.625-.625zm-3.75-3.75a.625.625 0 0 0-.625.625v8.75c0 .345.28.625.625.625H6.25V8.125c0-1.036.84-1.875 1.875-1.875h5.625V4.375a.625.625 0 0 0-.625-.625z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CopyMediumIcon.displayName = "CopyMediumIcon";
export { CopyMediumIcon };
