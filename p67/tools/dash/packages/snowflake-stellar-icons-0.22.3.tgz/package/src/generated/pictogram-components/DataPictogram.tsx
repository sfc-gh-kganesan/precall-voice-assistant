import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const DataPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M12.377 24.038a2 2 0 0 1-1.501.659h-.054a5.822 5.822 0 0 0 0 11.643h23.465a8.43 8.43 0 1 0-.535-16.842 2 2 0 0 1-2.012-1.333 9.74 9.74 0 0 0-9.185-6.505c-5.376 0-9.733 4.357-9.733 9.733q0 .551.06 1.084a2 2 0 0 1-.505 1.56m21.25-6.536C32.022 12.935 27.67 9.66 22.554 9.66c-6.245 0-11.352 4.88-11.712 11.036a12 12 0 0 0 .051 2h-.071A7.825 7.825 0 0 0 3 30.518a7.82 7.82 0 0 0 7.822 7.822h23.465c5.76 0 10.43-4.67 10.43-10.43s-4.67-10.428-10.43-10.428q-.333 0-.66.02"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataPictogram.displayName = "DataPictogram";
export { DataPictogram };
