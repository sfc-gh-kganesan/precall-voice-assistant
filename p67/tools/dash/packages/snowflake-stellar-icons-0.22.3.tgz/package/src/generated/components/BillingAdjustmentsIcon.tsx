import { forwardRef, ForwardedRef } from "react";

import { BillingAdjustmentsMediumIcon } from "./BillingAdjustmentsMediumIcon";
import { BillingAdjustmentsRegularIcon } from "./BillingAdjustmentsRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BillingAdjustmentsIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BillingAdjustmentsIcon = forwardRef(
  (
    { size = "regular", ...props }: BillingAdjustmentsIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BillingAdjustmentsRegularIcon />;

    if (size === "medium") {
      icon = <BillingAdjustmentsMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BillingAdjustmentsIcon.displayName = "BillingAdjustmentsIcon";

export type { BillingAdjustmentsIconProps };
export { BillingAdjustmentsIcon };
