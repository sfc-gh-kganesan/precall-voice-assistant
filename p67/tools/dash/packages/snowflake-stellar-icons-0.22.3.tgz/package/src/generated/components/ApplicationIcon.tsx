import { forwardRef, ForwardedRef } from "react";

import { ApplicationMediumIcon } from "./ApplicationMediumIcon";
import { ApplicationRegularIcon } from "./ApplicationRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ApplicationIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ApplicationIcon = forwardRef(
  (
    { size = "regular", ...props }: ApplicationIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ApplicationRegularIcon />;

    if (size === "medium") {
      icon = <ApplicationMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ApplicationIcon.displayName = "ApplicationIcon";

export type { ApplicationIconProps };
export { ApplicationIcon };
