import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CriticalFillRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10.485 1a1 1 0 0 1 .707.293l3.515 3.515a1 1 0 0 1 .293.707v4.97a1 1 0 0 1-.293.707l-3.515 3.515a1 1 0 0 1-.707.293h-4.97a1 1 0 0 1-.707-.293l-3.515-3.515A1 1 0 0 1 1 10.485v-4.97a1 1 0 0 1 .293-.707l3.515-3.515A1 1 0 0 1 5.515 1zM4 7.5v1h8v-1z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CriticalFillRegularIcon.displayName = "CriticalFillRegularIcon";
export { CriticalFillRegularIcon };
