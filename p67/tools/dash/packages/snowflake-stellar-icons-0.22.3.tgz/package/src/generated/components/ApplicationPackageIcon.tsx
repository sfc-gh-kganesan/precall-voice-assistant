import { forwardRef, ForwardedRef } from "react";

import { ApplicationPackageMediumIcon } from "./ApplicationPackageMediumIcon";
import { ApplicationPackageRegularIcon } from "./ApplicationPackageRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ApplicationPackageIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ApplicationPackageIcon = forwardRef(
  (
    { size = "regular", ...props }: ApplicationPackageIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ApplicationPackageRegularIcon />;

    if (size === "medium") {
      icon = <ApplicationPackageMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ApplicationPackageIcon.displayName = "ApplicationPackageIcon";

export type { ApplicationPackageIconProps };
export { ApplicationPackageIcon };
