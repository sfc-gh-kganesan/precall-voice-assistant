import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DatabaseLinkMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path d="M12.5 13.75h-2.38a2.514 2.514 0 0 0 0 5.026h2.38v1.25h-2.38a3.764 3.764 0 0 1 0-7.526h2.38zm3.737-1.25a3.763 3.763 0 0 1 0 7.526h-2.411v-1.25h2.41a2.513 2.513 0 0 0 0-5.026h-2.41V12.5z" />
              <path d="M16.25 16.875H10v-1.25h6.25z" />
              <path
                fillRule="evenodd"
                d="M10.001 2.5c1.63 0 3.136.328 4.258.889 1.084.541 1.993 1.407 1.993 2.547q.001.108-.01.211.01.112.01.228V10h-1.25V8.033a5.3 5.3 0 0 1-.743.45c-1.122.56-2.628.888-4.258.888s-3.136-.328-4.258-.888A5.3 5.3 0 0 1 5 8.033v7.94c-.743-.612-1.25-1.41-1.25-2.347V6.375q0-.118.01-.232a2 2 0 0 1-.01-.207c0-1.14.91-2.006 1.993-2.547 1.122-.56 2.629-.889 4.258-.889m0 1.25c-1.463 0-2.758.344-3.666.868-.792.458-1.207.996-1.31 1.506.093.38.465.835 1.277 1.24.915.457 2.222.757 3.7.757 1.477 0 2.784-.3 3.698-.757.812-.405 1.183-.86 1.276-1.24-.103-.51-.517-1.049-1.309-1.506-.794-.458-1.884-.78-3.125-.852z"
                clipRule="evenodd"
              />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h20v20H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
DatabaseLinkMediumIcon.displayName = "DatabaseLinkMediumIcon";
export { DatabaseLinkMediumIcon };
