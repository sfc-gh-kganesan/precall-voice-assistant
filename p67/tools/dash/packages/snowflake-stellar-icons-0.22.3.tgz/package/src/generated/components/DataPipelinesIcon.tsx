import { forwardRef, ForwardedRef } from "react";

import { DataPipelinesMediumIcon } from "./DataPipelinesMediumIcon";
import { DataPipelinesRegularIcon } from "./DataPipelinesRegularIcon";

import { DataPipelines_1xIcon } from "./DataPipelines_1xIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";
import { IconWith1x } from "../../IconWith1x";

interface DataPipelinesIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DataPipelinesIcon = forwardRef(
  (
    { size = "regular", ...props }: DataPipelinesIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = (
      <IconWith1x
        icon1x={DataPipelines_1xIcon}
        icon2x={DataPipelinesRegularIcon}
      />
    );

    if (size === "medium") {
      icon = <DataPipelinesMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DataPipelinesIcon.displayName = "DataPipelinesIcon";

export type { DataPipelinesIconProps };
export { DataPipelinesIcon };
