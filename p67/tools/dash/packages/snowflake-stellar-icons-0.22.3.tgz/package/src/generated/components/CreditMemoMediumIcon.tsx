import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CreditMemoMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M10 11.563a.937.937 0 1 1 0 1.874.937.937 0 0 1 0-1.874M10.625 10h-1.25V5h1.25z" />
              <path
                fillRule="evenodd"
                d="M15.625 1.25c.345 0 .625.28.625.625v16.25a.625.625 0 0 1-.972.52l-1.528-1.02-1.528 1.02a.625.625 0 0 1-.694 0L10 17.625l-1.528 1.02a.625.625 0 0 1-.694 0l-1.528-1.02-1.528 1.02a.626.626 0 0 1-.972-.52V1.875a.625.625 0 0 1 .625-.625zM5 16.957l.903-.602c.21-.14.484-.14.694 0l1.528 1.018 1.528-1.018c.21-.14.484-.14.694 0l1.528 1.018 1.528-1.018c.21-.14.484-.14.694 0l.903.602V2.5H5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CreditMemoMediumIcon.displayName = "CreditMemoMediumIcon";
export { CreditMemoMediumIcon };
