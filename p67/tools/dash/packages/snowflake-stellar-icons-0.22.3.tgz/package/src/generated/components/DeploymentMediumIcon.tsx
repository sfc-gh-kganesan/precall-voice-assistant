import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DeploymentMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} fillRule="evenodd" clipRule="evenodd">
              <path d="M6.369 13.783c.976.976.856 2.116-.12 3.092l-.096.088c-1.05.866-3.654.537-3.654.537l-.04-.448c-.05-.792-.065-2.426.578-3.205l.087-.096c.977-.976 2.269-.944 3.245.032m-.884.884c-.296-.296-.564-.38-.755-.383-.186-.002-.44.07-.722.35-.022.024-.107.138-.184.431-.073.28-.114.622-.13.98-.003.088 0 .176 0 .262.084-.001.173.002.262-.002.357-.015.699-.056.978-.13.294-.077.408-.161.431-.184.343-.342.421-.598.43-.732.005-.105-.02-.303-.31-.592m8.27-8.372a1.876 1.876 0 1 1-2.653 2.651 1.876 1.876 0 0 1 2.653-2.651m-.884.884a.626.626 0 1 0-.884.886.626.626 0 0 0 .884-.886" />
              <path d="M17.505 3.738a12.5 12.5 0 0 1-2.079 6.902l-.427.646v5.702c0 1.67-2.016 2.506-3.198 1.329L9.416 15.94l-.004.002-5.304-5.303.003-.004-2.43-2.439C.504 7.015 1.341 5 3.01 5h5.927l.34-.238a12.5 12.5 0 0 1 7.168-2.26h1.06zm-1.25.017a11.25 11.25 0 0 0-6.26 2.03l-.778.543a11.25 11.25 0 0 0-3.436 3.85l-.128.235.224.226 3.533 3.535.002-.002.247.246a11.25 11.25 0 0 0 4.297-3.822l.428-.646a11.25 11.25 0 0 0 1.87-6.195M3.01 6.25a.625.625 0 0 0-.443 1.066l2.167 2.176a12.5 12.5 0 0 1 2.582-3.243zm10.74 6.626a12.5 12.5 0 0 1-3.163 2.467l2.096 2.09a.625.625 0 0 0 1.066-.444z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
DeploymentMediumIcon.displayName = "DeploymentMediumIcon";
export { DeploymentMediumIcon };
