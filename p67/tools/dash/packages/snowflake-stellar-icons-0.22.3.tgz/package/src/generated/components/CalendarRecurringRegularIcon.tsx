import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CalendarRecurringRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M11.003 9.002a3.01 3.01 0 0 1-3.014 3.004c-.774 0-1.48-.292-2.013-.77v.462h-1V9.965a.5.5 0 0 1 .5-.5h1.74v1h-.6c.359.335.842.54 1.373.54a2.01 2.01 0 0 0 2.014-2.003zM7.99 5.998c.773 0 1.48.291 2.013.77v-.463h1v1.733a.5.5 0 0 1-.5.5h-1.74v-1h.6a2 2 0 0 0-1.374-.54c-1.114 0-2.013.9-2.013 2.004h-1a3.01 3.01 0 0 1 3.013-3.004" />
              <path
                fillRule="evenodd"
                d="M6 3h4V2h1v1h1.5A1.5 1.5 0 0 1 14 4.5v8a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 12.5v-8A1.5 1.5 0 0 1 3.5 3H5V2h1zM3.5 4a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-8a.5.5 0 0 0-.5-.5H11v1h-1V4H6v1H5V4z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CalendarRecurringRegularIcon.displayName = "CalendarRecurringRegularIcon";
export { CalendarRecurringRegularIcon };
