import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const ConnectorPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10.417 11.5c-2.363 0-4.209 1.829-4.209 4s1.846 4 4.209 4 4.208-1.829 4.208-4-1.845-4-4.208-4m-6.209 4c0-3.352 2.819-6 6.209-6 3.138 0 5.787 2.27 6.162 5.267h2.484c1.664 0 3.083 1.305 3.083 3v9.166c0 .514.446 1 1.083 1h2.403v-4.216c0-2.8 2.352-5 5.166-5h10.868c2.815 0 5.167 2.2 5.167 5V34.15c0 2.8-2.352 5-5.167 5H30.798c-2.814 0-5.166-2.2-5.166-5v-4.217h-2.403c-1.664 0-3.083-1.305-3.083-3v-9.166c0-.515-.446-1-1.083-1h-2.576c-.604 2.728-3.12 4.733-6.07 4.733-3.39 0-6.209-2.648-6.209-6m23.424 8.217c0-1.619 1.379-3 3.166-3h10.868c1.788 0 3.167 1.381 3.167 3V34.15c0 1.619-1.379 3-3.167 3H30.798c-1.787 0-3.166-1.381-3.166-3zm11.342 5.216c0 1.454-1.228 2.633-2.743 2.633s-2.743-1.179-2.743-2.633 1.228-2.633 2.743-2.633 2.743 1.179 2.743 2.633"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ConnectorPictogram.displayName = "ConnectorPictogram";
export { ConnectorPictogram };
