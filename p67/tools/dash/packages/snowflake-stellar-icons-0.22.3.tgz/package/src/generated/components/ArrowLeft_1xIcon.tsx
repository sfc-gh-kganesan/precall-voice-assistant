import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowLeft_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M2 7.5a.5.5 0 0 1 .146-.354l5-5 .708.708L3.707 7H14v1H3.707l4.147 4.147-.708.707-5-5A.5.5 0 0 1 2 7.5"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowLeft_1xIcon.displayName = "ArrowLeft_1xIcon";
export { ArrowLeft_1xIcon };
