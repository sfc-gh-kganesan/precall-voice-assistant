import { forwardRef, ForwardedRef } from "react";

import { CellCollapseCodeMediumIcon } from "./CellCollapseCodeMediumIcon";
import { CellCollapseCodeRegularIcon } from "./CellCollapseCodeRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CellCollapseCodeIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CellCollapseCodeIcon = forwardRef(
  (
    { size = "regular", ...props }: CellCollapseCodeIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CellCollapseCodeRegularIcon />;

    if (size === "medium") {
      icon = <CellCollapseCodeMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CellCollapseCodeIcon.displayName = "CellCollapseCodeIcon";

export type { CellCollapseCodeIconProps };
export { CellCollapseCodeIcon };
