import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BriefcaseRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M9.103 2.005a1 1 0 0 1 .892.892L10 3v1h2.5A1.5 1.5 0 0 1 14 5.5v7a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 12.5v-7A1.5 1.5 0 0 1 3.5 4H6V3a1 1 0 0 1 1-1h2zM7 9v1h2V9zm0-5h2V3H7zm2.995 6.102A1 1 0 0 1 9 11H7a1 1 0 0 1-.995-.898L6 10H4.5A2.5 2.5 0 0 1 3 9.496V12.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V9.496a2.5 2.5 0 0 1-1.5.504H10zM11.5 9A1.5 1.5 0 0 0 13 7.5v-2a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v2A1.5 1.5 0 0 0 4.5 9H6l.005-.103A1 1 0 0 1 7 8h2l.103.005a1 1 0 0 1 .892.892L10 9z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BriefcaseRegularIcon.displayName = "BriefcaseRegularIcon";
export { BriefcaseRegularIcon };
