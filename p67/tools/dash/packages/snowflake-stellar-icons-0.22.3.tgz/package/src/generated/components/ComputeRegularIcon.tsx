import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ComputeRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M9.112 1.184a.5.5 0 0 1 .885.366L9.55 6H13a.5.5 0 0 1 .387.815l-6.5 8a.5.5 0 0 1-.884-.365L6.448 10H3a.5.5 0 0 1-.388-.816zM4.049 9H7a.5.5 0 0 1 .498.55l-.335 3.34L11.95 7H9a.5.5 0 0 1-.497-.55l.334-3.342z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ComputeRegularIcon.displayName = "ComputeRegularIcon";
export { ComputeRegularIcon };
