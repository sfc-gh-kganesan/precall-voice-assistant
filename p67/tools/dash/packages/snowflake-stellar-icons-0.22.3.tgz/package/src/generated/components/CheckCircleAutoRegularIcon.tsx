import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CheckCircleAutoRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8 1a7 7 0 1 1-6.928 6h1.013Q2.001 7.489 2 8a6 6 0 1 0 5-5.916V1.072q.49-.07 1-.072" />
              <path d="m11.872 5.835-4.5 5a.5.5 0 0 1-.726.018l-2.5-2.5.708-.707 2.125 2.126 4.149-4.607zm-8.797-4.39a.363.363 0 0 1 .678 0c.302.791.935 1.41 1.732 1.697l.048.017a.367.367 0 0 1 0 .69A2.94 2.94 0 0 0 3.76 5.622a.368.368 0 0 1-.692 0A2.94 2.94 0 0 0 1.295 3.85a.367.367 0 0 1 0-.69l.048-.018a2.9 2.9 0 0 0 1.732-1.697" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CheckCircleAutoRegularIcon.displayName = "CheckCircleAutoRegularIcon";
export { CheckCircleAutoRegularIcon };
