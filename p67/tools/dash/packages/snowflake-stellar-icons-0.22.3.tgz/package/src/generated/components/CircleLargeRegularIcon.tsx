import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CircleLargeRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path fill={iconColor} d="M12 8a4 4 0 1 1-8 0 4 4 0 0 1 8 0" />
          </>
        }
        {...props}
      />
    );
  },
);
CircleLargeRegularIcon.displayName = "CircleLargeRegularIcon";
export { CircleLargeRegularIcon };
