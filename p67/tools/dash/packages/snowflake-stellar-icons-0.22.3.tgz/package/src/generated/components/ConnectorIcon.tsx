import { forwardRef, ForwardedRef } from "react";

import { ConnectorMediumIcon } from "./ConnectorMediumIcon";
import { ConnectorRegularIcon } from "./ConnectorRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ConnectorIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ConnectorIcon = forwardRef(
  (
    { size = "regular", ...props }: ConnectorIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ConnectorRegularIcon />;

    if (size === "medium") {
      icon = <ConnectorMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ConnectorIcon.displayName = "ConnectorIcon";

export type { ConnectorIconProps };
export { ConnectorIcon };
