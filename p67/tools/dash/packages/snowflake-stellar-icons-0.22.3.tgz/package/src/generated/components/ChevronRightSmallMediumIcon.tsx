import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronRightSmallMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m8.567 14.192 3.75-3.75a.625.625 0 0 0 0-.884l-3.75-3.75-.884.884L10.991 10l-3.308 3.308z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronRightSmallMediumIcon.displayName = "ChevronRightSmallMediumIcon";
export { ChevronRightSmallMediumIcon };
