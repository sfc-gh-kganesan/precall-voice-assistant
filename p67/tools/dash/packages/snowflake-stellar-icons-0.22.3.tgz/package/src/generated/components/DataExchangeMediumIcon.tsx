import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DataExchangeMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M9.92 2.506a4.96 4.96 0 0 1 4.663 4.335 4.416 4.416 0 0 1 4.167 4.409l-.005.22a4.417 4.417 0 0 1-4.185 4.19l-.015.002-.196.004h-.599v-1.25h.568l.189-.004a3.17 3.17 0 0 0 2.977-2.848l.016-.314a3.167 3.167 0 0 0-2.843-3.15l-.323-.016q-.144 0-.282.012l-.683.06.003-.685v-.023a3.71 3.71 0 0 0-3.517-3.693l-.19-.005a3.71 3.71 0 0 0-3.71 3.709l.008.242q.025.36.114.7l.23.875-.9-.095A2.626 2.626 0 0 0 2.5 11.792l.012.268a2.625 2.625 0 0 0 2.612 2.356h4.033L7.03 12.29l.884-.884 3.153 3.153a.625.625 0 0 1 0 .884L7.969 18.54l-.884-.884 1.987-1.989H5.125a3.875 3.875 0 0 1-3.87-3.675l-.005-.199a3.88 3.88 0 0 1 3.481-3.857 5 5 0 0 1-.025-.476A4.96 4.96 0 0 1 9.664 2.5z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataExchangeMediumIcon.displayName = "DataExchangeMediumIcon";
export { DataExchangeMediumIcon };
