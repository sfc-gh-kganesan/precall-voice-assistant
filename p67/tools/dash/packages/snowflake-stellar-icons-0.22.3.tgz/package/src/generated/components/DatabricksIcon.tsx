import { forwardRef, ForwardedRef } from "react";

import { DatabricksMediumIcon } from "./DatabricksMediumIcon";
import { DatabricksRegularIcon } from "./DatabricksRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DatabricksIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DatabricksIcon = forwardRef(
  (
    { size = "regular", ...props }: DatabricksIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DatabricksRegularIcon />;

    if (size === "medium") {
      icon = <DatabricksMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DatabricksIcon.displayName = "DatabricksIcon";

export type { DatabricksIconProps };
export { DatabricksIcon };
