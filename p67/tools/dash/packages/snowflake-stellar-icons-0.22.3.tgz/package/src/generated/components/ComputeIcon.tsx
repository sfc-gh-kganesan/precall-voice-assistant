import { forwardRef, ForwardedRef } from "react";

import { ComputeMediumIcon } from "./ComputeMediumIcon";
import { ComputeRegularIcon } from "./ComputeRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ComputeIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ComputeIcon = forwardRef(
  (
    { size = "regular", ...props }: ComputeIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ComputeRegularIcon />;

    if (size === "medium") {
      icon = <ComputeMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ComputeIcon.displayName = "ComputeIcon";

export type { ComputeIconProps };
export { ComputeIcon };
