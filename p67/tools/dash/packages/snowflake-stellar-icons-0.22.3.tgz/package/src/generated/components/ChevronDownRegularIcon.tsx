import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronDownRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m13.354 5.854-5 5a.5.5 0 0 1-.708 0l-5-5 .708-.708L8 9.793l4.647-4.647z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronDownRegularIcon.displayName = "ChevronDownRegularIcon";
export { ChevronDownRegularIcon };
