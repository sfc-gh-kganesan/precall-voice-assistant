import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const DashboardPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M11 8h6.615a3 3 0 0 1 3 3v6.615a3 3 0 0 1-3 3H11a3 3 0 0 1-3-3V11a3 3 0 0 1 3-3m-5 3a5 5 0 0 1 5-5h6.615a5 5 0 0 1 5 5v6.615a5 5 0 0 1-5 5H11a5 5 0 0 1-5-5zm5 16.385h6.615a3 3 0 0 1 3 3V37a3 3 0 0 1-3 3H11a3 3 0 0 1-3-3v-6.615a3 3 0 0 1 3-3m-5 3a5 5 0 0 1 5-5h6.615a5 5 0 0 1 5 5V37a5 5 0 0 1-5 5H11a5 5 0 0 1-5-5zM37 8h-6.615a3 3 0 0 0-3 3v6.616a3 3 0 0 0 3 3H37a3 3 0 0 0 3-3V11a3 3 0 0 0-3-3m-6.615-2a5 5 0 0 0-5 5v6.616a5 5 0 0 0 5 5H37a5 5 0 0 0 5-5V11a5 5 0 0 0-5-5zm0 21.385H37a3 3 0 0 1 3 3V37a3 3 0 0 1-3 3h-6.615a3 3 0 0 1-3-3v-6.615a3 3 0 0 1 3-3m-5 3a5 5 0 0 1 5-5H37a5 5 0 0 1 5 5V37a5 5 0 0 1-5 5h-6.615a5 5 0 0 1-5-5z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DashboardPictogram.displayName = "DashboardPictogram";
export { DashboardPictogram };
