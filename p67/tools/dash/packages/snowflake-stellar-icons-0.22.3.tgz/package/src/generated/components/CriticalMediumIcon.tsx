import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CriticalMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M15 10.625H5v-1.25h10z" />
              <path
                fillRule="evenodd"
                d="M13.23 1.256c.286.028.555.155.76.36l4.394 4.394c.234.234.366.552.366.883v6.214l-.006.123a1.25 1.25 0 0 1-.36.76l-4.393 4.394a1.25 1.25 0 0 1-.761.36l-.123.006H6.893l-.123-.006a1.25 1.25 0 0 1-.669-.277l-.091-.083-4.394-4.393a1.25 1.25 0 0 1-.36-.761l-.006-.123V6.893c0-.29.1-.57.283-.792l.083-.091L6.01 1.616a1.25 1.25 0 0 1 .883-.366h6.214zM2.5 6.893v6.214L6.893 17.5h6.214l4.393-4.393V6.893L13.107 2.5H6.893z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CriticalMediumIcon.displayName = "CriticalMediumIcon";
export { CriticalMediumIcon };
