import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BillingAdjustmentsMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M10.625 3.75v.997c1.323.196 2.202 1.042 2.289 2.29h-1.432c-.098-.576-.619-1.053-1.454-1.053-.77 0-1.225.315-1.226.857 0 .477.348.705.88.857l1.279.357c1.095.315 2.028.837 2.028 2.344 0 1.247-.91 2.103-2.364 2.266v1.085H9.41v-1.117c-1.366-.239-2.31-1.226-2.397-2.657h1.432c.065.824.77 1.453 1.66 1.453.835 0 1.41-.402 1.41-.998 0-.531-.402-.835-.944-.986l-1.28-.36c-1.074-.303-1.974-.856-1.974-2.233 0-1.085.846-1.899 2.093-2.105V3.75z" />
              <path
                fillRule="evenodd"
                d="M15.625 1.25c.345 0 .625.28.625.625v16.25a.625.625 0 0 1-.972.52l-1.528-1.02-1.528 1.02a.625.625 0 0 1-.694 0L10 17.625l-1.528 1.02a.625.625 0 0 1-.694 0l-1.528-1.02-1.528 1.02a.626.626 0 0 1-.972-.52V1.875a.625.625 0 0 1 .625-.625zM5 16.957l.903-.602.082-.046a.63.63 0 0 1 .612.046l1.528 1.018 1.528-1.018.082-.046a.63.63 0 0 1 .612.046l1.528 1.018 1.528-1.018.082-.046a.63.63 0 0 1 .612.046l.903.602V2.5H5z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BillingAdjustmentsMediumIcon.displayName = "BillingAdjustmentsMediumIcon";
export { BillingAdjustmentsMediumIcon };
