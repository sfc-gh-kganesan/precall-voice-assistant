import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AmpersatMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M9.73 3.825q1.35 0 2.49.51A5.9 5.9 0 0 1 14.185 5.7q.84.855 1.29 1.95.465 1.095.465 2.295 0 .945-.3 1.665-.285.705-.84 1.11t-1.335.406q-.465 0-.885-.166a2.15 2.15 0 0 1-.72-.495 1.7 1.7 0 0 1-.263-.414 2.47 2.47 0 0 1-1.267.939q-.435.136-.945.136a3 3 0 0 1-1.575-.421q-.69-.42-1.095-1.14T6.31 9.93t.405-1.635 1.095-1.14a2.94 2.94 0 0 1 1.575-.435q.735 0 1.335.3.53.258.87.695V6.87h.975v4.14q0 .555.24.81.256.255.675.255a1.1 1.1 0 0 0 .975-.525q.36-.525.36-1.575 0-1.08-.375-2.01t-1.05-1.62a4.8 4.8 0 0 0-1.605-1.08 5.3 5.3 0 0 0-2.055-.39q-1.095 0-2.04.39-.93.375-1.62 1.065T4.99 7.95q-.375.93-.375 2.04 0 1.08.36 2.025.375.93 1.05 1.635.69.72 1.635 1.125t2.1.405q.675 0 1.305-.15.63-.135 1.14-.42l.48.9q-1.275.72-2.955.72-1.32 0-2.46-.48a6 6 0 0 1-1.98-1.32 6.2 6.2 0 0 1-1.335-1.98 6.4 6.4 0 0 1-.465-2.445 6.13 6.13 0 0 1 1.8-4.395 6.1 6.1 0 0 1 1.995-1.305q1.14-.48 2.445-.48M9.43 7.8a1.94 1.94 0 0 0-1.74 1.035q-.255.48-.255 1.095 0 .6.255 1.095.27.48.72.765t1.02.285q.585 0 1.035-.284a2 2 0 0 0 .705-.766q.27-.495.27-1.11 0-.93-.57-1.515-.57-.6-1.44-.6"
            />
          </>
        }
        {...props}
      />
    );
  },
);
AmpersatMediumIcon.displayName = "AmpersatMediumIcon";
export { AmpersatMediumIcon };
