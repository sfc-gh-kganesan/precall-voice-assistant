import { forwardRef, ForwardedRef } from "react";

import { BookClosedMediumIcon } from "./BookClosedMediumIcon";
import { BookClosedRegularIcon } from "./BookClosedRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BookClosedIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BookClosedIcon = forwardRef(
  (
    { size = "regular", ...props }: BookClosedIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BookClosedRegularIcon />;

    if (size === "medium") {
      icon = <BookClosedMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BookClosedIcon.displayName = "BookClosedIcon";

export type { BookClosedIconProps };
export { BookClosedIcon };
