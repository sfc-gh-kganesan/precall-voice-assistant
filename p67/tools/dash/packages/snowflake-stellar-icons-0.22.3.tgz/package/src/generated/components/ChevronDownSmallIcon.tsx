import { forwardRef, ForwardedRef } from "react";

import { ChevronDownSmallMediumIcon } from "./ChevronDownSmallMediumIcon";
import { ChevronDownSmallRegularIcon } from "./ChevronDownSmallRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronDownSmallIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronDownSmallIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronDownSmallIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronDownSmallRegularIcon />;

    if (size === "medium") {
      icon = <ChevronDownSmallMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronDownSmallIcon.displayName = "ChevronDownSmallIcon";

export type { ChevronDownSmallIconProps };
export { ChevronDownSmallIcon };
