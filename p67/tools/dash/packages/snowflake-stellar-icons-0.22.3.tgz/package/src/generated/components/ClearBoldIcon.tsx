import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
import { IconWrapper } from "../../IconWrapper";
import { IconProps } from "../../types";
const ClearBoldIcon = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <IconWrapper
        {...props}
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              d="M13.707 3.72 9.419 8.007l4.28 4.28-1.415 1.414-4.28-4.28-4.278 4.28-1.414-1.414 4.279-4.28L2.303 3.72l1.414-1.414 4.288 4.287 4.288-4.287z"
            />
          </>
        }
      />
    );
  },
);
ClearBoldIcon.displayName = "ClearBoldIcon";
export { ClearBoldIcon };
