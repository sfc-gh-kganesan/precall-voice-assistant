import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CellCollapseResultMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M17.5 17.5h-15v-1.25h15zM9.192 6.072 7.134 8.13l2.058 2.058-.884.884L5.366 8.13l2.942-2.942zm5.442 2.058-2.942 2.942-.884-.884 2.058-2.058-2.058-2.058.884-.884z" />
              <path
                fillRule="evenodd"
                d="M16.875 2.5a.626.626 0 0 1 .625.625v10l-.012.126a.626.626 0 0 1-.613.499H3.125a.626.626 0 0 1-.625-.625v-10c0-.345.28-.625.625-.625zM3.75 12.5h12.5V3.75H3.75z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CellCollapseResultMediumIcon.displayName = "CellCollapseResultMediumIcon";
export { CellCollapseResultMediumIcon };
