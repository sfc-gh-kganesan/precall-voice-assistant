import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const DataPrivacyIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={`url(#${idPrefix}-svg-3827615911__a)`}
              d="M61.009 51.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09L77.237 93.337c-4.554 2.382-11.31 2.361-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
            />
            <path
              fill={`url(#${idPrefix}-svg-3827615911__b)`}
              d="M61.009 40.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09L77.237 82.337c-4.554 2.382-11.31 2.361-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
            />
            <mask
              id={`${idPrefix}-svg-3827615911__d`}
              width={82}
              height={46}
              x={28}
              y={50}
              maskUnits="userSpaceOnUse"
              style={{
                maskType: "alpha",
              }}
            >
              <path
                fill={`url(#${idPrefix}-svg-3827615911__c)`}
                d="M61.009 51.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09L77.237 93.337c-4.554 2.382-11.31 2.361-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
              />
            </mask>
            <g
              filter={`url(#${idPrefix}-svg-3827615911__e)`}
              mask={`url(#${idPrefix}-svg-3827615911__d)`}
            >
              <path
                fill={`url(#${idPrefix}-svg-3827615911__f)`}
                d="M61.009 40.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09L77.237 82.337c-4.554 2.382-11.31 2.361-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
              />
            </g>
            <mask
              id={`${idPrefix}-svg-3827615911__h`}
              width={82}
              height={46}
              x={28}
              y={39}
              maskUnits="userSpaceOnUse"
              style={{
                maskType: "alpha",
              }}
            >
              <path
                fill={`url(#${idPrefix}-svg-3827615911__g)`}
                d="M61.009 40.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09L77.237 82.337c-4.554 2.382-11.31 2.361-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
              />
            </mask>
            <g
              filter={`url(#${idPrefix}-svg-3827615911__i)`}
              mask={`url(#${idPrefix}-svg-3827615911__h)`}
            >
              <path
                fill={`url(#${idPrefix}-svg-3827615911__j)`}
                d="M61.009 28.001c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09L77.237 69.402c-4.554 2.382-11.31 2.361-15.848-.048l-28.9-15.346c-5.539-2.942-5.524-8.172.032-11.082z"
              />
            </g>
            <path
              fill={`url(#${idPrefix}-svg-3827615911__k)`}
              d="M61.009 27.936c4.55-2.384 11.307-2.367 15.847.04l28.948 15.346c5.549 2.942 5.534 8.179-.032 11.09L77.237 69.337c-4.554 2.382-11.31 2.361-15.847-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.03-11.082z"
            />
            <path
              fill={`url(#${idPrefix}-svg-3827615911__l)`}
              fillRule="evenodd"
              d="M55.497 41.124c-.486.263-.49.696-.008.966l1.155.65c.482.27 1.266.276 1.752.013l9.802-5.305c.486-.263.49-.695.008-.966l-1.155-.649c-.482-.27-1.266-.276-1.752-.014zm-7.046 5.413c-.8-.45-.795-1.17.013-1.606l1.836-.994c.807-.437 2.11-.427 2.911.023s.795 1.169-.012 1.606l-1.837.994c-.807.437-2.11.426-2.911-.023m6.337 3.56c-.8-.449-.795-1.168.013-1.605l1.836-.994c.807-.437 2.11-.426 2.911.024s.795 1.168-.012 1.605l-1.837.994c-.807.437-2.11.427-2.911-.023m7.039-4.446c-.482-.27-.478-.703.008-.966l9.802-5.305c.486-.263 1.27-.257 1.751.014l1.156.65c.481.27.478.702-.008.965l-9.802 5.305c-.486.263-1.27.257-1.752-.014zm6.068 3.409c-.482-.27-.478-.703.008-.966l9.802-5.305c.486-.263 1.27-.257 1.752.014l1.155.65c.481.27.478.702-.008.965l-9.802 5.305c-.486.263-1.27.257-1.752-.014zm-7.038 4.447c-.8-.45-.795-1.169.013-1.606l1.836-.993c.807-.437 2.111-.427 2.912.023s.794 1.168-.013 1.605l-1.836.994c-.808.437-2.111.427-2.912-.023m6.079 1.803c-.808.437-.813 1.156-.013 1.606s2.104.46 2.912.023l1.836-.994c.808-.437.813-1.156.013-1.605s-2.104-.46-2.912-.023zm7.034-3.806c-.486.263-.49.695-.008.966l1.156.649c.481.27 1.265.276 1.75.014l9.804-5.305c.485-.263.489-.696.007-.966l-1.155-.65c-.482-.27-1.266-.276-1.751-.013zm5.812 4.235c-.482-.27-.478-.703.007-.966l9.803-5.305c.486-.263 1.27-.256 1.751.014l1.156.65c.481.27.478.702-.008.965l-9.803 5.305c-.485.263-1.27.257-1.75-.014zm-7.04 4.447c-.8-.45-.794-1.169.013-1.606l1.837-.994c.807-.437 2.11-.426 2.911.023.8.45.795 1.169-.012 1.606l-1.837.994c-.807.437-2.11.426-2.911-.023"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-3827615911__m)`}
              d="M86.96 71.778c5.16-1.368 11.004-5.756 14.441-8.745a3.384 3.384 0 0 1 4.406 0c3.438 2.99 9.282 7.377 14.441 8.745 1.601.425 2.97 1.776 2.867 3.43-1.278 20.4-15.354 30.601-19.511 30.601s-18.23-10.2-19.51-30.6c-.104-1.655 1.265-3.006 2.866-3.43"
            />
            <path
              fill={`url(#${idPrefix}-svg-3827615911__n)`}
              d="M105.584 84.662A3.995 3.995 0 0 0 103.997 77a3.994 3.994 0 0 0-1.522 7.688l-1.661 5.756a2 2 0 0 0 1.923 2.554l2.603-.002a2 2 0 0 0 1.919-2.557z"
            />
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__a`}
                x1={129.378}
                x2={133.158}
                y1={32.762}
                y2={134.693}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__b`}
                x1={130.6}
                x2={133.732}
                y1={32.775}
                y2={189.957}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__c`}
                x1={129.378}
                x2={133.158}
                y1={32.762}
                y2={134.693}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__f`}
                x1={130.6}
                x2={133.732}
                y1={32.775}
                y2={189.957}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__g`}
                x1={130.6}
                x2={133.732}
                y1={32.775}
                y2={189.957}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__j`}
                x1={80.016}
                x2={77.236}
                y1={38.521}
                y2={132.143}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__k`}
                x1={118.331}
                x2={102.326}
                y1={4.72}
                y2={120.516}
                gradientUnits="userSpaceOnUse"
              >
                <stop offset={0.37} stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__l`}
                x1={87}
                x2={81.29}
                y1={38}
                y2={68.541}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#91BDFF" stopOpacity={0} />
                <stop offset={1} stopColor="#91BDFF" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__m`}
                x1={130}
                x2={75.936}
                y1={102.5}
                y2={76.142}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-3827615911__n`}
                x1={104}
                x2={115.384}
                y1={86.09}
                y2={53.3}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <filter
                id={`${idPrefix}-svg-3827615911__e`}
                width={95.612}
                height={58.951}
                x={21.344}
                y={36.159}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset dy={4} />
                <feGaussianBlur stdDeviation={3.5} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_815"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_815"
                  result="shape"
                />
              </filter>
              <filter
                id={`${idPrefix}-svg-3827615911__i`}
                width={95.612}
                height={58.951}
                x={21.344}
                y={23.224}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset dy={4} />
                <feGaussianBlur stdDeviation={3.5} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_815"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_815"
                  result="shape"
                />
              </filter>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
DataPrivacyIllustration.displayName = "DataPrivacyIllustration";
export { DataPrivacyIllustration };
