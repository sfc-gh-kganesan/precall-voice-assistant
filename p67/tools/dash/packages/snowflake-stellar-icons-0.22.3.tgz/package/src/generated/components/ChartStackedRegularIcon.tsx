import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartStackedRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M11 5.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-3l-.098-.01A.5.5 0 0 1 11 12.5zm3 6.5V8h-2v4zm0-5V6h-2v1zM6 3.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v9l-.01.1a.5.5 0 0 1-.49.4h-3l-.098-.01A.5.5 0 0 1 6 12.5zM9 5V4H7v1zm0 7V6H7v6zM1 7.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-.5.5h-3l-.098-.01A.5.5 0 0 1 1 12.5zM4 12v-2H2v2zm0-3V8H2v1z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartStackedRegularIcon.displayName = "ChartStackedRegularIcon";
export { ChartStackedRegularIcon };
