import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronLeftRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m10.146 13.354-5-5a.5.5 0 0 1 0-.708l5-5 .707.708L6.208 8l4.647 4.647z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronLeftRegularIcon.displayName = "ChevronLeftRegularIcon";
export { ChevronLeftRegularIcon };
