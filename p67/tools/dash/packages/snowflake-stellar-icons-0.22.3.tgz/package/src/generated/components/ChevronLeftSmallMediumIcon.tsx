import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronLeftSmallMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m11.433 14.192-3.75-3.75a.625.625 0 0 1 0-.884l3.75-3.75.884.884L9.009 10l3.308 3.308z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronLeftSmallMediumIcon.displayName = "ChevronLeftSmallMediumIcon";
export { ChevronLeftSmallMediumIcon };
