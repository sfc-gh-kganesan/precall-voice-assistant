import { forwardRef, ForwardedRef } from "react";

import { CircleLargeMediumIcon } from "./CircleLargeMediumIcon";
import { CircleLargeRegularIcon } from "./CircleLargeRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CircleLargeIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CircleLargeIcon = forwardRef(
  (
    { size = "regular", ...props }: CircleLargeIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CircleLargeRegularIcon />;

    if (size === "medium") {
      icon = <CircleLargeMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CircleLargeIcon.displayName = "CircleLargeIcon";

export type { CircleLargeIconProps };
export { CircleLargeIcon };
