import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const DatabasePictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M36.523 16.917c2.966-1.424 4.007-3.02 4.007-4.19 0-1.168-1.041-2.765-4.007-4.189C33.68 7.174 29.61 6.273 25 6.273s-8.681.901-11.523 2.265c-2.966 1.424-4.007 3.02-4.007 4.19h.022v.296c.162 1.134 1.263 2.586 3.985 3.893C16.32 18.28 20.39 19.182 25 19.182s8.682-.901 11.523-2.265m-27.031 8.7V16.74c2.976 2.645 8.805 4.443 15.508 4.443 6.723 0 12.566-1.808 15.534-4.466v8.748c-1.205 1.24-3.154 2.369-5.694 3.211-2.789.925-6.202 1.476-9.904 1.476-3.597 0-6.923-.52-9.668-1.4-2.542-.813-4.52-1.913-5.776-3.134m0 2.614v7.041c0 1.816 1.33 3.658 4.084 5.1 2.732 1.431 6.687 2.355 11.424 2.355s8.7-.924 11.438-2.355c2.762-1.443 4.096-3.285 4.096-5.1v-7.149c-1.376.982-3.09 1.804-5.014 2.442-3.031 1.006-6.677 1.586-10.584 1.586-3.798 0-7.348-.548-10.327-1.502-1.961-.628-3.708-1.443-5.117-2.418m33.126-15.504h-.005c0-4.669-7.885-8.454-17.613-8.454S7.387 8.058 7.387 12.728q0 .212.021.422v22.123c0 2.853 2.082 5.238 5.17 6.855 3.112 1.63 7.431 2.599 12.422 2.599 4.99 0 9.316-.97 12.434-2.598 3.093-1.616 5.184-4.002 5.184-6.856z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DatabasePictogram.displayName = "DatabasePictogram";
export { DatabasePictogram };
