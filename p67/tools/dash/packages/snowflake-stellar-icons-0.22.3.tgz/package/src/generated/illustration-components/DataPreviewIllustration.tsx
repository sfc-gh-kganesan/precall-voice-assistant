import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { IconProps } from "../../types";
import { IllustrationWrapper } from "../../IllustrationWrapper";
const DataPreviewIllustration = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const idPrefix = useId();
    return (
      <IllustrationWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={`url(#${idPrefix}-svg-1416947307__a)`}
              d="M58.142 44.936c4.551-2.384 11.307-2.367 15.848.04l28.947 15.346c5.549 2.942 5.535 8.179-.031 11.09L74.371 86.337c-4.554 2.382-11.31 2.361-15.848-.048l-28.9-15.346c-5.54-2.942-5.524-8.171.031-11.082z"
            />
            <path
              fill={`url(#${idPrefix}-svg-1416947307__b)`}
              d="M58.142 33.936c4.551-2.384 11.307-2.367 15.848.04l28.947 15.346c5.549 2.942 5.535 8.179-.031 11.09L74.371 75.337c-4.554 2.382-11.31 2.361-15.848-.048l-28.9-15.346c-5.54-2.942-5.524-8.171.031-11.082z"
            />
            <mask
              id={`${idPrefix}-svg-1416947307__d`}
              width={83}
              height={46}
              x={25}
              y={43}
              maskUnits="userSpaceOnUse"
              style={{
                maskType: "alpha",
              }}
            >
              <path
                fill={`url(#${idPrefix}-svg-1416947307__c)`}
                d="M58.142 44.936c4.551-2.384 11.307-2.367 15.848.04l28.947 15.346c5.549 2.942 5.535 8.179-.031 11.09L74.371 86.337c-4.554 2.382-11.31 2.361-15.848-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.031-11.082z"
              />
            </mask>
            <g mask={`url(#${idPrefix}-svg-1416947307__d)`}>
              <g filter={`url(#${idPrefix}-svg-1416947307__e)`}>
                <path
                  fill={`url(#${idPrefix}-svg-1416947307__f)`}
                  fillRule="evenodd"
                  d="M100.908 29h-.233c-12.361 0-22.585 9.153-24.264 21.052a25 25 0 0 0-.278 3.723c0 13.683 11.093 24.775 24.775 24.775a24.67 24.67 0 0 0 14.8-4.905l14.044 14.044a2.356 2.356 0 0 0 3.332-3.332L119.205 70.48a24.68 24.68 0 0 0 6.478-16.704c0-13.683-11.092-24.775-24.775-24.775"
                  clipRule="evenodd"
                />
              </g>
              <g filter={`url(#${idPrefix}-svg-1416947307__g)`}>
                <path
                  fill={`url(#${idPrefix}-svg-1416947307__h)`}
                  d="M58.142 33.936c4.551-2.384 11.307-2.367 15.848.04l28.947 15.346c5.549 2.942 5.535 8.179-.031 11.09L74.371 75.337c-4.554 2.382-11.31 2.361-15.848-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.031-11.082z"
                />
              </g>
            </g>
            <path
              fill={`url(#${idPrefix}-svg-1416947307__i)`}
              d="M58.142 20.936c4.551-2.384 11.307-2.367 15.848.04l28.947 15.346c5.549 2.942 5.535 8.179-.031 11.09L74.371 62.337c-4.554 2.382-11.31 2.361-15.848-.048l-28.9-15.346c-5.54-2.942-5.524-8.171.031-11.082z"
            />
            <mask
              id={`${idPrefix}-svg-1416947307__k`}
              width={83}
              height={46}
              x={25}
              y={32}
              maskUnits="userSpaceOnUse"
              style={{
                maskType: "alpha",
              }}
            >
              <path
                fill={`url(#${idPrefix}-svg-1416947307__j)`}
                d="M58.142 33.936c4.551-2.384 11.307-2.367 15.848.04l28.947 15.346c5.549 2.942 5.535 8.179-.031 11.09L74.371 75.337c-4.554 2.382-11.31 2.361-15.848-.048l-28.9-15.346c-5.54-2.942-5.525-8.171.031-11.082z"
              />
            </mask>
            <g mask={`url(#${idPrefix}-svg-1416947307__k)`}>
              <g filter={`url(#${idPrefix}-svg-1416947307__l)`}>
                <path
                  fill={`url(#${idPrefix}-svg-1416947307__m)`}
                  fillRule="evenodd"
                  d="M102.908 31h-.233c-12.361 0-22.585 9.153-24.264 21.052a25 25 0 0 0-.278 3.723c0 13.683 11.093 24.775 24.775 24.775a24.67 24.67 0 0 0 14.8-4.905l14.044 14.044a2.356 2.356 0 0 0 3.332-3.332L121.205 72.48a24.68 24.68 0 0 0 6.478-16.704c0-13.683-11.092-24.775-24.775-24.775"
                  clipRule="evenodd"
                />
              </g>
              <g filter={`url(#${idPrefix}-svg-1416947307__n)`}>
                <path
                  fill={`url(#${idPrefix}-svg-1416947307__o)`}
                  d="M58.142 21.001c4.551-2.384 11.307-2.367 15.848.04l28.947 15.346c5.549 2.942 5.535 8.179-.031 11.09L74.371 62.402c-4.554 2.382-11.31 2.361-15.848-.048l-28.9-15.346c-5.54-2.942-5.525-8.172.031-11.082z"
                />
                <path
                  fill={`url(#${idPrefix}-svg-1416947307__p)`}
                  fillRule="evenodd"
                  d="m99.458 28.81-.101.001h-.132c-12.362 0-22.586 9.153-24.264 21.052a25 25 0 0 0-.278 3.723c0 13.682 11.092 24.774 24.775 24.774q.159 0 .318-.002c8.353-.105 19.047-.337 23.389 4.005l5.137 5.137a2.356 2.356 0 0 0 3.332-3.332l-10.232-10.23c-2.255-2.256-2.247-5.05-.748-7.52a24.66 24.66 0 0 0 3.579-12.832c0-13.683-11.092-24.775-24.775-24.775"
                  clipRule="evenodd"
                />
              </g>
            </g>
            <path
              fill={`url(#${idPrefix}-svg-1416947307__q)`}
              fillRule="evenodd"
              d="M99.227 28.647h-.233C86.632 28.647 76.41 37.8 74.73 49.7a25 25 0 0 0-.278 3.723c0 13.683 11.093 24.775 24.775 24.775 5.548 0 10.671-1.824 14.8-4.905l14.044 14.044a2.356 2.356 0 0 0 3.332-3.331l-13.879-13.88a24.68 24.68 0 0 0 6.478-16.703c0-13.683-11.092-24.775-24.775-24.775"
              clipRule="evenodd"
            />
            <path
              fill={`url(#${idPrefix}-svg-1416947307__r)`}
              fillRule="evenodd"
              d="M87.706 43.734a1.5 1.5 0 0 0 0 3h1.616a1.5 1.5 0 0 0 0-3zm0 6.3a1.5 1.5 0 1 0 0 3h1.616a1.5 1.5 0 0 0 0-3zm6.117-5.3a1 1 0 0 1 1-1h17.124a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H94.823a1 1 0 0 1-1-1zm1 5.3a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h17.124a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1zm-8.616 7.8a1.5 1.5 0 0 1 1.5-1.5h1.616a1.5 1.5 0 0 1 0 3h-1.616a1.5 1.5 0 0 1-1.5-1.5m8.616-1.5a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h17.124a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1zm-8.617 7.8a1.5 1.5 0 0 1 1.5-1.5h1.616a1.5 1.5 0 1 1 0 3h-1.616a1.5 1.5 0 0 1-1.5-1.5m8.617-1.5a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h17.124a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1z"
              clipRule="evenodd"
            />
            <defs>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__a`}
                x1={126.512}
                x2={130.292}
                y1={25.762}
                y2={127.693}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__b`}
                x1={127.733}
                x2={130.865}
                y1={25.775}
                y2={182.957}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__c`}
                x1={126.512}
                x2={130.292}
                y1={25.762}
                y2={127.693}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__f`}
                x1={97.431}
                x2={133.664}
                y1={34.65}
                y2={91.625}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#B2D1FE" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__h`}
                x1={127.733}
                x2={130.865}
                y1={25.775}
                y2={182.957}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__i`}
                x1={77.15}
                x2={74.37}
                y1={31.456}
                y2={125.078}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__j`}
                x1={127.733}
                x2={130.865}
                y1={25.775}
                y2={182.957}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__m`}
                x1={99.431}
                x2={135.664}
                y1={36.65}
                y2={93.625}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#B2D1FE" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__o`}
                x1={77.15}
                x2={74.37}
                y1={31.521}
                y2={125.143}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__p`}
                x1={77.15}
                x2={74.37}
                y1={31.521}
                y2={125.143}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#ECF3FF" />
                <stop offset={1} stopColor="#5B9CFC" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__q`}
                x1={103.273}
                x2={132.598}
                y1={23.393}
                y2={78.682}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#76AEFF" />
                <stop offset={1} stopColor="#0F53FA" />
              </linearGradient>
              <linearGradient
                id={`${idPrefix}-svg-1416947307__r`}
                x1={81.506}
                x2={136.023}
                y1={71.355}
                y2={75.509}
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#fff" />
                <stop offset={1} stopColor="#fff" stopOpacity={0} />
              </linearGradient>
              <filter
                id={`${idPrefix}-svg-1416947307__e`}
                width={79.64}
                height={81.379}
                x={65.133}
                y={18}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset />
                <feGaussianBlur stdDeviation={5.5} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_664"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_664"
                  result="shape"
                />
              </filter>
              <filter
                id={`${idPrefix}-svg-1416947307__g`}
                width={95.612}
                height={58.951}
                x={18.478}
                y={29.159}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset dy={4} />
                <feGaussianBlur stdDeviation={3.5} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_664"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_664"
                  result="shape"
                />
              </filter>
              <filter
                id={`${idPrefix}-svg-1416947307__l`}
                width={79.64}
                height={81.379}
                x={67.133}
                y={20}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset />
                <feGaussianBlur stdDeviation={5.5} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_664"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_664"
                  result="shape"
                />
              </filter>
              <filter
                id={`${idPrefix}-svg-1416947307__n`}
                width={120.846}
                height={82.966}
                x={18.478}
                y={16.224}
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
              >
                <feFlood floodOpacity={0} result="BackgroundImageFix" />
                <feColorMatrix
                  in="SourceAlpha"
                  result="hardAlpha"
                  values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
                />
                <feOffset dy={4} />
                <feGaussianBlur stdDeviation={3.5} />
                <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0" />
                <feBlend
                  in2="BackgroundImageFix"
                  mode="overlay"
                  result="effect1_dropShadow_1_664"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="effect1_dropShadow_1_664"
                  result="shape"
                />
              </filter>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
DataPreviewIllustration.displayName = "DataPreviewIllustration";
export { DataPreviewIllustration };
