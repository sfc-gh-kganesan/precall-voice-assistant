import { forwardRef, ForwardedRef } from "react";

import { ChartPieMediumIcon } from "./ChartPieMediumIcon";
import { ChartPieRegularIcon } from "./ChartPieRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChartPieIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChartPieIcon = forwardRef(
  (
    { size = "regular", ...props }: ChartPieIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChartPieRegularIcon />;

    if (size === "medium") {
      icon = <ChartPieMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChartPieIcon.displayName = "ChartPieIcon";

export type { ChartPieIconProps };
export { ChartPieIcon };
