import { forwardRef, ForwardedRef } from "react";

import { ChevronRightSmallMediumIcon } from "./ChevronRightSmallMediumIcon";
import { ChevronRightSmallRegularIcon } from "./ChevronRightSmallRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronRightSmallIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronRightSmallIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronRightSmallIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronRightSmallRegularIcon />;

    if (size === "medium") {
      icon = <ChevronRightSmallMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronRightSmallIcon.displayName = "ChevronRightSmallIcon";

export type { ChevronRightSmallIconProps };
export { ChevronRightSmallIcon };
