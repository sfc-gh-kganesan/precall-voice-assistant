import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DollarSignMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M10.625 4.403q.723.077 1.314.361.812.39 1.279 1.072.466.676.487 1.557h-1.512q-.082-.757-.67-1.174-.59-.42-1.482-.42-.64 0-1.106.213-.467.208-.726.576-.253.363-.253.827 0 .389.172.67.177.285.461.476.29.186.62.314.33.122.634.202l1.015.278q.498.128 1.02.346.522.219.969.576t.721.885q.279.528.279 1.263 0 .929-.457 1.648-.451.72-1.313 1.136-.63.304-1.452.386V17.5h-1.25v-1.907a4.4 4.4 0 0 1-1.395-.357 3.14 3.14 0 0 1-1.334-1.104q-.483-.72-.534-1.707h1.574q.046.592.366.987.325.39.826.58.509.188 1.112.188.664 0 1.182-.219.523-.224.823-.617.3-.401.299-.934 0-.486-.264-.795a1.95 1.95 0 0 0-.705-.511 7 7 0 0 0-1-.358l-1.228-.352q-1.248-.357-1.979-1.05-.726-.694-.726-1.834 0-.943.487-1.647t1.32-1.094a4 4 0 0 1 1.176-.346V2.5h1.25z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DollarSignMediumIcon.displayName = "DollarSignMediumIcon";
export { DollarSignMediumIcon };
