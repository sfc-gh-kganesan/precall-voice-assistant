import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClassificationRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M9.5 3a1.5 1.5 0 0 1 0 3h-1v2h4a.5.5 0 0 1 .5.5V10h.5a1.5 1.5 0 0 1 0 3h-1a1.5 1.5 0 0 1-.5-2.913V9H8.5v1a1.5 1.5 0 0 1 0 3h-1a1.5 1.5 0 0 1 0-3V9H4v1.087A1.5 1.5 0 0 1 3.5 13h-1a1.5 1.5 0 0 1 0-3H3V8.5a.5.5 0 0 1 .5-.5h4V6h-1a1.5 1.5 0 1 1 0-3zm3 8a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1zm-10 0a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1zm5 0a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1zm-1-7a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClassificationRegularIcon.displayName = "ClassificationRegularIcon";
export { ClassificationRegularIcon };
