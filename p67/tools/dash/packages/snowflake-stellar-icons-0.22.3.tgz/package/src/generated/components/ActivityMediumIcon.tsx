import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ActivityMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.516 2.5c.242.006.46.153.557.375l4.456 12.678 2.534-6.451.044-.077a.63.63 0 0 1 .518-.275h3.125V10h-2.734l-2.954 7.316a.625.625 0 0 1-1.134-.022L7.462 4.597l-2.528 6.308a.63.63 0 0 1-.559.345H1.25V10h2.74l2.95-7.154.047-.077a.63.63 0 0 1 .529-.269"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ActivityMediumIcon.displayName = "ActivityMediumIcon";
export { ActivityMediumIcon };
