import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ColumnSingleMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M13.125 2.5a.625.625 0 0 1 .625.625v13.75l-.012.126a.626.626 0 0 1-.613.499h-6.25a.625.625 0 0 1-.625-.625V3.125c0-.345.28-.625.625-.625zM7.5 13.125v3.125h5v-3.125zm0-5v3.75h5v-3.75zm0-1.25h5V3.75h-5z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ColumnSingleMediumIcon.displayName = "ColumnSingleMediumIcon";
export { ColumnSingleMediumIcon };
