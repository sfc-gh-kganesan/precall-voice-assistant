import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { IconProps } from "../../types";
import { useIconContext } from "../../useIconContext";
import { PictogramWrapper } from "../../PictogramWrapper";
const DataPreviewPictogram = forwardRef(
  (props: IconProps, ref: ForwardedRef<SVGSVGElement>) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <PictogramWrapper
        ref={ref}
        svgContent={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M38.55 22.775c0 8.16-6.615 14.775-14.775 14.775S9 30.935 9 22.775 15.615 8 23.775 8 38.55 14.615 38.55 22.775M34.91 35.323a16.7 16.7 0 0 1-11.134 4.227C14.51 39.55 7 32.04 7 22.775S14.51 6 23.775 6 40.55 13.51 40.55 22.775c0 4.273-1.597 8.172-4.227 11.134l7.384 7.384a1 1 0 0 1-1.414 1.414z"
              clipRule="evenodd"
            />
            <path
              fill={iconColor}
              d="M13.864 17.235h2.083v2h-2.083zM13.864 21.678h2.083v2h-2.083zM13.864 26.121h2.083v2h-2.083zM17.247 17.235h16.667v2H17.247zM17.247 21.678h16.667v2H17.247zM17.247 26.121h16.667v2H17.247z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataPreviewPictogram.displayName = "DataPreviewPictogram";
export { DataPreviewPictogram };
