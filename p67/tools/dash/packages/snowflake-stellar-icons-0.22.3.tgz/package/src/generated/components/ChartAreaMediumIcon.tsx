import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartAreaMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M15.625 2.5c1.035 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875H4.375A1.875 1.875 0 0 1 2.5 15.625V4.375c0-1.036.84-1.875 1.875-1.875zM3.75 13.384v2.241c0 .345.28.625.625.625H6.25v-5.366zM7.5 16.25h1.875v-4.741L7.5 9.634zm6.25-6.616v6.616h1.875c.345 0 .625-.28.625-.625V7.134zm-2.241 2.241a1.25 1.25 0 0 1-.884.366v4.009H12.5v-5.366zM4.375 3.75a.625.625 0 0 0-.625.625v7.241L6.616 8.75a1.25 1.25 0 0 1 1.768 0l2.241 2.241 5.625-5.625v-.991a.625.625 0 0 0-.625-.625z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartAreaMediumIcon.displayName = "ChartAreaMediumIcon";
export { ChartAreaMediumIcon };
