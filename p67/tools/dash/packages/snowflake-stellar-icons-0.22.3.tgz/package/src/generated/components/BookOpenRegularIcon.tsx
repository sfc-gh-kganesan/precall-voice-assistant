import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BookOpenRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.403 4.449A4.77 4.77 0 0 0 2 4.61v7.41a5.36 5.36 0 0 1 5.5-.052V4.51zM14 4.505a4.98 4.98 0 0 0-5.332-.088l-.168.101v7.474a5.56 5.56 0 0 1 5.5-.034zm1 7.987c0 .568-.639.9-1.104.576a4.57 4.57 0 0 0-4.994-.153l-.641.392-.269.163-.263-.17-.573-.37a4.36 4.36 0 0 0-5.036.221.694.694 0 0 1-1.12-.548V4.462c0-.22.101-.427.274-.562l.184-.137a5.77 5.77 0 0 1 6.487-.155l.062.04.14-.085a5.98 5.98 0 0 1 6.545.2.72.72 0 0 1 .308.59z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BookOpenRegularIcon.displayName = "BookOpenRegularIcon";
export { BookOpenRegularIcon };
