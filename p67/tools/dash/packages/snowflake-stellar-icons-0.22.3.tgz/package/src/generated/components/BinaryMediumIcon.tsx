import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BinaryMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M11.25 16.25H10V3.75h1.25z" />
              <path
                fillRule="evenodd"
                d="M4.375 5C6.101 5 7.5 6.4 7.5 8.125v3.75a3.125 3.125 0 1 1-6.25 0v-3.75C1.25 6.399 2.65 5 4.375 5m0 1.25c-1.036 0-1.875.84-1.875 1.875v3.75a1.875 1.875 0 0 0 3.75 0v-3.75c0-1.036-.84-1.875-1.875-1.875"
                clipRule="evenodd"
              />
              <path d="M16.875 5a.625.625 0 0 1 .625.625v8.125h1.25V15H15v-1.25h1.25v-7.5H15V5z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BinaryMediumIcon.displayName = "BinaryMediumIcon";
export { BinaryMediumIcon };
