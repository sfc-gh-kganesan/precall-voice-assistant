import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const AiMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M14.184 11.282a.614.614 0 0 1 1.147 0 4.9 4.9 0 0 0 2.677 2.77l.25.098.081.029a.62.62 0 0 1 0 1.168l-.259.102a4.97 4.97 0 0 0-2.738 2.891c-.184.514-.878.546-1.126.097l-.043-.097a4.97 4.97 0 0 0-2.998-2.993l-.097-.042a.622.622 0 0 1 .097-1.126l.082-.03a4.9 4.9 0 0 0 2.824-2.62zm.573 1.612a6.2 6.2 0 0 1-1.93 1.878 6.2 6.2 0 0 1 1.93 1.934 6.2 6.2 0 0 1 1.93-1.934 6.2 6.2 0 0 1-1.93-1.878M6.744 1.913c.322-.884 1.574-.884 1.896 0a8.07 8.07 0 0 0 4.83 4.823c.885.322.885 1.573 0 1.895l-.415.163a8.07 8.07 0 0 0-4.414 4.66c-.303.829-1.422.88-1.827.155l-.07-.155a8.07 8.07 0 0 0-4.83-4.823l-.156-.07c-.726-.405-.674-1.523.156-1.825A8.07 8.07 0 0 0 6.58 2.327zm.948.988a9.32 9.32 0 0 1-4.789 4.781 9.32 9.32 0 0 1 4.789 4.783 9.32 9.32 0 0 1 4.788-4.783 9.32 9.32 0 0 1-4.788-4.781"
                clipRule="evenodd"
              />
              <path d="M17.5 3.75h1.25V5H17.5v1.25h-1.25V5H15V3.75h1.25V2.5h1.25z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
AiMediumIcon.displayName = "AiMediumIcon";
export { AiMediumIcon };
