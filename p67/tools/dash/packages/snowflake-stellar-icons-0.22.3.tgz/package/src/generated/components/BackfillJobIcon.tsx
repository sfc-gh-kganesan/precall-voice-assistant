import { forwardRef, ForwardedRef } from "react";

import { BackfillJobMediumIcon } from "./BackfillJobMediumIcon";
import { BackfillJobRegularIcon } from "./BackfillJobRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BackfillJobIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BackfillJobIcon = forwardRef(
  (
    { size = "regular", ...props }: BackfillJobIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BackfillJobRegularIcon />;

    if (size === "medium") {
      icon = <BackfillJobMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BackfillJobIcon.displayName = "BackfillJobIcon";

export type { BackfillJobIconProps };
export { BackfillJobIcon };
