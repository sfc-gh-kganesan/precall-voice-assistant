import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CommaMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M9.825 6.25c.746 0 1.407.353 1.833.898 1.191 1.472 1.069 4.749-1.867 6.24-1.074.546-1.443-.57-.616-1.448.285-.303.552-.648.79-1.048q-.07.006-.14.008a2.325 2.325 0 1 1 0-4.65"
            />
          </>
        }
        {...props}
      />
    );
  },
);
CommaMediumIcon.displayName = "CommaMediumIcon";
export { CommaMediumIcon };
