import { forwardRef, ForwardedRef } from "react";

import { CircleMediumIcon } from "./CircleMediumIcon";
import { CircleRegularIcon } from "./CircleRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CircleIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CircleIcon = forwardRef(
  (
    { size = "regular", ...props }: CircleIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CircleRegularIcon />;

    if (size === "medium") {
      icon = <CircleMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CircleIcon.displayName = "CircleIcon";

export type { CircleIconProps };
export { CircleIcon };
