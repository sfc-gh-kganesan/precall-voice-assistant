import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChartStackedMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M13.75 6.875c0-.345.28-.625.625-.625h3.75c.345 0 .625.28.625.625v8.75a.625.625 0 0 1-.625.625h-3.75l-.122-.012a.625.625 0 0 1-.503-.613zM17.5 15v-5H15v5zm0-6.25V7.5H15v1.25zm-10-4.375c0-.345.28-.625.625-.625h3.75c.345 0 .625.28.625.625v11.25l-.012.126a.626.626 0 0 1-.613.499h-3.75l-.122-.012a.625.625 0 0 1-.503-.613zm3.75 1.875V5h-2.5v1.25zm0 8.75V7.5h-2.5V15zm-10-5.625c0-.345.28-.625.625-.625h3.75c.345 0 .625.28.625.625v6.25a.625.625 0 0 1-.625.625h-3.75l-.122-.012a.625.625 0 0 1-.503-.613zM5 15v-2.5H2.5V15zm0-3.75V10H2.5v1.25z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChartStackedMediumIcon.displayName = "ChartStackedMediumIcon";
export { ChartStackedMediumIcon };
