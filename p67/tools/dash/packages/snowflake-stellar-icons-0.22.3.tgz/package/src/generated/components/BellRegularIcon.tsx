import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BellRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M7 13c0 .106.05.214.229.32.188.11.47.18.771.18.3 0 .583-.07.771-.18.18-.106.229-.214.229-.32h1c0 .56-.334.953-.722 1.18-.378.223-.846.32-1.278.32s-.9-.097-1.278-.32C6.334 13.954 6 13.56 6 13z" />
              <path
                fillRule="evenodd"
                d="M8.071 2a4.786 4.786 0 0 1 4.786 4.786v1.108a.5.5 0 0 0 .159.366l.713.666a1.3 1.3 0 0 1 .414.95V11.5a.5.5 0 0 1-.5.5H2.5a.5.5 0 0 1-.5-.5v-1.437c0-.501.25-.97.668-1.248l.395-.262a.5.5 0 0 0 .223-.416v-1.35A4.786 4.786 0 0 1 8.071 2m0 1a3.786 3.786 0 0 0-3.785 3.786v1.35c0 .502-.25.97-.668 1.249l-.395.262a.5.5 0 0 0-.223.416V11h10.143V9.876a.3.3 0 0 0-.095-.219l-.714-.667a1.5 1.5 0 0 1-.477-1.096V6.786A3.786 3.786 0 0 0 8.071 3"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BellRegularIcon.displayName = "BellRegularIcon";
export { BellRegularIcon };
