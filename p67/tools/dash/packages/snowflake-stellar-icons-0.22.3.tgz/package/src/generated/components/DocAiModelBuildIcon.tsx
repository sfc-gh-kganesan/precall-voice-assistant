import { forwardRef, ForwardedRef } from "react";

import { DocAiModelBuildMediumIcon } from "./DocAiModelBuildMediumIcon";
import { DocAiModelBuildRegularIcon } from "./DocAiModelBuildRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface DocAiModelBuildIconProps extends IconProps {
  size?: "medium" | "regular";
}

const DocAiModelBuildIcon = forwardRef(
  (
    { size = "regular", ...props }: DocAiModelBuildIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <DocAiModelBuildRegularIcon />;

    if (size === "medium") {
      icon = <DocAiModelBuildMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

DocAiModelBuildIcon.displayName = "DocAiModelBuildIcon";

export type { DocAiModelBuildIconProps };
export { DocAiModelBuildIcon };
