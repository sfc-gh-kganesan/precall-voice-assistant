import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChevronRightMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="m7.317 3.308 6.25 6.25a.625.625 0 0 1 0 .884l-6.25 6.25-.884-.884L12.241 10 6.433 4.192z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ChevronRightMediumIcon.displayName = "ChevronRightMediumIcon";
export { ChevronRightMediumIcon };
