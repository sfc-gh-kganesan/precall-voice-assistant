import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ClassificationMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M11.875 3.75a1.875 1.875 0 0 1 0 3.75h-1.25V10h5c.345 0 .625.28.625.625V12.5h.625a1.875 1.875 0 0 1 0 3.75h-1.25A1.875 1.875 0 0 1 15 12.609V11.25h-4.375v1.25a1.875 1.875 0 0 1 0 3.75h-1.25a1.875 1.875 0 0 1 0-3.75v-1.25H5v1.359a1.874 1.874 0 0 1-.625 3.641h-1.25a1.875 1.875 0 0 1 0-3.75h.625v-1.875c0-.345.28-.625.625-.625h5V7.5h-1.25a1.875 1.875 0 0 1 0-3.75zm3.75 10a.625.625 0 1 0 0 1.25h1.25a.625.625 0 1 0 0-1.25zm-12.5 0a.625.625 0 1 0 0 1.25h1.25a.625.625 0 1 0 0-1.25zm6.25 0a.625.625 0 1 0 0 1.25h1.25a.625.625 0 1 0 0-1.25zM8.125 5a.625.625 0 1 0 0 1.25h3.75a.625.625 0 1 0 0-1.25z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ClassificationMediumIcon.displayName = "ClassificationMediumIcon";
export { ClassificationMediumIcon };
