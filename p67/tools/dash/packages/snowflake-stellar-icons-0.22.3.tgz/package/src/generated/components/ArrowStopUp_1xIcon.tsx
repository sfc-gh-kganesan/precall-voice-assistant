import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ArrowStopUp_1xIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              d="M7.5 4.5a.5.5 0 0 1 .354.146l4.5 4.5-.707.708L8 6.207V14H7V6.207L3.354 9.854l-.708-.708 4.5-4.5A.5.5 0 0 1 7.5 4.5M14 3H1V2h13z"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ArrowStopUp_1xIcon.displayName = "ArrowStopUp_1xIcon";
export { ArrowStopUp_1xIcon };
