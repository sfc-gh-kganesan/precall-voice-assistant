import { forwardRef, ForwardedRef } from "react";

import { ApprovalMediumIcon } from "./ApprovalMediumIcon";
import { ApprovalRegularIcon } from "./ApprovalRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ApprovalIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ApprovalIcon = forwardRef(
  (
    { size = "regular", ...props }: ApprovalIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ApprovalRegularIcon />;

    if (size === "medium") {
      icon = <ApprovalMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ApprovalIcon.displayName = "ApprovalIcon";

export type { ApprovalIconProps };
export { ApprovalIcon };
