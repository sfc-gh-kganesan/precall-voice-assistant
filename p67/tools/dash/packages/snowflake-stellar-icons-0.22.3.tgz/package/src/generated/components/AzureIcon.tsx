import { forwardRef, ForwardedRef } from "react";

import { AzureMediumIcon } from "./AzureMediumIcon";
import { AzureRegularIcon } from "./AzureRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface AzureIconProps extends IconProps {
  size?: "medium" | "regular";
}

const AzureIcon = forwardRef(
  (
    { size = "regular", ...props }: AzureIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <AzureRegularIcon />;

    if (size === "medium") {
      icon = <AzureMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

AzureIcon.displayName = "AzureIcon";

export type { AzureIconProps };
export { AzureIcon };
