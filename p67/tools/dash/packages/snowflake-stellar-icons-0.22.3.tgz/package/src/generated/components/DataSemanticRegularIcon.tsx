import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DataSemanticRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M8.001 2c1.296 0 2.493.233 3.385.629.445.198.837.447 1.124.748.27.284.461.634.486 1.036h.005v.664l.001.023-.001.021v5.639c.008.068.016.148.016.232l-.008.182c-.08.892-.74 1.59-1.578 2.05C10.524 13.72 9.308 14 8 14c-1.315 0-2.53-.307-3.433-.83C3.677 12.659 3 11.873 3 10.902v-.42c-.25-.288-.38-.55-.441-.718A1 1 0 0 1 2.5 9.4V6.5A.5.5 0 0 1 3 6V4.413h.006c.025-.402.216-.752.486-1.036.287-.301.679-.55 1.124-.748C5.508 2.233 6.706 2 8.001 2M4 7.068q.09.075.202.154c.682.465 2.05.968 4.728.817A1.01 1.01 0 0 1 10 9.043v1.997c0 .52-.403.96-.93.992-2.455.149-4.005-.214-4.987-.722.14.343.458.692.984.997C5.793 12.726 6.83 13 8 13c1.178 0 2.22-.255 2.95-.654.696-.381 1.024-.838 1.063-1.269l.004-.086q0-.053-.012-.137l-.005-.03V6.04a4.4 4.4 0 0 1-.615.331C10.494 6.767 9.296 7 8 7s-2.493-.233-3.385-.629A4.4 4.4 0 0 1 4 6.04zm-.5 2.36c.046.124.254.572.993.97.762.409 2.122.78 4.507.636v-1.99l-.002-.003-.005-.003h-.007c-2.81.158-4.422-.359-5.347-.99l-.139-.1zM8.001 3c-1.119 0-2.116.251-2.836.64-.603.327-.957.718-1.095 1.094a1 1 0 0 0 .147.2c.168.177.437.36.805.523.737.327 1.79.543 2.979.543s2.242-.216 2.979-.543c.368-.164.636-.346.805-.523a1 1 0 0 0 .146-.2c-.138-.376-.491-.767-1.094-1.093-.63-.34-1.472-.576-2.422-.63z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
DataSemanticRegularIcon.displayName = "DataSemanticRegularIcon";
export { DataSemanticRegularIcon };
