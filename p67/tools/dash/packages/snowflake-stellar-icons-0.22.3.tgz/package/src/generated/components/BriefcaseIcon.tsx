import { forwardRef, ForwardedRef } from "react";

import { BriefcaseMediumIcon } from "./BriefcaseMediumIcon";
import { BriefcaseRegularIcon } from "./BriefcaseRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface BriefcaseIconProps extends IconProps {
  size?: "medium" | "regular";
}

const BriefcaseIcon = forwardRef(
  (
    { size = "regular", ...props }: BriefcaseIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <BriefcaseRegularIcon />;

    if (size === "medium") {
      icon = <BriefcaseMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

BriefcaseIcon.displayName = "BriefcaseIcon";

export type { BriefcaseIconProps };
export { BriefcaseIcon };
