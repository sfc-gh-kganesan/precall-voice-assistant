import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const DeleteMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M8.75 13.75H7.5v-5h1.25zm3.75 0h-1.25v-5h1.25z" />
              <path
                fillRule="evenodd"
                d="M11.875 2.5c1.036 0 1.875.84 1.875 1.875V5h3.75v1.25h-1.284l-.526 9.479a1.876 1.876 0 0 1-1.873 1.771H6.183a1.876 1.876 0 0 1-1.873-1.771L3.784 6.25H2.5V5h3.75v-.625c0-1.036.84-1.875 1.875-1.875zM5.558 15.66c.018.33.293.59.625.59h7.634c.332 0 .607-.26.625-.59l.523-9.41h-9.93zM8.125 3.75a.625.625 0 0 0-.625.625V5h5v-.625a.625.625 0 0 0-.625-.625z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
DeleteMediumIcon.displayName = "DeleteMediumIcon";
export { DeleteMediumIcon };
