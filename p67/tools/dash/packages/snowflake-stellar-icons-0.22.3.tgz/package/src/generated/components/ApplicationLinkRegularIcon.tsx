import { useId } from "@react-aria/utils";
import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ApplicationLinkRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const idPrefix = useId();
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} clipPath={`url(#${idPrefix}-prefix__a)`}>
              <path d="M10 11H8.096a2.011 2.011 0 0 0 0 4.02H10v1H8.096a3.01 3.01 0 1 1 0-6.02H10zm2.99-1a3.011 3.011 0 0 1 0 6.02h-1.93v-1h1.93a2.01 2.01 0 1 0 0-4.02h-1.93v-1z" />
              <path d="M13 13.5H8v-1h5zM7.753 1.315a.5.5 0 0 1 .494 0L13.75 4.44a.5.5 0 0 1 .253.435V9h-1V5.165L8 2.325l-5.002 2.84v5.669L4 11.402v1.152l-1.749-.993a.5.5 0 0 1-.253-.435V4.875l.005-.066a.5.5 0 0 1 .248-.369z" />
              <path d="M8 5a3 3 0 0 1 3 3c0 .351-.064.687-.175 1H9.73A2 2 0 1 0 6 8c0 .365.1.706.27 1H5.174A3 3 0 0 1 8 5" />
            </g>
            <defs>
              <clipPath id={`${idPrefix}-prefix__a`}>
                <path fill="#fff" d="M0 0h16v16H0z" />
              </clipPath>
            </defs>
          </>
        }
        {...props}
      />
    );
  },
);
ApplicationLinkRegularIcon.displayName = "ApplicationLinkRegularIcon";
export { ApplicationLinkRegularIcon };
