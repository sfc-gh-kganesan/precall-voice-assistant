import { forwardRef, ForwardedRef } from "react";

import { ChevronLeftMediumIcon } from "./ChevronLeftMediumIcon";
import { ChevronLeftRegularIcon } from "./ChevronLeftRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronLeftIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronLeftIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronLeftIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronLeftRegularIcon />;

    if (size === "medium") {
      icon = <ChevronLeftMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronLeftIcon.displayName = "ChevronLeftIcon";

export type { ChevronLeftIconProps };
export { ChevronLeftIcon };
