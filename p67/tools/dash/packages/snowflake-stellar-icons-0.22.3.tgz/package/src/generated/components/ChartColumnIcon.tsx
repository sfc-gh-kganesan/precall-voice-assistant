import { forwardRef, ForwardedRef } from "react";

import { ChartColumnMediumIcon } from "./ChartColumnMediumIcon";
import { ChartColumnRegularIcon } from "./ChartColumnRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChartColumnIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChartColumnIcon = forwardRef(
  (
    { size = "regular", ...props }: ChartColumnIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChartColumnRegularIcon />;

    if (size === "medium") {
      icon = <ChartColumnMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChartColumnIcon.displayName = "ChartColumnIcon";

export type { ChartColumnIconProps };
export { ChartColumnIcon };
