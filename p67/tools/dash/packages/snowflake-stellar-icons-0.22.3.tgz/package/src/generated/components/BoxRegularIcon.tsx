import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BoxRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M7.194 1.42a1.5 1.5 0 0 1 1.612 0l4.963 3.158A.5.5 0 0 1 14 5v5.451a1.5 1.5 0 0 1-.694 1.266l-5.037 3.205-.064.034a.5.5 0 0 1-.474-.034l-5.037-3.205A1.5 1.5 0 0 1 2 10.45V5a.5.5 0 0 1 .231-.423zM3 10.451a.5.5 0 0 0 .231.422L7.5 13.59V8.775L3 5.911zm8.472-3.568.021 2.795-.995.63-.021-2.791L8.5 8.775v4.815l4.269-2.717a.5.5 0 0 0 .231-.422v-4.54zM3.432 5 8 7.907l1.886-1.2-4.53-2.932zm4.837-2.736a.5.5 0 0 0-.538 0l-1.448.92 4.53 2.932L12.57 5z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BoxRegularIcon.displayName = "BoxRegularIcon";
export { BoxRegularIcon };
