import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ChatHeartMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor} fillRule="evenodd" clipRule="evenodd">
              <path d="M9.968 7.191a2.455 2.455 0 0 1 3.317.166c.982.994.914 2.434.034 3.484-.519.62-1.54 1.509-3.009 2.651a.624.624 0 0 1-.776-.007c-1.414-1.144-2.401-2.03-2.915-2.644-.88-1.05-.948-2.49.034-3.484a2.454 2.454 0 0 1 3.315-.166m2.427 1.045a1.206 1.206 0 0 0-1.721 0l-.261.265a.626.626 0 0 1-.89-.001l-.26-.264a1.205 1.205 0 0 0-1.72 0c-.46.465-.498 1.166.034 1.802.387.462 1.162 1.174 2.356 2.156 1.246-.987 2.044-1.698 2.428-2.156.532-.636.493-1.337.034-1.802" />
              <path d="M15.625 3.75c1.035 0 1.875.84 1.875 1.875v8.75c0 1.036-.84 1.875-1.875 1.875H6.422l-2.976 1.786A.625.625 0 0 1 2.5 17.5V5.625c0-1.036.84-1.875 1.875-1.875zM4.375 5a.625.625 0 0 0-.625.625v10.772l2.179-1.308.074-.039A.6.6 0 0 1 6.25 15h9.375c.345 0 .625-.28.625-.625v-8.75A.625.625 0 0 0 15.625 5z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
ChatHeartMediumIcon.displayName = "ChatHeartMediumIcon";
export { ChatHeartMediumIcon };
