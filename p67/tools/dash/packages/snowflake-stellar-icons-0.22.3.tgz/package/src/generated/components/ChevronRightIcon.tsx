import { forwardRef, ForwardedRef } from "react";

import { ChevronRightMediumIcon } from "./ChevronRightMediumIcon";
import { ChevronRightRegularIcon } from "./ChevronRightRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronRightIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronRightIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronRightIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronRightRegularIcon />;

    if (size === "medium") {
      icon = <ChevronRightMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronRightIcon.displayName = "ChevronRightIcon";

export type { ChevronRightIconProps };
export { ChevronRightIcon };
