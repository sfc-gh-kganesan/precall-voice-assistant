import { forwardRef, ForwardedRef } from "react";

import { CellCollapseResultMediumIcon } from "./CellCollapseResultMediumIcon";
import { CellCollapseResultRegularIcon } from "./CellCollapseResultRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface CellCollapseResultIconProps extends IconProps {
  size?: "medium" | "regular";
}

const CellCollapseResultIcon = forwardRef(
  (
    { size = "regular", ...props }: CellCollapseResultIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <CellCollapseResultRegularIcon />;

    if (size === "medium") {
      icon = <CellCollapseResultMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

CellCollapseResultIcon.displayName = "CellCollapseResultIcon";

export type { CellCollapseResultIconProps };
export { CellCollapseResultIcon };
