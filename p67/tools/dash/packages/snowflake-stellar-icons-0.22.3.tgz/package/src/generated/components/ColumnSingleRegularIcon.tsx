import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ColumnSingleRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M10.5 2a.5.5 0 0 1 .5.5v11l-.01.1a.5.5 0 0 1-.49.4h-5a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5zM6 10.5V13h4v-2.5zm0-4v3h4v-3zm0-1h4V3H6z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ColumnSingleRegularIcon.displayName = "ColumnSingleRegularIcon";
export { ColumnSingleRegularIcon };
