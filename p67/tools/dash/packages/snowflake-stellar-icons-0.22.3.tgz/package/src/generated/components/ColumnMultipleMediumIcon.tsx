import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const ColumnMultipleMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M13.75 4.375c0-.345.28-.625.625-.625h3.75c.345 0 .625.28.625.625v11.25l-.012.126a.626.626 0 0 1-.613.499h-3.75l-.122-.012a.625.625 0 0 1-.503-.613zM17.5 15V5H15v10zM7.5 4.375c0-.345.28-.625.625-.625h3.75c.345 0 .625.28.625.625v11.25l-.012.126a.626.626 0 0 1-.613.499h-3.75l-.122-.012a.625.625 0 0 1-.503-.613zM11.25 15V5h-2.5v10zm-10-10.625c0-.345.28-.625.625-.625h3.75c.345 0 .625.28.625.625v11.25l-.012.126a.626.626 0 0 1-.613.499h-3.75l-.122-.012a.625.625 0 0 1-.503-.613zM5 15V5H2.5v10z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
ColumnMultipleMediumIcon.displayName = "ColumnMultipleMediumIcon";
export { ColumnMultipleMediumIcon };
