import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const CalendarPlusRegularIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path d="M13.003 12.003H16v1h-2.997V16h-1v-2.997H9v-1h3.003V9h1z" />
              <path
                fillRule="evenodd"
                d="M6 3h4V2h1v1h1.5A1.5 1.5 0 0 1 14 4.5V7H3v5.5a.5.5 0 0 0 .5.5H7v1H3.5A1.5 1.5 0 0 1 2 12.5v-8A1.5 1.5 0 0 1 3.5 3H5V2h1zM3.5 4a.5.5 0 0 0-.5.5V6h10V4.5a.5.5 0 0 0-.5-.5H11v1h-1V4H6v1H5V4z"
                clipRule="evenodd"
              />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
CalendarPlusRegularIcon.displayName = "CalendarPlusRegularIcon";
export { CalendarPlusRegularIcon };
