import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BriefcaseMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <path
              fill={iconColor}
              fillRule="evenodd"
              d="M11.378 2.506c.588.06 1.056.528 1.116 1.116l.006.128V5h3.125c1.035 0 1.875.84 1.875 1.875v8.75c0 1.035-.84 1.875-1.875 1.875H4.375A1.875 1.875 0 0 1 2.5 15.625v-8.75C2.5 5.839 3.34 5 4.375 5H7.5V3.75c0-.69.56-1.25 1.25-1.25h2.5zM8.75 11.25v1.25h2.5v-1.25zm0-6.25h2.5V3.75h-2.5zm3.744 7.628a1.25 1.25 0 0 1-1.244 1.122h-2.5a1.25 1.25 0 0 1-1.244-1.122L7.5 12.5H5.625a3.1 3.1 0 0 1-1.875-.63v3.755c0 .345.28.625.625.625h11.25c.345 0 .625-.28.625-.625V11.87c-.523.394-1.17.63-1.875.63H12.5zm1.881-1.378c1.036 0 1.875-.84 1.875-1.875v-2.5a.625.625 0 0 0-.625-.625H4.375a.625.625 0 0 0-.625.625v2.5c0 1.036.84 1.875 1.875 1.875H7.5l.006-.128A1.25 1.25 0 0 1 8.75 10h2.5l.128.006c.588.06 1.056.528 1.116 1.116l.006.128z"
              clipRule="evenodd"
            />
          </>
        }
        {...props}
      />
    );
  },
);
BriefcaseMediumIcon.displayName = "BriefcaseMediumIcon";
export { BriefcaseMediumIcon };
