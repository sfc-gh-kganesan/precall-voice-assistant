import { forwardRef, ForwardedRef } from "react";

import { ChevronLeftSmallMediumIcon } from "./ChevronLeftSmallMediumIcon";
import { ChevronLeftSmallRegularIcon } from "./ChevronLeftSmallRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ChevronLeftSmallIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ChevronLeftSmallIcon = forwardRef(
  (
    { size = "regular", ...props }: ChevronLeftSmallIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ChevronLeftSmallRegularIcon />;

    if (size === "medium") {
      icon = <ChevronLeftSmallMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ChevronLeftSmallIcon.displayName = "ChevronLeftSmallIcon";

export type { ChevronLeftSmallIconProps };
export { ChevronLeftSmallIcon };
