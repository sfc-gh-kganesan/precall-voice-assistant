import { forwardRef, ForwardedRef } from "react";
import { baltoTheme } from "@snowflake/balto-themes/baltoTheme.stylex.js";
import { useIconContext } from "../../useIconContext";
const BookOpenAiMediumIcon = forwardRef(
  (
    props: React.ComponentPropsWithoutRef<"g">,
    ref: ForwardedRef<SVGGElement>,
  ) => {
    const { color: iconColor = baltoTheme.reusableIconDefault } =
      useIconContext();
    return (
      <g
        ref={ref}
        children={
          <>
            <g fill={iconColor}>
              <path
                fillRule="evenodd"
                d="M13.796 9.838c.273-.714 1.285-.714 1.558 0a6.66 6.66 0 0 0 3.638 3.764l.338.132.11.04c.745.267.745 1.318 0 1.586a6.75 6.75 0 0 0-4.071 4.066c-.251.696-1.191.74-1.529.13l-.058-.13a6.75 6.75 0 0 0-4.073-4.066c-.743-.268-.743-1.319 0-1.586l.112-.04a6.67 6.67 0 0 0 3.837-3.56zm.78 1.304a7.9 7.9 0 0 1-3.537 3.433 8 8 0 0 1 3.536 3.54 8 8 0 0 1 3.537-3.542 7.9 7.9 0 0 1-3.537-3.431"
                clipRule="evenodd"
              />
              <path d="M10.183 4.453a7.48 7.48 0 0 1 8.183.25c.24.168.384.444.384.737V10H17.5V5.63a6.23 6.23 0 0 0-6.665-.11l-.21.128V10h-1.25V5.637l-.12-.077a5.96 5.96 0 0 0-6.755.2v9.264a6.7 6.7 0 0 1 5-.808v1.29a5.45 5.45 0 0 0-4.85.932.868.868 0 0 1-1.4-.686V5.576a.89.89 0 0 1 .343-.701l.23-.171a7.21 7.21 0 0 1 8.109-.194l.075.049z" />
            </g>
          </>
        }
        {...props}
      />
    );
  },
);
BookOpenAiMediumIcon.displayName = "BookOpenAiMediumIcon";
export { BookOpenAiMediumIcon };
