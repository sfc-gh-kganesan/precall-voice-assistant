import { forwardRef, ForwardedRef } from "react";

import { ConditionMediumIcon } from "./ConditionMediumIcon";
import { ConditionRegularIcon } from "./ConditionRegularIcon";

import { IconProps } from "../../types";
import { IconWrapper } from "../../IconWrapper";

interface ConditionIconProps extends IconProps {
  size?: "medium" | "regular";
}

const ConditionIcon = forwardRef(
  (
    { size = "regular", ...props }: ConditionIconProps,
    ref: ForwardedRef<SVGSVGElement>,
  ) => {
    let icon = <ConditionRegularIcon />;

    if (size === "medium") {
      icon = <ConditionMediumIcon />;
    }

    return <IconWrapper ref={ref} svgContent={icon} {...props} />;
  },
);

ConditionIcon.displayName = "ConditionIcon";

export type { ConditionIconProps };
export { ConditionIcon };
