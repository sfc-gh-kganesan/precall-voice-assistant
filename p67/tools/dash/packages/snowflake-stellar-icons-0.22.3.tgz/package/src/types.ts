import type * as React from "react";

export interface IconProps
  extends Omit<
    React.SVGAttributes<SVGSVGElement>,
    "width" | "height" | "color" | "fill" | "stroke"
  > {
  children?: never | undefined;
}
