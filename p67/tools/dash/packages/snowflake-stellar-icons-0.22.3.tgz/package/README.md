# Dev Guide

### Update icons from Figma

### Get Figma token

- Figma token: Click "Get personal access token" from: https://www.figma.com/developers/api#access-tokens
- Run `export FIGMA_TOKEN=<token>` in terminal.

### Download and generate components for icons

Old icons:

```
DEBUG=oclif:balto-cli:svg-icon:update FIGMA_FILE_ID=OOGIm7XG7Y6wZZJUbV2LCX ./balto-cli svg-icon update --type="icon"
DEBUG=oclif:balto-cli:svg-icon:generate-components ./balto-cli svg-icon generate-components --type="icon"
```

New Icons:

```
DEBUG=oclif:balto-cli:svg-icon:generate-new ./balto-cli svg-icon generate-new --type icon --figmaFileId XFYuFXmNOng6nzjMQd2vgW --figmaNodeId 0-1 --figmaNodeId1x 270-905 --figmaNodeIdBold 2453-589
```

### Download and generate components for badge illustrations

```
DEBUG=oclif:balto-cli:svg-icon:update FIGMA_FILE_ID=XKmJ83LQkDEFLu93Q9FC8B ./balto-cli svg-icon update --type="badge"
DEBUG=oclif:balto-cli:svg-icon:generate-components ./balto-cli svg-icon generate-components --type="badge"
```

### Download and generate components for pictograms

```
DEBUG=oclif:balto-cli:svg-icon:update FIGMA_FILE_ID=ifsEEiiVkoUesjdF99Iu8M ./balto-cli svg-icon update --type="pictogram"
DEBUG=oclif:balto-cli:svg-icon:generate-components ./balto-cli svg-icon generate-components --type="pictogram"
```

### Download and generate components for illustrations

```
DEBUG=oclif:balto-cli:svg-icon:update FIGMA_FILE_ID=Q6Sg1b2wpaza7BO4ZcPf9F ./balto-cli svg-icon update --type="illustration"
DEBUG=oclif:balto-cli:svg-icon:generate-components ./balto-cli svg-icon generate-components --type="illustration"
```

### Notes

- Figma file for icons: https://www.figma.com/design/OOGIm7XG7Y6wZZJUbV2LCX/Icons-export
- Figma file for badges: https://www.figma.com/design/XKmJ83LQkDEFLu93Q9FC8B/Badge-illustration-export
- Figma file for pictograms: https://www.figma.com/design/ifsEEiiVkoUesjdF99Iu8M/Pictogram-Export
- Figma file for illustrations: https://www.figma.com/design/Q6Sg1b2wpaza7BO4ZcPf9F/Illustration-Export

## New Icons Snapps Core Ui Update process

1. Run the following to pull and update the icons from figma
   ```
   DEBUG=oclif:balto-cli:svg-icon:generate-new ./balto-cli svg-icon generate-new --type icon --figmaFileId XFYuFXmNOng6nzjMQd2vgW --figmaNodeId 0-1 --figmaNodeId1x 270-905
   ```
1. Commit
1. From the root of balto's repo run `./cmd/canary`
1. Ensure you have snapps locally on your computer located in the same folder as Balto
1. Checkout the snapps branch `balto-new-icons`
1. Update the version in the pnpm workspaces file to use the version you just published
1. From the `icons` package run `pnpm update-core-ui-icons`
1. Commit and push your changes to snapps
