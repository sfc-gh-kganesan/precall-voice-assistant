import { Flex, ProgressBar } from "@snowflake/stellar-components";
import * as stylex from "@stylexjs/stylex";

import type { CellRendererProps } from "./types";
import type { DataRecord } from "../data.types";

const styles = stylex.create({
  progressWrapper: {
    height: "100%",
  },
  progressStyles: {
    flexGrow: 1,
  },
});

/**
 * The component that renders the progress bar.
 */
function ProgressRenderer<T extends DataRecord = DataRecord>(
  props: CellRendererProps<number, T>,
) {
  const { cellData } = props;
  return (
    <Flex grow={1} align="center" {...stylex.props(styles.progressWrapper)}>
      <ProgressBar
        size="small"
        value={cellData as number}
        max={100}
        aria-label={cellData?.toString() ?? "Unknown"}
        {...stylex.props(styles.progressStyles)}
      />
    </Flex>
  );
}
ProgressRenderer.displayName = "ProgressRenderer";

export { ProgressRenderer };
export type {};
