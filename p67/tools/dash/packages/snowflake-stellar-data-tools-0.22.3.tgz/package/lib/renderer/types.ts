import type { DataRecord, FieldDefinition } from "../data.types";

interface CellRendererProps<S, T extends DataRecord = DataRecord> {
  /**
   * This can be undefined when using pivot functionality.
   */
  cellData?: S | undefined;
  /**
   * This can be undefined when using pivot functionality.
   */
  rowData?: T | undefined;
  /**
   * The field definition.
   */
  fieldDefinition?: FieldDefinition<T, keyof T> | undefined;
}

export type { CellRendererProps };
