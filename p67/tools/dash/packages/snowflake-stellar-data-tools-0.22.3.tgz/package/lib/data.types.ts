type FieldDataType = "text" | "number" | "date" | "boolean" | "object";
interface DataRecord {
  [key: string]: unknown;
}

/**
 * Field definition for Data.
 */
interface FieldDefinition<
  /**
   * The type of the data.
   */
  T extends DataRecord,
  /**
   * The key of the field.
   * default keyof T
   */
  K extends keyof T = keyof T,
  /**
   * The type of the field.
   * default unknown
   */
  S extends T[K] = T[K],
> {
  /**
   * The id of the field. This is used to identify the field in the state.
   * by default the field name is used when ID is not specified.
   */
  id?: string | undefined;
  /**
   * The label of the field. This is used to display the field.
   */
  label: string;
  /**
   * The field of the field. This is used to access the value from the row.
   */
  field: K; // TODO check for need of derived field | ((val: T) => string | number | Date);
  /**
   * The description of the field. This is used to display a tooltip for the field.
   */
  description?: string | undefined;
  /**
   * Sort function for the field.
   * @param a first record to compare
   * @param b second record to compare
   * @returns -1 if a < b, 0 if a == b, 1 if a > b
   */
  compareFn?:
    | ((
        a?: S | undefined,
        b?: S | undefined,
        rowA?: T | undefined,
        rowB?: T | undefined,
      ) => number)
    | undefined;
  /**
   * Whether the field is sortable.
   * default false
   */
  sortable?: boolean | undefined;

  /**
   * Data type of the field.
   * default inferred from the data for 'text', 'number', 'date', 'boolean'.
   * 'text' is used when the data is not inferable.
   */
  fieldType?: FieldDataType | undefined;
  /**
   * Accessor function for the field.
   * @param row original row data
   * @returns translated value for the field
   */
  accessor?: (<S extends T[K]>(row: T) => S) | undefined;

  /**
   * Formatter function for the field.
   * @param fieldData original field data
   * @param rowData original row data
   * @returns formatted value for the field
   */
  formatter?: FieldFormatter<S, T> | undefined;
}
/**
 * Formatter function for the field.
 * @param fieldData original field data
 * @param rowData original row data
 * @returns formatted value for the field
 */
type FieldFormatter<S, T extends DataRecord = DataRecord> = (
  fieldData?: S,
  rowData?: T | undefined,
) => string;

export type { DataRecord, FieldDefinition, FieldDataType, FieldFormatter };
