import { describe, expect, it } from "vitest";

import { dateTimeFormatter } from "./dateTimeFormatter";

describe("dateTimeFormatter", () => {
  // Test date: Wed Mar 26 2025 16:17:47 GMT-0700 (Pacific Daylight Time)
  const testEpoch = 1743031067810;
  const testISO = "2025-03-26T23:17:47.810Z";

  describe("input types", () => {
    it("handles epoch milliseconds", () => {
      expect(dateTimeFormatter(testEpoch)).toBe("3/26/2025, 11:17:47 PM UTC");
    });

    it("handles ISO string", () => {
      expect(dateTimeFormatter(testISO)).toBe("3/26/2025, 11:17:47 PM UTC");
    });
  });

  describe("format styles", () => {
    it("formats with short style", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          dateStyle: "short",
          timeStyle: "short",
        }),
      ).toBe("3/26/25, 11:17 PM");
    });

    it("formats with medium style", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          dateStyle: "medium",
          timeStyle: "medium",
        }),
      ).toBe("Mar 26, 2025, 11:17:47 PM");
    });

    it("formats with long style", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          dateStyle: "long",
          timeStyle: "long",
        }),
      ).toBe("March 26, 2025 at 11:17:47 PM UTC");
    });

    it("formats with full style", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          dateStyle: "full",
          timeStyle: "full",
        }),
      ).toBe(
        "Wednesday, March 26, 2025 at 11:17:47 PM Coordinated Universal Time",
      );
    });
  });

  describe("custom formats", () => {
    it("formats date only (MMM DD)", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          month: "short",
          day: "numeric",
        }),
      ).toBe("Mar 26");
    });

    it("formats time only (HH:MMam/pm)", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        }),
      ).toBe("11:17 PM");
    });

    it("formats with 24-hour time", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        }),
      ).toBe("23:17");
    });
  });

  describe("timezone handling", () => {
    it("formats in UTC", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          timeZone: "UTC",
        }),
      ).toBe("3/26/2025, 11:17:47 PM UTC");
    });

    it("formats in America/New_York", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          timeZone: "America/New_York",
        }),
      ).toBe("3/26/2025, 7:17:47 PM EDT");
    });

    it("formats in Asia/Shanghai", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          timeZone: "Asia/Shanghai",
        }),
      ).toBe("3/27/2025, 7:17:47 AM GMT+8");
    });
  });

  describe("internationalization", () => {
    it("formats in Spanish (Spain)", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          year: "numeric",
          month: "short",
          day: "numeric",
          locale: "es-ES",
        }),
      ).toBe("26 mar 2025");
    });

    it("formats in French (France)", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          year: "numeric",
          month: "short",
          day: "numeric",
          locale: "fr-FR",
        }),
      ).toBe("26 mars 2025");
    });

    it("formats in German (Germany)", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          year: "numeric",
          month: "short",
          day: "numeric",
          locale: "de-DE",
        }),
      ).toBe("26. März 2025");
    });

    it("formats in Japanese (Japan)", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          year: "numeric",
          month: "short",
          day: "numeric",
          locale: "ja-JP",
        }),
      ).toBe("2025年3月26日");
    });

    it("formats in Chinese (China)", () => {
      expect(
        dateTimeFormatter(testEpoch, {
          year: "numeric",
          month: "short",
          day: "numeric",
          locale: "zh-CN",
        }),
      ).toBe("2025年3月26日");
    });
  });
});
