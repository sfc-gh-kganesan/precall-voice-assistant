import { Temporal } from "temporal-polyfill";
import { describe, expect, it } from "vitest";

import { timeSinceFormatter } from "./timeSinceFormatter";

const startTime = "2023-08-01T14:38:32.0+00:00";
const endTime = "2025-03-26T14:38:32.0+00:00";
describe("timeSinceFormatter", () => {
  describe("should support inputs as", () => {
    it("number", () => {
      const result = timeSinceFormatter(new Date(startTime).getTime(), {
        to: new Date(endTime).getTime(),
      });
      expect(result).toBe("1y 7m");
    });
    it("string", () => {
      const result = timeSinceFormatter(startTime, {
        to: endTime,
      });
      expect(result).toBe("1y 7m");
    });
    it("Temporal.Instant", () => {
      const result = timeSinceFormatter(Temporal.Instant.from(startTime), {
        to: Temporal.Instant.from(endTime),
      });
      expect(result).toBe("1y 7m");
    });
  });
  describe("durationStyle", () => {
    it("should handle long duration style", () => {
      const result = timeSinceFormatter(startTime, {
        to: endTime,
        durationStyle: "long",
      });
      expect(result).toBe("1 year, 7 months");
    });
    it("should handle short duration style", () => {
      const result = timeSinceFormatter(startTime, {
        to: endTime,
        durationStyle: "short",
      });
      expect(result).toBe("1 yr, 7 mths");
    });
  });
  describe("locale", () => {
    it("should handle fr locale", () => {
      const result = timeSinceFormatter(startTime, {
        to: endTime,
        locale: "fr-FR",
        durationStyle: "narrow",
      });
      expect(result).toBe("1a 7m.");
    });
    it("should handle ja locale", () => {
      const result = timeSinceFormatter(startTime, {
        to: endTime,
        locale: "ja-JP",
        durationStyle: "short",
      });
      expect(result).toBe("1 年 7 か月");
    });
    it("should handle de locale", () => {
      const result = timeSinceFormatter(startTime, {
        to: endTime,
        locale: "de-DE",
        durationStyle: "long",
      });
      expect(result).toBe("1 Jahr, 7 Monate");
    });
  });

  describe("largestUnit", () => {
    it("should handle months", () => {
      const result = timeSinceFormatter(startTime, {
        to: endTime,
        largestUnit: "months",
      });
      expect(result).toBe("19m");
    });
    it("should handle weeks", () => {
      const result = timeSinceFormatter(startTime, {
        to: endTime,
        largestUnit: "weeks",
        smallestUnit: "days",
      });
      expect(result).toBe("86w 1d");
    });
  });
});
