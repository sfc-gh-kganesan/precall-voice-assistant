import "@formatjs/intl-durationformat/polyfill";
import { Temporal } from "temporal-polyfill";

import type { DataRecord, FieldFormatter } from "../data.types";

/**
 * The precision of the timeSinceFormatter.
 */
type Precision =
  | "years"
  | "months"
  | "weeks"
  | "days"
  | "hours"
  | "minutes"
  | "seconds";
type DurationStyle = "long" | "short" | "narrow";
/**
 * Options for the timeSinceFormatter.
 */
interface TimeSinceOptions {
  /**
   * The locale to use for the formatter.
   */
  locale?: string | undefined;
  /**
   * The instant to format.
   * number: epoch milliseconds
   * string: RFC3339 date-time in %Y-%M-%DT%h:%m:%sZ format
   * Temporal.Instant: the instant to format
   */
  to?: number | string | Temporal.Instant | undefined;
  /**
   * The largest unit to use for the formatter.
   */
  largestUnit?: Precision | undefined;
  /**
   * The smallest unit to use for the formatter.
   */
  smallestUnit?: Precision | undefined;
  /**
   * The style to use for the formatter.
   */
  durationStyle?: DurationStyle | undefined;
}

const createPlainDateTime = (
  value: number | string | Temporal.Instant,
): Temporal.PlainDateTime => {
  if (typeof value === "number") {
    return Temporal.Instant.fromEpochMilliseconds(value)
      .toZonedDateTimeISO("UTC")
      .toPlainDateTime();
  }
  return Temporal.Instant.from(value)
    .toZonedDateTimeISO("UTC")
    .toPlainDateTime();
};
/**
 * Formats a instant as a human readable in the current locale.
 * @param value - The instant to format.
 *                number: epoch milliseconds
 *                string: RFC3339 date-time in %Y-%M-%DT%h:%m:%sZ format
 * @param options - The options for the formatter.
 * @returns The formatted time since the given date.
 */
const timeSinceFormatter: FieldFormatter<
  number | string | Temporal.Instant,
  DataRecord
> = (
  value?: number | string | Temporal.Instant | undefined,
  options?: TimeSinceOptions | undefined,
): string => {
  if (value === undefined) return "";
  // remove once https://github.com/microsoft/TypeScript/issues/60608 is fixed
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const formatter = new (Intl as any).DurationFormat(
    options?.locale ?? "en-US",
    {
      style: options?.durationStyle ?? "narrow",
    },
  );

  const toInstant = createPlainDateTime(options?.to ?? Temporal.Now.instant());

  const fromInstant = createPlainDateTime(value);

  const duration = toInstant.since(fromInstant, {
    largestUnit: options?.largestUnit ?? "years",
    smallestUnit: options?.smallestUnit ?? "months",
  });

  return formatter.format(duration);
};

export { timeSinceFormatter };
export type { Precision, TimeSinceOptions, DurationStyle };
