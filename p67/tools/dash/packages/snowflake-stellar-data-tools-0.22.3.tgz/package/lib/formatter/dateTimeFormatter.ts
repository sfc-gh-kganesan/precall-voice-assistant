import { Temporal } from "temporal-polyfill";

import type { FieldFormatter } from "../data.types";

interface DateTimeFormatterOptions extends Intl.DateTimeFormatOptions {
  locale?: string | undefined;
}

const dateTimeFormatter: FieldFormatter<number | string> = (
  value?: number | string | undefined,
  options: DateTimeFormatterOptions = {},
): string => {
  if (value === undefined) return "";
  const instant =
    typeof value === "number"
      ? Temporal.Instant.fromEpochMilliseconds(value)
      : Temporal.Instant.from(value);
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const dateTime = instant.toZonedDateTimeISO(
    options.timeZone ?? timeZone ?? "UTC",
  );

  // Exclude timeZone from options as it is already set inside Temporal.
  const { timeZone: _timeZone, ...restOptions } = options;
  return dateTime.toLocaleString(options.locale || "en-US", restOptions);
};

export { dateTimeFormatter };
export type { DateTimeFormatterOptions };
