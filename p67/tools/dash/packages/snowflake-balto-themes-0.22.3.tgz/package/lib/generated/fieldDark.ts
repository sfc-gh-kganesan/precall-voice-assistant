/**
 * Do not edit directly, this file was auto-generated.
 */

export const fieldDarkColorKeys = [] as const;
export type fieldDarkColor = (typeof fieldDarkColorKeys)[number];

export const fieldDarkDimensionKeys = ["borderRadiusDefault"] as const;
export type fieldDarkDimension = (typeof fieldDarkDimensionKeys)[number];

const fieldDarkValidKeys = ["borderRadiusDefault"] as const;
type fieldDarkValidKey = (typeof fieldDarkValidKeys)[number];

export type fieldDark = fieldDarkValidKey;

export const fieldDarkStyles = {
  borderRadiusDefault: "6px",
} as const satisfies Readonly<Record<fieldDark, string | number>>;

export type fieldDarkTypes = {
  borderRadiusDefault: string;
};
