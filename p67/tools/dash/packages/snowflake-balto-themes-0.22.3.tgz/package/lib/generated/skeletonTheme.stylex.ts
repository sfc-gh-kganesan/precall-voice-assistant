/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const skeletonTheme = stylex.defineVars({
  shimmerStartDefault: "#dee3ea",
  shimmerEndDefault: "#d5dae4",
});
