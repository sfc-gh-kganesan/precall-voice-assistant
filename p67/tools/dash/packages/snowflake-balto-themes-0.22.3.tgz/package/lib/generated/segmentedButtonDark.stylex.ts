/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { segmentedButtonTheme as styleVars } from "./segmentedButtonTheme.stylex.js";

export const segmentedButtonDark = stylex.createTheme(styleVars, {
  rootBackgroundDefault: "#0f161e",
  selectedItemBackgroundDefault: "#1e252f",
});
