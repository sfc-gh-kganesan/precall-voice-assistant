/**
 * Do not edit directly, this file was auto-generated.
 */

export const appNavigationLightColorKeys = [
  "itemBackgroundHover",
  "sidebarBackgroundDefault",
] as const;
export type appNavigationLightColor =
  (typeof appNavigationLightColorKeys)[number];

export const appNavigationLightDimensionKeys = [] as const;
export type appNavigationLightDimension =
  (typeof appNavigationLightDimensionKeys)[number];

const appNavigationLightValidKeys = [
  "itemBackgroundHover",
  "sidebarBackgroundDefault",
] as const;
type appNavigationLightValidKey = (typeof appNavigationLightValidKeys)[number];

export type appNavigationLight = appNavigationLightValidKey;

export const appNavigationLightStyles = {
  itemBackgroundHover: "#dee3ea",
  sidebarBackgroundDefault: "#f7f7f7",
} as const satisfies Readonly<Record<appNavigationLight, string | number>>;

export type appNavigationLightTypes = {
  itemBackgroundHover: string;
  sidebarBackgroundDefault: string;
};
