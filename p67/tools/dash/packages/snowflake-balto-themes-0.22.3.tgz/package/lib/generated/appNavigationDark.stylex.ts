/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { appNavigationTheme as styleVars } from "./appNavigationTheme.stylex.js";

export const appNavigationDark = stylex.createTheme(styleVars, {
  itemBackgroundHover: "#293246",
  sidebarBackgroundDefault: "#191e24",
});
