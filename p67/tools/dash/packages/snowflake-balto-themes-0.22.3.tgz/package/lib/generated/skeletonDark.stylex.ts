/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { skeletonTheme as styleVars } from "./skeletonTheme.stylex.js";

export const skeletonDark = stylex.createTheme(styleVars, {
  shimmerStartDefault: "#293246",
  shimmerEndDefault: "#1e252f",
});
