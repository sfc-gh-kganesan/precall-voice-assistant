/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { toolbarTheme as styleVars } from "./toolbarTheme.stylex.js";

export const toolbarDark = stylex.createTheme(styleVars, {
  boxShadowDefault: "0px 2px 8px rgba(0, 0, 0, 0.25)",
  borderColorDefault: "#293246",
  borderWidthDefault: "1px",
  borderStyleDefault: "solid",
  borderRadiusDefault: "8px",
});
