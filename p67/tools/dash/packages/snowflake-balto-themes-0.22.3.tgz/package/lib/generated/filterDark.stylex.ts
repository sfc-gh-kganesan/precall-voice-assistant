/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { filterTheme as styleVars } from "./filterTheme.stylex.js";

export const filterDark = stylex.createTheme(styleVars, {
  activeBackgroundDefault: "#293246",
  activeBackgroundHover: "#5d6a85",
  activeBackgroundActive: "#0f161e",
  activeTextColorDefault: "#fbfbfb",
  activeTextColorHover: "#fbfbfb",
  activeTextColorActive: "#fbfbfb",
  activeClearBackgroundDefault: "#293246",
  activeClearBackgroundHover: "#9fabc1",
  activeClearBackgroundActive: "#5d6a85",
});
