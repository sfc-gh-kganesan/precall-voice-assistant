/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { skeletonTheme as styleVars } from "./skeletonTheme.stylex.js";

export const skeletonLight = stylex.createTheme(styleVars, {
  shimmerStartDefault: "#dee3ea",
  shimmerEndDefault: "#d5dae4",
});
