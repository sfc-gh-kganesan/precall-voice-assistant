/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { progressBarTheme as styleVars } from "./progressBarTheme.stylex.js";

export const progressBarLight = stylex.createTheme(styleVars, {
  backgroundDefault: "#dee3ea",
  filledDefault: "#1a6ce7",
  filledSuccess: "#0e9c73",
  filledError: "#d3132f",
});
