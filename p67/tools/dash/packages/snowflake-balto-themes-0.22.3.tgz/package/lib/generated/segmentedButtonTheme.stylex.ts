/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const segmentedButtonTheme = stylex.defineVars({
  rootBackgroundDefault: "#f5f5f5",
  /** A background primitive for components and surfaces on Level 3 (temporary surfaces- dialogs, popovers, sidepanel, etc.). */
  selectedItemBackgroundDefault: "#fbfbfb",
});
