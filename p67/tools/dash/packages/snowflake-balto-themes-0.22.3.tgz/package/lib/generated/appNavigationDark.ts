/**
 * Do not edit directly, this file was auto-generated.
 */

export const appNavigationDarkColorKeys = [
  "itemBackgroundHover",
  "sidebarBackgroundDefault",
] as const;
export type appNavigationDarkColor =
  (typeof appNavigationDarkColorKeys)[number];

export const appNavigationDarkDimensionKeys = [] as const;
export type appNavigationDarkDimension =
  (typeof appNavigationDarkDimensionKeys)[number];

const appNavigationDarkValidKeys = [
  "itemBackgroundHover",
  "sidebarBackgroundDefault",
] as const;
type appNavigationDarkValidKey = (typeof appNavigationDarkValidKeys)[number];

export type appNavigationDark = appNavigationDarkValidKey;

export const appNavigationDarkStyles = {
  itemBackgroundHover: "#293246",
  sidebarBackgroundDefault: "#191e24",
} as const satisfies Readonly<Record<appNavigationDark, string | number>>;

export type appNavigationDarkTypes = {
  itemBackgroundHover: string;
  sidebarBackgroundDefault: string;
};
