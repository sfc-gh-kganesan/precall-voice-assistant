/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const progressBarTheme = stylex.defineVars({
  backgroundDefault: "#dee3ea",
  filledDefault: "#1a6ce7",
  filledSuccess: "#0e9c73",
  /** UI elements in an critical state- not necessarily accessible for text. */
  filledError: "#d3132f",
});
