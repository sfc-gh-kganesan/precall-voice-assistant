/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const baseDimension = stylex.defineVars({
  spacing_0x: "0px",
  textSmall: "12px",
  textRegular: "14px",
  textLarge: "16px",
  textXlarge: "20px",
  textXxlarge: "28px",
  textXxxlarge: "40px",
  spacing_0_25x: "2px",
  spacing_0_5x: "4px",
  spacing_0_75x: "6px",
  spacing_1x: "8px",
  spacing_1_5x: "12px",
  spacing_2x: "16px",
  spacing_2_5x: "20px",
  spacing_3x: "24px",
  spacing_4x: "32px",
  spacing_5x: "40px",
  spacing_6x: "48px",
  spacing_8x: "64px",
  radiusXsmall: "4px",
  radiusSmall: "6px",
  radiusMedium: "8px",
  radiusLarge: "16px",
  breakpointXsmall: "480px",
  breakpointSmall: "720px",
  breakpointMedium: "1024px",
  breakpointLarge: "1360px",
  breakpointXlarge: "1680px",
});
