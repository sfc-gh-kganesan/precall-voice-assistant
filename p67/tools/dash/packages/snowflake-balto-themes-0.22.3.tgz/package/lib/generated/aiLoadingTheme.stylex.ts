/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const aiLoadingTheme = stylex.defineVars({
  /** This variable allows consumers of the AI Loading Box component to change the default width of 3px to 2px.. */
  aiLoadingBoxBorderWidth: stylex.types.integer(3),
});
