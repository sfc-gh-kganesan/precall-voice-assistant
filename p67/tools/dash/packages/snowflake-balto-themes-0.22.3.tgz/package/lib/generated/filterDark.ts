/**
 * Do not edit directly, this file was auto-generated.
 */

export const filterDarkColorKeys = [
  "activeBackgroundDefault",
  "activeBackgroundHover",
  "activeBackgroundActive",
  "activeTextColorDefault",
  "activeTextColorHover",
  "activeTextColorActive",
  "activeClearBackgroundDefault",
  "activeClearBackgroundHover",
  "activeClearBackgroundActive",
] as const;
export type filterDarkColor = (typeof filterDarkColorKeys)[number];

export const filterDarkDimensionKeys = [] as const;
export type filterDarkDimension = (typeof filterDarkDimensionKeys)[number];

const filterDarkValidKeys = [
  "activeBackgroundDefault",
  "activeBackgroundHover",
  "activeBackgroundActive",
  "activeTextColorDefault",
  "activeTextColorHover",
  "activeTextColorActive",
  "activeClearBackgroundDefault",
  "activeClearBackgroundHover",
  "activeClearBackgroundActive",
] as const;
type filterDarkValidKey = (typeof filterDarkValidKeys)[number];

export type filterDark = filterDarkValidKey;

export const filterDarkStyles = {
  activeBackgroundDefault: "#293246",
  activeBackgroundHover: "#5d6a85",
  activeBackgroundActive: "#0f161e",
  activeTextColorDefault: "#fbfbfb",
  activeTextColorHover: "#fbfbfb",
  activeTextColorActive: "#fbfbfb",
  activeClearBackgroundDefault: "#293246",
  activeClearBackgroundHover: "#9fabc1",
  activeClearBackgroundActive: "#5d6a85",
} as const satisfies Readonly<Record<filterDark, string | number>>;

export type filterDarkTypes = {
  activeBackgroundDefault: string;
  activeBackgroundHover: string;
  activeBackgroundActive: string;
  activeTextColorDefault: string;
  activeTextColorHover: string;
  activeTextColorActive: string;
  activeClearBackgroundDefault: string;
  activeClearBackgroundHover: string;
  activeClearBackgroundActive: string;
};
