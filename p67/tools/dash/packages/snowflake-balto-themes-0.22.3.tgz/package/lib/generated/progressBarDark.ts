/**
 * Do not edit directly, this file was auto-generated.
 */

export const progressBarDarkColorKeys = [
  "backgroundDefault",
  "filledDefault",
  "filledSuccess",
  "filledError",
] as const;
export type progressBarDarkColor = (typeof progressBarDarkColorKeys)[number];

export const progressBarDarkDimensionKeys = [] as const;
export type progressBarDarkDimension =
  (typeof progressBarDarkDimensionKeys)[number];

const progressBarDarkValidKeys = [
  "backgroundDefault",
  "filledDefault",
  "filledSuccess",
  "filledError",
] as const;
type progressBarDarkValidKey = (typeof progressBarDarkValidKeys)[number];

export type progressBarDark = progressBarDarkValidKey;

export const progressBarDarkStyles = {
  backgroundDefault: "#5d6a85",
  filledDefault: "#5999f8",
  filledSuccess: "#087959",
  filledError: "#e32442",
} as const satisfies Readonly<Record<progressBarDark, string | number>>;

export type progressBarDarkTypes = {
  backgroundDefault: string;
  filledDefault: string;
  filledSuccess: string;
  filledError: string;
};
