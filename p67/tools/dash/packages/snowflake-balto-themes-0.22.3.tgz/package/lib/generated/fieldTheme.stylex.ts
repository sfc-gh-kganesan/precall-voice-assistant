/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const fieldTheme = stylex.defineVars({
  borderRadiusDefault: "6px",
});
