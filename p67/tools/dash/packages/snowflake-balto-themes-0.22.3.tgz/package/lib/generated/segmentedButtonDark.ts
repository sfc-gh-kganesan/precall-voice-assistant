/**
 * Do not edit directly, this file was auto-generated.
 */

export const segmentedButtonDarkColorKeys = [
  "rootBackgroundDefault",
  "selectedItemBackgroundDefault",
] as const;
export type segmentedButtonDarkColor =
  (typeof segmentedButtonDarkColorKeys)[number];

export const segmentedButtonDarkDimensionKeys = [] as const;
export type segmentedButtonDarkDimension =
  (typeof segmentedButtonDarkDimensionKeys)[number];

const segmentedButtonDarkValidKeys = [
  "rootBackgroundDefault",
  "selectedItemBackgroundDefault",
] as const;
type segmentedButtonDarkValidKey =
  (typeof segmentedButtonDarkValidKeys)[number];

export type segmentedButtonDark = segmentedButtonDarkValidKey;

export const segmentedButtonDarkStyles = {
  rootBackgroundDefault: "#0f161e",
  selectedItemBackgroundDefault: "#1e252f",
} as const satisfies Readonly<Record<segmentedButtonDark, string | number>>;

export type segmentedButtonDarkTypes = {
  rootBackgroundDefault: string;
  selectedItemBackgroundDefault: string;
};
