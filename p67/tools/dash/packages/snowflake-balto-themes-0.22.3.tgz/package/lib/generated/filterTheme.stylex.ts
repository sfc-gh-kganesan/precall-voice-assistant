/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const filterTheme = stylex.defineVars({
  activeBackgroundDefault: "#5d6a85",
  activeBackgroundHover: "#70819a",
  activeBackgroundActive: "#293246",
  activeTextColorDefault: "#fbfbfb",
  activeTextColorHover: "#fbfbfb",
  activeTextColorActive: "#fbfbfb",
  activeClearBackgroundDefault: "#5d6a85",
  activeClearBackgroundHover: "#293246",
  activeClearBackgroundActive: "#70819a",
});
