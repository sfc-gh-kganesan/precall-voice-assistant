/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { segmentedButtonTheme as styleVars } from "./segmentedButtonTheme.stylex.js";

export const segmentedButtonLight = stylex.createTheme(styleVars, {
  rootBackgroundDefault: "#f5f5f5",
  selectedItemBackgroundDefault: "#fbfbfb",
});
