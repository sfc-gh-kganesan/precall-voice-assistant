/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { progressBarTheme as styleVars } from "./progressBarTheme.stylex.js";

export const progressBarDark = stylex.createTheme(styleVars, {
  backgroundDefault: "#5d6a85",
  filledDefault: "#5999f8",
  filledSuccess: "#087959",
  filledError: "#e32442",
});
