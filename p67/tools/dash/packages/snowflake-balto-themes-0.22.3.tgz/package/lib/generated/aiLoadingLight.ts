/**
 * Do not edit directly, this file was auto-generated.
 */

export const aiLoadingLightColorKeys = [] as const;
export type aiLoadingLightColor = (typeof aiLoadingLightColorKeys)[number];

export const aiLoadingLightDimensionKeys = ["aiLoadingBoxBorderWidth"] as const;
export type aiLoadingLightDimension =
  (typeof aiLoadingLightDimensionKeys)[number];

const aiLoadingLightValidKeys = ["aiLoadingBoxBorderWidth"] as const;
type aiLoadingLightValidKey = (typeof aiLoadingLightValidKeys)[number];

export type aiLoadingLight = aiLoadingLightValidKey;

export const aiLoadingLightStyles = {
  /** This variable allows consumers of the AI Loading Box component to change the default width of 3px to 2px.. */
  aiLoadingBoxBorderWidth: 3,
} as const satisfies Readonly<Record<aiLoadingLight, string | number>>;

export type aiLoadingLightTypes = {
  /** This variable allows consumers of the AI Loading Box component to change the default width of 3px to 2px.. */
  aiLoadingBoxBorderWidth: number;
};
