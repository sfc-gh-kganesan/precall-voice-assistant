/**
 * Do not edit directly, this file was auto-generated.
 */

export const buttonDarkColorKeys = [
  "primaryBackgroundDefault",
  "primaryBackgroundDisabled",
  "primaryBackgroundHover",
  "primaryBackgroundPress",
  "primaryBorderDefault",
  "primaryBorderDisabled",
  "primaryBorderHover",
  "primaryBorderPress",
  "primaryTextDefault",
  "primaryTextDisabled",
  "primaryTextHover",
  "primaryTextPress",
  "primaryCriticalBackgroundDefault",
  "primaryCriticalBackgroundDisabled",
  "primaryCriticalBackgroundHover",
  "primaryCriticalBackgroundPress",
  "primaryCriticalBorderDefault",
  "primaryCriticalBorderDisabled",
  "primaryCriticalBorderHover",
  "primaryCriticalBorderPress",
  "primaryCriticalTextDefault",
  "primaryCriticalTextDisabled",
  "primaryCriticalTextHover",
  "primaryCriticalTextPress",
  "secondaryBackgroundDefault",
  "secondaryBackgroundDisabled",
  "secondaryBackgroundHover",
  "secondaryBackgroundPress",
  "secondaryTextDefault",
  "secondaryTextDisabled",
  "secondaryTextHover",
  "secondaryTextPress",
  "secondaryBorderDefault",
  "secondaryBorderDisabled",
  "secondaryBorderHover",
  "secondaryBorderPress",
  "tertiaryBackgroundDefault",
  "tertiaryBackgroundDisabled",
  "tertiaryBackgroundHover",
  "tertiaryBackgroundPress",
  "tertiaryTextDefault",
  "tertiaryTextDisabled",
  "tertiaryTextHover",
  "tertiaryTextPress",
  "tertiaryBorderDefault",
  "tertiaryBorderDisabled",
  "tertiaryBorderHover",
  "tertiaryBorderPress",
] as const;
export type buttonDarkColor = (typeof buttonDarkColorKeys)[number];

export const buttonDarkDimensionKeys = ["borderRadiusDefault"] as const;
export type buttonDarkDimension = (typeof buttonDarkDimensionKeys)[number];

const buttonDarkValidKeys = [
  "borderRadiusDefault",
  "primaryShadowDefault",
  "primaryBackgroundDefault",
  "primaryBackgroundDisabled",
  "primaryBackgroundHover",
  "primaryBackgroundPress",
  "primaryBorderDefault",
  "primaryBorderDisabled",
  "primaryBorderHover",
  "primaryBorderPress",
  "primaryBorderWidthDefault",
  "primaryTextDefault",
  "primaryTextDisabled",
  "primaryTextHover",
  "primaryTextPress",
  "primaryCriticalShadowDefault",
  "primaryCriticalBackgroundDefault",
  "primaryCriticalBackgroundDisabled",
  "primaryCriticalBackgroundHover",
  "primaryCriticalBackgroundPress",
  "primaryCriticalBorderDefault",
  "primaryCriticalBorderDisabled",
  "primaryCriticalBorderHover",
  "primaryCriticalBorderPress",
  "primaryCriticalBorderWidthDefault",
  "primaryCriticalTextDefault",
  "primaryCriticalTextDisabled",
  "primaryCriticalTextHover",
  "primaryCriticalTextPress",
  "secondaryShadowDefault",
  "secondaryBackgroundDefault",
  "secondaryBackgroundDisabled",
  "secondaryBackgroundHover",
  "secondaryBackgroundPress",
  "secondaryTextDefault",
  "secondaryTextDisabled",
  "secondaryTextHover",
  "secondaryTextPress",
  "secondaryBorderDefault",
  "secondaryBorderDisabled",
  "secondaryBorderHover",
  "secondaryBorderPress",
  "secondaryBorderWidthDefault",
  "tertiaryShadowDefault",
  "tertiaryBackgroundDefault",
  "tertiaryBackgroundDisabled",
  "tertiaryBackgroundHover",
  "tertiaryBackgroundPress",
  "tertiaryTextDefault",
  "tertiaryTextDisabled",
  "tertiaryTextHover",
  "tertiaryTextPress",
  "tertiaryBorderDefault",
  "tertiaryBorderDisabled",
  "tertiaryBorderHover",
  "tertiaryBorderPress",
  "tertiaryBorderWidthDefault",
] as const;
type buttonDarkValidKey = (typeof buttonDarkValidKeys)[number];

export type buttonDark = buttonDarkValidKey;

export const buttonDarkStyles = {
  borderRadiusDefault: "6px",
  primaryShadowDefault: "none",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundDefault: "#004cbe",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundDisabled: "#002c6e",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundHover: "#085bd7",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundPress: "#1a6ce7",
  primaryBorderDefault: "transparent",
  primaryBorderDisabled: "transparent",
  primaryBorderHover: "transparent",
  primaryBorderPress: "transparent",
  primaryBorderWidthDefault: "0px",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  primaryTextDefault: "#f1f7ff",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  primaryTextDisabled: "#085bd7",
  primaryTextHover: "#fbfbfb",
  primaryTextPress: "#fbfbfb",
  primaryCriticalShadowDefault: "none",
  primaryCriticalBackgroundDefault: "#d3132f",
  primaryCriticalBackgroundDisabled: "#ffd1dc",
  primaryCriticalBackgroundHover: "#bf0822",
  primaryCriticalBackgroundPress: "#a40319",
  primaryCriticalBorderDefault: "transparent",
  primaryCriticalBorderDisabled: "transparent",
  primaryCriticalBorderHover: "transparent",
  primaryCriticalBorderPress: "transparent",
  primaryCriticalBorderWidthDefault: "0px",
  primaryCriticalTextDefault: "#fff5f8",
  primaryCriticalTextDisabled: "#f76a86",
  primaryCriticalTextHover: "#fff5f8",
  primaryCriticalTextPress: "#fff5f8",
  secondaryShadowDefault: "none",
  /** A background primitive for components and surfaces on Level 2 (form control, cards). */
  secondaryBackgroundDefault: "#1e252f",
  /** A background primitive for components and surfaces on Level 1 (the page canvas). */
  secondaryBackgroundDisabled: "#191e24",
  /** A background primitive for components and surfaces on Level 2 (form control, cards). */
  secondaryBackgroundHover: "#1e252f",
  secondaryBackgroundPress: "#293246",
  /** For paragraph and any other primary text. */
  secondaryTextDefault: "#bdc4d5",
  /** For text that is disabled. This token does not need to pass WCAG contrast because disabled text is already not machine-readable. Please supplement with appropriate aria-label to meet accessibility guidelines. . */
  secondaryTextDisabled: "#5d6a85",
  /** For paragraph and any other primary text. */
  secondaryTextHover: "#bdc4d5",
  /** For paragraph and any other primary text. */
  secondaryTextPress: "#bdc4d5",
  secondaryBorderDefault: "#5d6a85",
  secondaryBorderDisabled: "#293246",
  secondaryBorderHover: "#8a96ad",
  secondaryBorderPress: "#5d6a85",
  secondaryBorderWidthDefault: "1px",
  tertiaryShadowDefault: "none",
  tertiaryBackgroundDefault: "transparent",
  tertiaryBackgroundDisabled: "transparent",
  /** A background primitive for components and surfaces on Level 2 (form control, cards). */
  tertiaryBackgroundHover: "#1e252f",
  tertiaryBackgroundPress: "#293246",
  /** For text that is set back or secondary. */
  tertiaryTextDefault: "#8a96ad",
  /** For text that is disabled. This token does not need to pass WCAG contrast because disabled text is already not machine-readable. Please supplement with appropriate aria-label to meet accessibility guidelines. . */
  tertiaryTextDisabled: "#5d6a85",
  /** For paragraph and any other primary text. */
  tertiaryTextHover: "#bdc4d5",
  /** For paragraph and any other primary text. */
  tertiaryTextPress: "#bdc4d5",
  tertiaryBorderDefault: "transparent",
  tertiaryBorderDisabled: "transparent",
  tertiaryBorderHover: "transparent",
  tertiaryBorderPress: "transparent",
  tertiaryBorderWidthDefault: "0px",
} as const satisfies Readonly<Record<buttonDark, string | number>>;

export type buttonDarkTypes = {
  borderRadiusDefault: string;
  primaryShadowDefault: string;
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundDefault: string;
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundDisabled: string;
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundHover: string;
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundPress: string;
  primaryBorderDefault: string;
  primaryBorderDisabled: string;
  primaryBorderHover: string;
  primaryBorderPress: string;
  primaryBorderWidthDefault: string;
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  primaryTextDefault: string;
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  primaryTextDisabled: string;
  primaryTextHover: string;
  primaryTextPress: string;
  primaryCriticalShadowDefault: string;
  primaryCriticalBackgroundDefault: string;
  primaryCriticalBackgroundDisabled: string;
  primaryCriticalBackgroundHover: string;
  primaryCriticalBackgroundPress: string;
  primaryCriticalBorderDefault: string;
  primaryCriticalBorderDisabled: string;
  primaryCriticalBorderHover: string;
  primaryCriticalBorderPress: string;
  primaryCriticalBorderWidthDefault: string;
  primaryCriticalTextDefault: string;
  primaryCriticalTextDisabled: string;
  primaryCriticalTextHover: string;
  primaryCriticalTextPress: string;
  secondaryShadowDefault: string;
  /** A background primitive for components and surfaces on Level 2 (form control, cards). */
  secondaryBackgroundDefault: string;
  /** A background primitive for components and surfaces on Level 1 (the page canvas). */
  secondaryBackgroundDisabled: string;
  /** A background primitive for components and surfaces on Level 2 (form control, cards). */
  secondaryBackgroundHover: string;
  secondaryBackgroundPress: string;
  /** For paragraph and any other primary text. */
  secondaryTextDefault: string;
  /** For text that is disabled. This token does not need to pass WCAG contrast because disabled text is already not machine-readable. Please supplement with appropriate aria-label to meet accessibility guidelines. . */
  secondaryTextDisabled: string;
  /** For paragraph and any other primary text. */
  secondaryTextHover: string;
  /** For paragraph and any other primary text. */
  secondaryTextPress: string;
  secondaryBorderDefault: string;
  secondaryBorderDisabled: string;
  secondaryBorderHover: string;
  secondaryBorderPress: string;
  secondaryBorderWidthDefault: string;
  tertiaryShadowDefault: string;
  tertiaryBackgroundDefault: string;
  tertiaryBackgroundDisabled: string;
  /** A background primitive for components and surfaces on Level 2 (form control, cards). */
  tertiaryBackgroundHover: string;
  tertiaryBackgroundPress: string;
  /** For text that is set back or secondary. */
  tertiaryTextDefault: string;
  /** For text that is disabled. This token does not need to pass WCAG contrast because disabled text is already not machine-readable. Please supplement with appropriate aria-label to meet accessibility guidelines. . */
  tertiaryTextDisabled: string;
  /** For paragraph and any other primary text. */
  tertiaryTextHover: string;
  /** For paragraph and any other primary text. */
  tertiaryTextPress: string;
  tertiaryBorderDefault: string;
  tertiaryBorderDisabled: string;
  tertiaryBorderHover: string;
  tertiaryBorderPress: string;
  tertiaryBorderWidthDefault: string;
};
