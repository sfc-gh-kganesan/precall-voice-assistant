/**
 * Do not edit directly, this file was auto-generated.
 */

export const filterLightColorKeys = [
  "activeBackgroundDefault",
  "activeBackgroundHover",
  "activeBackgroundActive",
  "activeTextColorDefault",
  "activeTextColorHover",
  "activeTextColorActive",
  "activeClearBackgroundDefault",
  "activeClearBackgroundHover",
  "activeClearBackgroundActive",
] as const;
export type filterLightColor = (typeof filterLightColorKeys)[number];

export const filterLightDimensionKeys = [] as const;
export type filterLightDimension = (typeof filterLightDimensionKeys)[number];

const filterLightValidKeys = [
  "activeBackgroundDefault",
  "activeBackgroundHover",
  "activeBackgroundActive",
  "activeTextColorDefault",
  "activeTextColorHover",
  "activeTextColorActive",
  "activeClearBackgroundDefault",
  "activeClearBackgroundHover",
  "activeClearBackgroundActive",
] as const;
type filterLightValidKey = (typeof filterLightValidKeys)[number];

export type filterLight = filterLightValidKey;

export const filterLightStyles = {
  activeBackgroundDefault: "#5d6a85",
  activeBackgroundHover: "#70819a",
  activeBackgroundActive: "#293246",
  activeTextColorDefault: "#fbfbfb",
  activeTextColorHover: "#fbfbfb",
  activeTextColorActive: "#fbfbfb",
  activeClearBackgroundDefault: "#5d6a85",
  activeClearBackgroundHover: "#293246",
  activeClearBackgroundActive: "#70819a",
} as const satisfies Readonly<Record<filterLight, string | number>>;

export type filterLightTypes = {
  activeBackgroundDefault: string;
  activeBackgroundHover: string;
  activeBackgroundActive: string;
  activeTextColorDefault: string;
  activeTextColorHover: string;
  activeTextColorActive: string;
  activeClearBackgroundDefault: string;
  activeClearBackgroundHover: string;
  activeClearBackgroundActive: string;
};
