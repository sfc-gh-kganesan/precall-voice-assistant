/**
 * Do not edit directly, this file was auto-generated.
 */

export const segmentedButtonLightColorKeys = [
  "rootBackgroundDefault",
  "selectedItemBackgroundDefault",
] as const;
export type segmentedButtonLightColor =
  (typeof segmentedButtonLightColorKeys)[number];

export const segmentedButtonLightDimensionKeys = [] as const;
export type segmentedButtonLightDimension =
  (typeof segmentedButtonLightDimensionKeys)[number];

const segmentedButtonLightValidKeys = [
  "rootBackgroundDefault",
  "selectedItemBackgroundDefault",
] as const;
type segmentedButtonLightValidKey =
  (typeof segmentedButtonLightValidKeys)[number];

export type segmentedButtonLight = segmentedButtonLightValidKey;

export const segmentedButtonLightStyles = {
  rootBackgroundDefault: "#f5f5f5",
  /** A background primitive for components and surfaces on Level 3 (temporary surfaces- dialogs, popovers, sidepanel, etc.). */
  selectedItemBackgroundDefault: "#fbfbfb",
} as const satisfies Readonly<Record<segmentedButtonLight, string | number>>;

export type segmentedButtonLightTypes = {
  rootBackgroundDefault: string;
  /** A background primitive for components and surfaces on Level 3 (temporary surfaces- dialogs, popovers, sidepanel, etc.). */
  selectedItemBackgroundDefault: string;
};
