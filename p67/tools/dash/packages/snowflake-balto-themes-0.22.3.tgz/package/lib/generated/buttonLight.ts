/**
 * Do not edit directly, this file was auto-generated.
 */

export const fieldLightColorKeys = [] as const;
export type fieldLightColor = (typeof fieldLightColorKeys)[number];

export const fieldLightDimensionKeys = ["borderRadiusDefault"] as const;
export type fieldLightDimension = (typeof fieldLightDimensionKeys)[number];

const fieldLightValidKeys = ["borderRadiusDefault"] as const;
type fieldLightValidKey = (typeof fieldLightValidKeys)[number];

export type fieldLight = fieldLightValidKey;

export const fieldLightStyles = {
  borderRadiusDefault: "6px",
} as const satisfies Readonly<Record<fieldLight, string | number>>;

export type fieldLightTypes = {
  borderRadiusDefault: string;
};
