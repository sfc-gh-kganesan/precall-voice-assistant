/**
 * Do not edit directly, this file was auto-generated.
 */

export const aiLoadingDarkColorKeys = [] as const;
export type aiLoadingDarkColor = (typeof aiLoadingDarkColorKeys)[number];

export const aiLoadingDarkDimensionKeys = ["aiLoadingBoxBorderWidth"] as const;
export type aiLoadingDarkDimension =
  (typeof aiLoadingDarkDimensionKeys)[number];

const aiLoadingDarkValidKeys = ["aiLoadingBoxBorderWidth"] as const;
type aiLoadingDarkValidKey = (typeof aiLoadingDarkValidKeys)[number];

export type aiLoadingDark = aiLoadingDarkValidKey;

export const aiLoadingDarkStyles = {
  /** This variable allows consumers of the AI Loading Box component to change the default width of 3px to 2px.. */
  aiLoadingBoxBorderWidth: 3,
} as const satisfies Readonly<Record<aiLoadingDark, string | number>>;

export type aiLoadingDarkTypes = {
  /** This variable allows consumers of the AI Loading Box component to change the default width of 3px to 2px.. */
  aiLoadingBoxBorderWidth: number;
};
