/**
 * Do not edit directly, this file was auto-generated.
 */

export const toolbarLightColorKeys = ["borderColorDefault"] as const;
export type toolbarLightColor = (typeof toolbarLightColorKeys)[number];

export const toolbarLightDimensionKeys = [
  "boxShadowDefault",
  "borderRadiusDefault",
] as const;
export type toolbarLightDimension = (typeof toolbarLightDimensionKeys)[number];

const toolbarLightValidKeys = [
  "boxShadowDefault",
  "borderColorDefault",
  "borderWidthDefault",
  "borderStyleDefault",
  "borderRadiusDefault",
] as const;
type toolbarLightValidKey = (typeof toolbarLightValidKeys)[number];

export type toolbarLight = toolbarLightValidKey;

export const toolbarLightStyles = {
  boxShadowDefault: "0px 2px 8px rgba(25, 30, 36, 0.15)",
  /** A contextless border primitive.. */
  borderColorDefault: "#d5dae4",
  borderWidthDefault: "1px",
  borderStyleDefault: "solid",
  borderRadiusDefault: "8px",
} as const satisfies Readonly<Record<toolbarLight, string | number>>;

export type toolbarLightTypes = {
  boxShadowDefault: string;
  /** A contextless border primitive.. */
  borderColorDefault: string;
  borderWidthDefault: string;
  borderStyleDefault: string;
  borderRadiusDefault: string;
};
