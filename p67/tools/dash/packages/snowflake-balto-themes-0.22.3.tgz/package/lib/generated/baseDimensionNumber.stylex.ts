/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const stylexVars = stylex.defineVars({
  textSmall: stylex.types.integer(12),
  textRegular: stylex.types.integer(14),
  textLarge: stylex.types.integer(16),
  textXlarge: stylex.types.integer(20),
  textXxlarge: stylex.types.integer(28),
  textXxxlarge: stylex.types.integer(40),
  spacing_0_25x: stylex.types.integer(2),
  spacing_0_5x: stylex.types.integer(4),
  spacing_0_75x: stylex.types.integer(6),
  spacing_1x: stylex.types.integer(8),
  spacing_1_5x: stylex.types.integer(12),
  spacing_2x: stylex.types.integer(16),
  spacing_2_5x: stylex.types.integer(20),
  spacing_3x: stylex.types.integer(24),
  spacing_4x: stylex.types.integer(32),
  spacing_5x: stylex.types.integer(40),
  spacing_6x: stylex.types.integer(48),
  spacing_8x: stylex.types.integer(64),
  radiusXsmall: stylex.types.integer(4),
  radiusSmall: stylex.types.integer(6),
  radiusMedium: stylex.types.integer(8),
  radiusLarge: stylex.types.integer(16),
  breakpointXsmall: stylex.types.integer(480),
  breakpointSmall: stylex.types.integer(720),
  breakpointMedium: stylex.types.integer(1024),
  breakpointLarge: stylex.types.integer(1360),
  breakpointXlarge: stylex.types.integer(1680),
});
