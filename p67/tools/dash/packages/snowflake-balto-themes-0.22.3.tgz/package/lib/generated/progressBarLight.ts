/**
 * Do not edit directly, this file was auto-generated.
 */

export const progressBarLightColorKeys = [
  "backgroundDefault",
  "filledDefault",
  "filledSuccess",
  "filledError",
] as const;
export type progressBarLightColor = (typeof progressBarLightColorKeys)[number];

export const progressBarLightDimensionKeys = [] as const;
export type progressBarLightDimension =
  (typeof progressBarLightDimensionKeys)[number];

const progressBarLightValidKeys = [
  "backgroundDefault",
  "filledDefault",
  "filledSuccess",
  "filledError",
] as const;
type progressBarLightValidKey = (typeof progressBarLightValidKeys)[number];

export type progressBarLight = progressBarLightValidKey;

export const progressBarLightStyles = {
  backgroundDefault: "#dee3ea",
  filledDefault: "#1a6ce7",
  filledSuccess: "#0e9c73",
  /** UI elements in an critical state- not necessarily accessible for text. */
  filledError: "#d3132f",
} as const satisfies Readonly<Record<progressBarLight, string | number>>;

export type progressBarLightTypes = {
  backgroundDefault: string;
  filledDefault: string;
  filledSuccess: string;
  /** UI elements in an critical state- not necessarily accessible for text. */
  filledError: string;
};
