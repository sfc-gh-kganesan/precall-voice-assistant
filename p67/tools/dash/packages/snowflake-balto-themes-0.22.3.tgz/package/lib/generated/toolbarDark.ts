/**
 * Do not edit directly, this file was auto-generated.
 */

export const toolbarDarkColorKeys = ["borderColorDefault"] as const;
export type toolbarDarkColor = (typeof toolbarDarkColorKeys)[number];

export const toolbarDarkDimensionKeys = [
  "boxShadowDefault",
  "borderRadiusDefault",
] as const;
export type toolbarDarkDimension = (typeof toolbarDarkDimensionKeys)[number];

const toolbarDarkValidKeys = [
  "boxShadowDefault",
  "borderColorDefault",
  "borderWidthDefault",
  "borderStyleDefault",
  "borderRadiusDefault",
] as const;
type toolbarDarkValidKey = (typeof toolbarDarkValidKeys)[number];

export type toolbarDark = toolbarDarkValidKey;

export const toolbarDarkStyles = {
  boxShadowDefault: "0px 2px 8px rgba(0, 0, 0, 0.25)",
  /** A contextless border primitive.. */
  borderColorDefault: "#293246",
  borderWidthDefault: "1px",
  borderStyleDefault: "solid",
  borderRadiusDefault: "8px",
} as const satisfies Readonly<Record<toolbarDark, string | number>>;

export type toolbarDarkTypes = {
  boxShadowDefault: string;
  /** A contextless border primitive.. */
  borderColorDefault: string;
  borderWidthDefault: string;
  borderStyleDefault: string;
  borderRadiusDefault: string;
};
