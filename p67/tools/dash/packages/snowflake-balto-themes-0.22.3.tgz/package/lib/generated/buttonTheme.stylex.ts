/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const buttonTheme = stylex.defineVars({
  borderRadiusDefault: "6px",
  primaryShadowDefault: "none",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundDefault: "#1a6ce7",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundDisabled: "#bbd6fe",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundHover: "#085bd7",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  primaryBackgroundPress: "#003e9a",
  primaryBorderDefault: "transparent",
  primaryBorderDisabled: "transparent",
  primaryBorderHover: "transparent",
  primaryBorderPress: "transparent",
  primaryBorderWidthDefault: "0px",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  primaryTextDefault: "#ffffff",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  primaryTextDisabled: "#5999f8",
  primaryTextHover: "#fbfbfb",
  primaryTextPress: "#fbfbfb",
  primaryCriticalShadowDefault: "none",
  primaryCriticalBackgroundDefault: "#d3132f",
  primaryCriticalBackgroundDisabled: "#ffd1dc",
  primaryCriticalBackgroundHover: "#bf0822",
  primaryCriticalBackgroundPress: "#a40319",
  primaryCriticalBorderDefault: "transparent",
  primaryCriticalBorderDisabled: "transparent",
  primaryCriticalBorderHover: "transparent",
  primaryCriticalBorderPress: "transparent",
  primaryCriticalBorderWidthDefault: "0px",
  primaryCriticalTextDefault: "#fff5f8",
  primaryCriticalTextDisabled: "#f76a86",
  primaryCriticalTextHover: "#fff5f8",
  primaryCriticalTextPress: "#fff5f8",
  secondaryShadowDefault: "none",
  /** A background primitive for components and surfaces on Level 2 (form control, cards). */
  secondaryBackgroundDefault: "#fbfbfb",
  /** A background primitive for components and surfaces on Level 1 (the page canvas). */
  secondaryBackgroundDisabled: "#ffffff",
  /** A background primitive for components and surfaces on Level 2 (form control, cards). */
  secondaryBackgroundHover: "#fbfbfb",
  secondaryBackgroundPress: "#dee3ea",
  secondaryBorderDefault: "#bdc4d5",
  secondaryBorderDisabled: "#dee3ea",
  secondaryBorderHover: "#9fabc1",
  secondaryBorderPress: "#9fabc1",
  secondaryBorderWidthDefault: "1px",
  /** For paragraph and any other primary text. */
  secondaryTextDefault: "#1e252f",
  /** For text that is disabled. This token does not need to pass WCAG contrast because disabled text is already not machine-readable. Please supplement with appropriate aria-label to meet accessibility guidelines. . */
  secondaryTextDisabled: "#9fabc1",
  /** For paragraph and any other primary text. */
  secondaryTextHover: "#1e252f",
  /** For paragraph and any other primary text. */
  secondaryTextPress: "#1e252f",
  tertiaryShadowDefault: "none",
  tertiaryBackgroundDefault: "transparent",
  tertiaryBackgroundDisabled: "transparent",
  /** For empty state backgrounds, disabled state backgrounds, etc. Not for text. . */
  tertiaryBackgroundHover: "#d5dae4",
  tertiaryBackgroundPress: "#bdc4d5",
  tertiaryBorderDefault: "transparent",
  tertiaryBorderDisabled: "transparent",
  tertiaryBorderHover: "transparent",
  tertiaryBorderPress: "transparent",
  tertiaryBorderWidthDefault: "0px",
  /** For text that is set back or secondary. */
  tertiaryTextDefault: "#5d6a85",
  /** For text that is disabled. This token does not need to pass WCAG contrast because disabled text is already not machine-readable. Please supplement with appropriate aria-label to meet accessibility guidelines. . */
  tertiaryTextDisabled: "#9fabc1",
  /** For paragraph and any other primary text. */
  tertiaryTextHover: "#1e252f",
  /** For paragraph and any other primary text. */
  tertiaryTextPress: "#1e252f",
});
