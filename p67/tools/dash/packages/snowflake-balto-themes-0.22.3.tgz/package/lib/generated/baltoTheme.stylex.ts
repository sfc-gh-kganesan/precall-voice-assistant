/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const baltoTheme = stylex.defineVars({
  fontFamilyBody:
    "Inter, Roboto, 'Helvetica Neue', 'Arial Nova', 'Nimbus Sans', Arial, sans-serif",
  fontFamilyMono:
    "'Apercu Mono Pro', ui-monospace, Menlo, Monaco, 'Cascadia Mono', 'Segoe UI Mono', 'Roboto Mono', 'Oxygen Mono', 'Ubuntu Monospace', 'Source Code Pro', 'Fira Mono', 'Droid Sans Mono', 'Courier New', monospace",
  fontFamilyEditorial:
    "Inter, Roboto, 'Helvetica Neue', 'Arial Nova', 'Nimbus Sans', Arial, sans-serif",
  fontFamilyHeading:
    "Inter, Roboto, 'Helvetica Neue', 'Arial Nova', 'Nimbus Sans', Arial, sans-serif",
  fontWeightRegular: stylex.types.integer(400),
  fontWeightMedium: stylex.types.integer(500),
  fontWeightSemiBold: stylex.types.integer(600),
  fontWeightBold: stylex.types.integer(700),
  fontSizeSmall: "12px",
  fontSizeRegular: "14px",
  fontSizeLarge: "16px",
  fontSizeXlarge: "20px",
  fontSizeXxlarge: "28px",
  fontSizeXxxlarge: "40px",
  lineHeightSmallSingleLine: "14px",
  lineHeightRegularSingleLine: "16px",
  lineHeightSmallBody: "18px",
  lineHeightRegularBody: "20px",
  lineHeightSubHeader: "20px",
  lineHeightPageHeader: "24px",
  lineHeightLargeEditorial: "34px",
  lineHeightLargerEditorial: "48px",
  /** A background primitive for components and surfaces on Level 1 (the page canvas). */
  surfaceLevel_1Background: "#ffffff",
  /** A border primitive for components and surfaces on Level 1 (the page canvas). */
  surfaceLevel_1Border: "#d5dae4",
  /** A background primitive for components and surfaces on Level 2 (form control, cards). */
  surfaceLevel_2Background: "#fbfbfb",
  /** A border primitive for components and surfaces on Level 2 (form control, cards). */
  surfaceLevel_2Border: "#d5dae4",
  /** A background primitive for components and surfaces on Level 3 (temporary surfaces- dialogs, popovers, sidepanel, etc.). */
  surfaceLevel_3Background: "#fbfbfb",
  /** A border primitive for components and surfaces on Level 3 (temporary surfaces- dialogs, popovers, sidepanel, etc.). */
  surfaceLevel_3Border: "#bdc4d5",
  elevation_1ShadowColor: "rgba(25, 30, 36, 0.1)",
  elevation_1ShadowBlur: "4px",
  elevation_1ShadowOfsetX: "0px",
  elevation_1ShadowOffsetY: "2px",
  elevation_1BoxShadow: "0px 2px 4px rgba(25, 30, 36, 0.1)",
  elevation_2ShadowColor: "rgba(25, 30, 36, 0.15)",
  elevation_2ShadowBlur: "8px",
  elevation_2ShadowOfsetX: "0px",
  elevation_2ShadowOffsetY: "2px",
  elevation_2BoxShadow: "0px 2px 8px rgba(25, 30, 36, 0.15)",
  elevation_3ShadowColor: "rgba(25, 30, 36, 0.2)",
  elevation_3ShadowBlur: "16px",
  elevation_3ShadowOfsetX: "0px",
  elevation_3ShadowOffsetY: "4px",
  elevation_3BoxShadow: "0px 4px 16px rgba(25, 30, 36, 0.2)",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  interactionPressableDefaultBackground: "#1a6ce7",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  interactionPressableDefaultContent: "#ffffff",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  interactionPressableHoveredBackground: "#085bd7",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  interactionPressablePressedBackground: "#003e9a",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. . */
  interactionPressableDisabledBackground: "#bbd6fe",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  interactionPressableDisabledContent: "#5999f8",
  chart_1: "#1a6ce7",
  chart_2: "#ecb700",
  chart_3: "#51caa5",
  chart_4: "#d3132f",
  chart_5: "#7157f4",
  chart_6: "#ff7c1d",
  chart_7: "#70ddff",
  chart_8: "#d45cff",
  chartDim_1: "#c6dbfd",
  chartDim_2: "#f5d791",
  chartDim_3: "#b0e5d1",
  chartDim_4: "#fccfcc",
  chartDim_5: "#d6d7ff",
  chartDim_6: "#ffd1b5",
  chartDim_7: "#96e5ff",
  chartDim_8: "#f3cdff",
  /** A contextless border primitive.. */
  reusableBorderDefault: "#d5dae4",
  /** A contextless border primitive for items that need more contrast. */
  reusableBorderBright: "#bdc4d5",
  /** A hover color for borders. */
  reusableBorderHover: "#9fabc1",
  /** A disabled color for borders. */
  reusableBorderDisabled: "#dee3ea",
  /** An active/selected color for borders. */
  reusableBorderActive: "#1a6ce7",
  /** A visual accessibility indicator for elements in keyboard focus. */
  reusableBorderFocusedActiveItem: "#d6e6ff",
  reusableBorderFocusedCriticalItem: "#ffd1dc",
  reusableBorderFocusedSuccessItem: "#51d9ae",
  reusableBorderFocusedWarningItem: "#ffedcd",
  /** For empty state backgrounds, disabled state backgrounds, etc. Not for text. . */
  reusableBackgroundNull: "#d5dae4",
  /** For an inset background on top of Level 2 and 3 surfaces. Appears. on code block backgrounds. Not for text. . */
  reusableBackgroundAdditionalInfo: "#f7f7f7",
  /** A row hover background color for cards, tables, etc.. */
  reusableBackgroundRowHover: "#eceef1",
  /** Knocked out UI/ to be used on content over items with Selected UI. */
  reusableBackgroundComponentSelectedKnockout: "#fbfbfb",
  /** For paragraph and any other primary text. */
  reusableTextPrimary: "#1e252f",
  /** For text that is set back or secondary. */
  reusableTextSecondary: "#5d6a85",
  /** For header text. */
  reusableTextHeader: "#1e252f",
  /** For hyperlinks. */
  reusableLinkDefault: "#1a6ce7",
  reusableLinkHover: "#004cbe",
  reusableLinkPress: "#003e9a",
  reusableLinkDisabled: "#86b6fc",
  /** An accessible color for text that appears over items with the Status Success Background token. */
  reusableLinkSuccessDefault: "#034237",
  /** An accessible color for text that appears over items with the Status Success Background token. */
  reusableLinkSuccessHover: "#001d11",
  /** An accessible color for text that appears over items with the Status Success Background token. */
  reusableLinkSuccessPress: "#000000",
  /** An accessible color for text that appears over items with the Status Success Background token. */
  reusableLinkSuccessDisabled: "#649c8e",
  /** An accessible color for text that appears over items with the Status Neutral Background token. */
  reusableLinkNeutralDefault: "#1e252f",
  /** An accessible color for text that appears over items with the Status Neutral Background token. */
  reusableLinkNeutralHover: "#000005",
  /** An accessible color for text that appears over items with the Status Neutral Background token. */
  reusableLinkNeutralPress: "#000000",
  /** An accessible color for text that appears over items with the Status Neutral Background token. */
  reusableLinkNeutralDisabled: "#717985",
  /** An accessible color for text that appears over items with the Status Critical Background token. */
  reusableLinkCriticalDefault: "#66000e",
  /** An accessible color for text that appears over items with the Status Critical Background token. */
  reusableLinkCriticalHover: "#3b0000",
  /** An accessible color for text that appears over items with the Status Critical Background token. */
  reusableLinkCriticalPress: "#290000",
  /** An accessible color for text that appears over items with the Status Critical Background token. */
  reusableLinkCriticalDisabled: "#cf655e",
  /** An accessible color for text that appears over items with the Status Caution Background token. */
  reusableLinkCautionDefault: "#653e03",
  /** An accessible color for text that appears over items with the Status Caution Background token. */
  reusableLinkCautionHover: "#3a1700",
  /** An accessible color for text that appears over items with the Status Caution Background token. */
  reusableLinkCautionPress: "#230000",
  /** An accessible color for text that appears over items with the Status Caution Background token. */
  reusableLinkCautionDisabled: "#ca965b",
  /** An accessible color for text that appears over items with the Status Info Background token. */
  reusableLinkInfoDefault: "#002c6e",
  /** An accessible color for text that appears over items with the Status Info Background token. */
  reusableLinkInfoHover: "#000142",
  /** An accessible color for text that appears over items with the Status Info Background token. */
  reusableLinkInfoPress: "#00001e",
  /** An accessible color for text that appears over items with the Status Info Background token. */
  reusableLinkInfoDisabled: "#7380ce",
  /** For icons on their own, not next to text. Icons next to text should inherit the text color token.. */
  reusableIconDefault: "#5d6a85",
  /** A slightly set back color for icons on their own. Icons next to text should inherit the text color token.. */
  reusableIconSubtle: "#bdc4d5",
  /** A primitive for selected text that is NOT on a blue background. */
  reusableSelectedText: "#085bd7",
  /** A primitive for backgrounds that are selected. */
  reusableSelectedBackground: "#d6e6ff",
  /** Selected UI that&#39;s not text- checkbox backgrounds, radio backgrounds, switches. */
  reusableSelectedUi: "#085bd7",
  /** A primitive for selected-hovered text that is NOT on a blue background. */
  reusableSelectedHoveredText: "#004cbe",
  /** A primitive for backgrounds that are selected- hovered state. */
  reusableSelectedHoveredBackground: "#bbd6fe",
  /** Selected hovered UI that&#39;s not text- checkbox backgrounds, radio backgrounds, switches. */
  reusableSelectedHoveredUi: "#1a6ce7",
  /** For text that is disabled. This token does not need to pass WCAG contrast because disabled text is already not machine-readable. Please supplement with appropriate aria-label to meet accessibility guidelines. . */
  reusableDisabledText: "#9fabc1",
  /** A color for status text that appears on any background color. Accessible on Level 1-3 bgs. . */
  statusCriticalMessageText: "#d3132f",
  /** An accessible color for text that appears over items with the Status Critical Background token. */
  statusCriticalText: "#66000e",
  /** Background color for 
critical (error, delete) states . */
  statusCriticalBackground: "#ffd1dc",
  /** UI elements in an critical state- not necessarily accessible for text. */
  statusCriticalUi: "#d3132f",
  statusCriticalChart: "#ef405e",
  statusCriticalChartDim: "#ffced0",
  /** A color for status text that appears on any background color. Accessible on Level 1-3 bgs. . */
  statusCautionMessageText: "#653e03",
  /** An accessible color for text that appears over items with the Status Caution Background token. */
  statusCautionText: "#653e03",
  /** Background color for 
caution (warning) states. */
  statusCautionBackground: "#ffedcd",
  /** UI elements in a caution state- not necessarily accessible for text. */
  statusCautionUi: "#f3be0f",
  statusCautionChart: "#f8c52a",
  statusCautionChartDim: "#fad67b",
  /** A color for status text that appears on any background color. Accessible on Level 1-3 bgs. . */
  statusSuccessMessageText: "#087959",
  /** An accessible color for text that appears over items with the Status Success Background token. */
  statusSuccessText: "#034237",
  /** Background color for 
success states . */
  statusSuccessBackground: "#bdf8e9",
  /** UI elements in a success state- not necessarily accessible for text. */
  statusSuccessUi: "#0e9c73",
  statusSuccessChart: "#51d9ae",
  statusSuccessChartDim: "#a0e9cd",
  /** A color for status text that appears on any background color. Accessible on Level 1-3 bgs. . */
  statusInfoMessageText: "#085bd7",
  /** An accessible color for text that appears over items with the Status Info Background token. */
  statusInfoText: "#002c6e",
  /** Background for info states. */
  statusInfoBackground: "#d6e6ff",
  /** UI elements in an info state- not necessarily accessible for text. */
  statusInfoUi: "#1a6ce7",
  statusInfoChart: "#3580f2",
  statusInfoChartDim: "#c5dcff",
  /** A color for status text that appears on any background color. Accessible on Level 1-3 bgs. . */
  statusNeutralMessageText: "#1e252f",
  /** An accessible color for text that appears over items with the Status Neutral Background token. */
  statusNeutralText: "#1e252f",
  /** Background color for 
neutral status states. */
  statusNeutralBackground: "#eceef1",
  /** UI elements in a neutral status state- not necessarily accessible for text. */
  statusNeutralUi: "#bdc4d5",
  statusNeutralChart: "#bdc4d5",
  statusNeutralChartDim: "#d5dae5",
  statusActiveChart: "#5d6a85",
  statusActiveChartDim: "#d6dae1",
  componentRangeSliderTrackBackgroundDefault: "#dee3ea",
  componentRangeSliderRangeBackgroundLeft: "#86b6fc",
  componentRangeSliderRangeBackgroundRight: "#3580f2",
  componentRangeSliderRangeBackgroundDisabled: "#dee3ea",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  componentRangeSliderThumbBackgroundDefault: "#ffffff",
  componentRangeSliderThumbBackgroundDisabled: "#d5dae4",
  componentRangeSliderThumbBorderDefault: "#d5dae4",
  componentRangeSliderThumbBorderDisabled: "#d5dae4",
  /** A primitive for anything &quot;pressable&quot; ie. with a hover, press, disabled state. Content is for text and icons appearing over the pressable bg.. */
  componentRangeSliderStepBackgroundDefault: "#ffffff",
  componentRangeSliderStepBackgroundDisabled: "#d5dae4",
  /** A border primitive for components and surfaces on Level 3 (temporary surfaces- dialogs, popovers, sidepanel, etc.). */
  componentRangeSliderStepBorderDefault: "#bdc4d5",
  componentRangeSliderStepBorderDisabled: "#d5dae4",
  componentDialogOverlay: "rgba(0, 0, 0, 0.2)",
  componentStatusPillActiveBackground: "#5d6a85",
  componentStatusPillActiveText: "#fbfbfb",
  componentPreviewBadgeDefaultText: "#191e24",
  componentPreviewBadgeDefaultBackground: "#dee3ea",
  componentPreviewBadgeHoveredText: "#191e24",
  componentPreviewBadgeHoveredBackground: "#d5dae4",
  componentPreviewBadgePressedText: "#191e24",
  componentPreviewBadgePressedBackground: "#bdc4d5",
  componentPreviewBadgeDisabledText: "#191e24",
  componentPreviewBadgeDisabledBackground: "#dee3ea",
  componentScrollbarThumb: "#dee3ea",
  componentFormControlBorderDefault: "#bdc4d5",
  componentFormControlBorderHover: "#9fabc1",
  componentFormControlBorderPress: "#9fabc1",
  componentFormControlBorderActive: "#1a6ce7",
  componentFormControlBorderDisabled: "#dee3ea",
  componentFormControlBorderCritical: "#d3132f",
  componentFormControlBorderCaution: "#f3be0f",
  componentFormControlBorderSuccess: "#0e9c73",
  componentFormControlBackgroundDefault: "#fbfbfb",
  componentFormControlBackgroundDisabled: "#eceef1",
  componentFormControlBackgroundUnselected: "#d5dae4",
  componentFormControlBackgroundSelectedDefault: "#1a6ce7",
  componentFormControlBackgroundSelectedHover: "#085bd7",
  componentFormControlBackgroundSelectedDisabled: "#bbd6fe",
  componentFormControlKnobDefault: "#fbfbfb",
  componentFormControlKnobDisabled: "#ffffff",
  componentFormControlKnobSelectedDisabled: "#ffffff",
  componentFormControlHelperTextDefault: "#5d6a85",
  componentFormControlHelperTextCritical: "#d3132f",
  componentFormControlHelperTextCaution: "#653e03",
  /** For code editors. */
  codeErroredBackground: "#ffd1dc",
  /** For code editors. */
  codeExecutedBackground: "#d6e6ff",
  /** For code editors. */
  codeLineNumberDefaultText: "#5d6a85",
  /** For code editors. */
  codeLineNumberActiveText: "#191e24",
  /** For code editors. */
  codeCommentText: "#5d6a85",
  /** For code editors. */
  codeSearchFocusedText: "#0f161e",
  /** For code editors. */
  codeSearchFocusedBackground: "#ffc49a",
  /** For code editors. */
  codeSearchHighlightedText: "#0f161e",
  /** For code editors. */
  codeSearchHighlightedBackground: "#ffedcd",
  /** For code editors. */
  codeSqlKeywordText: "#085bd7",
  /** For code editors. */
  codeSqlSystemFunctionText: "#087959",
  /** For code editors. */
  codeSqlEditorTextNameText: "#191e24",
  /** For code editors. */
  codeSqlStringText: "#860112",
  /** For code editors. */
  codeSqlTypeText: "#653e03",
  /** For code editors. */
  codePythonControlKeywordText: "#653e03",
  /** For code editors. */
  codePythonVariableNameText: "#002c6e",
  /** For code editors. */
  codePythonKeywordText: "#9712e8",
  /** For code editors. */
  codePythonFunctionOrVariableNameText: "#b67901",
  codePythonNumberText: "#087959",
  /** For code editors. */
  codePythonSpecialText: "#bf0822",
  /** For code editors. */
  codePythonTypeNameText: "#087959",
  /** For the large layout side panels on Worksheets ONLY. */
  productAreasWorksheetsPanelBackground: "#f7f7f7",
  /** For icons on tabs on the Worksheets page ONLY. */
  productAreasWorksheetsTabActionIconColor: "#5d6a85",
  /** For hovered icons on tabs on the Worksheets page ONLY. */
  productAreasWorksheetsTabActionHoverBackground: "#d5dae4",
  /** For pressed icons on tabs on the Worksheets page ONLY. */
  productAreasWorksheetsTabActionPressedBackground: "#bdc4d5",
  /** For the gradient at the end of  the tabs section on the Worksheets page ONLY. */
  productAreasWorksheetsTabOverflowGradient: "#ffffff",
  /** For the background behind Worksheets tabs ONLY. */
  productAreasWorksheetsTabAreaBackground: "#ffffff",
  /** For the active tab on the Worksheets page ONLY. */
  productAreasWorksheetsTabActiveBorder: "#d5dae4",
  /** For the active tab on the Worksheets page ONLY. */
  productAreasWorksheetsTabActiveBackground: "#f7f7f7",
  /** For the inactive tab on the Worksheets page ONLY. */
  productAreasWorksheetsTabInactiveBackground: "#eceef1",
  /** A background for cards on the Worksheets page ONLY. */
  productAreasWorksheetsCardBackgroundRegular: "#fbfbfb",
  /** A hovered background for cards on the Worksheets page ONLY. */
  productAreasWorksheetsCardBackgroundHover: "#ffffff",
  /** For listing cards on the Marketplace ONLY. */
  productAreasDmxListingCardBgHover: "#f7f7f7",
});
