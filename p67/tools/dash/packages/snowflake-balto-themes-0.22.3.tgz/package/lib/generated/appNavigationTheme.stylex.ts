/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";

export const appNavigationTheme = stylex.defineVars({
  itemBackgroundHover: "#dee3ea",
  sidebarBackgroundDefault: "#f7f7f7",
});
