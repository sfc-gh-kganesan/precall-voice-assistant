/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { aiLoadingTheme as styleVars } from "./aiLoadingTheme.stylex.js";

export const aiLoadingDark = stylex.createTheme(styleVars, {
  aiLoadingBoxBorderWidth: stylex.types.integer(3),
});
