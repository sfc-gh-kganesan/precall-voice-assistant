/**
 * Do not edit directly, this file was auto-generated.
 */

export const skeletonDarkColorKeys = [
  "shimmerStartDefault",
  "shimmerEndDefault",
] as const;
export type skeletonDarkColor = (typeof skeletonDarkColorKeys)[number];

export const skeletonDarkDimensionKeys = [] as const;
export type skeletonDarkDimension = (typeof skeletonDarkDimensionKeys)[number];

const skeletonDarkValidKeys = [
  "shimmerStartDefault",
  "shimmerEndDefault",
] as const;
type skeletonDarkValidKey = (typeof skeletonDarkValidKeys)[number];

export type skeletonDark = skeletonDarkValidKey;

export const skeletonDarkStyles = {
  shimmerStartDefault: "#293246",
  shimmerEndDefault: "#1e252f",
} as const satisfies Readonly<Record<skeletonDark, string | number>>;

export type skeletonDarkTypes = {
  shimmerStartDefault: string;
  shimmerEndDefault: string;
};
