/**
 * Do not edit directly, this file was auto-generated.
 */

export const skeletonLightColorKeys = [
  "shimmerStartDefault",
  "shimmerEndDefault",
] as const;
export type skeletonLightColor = (typeof skeletonLightColorKeys)[number];

export const skeletonLightDimensionKeys = [] as const;
export type skeletonLightDimension =
  (typeof skeletonLightDimensionKeys)[number];

const skeletonLightValidKeys = [
  "shimmerStartDefault",
  "shimmerEndDefault",
] as const;
type skeletonLightValidKey = (typeof skeletonLightValidKeys)[number];

export type skeletonLight = skeletonLightValidKey;

export const skeletonLightStyles = {
  shimmerStartDefault: "#dee3ea",
  shimmerEndDefault: "#d5dae4",
} as const satisfies Readonly<Record<skeletonLight, string | number>>;

export type skeletonLightTypes = {
  shimmerStartDefault: string;
  shimmerEndDefault: string;
};
