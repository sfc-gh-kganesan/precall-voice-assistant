/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { appNavigationTheme as styleVars } from "./appNavigationTheme.stylex.js";

export const appNavigationLight = stylex.createTheme(styleVars, {
  itemBackgroundHover: "#dee3ea",
  sidebarBackgroundDefault: "#f7f7f7",
});
