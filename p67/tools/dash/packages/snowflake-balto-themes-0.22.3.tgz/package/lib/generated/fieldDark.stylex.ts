/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { fieldTheme as styleVars } from "./fieldTheme.stylex.js";

export const fieldDark = stylex.createTheme(styleVars, {
  borderRadiusDefault: "6px",
});
