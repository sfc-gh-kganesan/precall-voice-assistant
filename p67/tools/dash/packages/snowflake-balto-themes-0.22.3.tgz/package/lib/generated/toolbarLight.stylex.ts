/**
 * Do not edit directly, this file was auto-generated.
 */

import * as stylex from "@stylexjs/stylex";
import { toolbarTheme as styleVars } from "./toolbarTheme.stylex.js";

export const toolbarLight = stylex.createTheme(styleVars, {
  boxShadowDefault: "0px 2px 8px rgba(25, 30, 36, 0.15)",
  borderColorDefault: "#d5dae4",
  borderWidthDefault: "1px",
  borderStyleDefault: "solid",
  borderRadiusDefault: "8px",
});
